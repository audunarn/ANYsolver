"""Headless runtime meshing and analysis facade for ANYsolver.

The module accepts normalized geometry dictionaries and contains no
ANYstructure imports or GUI dependencies.  Application integrations map their
own model state into this contract before invoking the solver.
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields
import collections
from contextlib import ExitStack
import hashlib
import json
import math
import os
import re
import threading
import time
from types import ModuleType
from typing import Callable, Mapping, Sequence, TypeAlias

import numpy as np

import anysolver as _full_backend
from .e4_pl_element import (
    QualifiedE4PLShellElement as _QualifiedE4PLShellElement,
    _q4_trusted_operation_scope as _Q4_TRUSTED_OPERATION_SCOPE,
)
from .e4_pl_s3_element import (
    QualifiedE4PLS3ShellElement as _QualifiedE4PLS3ShellElement,
    _s3_trusted_operation_scope as _S3_TRUSTED_OPERATION_SCOPE,
)
from .analysis_session import AnalysisSession as _backend_AnalysisSession
from .arc_length import ArcLengthControl as _backend_arc_length_control
from .arc_length import solve_static_arc_length as _backend_solve_static_arc_length
from .assembly import compute_stresses as _backend_compute_stresses
from .assembly import solve_linear as _backend_solve_linear
from .buckling import solve_eigenvalue_buckling as _backend_solve_buckling
from .contact import NonlinearTransientConfig as _backend_NonlinearTransientConfig
from .contact import RigidSphereImpact as _backend_RigidSphereImpact
from .contact import SphereContactConfig as _backend_SphereContactConfig
from .contact import solve_transient_sphere_impact as _backend_solve_transient_sphere_impact
from .dynamics import TransientConfig as _backend_TransientConfig
from .dynamics import solve_transient_newmark as _backend_solve_transient_newmark
from .fracture import FractureConfig as _backend_FractureConfig
from .fracture import ImpactDamageConfig as _backend_ImpactDamageConfig
from .fracture import PlasticImpactDamageConfig as _backend_PlasticImpactDamageConfig
from .kernel_warmup import warm_fe_solver_kernels as _backend_warm_fe_solver_kernels
from .material_curves import curve_from_properties as _backend_curve_from_properties
from .material_curves import dnv_c208_steel_properties as _material_dnv_c208_steel_properties
from .nonlinear import solve_nonlinear_load_stepping as _backend_solve_nonlinear_limit
from .nonlinear_static import solve_static_nonlinear as _backend_solve_static_nonlinear
from .recovery import recover_stress_result as _recover_stress_result
from .validation import load_case_resultant as _backend_load_case_resultant
from .validation import load_vector_resultant as _backend_load_vector_resultant


StatusCallback: TypeAlias = Callable[[str], None]
NormalizedGeometry: TypeAlias = Mapping[str, object]
GeneratedGeometry: TypeAlias = dict[str, object]

__all__ = [
    "GeneratedGeometry",
    "LightweightFEMConfig",
    "LightweightFEMResult",
    "NormalizedGeometry",
    "RuntimeAnalysisSelection",
    "RuntimeAnalysisContext",
    "StatusCallback",
    "apply_mode_shape_imperfections",
    "build_generated_geometry",
    "dnv_c208_steel_properties",
    "full_backend_api",
    "full_backend_available",
    "run_lightweight_fem",
    "run_production_fem",
    "resolve_runtime_analysis",
    "runtime_imperfection_preview_offsets",
    "warm_fe_solver_kernels",
]


@dataclass(frozen=True)
class LightweightFEMConfig:
    """Runtime options for the local lightweight solver."""

    mesh_fidelity: str = "coarse"
    pressure_pa: float = 0.0
    load_scale: float = 1.0
    include_stiffeners: bool = True
    include_girders: bool = True
    include_end_lids: bool = False
    num_buckling_modes: int = 5
    mesh_size_m: float = 0.0
    top_bottom_moment_nm: float = 0.0
    acceleration_x_m_s2: float = 0.0
    acceleration_y_m_s2: float = 0.0
    acceleration_z_m_s2: float = 0.0
    added_mass_kg: float = 0.0
    added_mass_location: str = "none"
    boundary_condition: str = "auto"
    # Per-DOF boundary model (new BC tab).  ``boundary_constraint_json`` is a
    # JSON object of the DOFs constrained on the WHOLE boundary, each mapped to
    # its enforced value, e.g. {"uz": 0.0, "rx": 0.0, "ux": 0.001}.  Empty +
    # boundary_auto_supports=True keeps the automatic well-posed supports;
    # empty + auto off means a free boundary.  Enforced (nonzero) values apply
    # to every run.  Selected-edge per-DOF constraints live in
    # custom_bc_segments_json (each segment carries a "constraints" dict).
    boundary_constraint_json: str = "{}"
    boundary_auto_supports: bool = True
    symmetry_mode: str = "none"
    shell_element_order: str = "S4"
    beam_element_order: str = "B2"
    member_model: str = "plates as shell, girders as beams"
    analysis_type: str = "linear eigenvalue"
    buckling_analysis_type: str = "linear eigenvalue"
    pressure_direction: str = "front"
    axial_force_n: float = 0.0
    torsional_moment_nm: float = 0.0
    shear_force_n: float = 0.0
    enforced_displacement_x_m: float = 0.0
    enforced_displacement_y_m: float = 0.0
    enforced_displacement_z_m: float = 0.0
    stiffener_eccentricity_m: float = 0.0
    girder_eccentricity_m: float = 0.0
    member_orientation: str = "auto"
    solver_type: str = "direct"
    stress_percentile: float = 95.0
    elastic_modulus_pa: float = 210.0e9
    poisson_ratio: float = 0.3
    yield_stress_pa: float = 355.0e6
    material_model: str = "linear elastic"
    steel_grade: str = "S355"
    steel_thickness_class: str = "auto"
    nonlinear_max_load_factor: float = 3.0
    nonlinear_steps: int = 12
    nonlinear_max_iterations: int = 25
    nonlinear_tolerance: float = 1.0e-6
    nonlinear_layers: int = 5
    nonlinear_solution_control: str = "newton force control"
    nonlinear_convergence_profile: str = "auto"
    nonlinear_assembly_threads: int = 0
    nonlinear_static_kinematics: str = "von_karman"
    post_buckling_enabled: bool = False
    post_buckling_stop_load_fraction: float = 0.5
    post_buckling_max_displacement_m: float = 0.0
    beam_consistent_mass_enabled: bool = False
    custom_load_bc_enabled: bool = False
    custom_loads_add_to_imported: bool = False
    custom_use_nullspace_projection: bool = True
    custom_pressure_pa: float = 0.0
    plate_edge_x0_support: str = "free"
    plate_edge_x1_support: str = "free"
    plate_edge_y0_support: str = "free"
    plate_edge_y1_support: str = "free"
    cylinder_lower_support: str = "free"
    cylinder_upper_support: str = "free"
    plate_edge_x0_load_n_per_m: float = 0.0
    plate_edge_x1_load_n_per_m: float = 0.0
    plate_edge_y0_load_n_per_m: float = 0.0
    plate_edge_y1_load_n_per_m: float = 0.0
    cylinder_lower_edge_load_n_per_m: float = 0.0
    cylinder_upper_edge_load_n_per_m: float = 0.0
    # Component edge loads: {"fx","fy","fz" [N/m], "mx","my","mz" [Nm/m]}
    # entered on global axes with no implicit sign conventions.  The whole-edge
    # payload maps edge keys (x0/x1/y0/y1, lower/upper, all) to component sets.
    edge_load_components_json: str = ""
    custom_loads_json: str = "[]"
    custom_pressure_patches_json: str = "[]"
    custom_edge_segments_json: str = "[]"
    custom_selected_edge_load_n_per_m: float = 0.0
    custom_selected_edge_load_components_json: str = ""
    local_refinement_enabled: bool = False
    local_refinement_patches_json: str = "[]"
    local_refinement_fine_factor: float = 0.3
    local_refinement_fine_size_m: float = 0.0
    local_refinement_extent_m: float = 0.0
    local_refinement_zone_factor: float = 1.0
    local_refinement_growth_factor: float = 1.35
    point_refinement_enabled: bool = False
    point_refinement_x_m: float = 0.0
    point_refinement_y_m: float = 0.0
    point_refinement_fine_factor: float = 0.3
    point_refinement_fine_size_m: float = 0.0
    point_refinement_extent_m: float = 0.25
    point_refinement_growth_factor: float = 1.35
    custom_time_domain_enabled: bool = False
    custom_time_domain_duration_s: float = 0.01
    custom_time_domain_total_time_s: float = 0.05
    custom_time_domain_dt_s: float = 0.0005
    custom_time_domain_result_interval_s: float = 0.0
    custom_time_domain_include_static_load: bool = False
    imperfection_enabled: bool = False
    imperfection_shape: str = "standard plate/cylinder"
    imperfection_amplitude_m: float = 0.0
    imperfection_wave_a: int = 1
    imperfection_wave_b: int = 1
    imperfection_mode_shapes_json: str = "[]"
    runtime_solver: str = "stepwise"
    allow_unbalanced_free_free: bool = False
    buckling_shift_load_factor: float = 0.0
    buckling_min_load_factor: float = 0.0
    buckling_max_load_factor: float = 0.0
    buckling_repeated_tolerance: float = 1.0e-3
    buckling_allow_dense_fallback: bool = False
    recovery_history_mode: str = "full"
    recovery_threads: int = 0
    memory_limit_mb: float = 0.0
    capacity_buckling_mode_number: int = 1
    capacity_mesh_min_elements_per_half_wave: int = 4
    fracture_enabled: bool = False
    fracture_strain_threshold: float = 0.02
    fracture_residual_stiffness_fraction: float = 1.0e-6
    fracture_max_deleted_fraction: float = 0.25
    fracture_min_load_factor: float = 0.0
    collision_enabled: bool = False
    collision_include_static_load: bool = False
    collision_damage_enabled: bool = True
    collision_material_nonlinear_enabled: bool = False
    collision_nonlinear_kinematics: str = "von_karman"
    collision_beam_contact_enabled: bool = False
    collision_nonlinear_max_iterations: int = 20
    collision_nonlinear_tolerance: float = 1.0e-6
    collision_nonlinear_cutbacks: int = 8
    collision_plastic_damage_threshold: float = 0.01
    collision_damage_criterion: str = "rtcl"
    collision_mass_kg: float = 1000.0
    collision_radius_m: float = 0.25
    collision_start_x_m: float = 0.0
    collision_start_y_m: float = 0.0
    collision_start_z_m: float = 1.0
    collision_vector_x: float = 0.0
    collision_vector_y: float = 0.0
    collision_vector_z: float = -1.0
    collision_speed_mps: float = 5.0
    collision_adaptive_mesh_enabled: bool = False
    collision_adaptive_fine_factor: float = 0.3
    collision_adaptive_fine_size_m: float = 0.0
    collision_adaptive_extent_m: float = 0.0
    collision_adaptive_growth_factor: float = 1.35
    collision_adaptive_zone_factor: float = 2.5
    detail_transition_style: str = "graded grid"
    custom_bc_segments_json: str = "[]"
    thickness_regions_json: str = "[]"
    collision_time_mode: str = "auto"
    collision_auto_steps_per_radius: float = 20.0
    collision_auto_post_contact_radii: float = 6.0
    collision_bounce_back_time_s: float = 0.01
    collision_total_time_s: float = 0.05
    collision_dt_s: float = 0.0005
    collision_result_interval_s: float = 0.0
    collision_penalty_stiffness_n_per_m: float = 0.0
    # Multiplies the auto contact penalty (ignored when a manual penalty is
    # set).  The scout preconditioner writes this; a user can also set it
    # directly to soften/stiffen contact.
    collision_penalty_scale: float = 1.0
    # Optional two-phase mode: run a cheap coarse "scout" collision first to
    # learn a convergence-achievable contact penalty, then apply it to the
    # real (fine) run.  See _collision_precondition_scout.
    collision_auto_precondition: bool = False
    collision_contact_damping: float = 0.0
    collision_max_iterations: int = 25
    collision_penetration_tolerance_m: float = 1.0e-8
    collision_force_tolerance_n: float = 1.0e-6
    collision_target_penetration_fraction: float = 0.01
    collision_max_event_substeps: int = 16
    collision_contact_surface: str = "midsurface"
    collision_damage_mode: str = "accumulated_damage"
    collision_damage_capacity_basis: str = "yield"
    collision_damage_user_capacity_pa: float = 0.0
    collision_damage_softening_start: float = 0.6
    collision_damage_delete_at: float = 1.0
    collision_damage_min_contact_area_m2: float = 1.0e-6
    collision_damage_max_deleted_fraction: float = 0.25
    collision_damage_neighbor_smoothing: bool = False
    # Added at the end to preserve the positional field order of the 0.1.x
    # configuration contract. New callers should prefer keyword arguments.
    follower_pressure: bool = False


@dataclass(frozen=True)
class RuntimeAnalysisSelection:
    """Effective analysis choices shared with application integrations."""

    static_nonlinear: bool
    material_nonlinear: bool
    solution_control: str
    kinematics: str


@dataclass(frozen=True)
class LightweightFEMResult:
    """Result contract returned to headless callers and application adapters."""

    status: str
    stress_max_pa: float
    stress_p95_pa: float
    displacement_max_m: float
    buckling_factors: tuple[float, ...] = field(default_factory=tuple)
    buckling_modes: list = field(default_factory=list)
    diagnostics: tuple[str, ...] = field(default_factory=tuple)
    mesh_info: dict[str, int] = field(default_factory=dict)
    prestress_summary: dict[str, float] = field(default_factory=dict)
    load_resultant: dict[str, tuple[float, float, float]] = field(default_factory=dict)
    visualization: dict[str, object] = field(default_factory=dict)
    solver_name: str = "ANYsolver lightweight"


_RUNTIME_CONTEXT_STRUCTURAL_REVISIONS = (
    "topology",
    "geometry",
    "material",
    "boundary",
    "mpc",
    "activity",
    "mass",
)

_RUNTIME_CONTEXT_LOAD_ONLY_FIELDS = frozenset(
    {
        "pressure_pa",
        "load_scale",
        "pressure_direction",
        "axial_force_n",
        "torsional_moment_nm",
        "shear_force_n",
        "top_bottom_moment_nm",
        "plate_edge_x0_load_n_per_m",
        "plate_edge_x1_load_n_per_m",
        "plate_edge_y0_load_n_per_m",
        "plate_edge_y1_load_n_per_m",
        "cylinder_lower_edge_load_n_per_m",
        "cylinder_upper_edge_load_n_per_m",
        "edge_load_components_json",
        "custom_loads_json",
        "custom_pressure_pa",
        "custom_pressure_patches_json",
        "custom_selected_edge_load_n_per_m",
        "custom_selected_edge_load_components_json",
        "stress_percentile",
        "recovery_history_mode",
        "recovery_threads",
        "memory_limit_mb",
        "solver_type",
        "runtime_solver",
        "analysis_type",
        "buckling_analysis_type",
        "num_buckling_modes",
    }
)


def _runtime_context_json_default(value: object) -> object:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, (set, frozenset, tuple)):
        return list(value)
    raise TypeError(f"unsupported runtime-context value: {type(value).__name__}")


def _runtime_context_key(
    generated_geometry: GeneratedGeometry,
    config: LightweightFEMConfig,
    material_properties: Mapping[str, object] | None,
) -> str:
    structural_config = {
        item.name: getattr(config, item.name)
        for item in fields(config)
        if item.name not in _RUNTIME_CONTEXT_LOAD_ONLY_FIELDS
    }
    payload = {
        "schema": "ANYSOLVER_RUNTIME_ANALYSIS_CONTEXT_V1",
        "geometry": generated_geometry,
        "structural_config": structural_config,
        "material_properties": dict(material_properties or {}),
    }
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
        default=_runtime_context_json_default,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _runtime_context_eligible(
    config: LightweightFEMConfig,
    geometry: Mapping[str, object] | None = None,
) -> bool:
    runtime_choice = _normalized_choice(config.runtime_solver, "stepwise")
    reference_elastic_spectral = _can_reuse_linear_buckling_session(config)
    # The cylinder lid gauge is intentionally installed only for the
    # buckling phase.  Until it has a separate immutable constraint owner, do
    # not retain that phase-mutated model across analyses.
    cylinder_gauge_mutation = bool(
        reference_elastic_spectral
        and config.include_end_lids
        and str((geometry or {}).get("geometry", "")).strip().lower()
        == "cylinder"
    )
    return bool(
        (runtime_choice == "static only" or reference_elastic_spectral)
        and not cylinder_gauge_mutation
        and not _wants_static_nonlinear_analysis(config)
        and not _wants_capacity_workflow(config)
        and not _wants_tangent_stability_analysis(config)
        and not config.custom_time_domain_enabled
        and not config.collision_enabled
        and not config.imperfection_enabled
        and not config.follower_pressure
        and not config.fracture_enabled
        and abs(float(config.acceleration_x_m_s2 or 0.0)) == 0.0
        and abs(float(config.acceleration_y_m_s2 or 0.0)) == 0.0
        and abs(float(config.acceleration_z_m_s2 or 0.0)) == 0.0
        and abs(float(config.added_mass_kg or 0.0)) == 0.0
    )


class RuntimeAnalysisContext:
    """Optional owner for repeated reference-elastic analyses of one model.

    The context keeps an immutable structural epoch and an AnalysisSession.
    Load-only changes reuse the model, reduced system and eligible elastic
    factorizations for linear static and supported spectral workflows.
    Prestress-dependent operators are rebuilt for every accepted state.  Any
    structural or mass mutation, failed finalization or key mismatch closes
    the old session before a new model can be captured.
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._key: str | None = None
        self._model: object | None = None
        self._session: _backend_AnalysisSession | None = None
        self._structural_revisions: tuple[int, ...] | None = None
        self._hits = 0
        self._misses = 0
        self._invalidations = 0
        self._closed = False

    def _revision_tuple(self, model: object) -> tuple[int, ...]:
        revisions = model.revision_signature()
        return tuple(
            int(revisions.get(name, 0))
            for name in _RUNTIME_CONTEXT_STRUCTURAL_REVISIONS
        )

    def acquire(self, key: str, builder: Callable[[], object]) -> tuple[object, _backend_AnalysisSession, bool]:
        with self._lock:
            if self._closed:
                raise RuntimeError("RuntimeAnalysisContext is closed")
            if self._model is not None and self._key == key:
                current = self._revision_tuple(self._model)
                if current != self._structural_revisions:
                    self._invalidate_locked()
                else:
                    self._hits += 1
                    assert self._session is not None
                    return self._model, self._session, True
            if self._model is not None:
                self._invalidate_locked()
            model = builder()
            session = _backend_AnalysisSession(model)
            self._key = str(key)
            self._model = model
            self._session = session
            self._structural_revisions = self._revision_tuple(model)
            self._misses += 1
            return model, session, False

    def finalize(self, model: object) -> None:
        with self._lock:
            if model is not self._model:
                raise ValueError("RuntimeAnalysisContext finalized a foreign model")
            current = self._revision_tuple(model)
            if current != self._structural_revisions:
                self._invalidate_locked()
                raise ValueError("RuntimeAnalysisContext structural inputs changed")

    def capture_finalized_structure(self, model: object) -> None:
        """Bind revisions after one-time model preparation on a cache miss."""

        with self._lock:
            if model is not self._model or self._session is None:
                raise ValueError("RuntimeAnalysisContext cannot capture a foreign model")
            self._structural_revisions = self._revision_tuple(model)

    def _invalidate_locked(self) -> None:
        if self._session is not None:
            self._session.close()
        self._key = None
        self._model = None
        self._session = None
        self._structural_revisions = None
        self._invalidations += 1

    def invalidate(self) -> None:
        with self._lock:
            self._invalidate_locked()

    def diagnostics(self) -> dict[str, object]:
        with self._lock:
            return {
                "schema": "ANYSOLVER_RUNTIME_ANALYSIS_CONTEXT_V1",
                "active": self._model is not None,
                "hits": int(self._hits),
                "misses": int(self._misses),
                "invalidations": int(self._invalidations),
                "analysis_session": (
                    {} if self._session is None else self._session.diagnostics()
                ),
            }

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._invalidate_locked()
            self._closed = True

    release = close

    def __enter__(self) -> "RuntimeAnalysisContext":
        if self._closed:
            raise RuntimeError("RuntimeAnalysisContext is closed")
        return self

    def __exit__(self, _exc_type, _exc, _traceback) -> None:
        self.close()


def _positive(value: float, fallback: float) -> float:
    try:
        value = float(value)
    except (TypeError, ValueError):
        return fallback
    return value if value > 0.0 else fallback


def dnv_c208_steel_properties(
    grade: str = "S355",
    thickness_m: float = 0.016,
    thickness_class: str = "auto",
) -> dict[str, float | str]:
    """Compatibility facade for the canonical material-curve table."""

    return _material_dnv_c208_steel_properties(
        grade,
        thickness_m,
        thickness_class=thickness_class,
    )


def _mesh_divisions(mesh_fidelity: str) -> int:
    return {"coarse": 8, "medium": 16, "fine": 32, "very fine": 48, "very_fine": 48}.get(str(mesh_fidelity).lower(), 8)


def _production_divisions(mesh_fidelity: str) -> int:
    return {"coarse": 4, "medium": 8, "fine": 12, "very fine": 20, "very_fine": 20}.get(str(mesh_fidelity).lower(), 4)


def _fidelity_refinement(mesh_fidelity: str) -> int:
    return {"coarse": 1, "medium": 2, "fine": 3, "very fine": 4, "very_fine": 4}.get(str(mesh_fidelity).lower(), 1)


def _requested_mesh_size(config: LightweightFEMConfig) -> float:
    try:
        size = float(config.mesh_size_m)
    except (TypeError, ValueError):
        return 0.0
    return size if size > 0.0 else 0.0


def _line_divisions(
    length: float,
    config: LightweightFEMConfig,
    fallback: int,
    max_element_size: float = 0.0,
) -> int:
    mesh_size = _requested_mesh_size(config)
    max_element_size = _positive(max_element_size, 0.0)
    if mesh_size > 0.0:
        if max_element_size > 0.0 and mesh_size > max_element_size:
            mesh_size = max_element_size
        return max(int(math.ceil(max(length, 1.0e-9) / mesh_size)), 1)
    divisions = max(int(fallback), 1)
    if max_element_size > 0.0:
        target_size = max_element_size / max(_fidelity_refinement(config.mesh_fidelity), 1)
        divisions = max(divisions, int(math.ceil(max(length, 1.0e-9) / target_size)))
    return divisions


def _axis_breaks(
    length: float,
    divisions: int,
    mandatory: tuple[float, ...] = (),
    max_element_size: float = 0.0,
) -> list[float]:
    length = max(float(length), 1.0e-9)
    divisions = max(int(divisions), 1)
    max_element_size = _positive(max_element_size, 0.0)
    if max_element_size > 0.0:
        divisions = max(divisions, int(math.ceil(length / max_element_size)))
    tol = max(length * 1.0e-9, 1.0e-9)
    mandatory_keys: set[float] = {0.0, round(length, 12)}
    values = [length * idx / divisions for idx in range(divisions + 1)]
    for value in mandatory:
        try:
            value = float(value)
        except (TypeError, ValueError):
            continue
        if tol < value < length - tol:
            values.append(value)
            mandatory_keys.add(round(value, 12))
    clean = []
    for value in sorted(values):
        value = min(max(float(value), 0.0), length)
        if not clean or abs(value - clean[-1]) > tol:
            clean.append(value)
    clean[0] = 0.0
    clean[-1] = length
    target_spacing = length / max(divisions, 1)
    min_spacing = 0.25 * target_spacing
    if min_spacing > tol and len(clean) > 2:
        changed = True
        while changed and len(clean) > 2:
            changed = False
            for index in range(1, len(clean)):
                if clean[index] - clean[index - 1] >= min_spacing:
                    continue
                left_key = round(clean[index - 1], 12)
                right_key = round(clean[index], 12)
                left_mandatory = left_key in mandatory_keys or index - 1 == 0
                right_mandatory = right_key in mandatory_keys or index == len(clean) - 1
                if left_mandatory and right_mandatory:
                    continue
                if right_mandatory and not left_mandatory:
                    del clean[index - 1]
                else:
                    del clean[index]
                changed = True
                break
    return clean


def _graded_axis_breaks(
    span: float,
    center: float,
    fine_size: float,
    coarse_size: float,
    fine_radius: float,
    transition: float,
    mandatory: tuple[float, ...] = (),
) -> list[float]:
    """Break coordinates graded from ``fine_size`` at ``center`` to ``coarse_size`` away.

    Within ``fine_radius`` of ``center`` the local element size is ``fine_size``;
    it then grows linearly over ``transition`` up to ``coarse_size``.  The walk
    is symmetric about the center so the impact region is finely and evenly
    resolved.  Mandatory coordinates (member lines) are inserted afterwards.
    """
    span = max(float(span), 1.0e-9)
    center = min(max(float(center), 0.0), span)
    fine_size = max(float(fine_size), span * 1.0e-4)
    coarse_size = max(float(coarse_size), fine_size)
    fine_radius = max(float(fine_radius), 0.0)
    transition = max(float(transition), fine_size)

    def local_size(x: float) -> float:
        distance = abs(x - center)
        if distance <= fine_radius:
            return fine_size
        blend = min((distance - fine_radius) / transition, 1.0)
        return fine_size + blend * (coarse_size - fine_size)

    # Walk outward from the center in both directions so the fine zone is
    # centered on the impact point regardless of where it falls.
    right = [center]
    x = center
    while x < span - 1.0e-12:
        x = min(x + local_size(x), span)
        right.append(x)
    left = []
    x = center
    while x > 1.0e-12:
        x = max(x - local_size(x), 0.0)
        left.append(x)
    values = sorted(set([0.0, span] + left + right))

    tol = max(span * 1.0e-9, 1.0e-12)
    for value in mandatory:
        try:
            coordinate = float(value)
        except (TypeError, ValueError):
            continue
        if tol < coordinate < span - tol:
            values.append(coordinate)
    mandatory_keys = {round(min(max(float(v), 0.0), span), 12) for v in mandatory if _is_number(v)}
    mandatory_keys.update({0.0, round(span, 12)})
    clean: list[float] = []
    for value in sorted(values):
        value = min(max(float(value), 0.0), span)
        if not clean or abs(value - clean[-1]) > tol:
            clean.append(round(value, 12))
    clean[0] = 0.0
    clean[-1] = round(span, 12)
    # Drop non-mandatory breaks that would create slivers thinner than 40% of
    # the fine size (they hurt conditioning without adding resolution).
    min_size = 0.4 * fine_size
    merged = [clean[0]]
    for index in range(1, len(clean)):
        value = clean[index]
        is_last = index == len(clean) - 1
        if not is_last and round(value, 12) not in mandatory_keys and (value - merged[-1]) < min_size:
            continue
        merged.append(value)
    if len(merged) >= 2 and (merged[-1] - merged[-2]) < min_size and len(merged) > 2:
        # collapse a trailing sliver into the interior neighbour
        keep_last = merged[-1]
        if round(merged[-2], 12) not in mandatory_keys:
            merged.pop(-2)
        merged[-1] = keep_last
    return merged


def _detail_axis_breaks(
    span: float,
    center: float,
    fine_size: float,
    coarse_size: float,
    extent: float,
    growth_factor: float,
    mandatory: tuple[float, ...] = (),
) -> list[float]:
    """Break coordinates for a point detail zone with geometric growth."""

    span = max(float(span), 1.0e-9)
    center = min(max(float(center), 0.0), span)
    fine_size = max(float(fine_size), span * 1.0e-4)
    coarse_size = max(float(coarse_size), fine_size)
    extent = max(float(extent), 0.0)
    growth_factor = max(float(growth_factor), 1.01)
    left_extent = max(center - extent, 0.0)
    right_extent = min(center + extent, span)

    values = {0.0, span, center, left_extent, right_extent}

    # Grade outward from the fine zone until an element reaches the coarse size,
    # then STOP: beyond the transition the base grid (merged in later) provides
    # the far-field coarse elements.  Tiling the whole span with growth breaks
    # here would misalign with the base grid and streak alternating
    # small/large elements across the entire domain (badly so for the periodic
    # circumference of a cylinder).
    x = center
    while x < right_extent - 1.0e-12:
        x = min(x + fine_size, right_extent)
        values.add(x)
    step = fine_size
    while x < span - 1.0e-12:
        step = min(coarse_size, step * growth_factor)
        x = min(x + step, span)
        values.add(x)
        if step >= coarse_size - 1.0e-12:
            break

    x = center
    while x > left_extent + 1.0e-12:
        x = max(x - fine_size, left_extent)
        values.add(x)
    step = fine_size
    while x > 1.0e-12:
        step = min(coarse_size, step * growth_factor)
        x = max(x - step, 0.0)
        values.add(x)
        if step >= coarse_size - 1.0e-12:
            break

    tol = max(span * 1.0e-9, 1.0e-12)
    for value in mandatory:
        try:
            coordinate = float(value)
        except (TypeError, ValueError):
            continue
        if tol < coordinate < span - tol:
            values.add(coordinate)

    clean: list[float] = []
    for value in sorted(values):
        coordinate = min(max(float(value), 0.0), span)
        if not clean or abs(coordinate - clean[-1]) > tol:
            clean.append(round(coordinate, 12))
    clean[0] = 0.0
    clean[-1] = round(span, 12)
    return clean


def _merge_axis_breaks(
    span: float,
    current: list[float],
    candidate: list[float],
    fine_size: float,
    mandatory: tuple[float, ...] = (),
) -> list[float]:
    """Merge refinement break coordinates without keeping avoidable slivers."""

    span = max(float(span), 1.0e-9)
    tol = max(span * 1.0e-9, 1.0e-12)
    mandatory_keys = {0.0, round(span, 12)}
    for value in mandatory:
        if _is_number(value):
            mandatory_keys.add(round(min(max(float(value), 0.0), span), 12))
    values = [0.0, span]
    for sequence in (current, candidate):
        for value in sequence:
            if not _is_number(value):
                continue
            coordinate = min(max(float(value), 0.0), span)
            values.append(coordinate)
    clean: list[float] = []
    for value in sorted(values):
        if not clean or abs(value - clean[-1]) > tol:
            clean.append(round(float(value), 12))
    clean[0] = 0.0
    clean[-1] = round(span, 12)

    min_size = max(0.4 * max(float(fine_size), 0.0), tol)
    if len(clean) <= 2 or min_size <= tol:
        return clean
    changed = True
    while changed and len(clean) > 2:
        changed = False
        for index in range(1, len(clean)):
            if clean[index] - clean[index - 1] >= min_size:
                continue
            left_key = round(clean[index - 1], 12)
            right_key = round(clean[index], 12)
            left_mandatory = left_key in mandatory_keys or index - 1 == 0
            right_mandatory = right_key in mandatory_keys or index == len(clean) - 1
            if left_mandatory and right_mandatory:
                continue
            if right_mandatory and not left_mandatory:
                del clean[index - 1]
            else:
                del clean[index]
            changed = True
            break

    # Relative sliver removal: where the graded refinement interleaves with the
    # base grid it can leave an element much smaller than BOTH of its neighbours
    # (e.g. a transition break landing just short of a base grid line).  A
    # genuine graded transition element is smaller than its coarse neighbour but
    # not its fine one, so it survives this test.  Merge each such sliver into
    # its smaller neighbour by dropping the shared non-mandatory break.
    sliver_frac = 0.6
    changed = True
    while changed and len(clean) > 3:
        changed = False
        for k in range(1, len(clean) - 2):
            e_prev = clean[k] - clean[k - 1]
            e_cur = clean[k + 1] - clean[k]
            e_next = clean[k + 2] - clean[k + 1]
            if e_cur >= sliver_frac * e_prev or e_cur >= sliver_frac * e_next:
                continue
            left_mandatory = round(clean[k], 12) in mandatory_keys
            right_mandatory = round(clean[k + 1], 12) in mandatory_keys
            if left_mandatory and right_mandatory:
                continue
            # Merge into the smaller neighbour so the grade stays smooth.
            if e_prev <= e_next and not left_mandatory:
                del clean[k]
            elif not right_mandatory:
                del clean[k + 1]
            elif not left_mandatory:
                del clean[k]
            else:
                continue
            changed = True
            break
    return clean


def _is_number(value: object) -> bool:
    try:
        float(value)
        return True
    except (TypeError, ValueError):
        return False


_LOCAL_PATCH_TRANSITION = "local patch (quad+tri)"
_GRADED_TRANSITION = "graded grid"


def _wants_local_patch_transition(config: "LightweightFEMConfig") -> bool:
    style = str(getattr(config, "detail_transition_style", _GRADED_TRANSITION) or "").strip().lower()
    return style.startswith("local")


def _local_patch_detail_windows(
    config: "LightweightFEMConfig",
    u_span: float,
    v_span: float,
    base_size: float,
    thickness: float,
    radius: float = 0.0,
) -> list[dict[str, float]]:
    """Detail windows (u0,u1,v0,v1,fine) in parametric space for all detail sources.

    ``u`` is the flat x / cylinder axial coordinate, ``v`` the flat y /
    circumferential arc.  Windows drive the local-patch transition mesher and
    replace the graded tensor-grid breaks when that style is selected.
    """
    windows: list[dict[str, float]] = []

    def add_point_window(center_u: float, center_v: float, extent: float, fine_requested: float, fine_factor: float, source: str) -> None:
        fine, requested, floored = _refinement_fine_size(base_size, thickness, fine_requested, fine_factor)
        extent = max(float(extent), fine)
        windows.append(
            {
                "u0": float(center_u) - extent,
                "u1": float(center_u) + extent,
                "v0": float(center_v) - extent,
                "v1": float(center_v) + extent,
                "fine": float(fine),
                "requested_fine": float(requested),
                "floored": bool(floored),
                "source": source,
                "center_u": float(center_u),
                "center_v": float(center_v),
                "extent": float(extent),
            }
        )

    if bool(config.collision_adaptive_mesh_enabled) and bool(config.collision_enabled):
        if radius > 0.0:
            impact = _collision_impact_point_cylinder(config, radius, u_span, v_span)
        else:
            impact = _collision_impact_point(config, u_span, v_span)
        if impact is not None:
            zone_factor = max(float(config.collision_adaptive_zone_factor), 0.5)
            sphere_radius = max(float(config.collision_radius_m), 1.0e-6)
            extent = float(config.collision_adaptive_extent_m or 0.0)
            if extent <= 0.0:
                extent = sphere_radius * zone_factor
            add_point_window(
                impact[0],
                impact[1],
                extent,
                float(config.collision_adaptive_fine_size_m),
                float(config.collision_adaptive_fine_factor),
                "impact",
            )

    if bool(config.point_refinement_enabled):
        add_point_window(
            float(config.point_refinement_x_m),
            float(config.point_refinement_y_m),
            max(float(config.point_refinement_extent_m or 0.0), 0.0),
            float(config.point_refinement_fine_size_m),
            float(config.point_refinement_fine_factor),
            "selected_point",
        )

    patches = _local_refinement_patches(config)
    if patches:
        extent_pad = max(float(config.local_refinement_extent_m or 0.0), 0.0)
        for patch in patches:
            min_u, max_u = _custom_patch_axis_interval(patch, "a", u_span)
            min_v = max(0.0, min(float(patch.get("min_b", 0.0)), v_span))
            max_v = max(0.0, min(float(patch.get("max_b", 0.0)), v_span))
            if max_u <= min_u or max_v <= min_v:
                continue
            fine, requested, floored = _refinement_fine_size(
                base_size,
                thickness,
                float(config.local_refinement_fine_size_m),
                float(config.local_refinement_fine_factor),
            )
            windows.append(
                {
                    "u0": min_u - extent_pad,
                    "u1": max_u + extent_pad,
                    "v0": min_v - extent_pad,
                    "v1": max_v + extent_pad,
                    "fine": float(fine),
                    "requested_fine": float(requested),
                    "floored": bool(floored),
                    "source": "selected_panels",
                    "center_u": 0.5 * (min_u + max_u),
                    "center_v": 0.5 * (min_v + max_v),
                    "extent": float(extent_pad),
                }
            )
    return windows


def _apply_local_patch_transition(
    nodes: list[dict[str, object]],
    shells: list[dict[str, object]],
    beams: list[dict[str, object]],
    windows: list[dict[str, float]],
    u_span: float,
    v_span: float,
    point_of_param,
    param_of_coords,
    periodic_v: bool = False,
) -> dict[str, object] | None:
    """Conformally refine skin cells inside detail windows with 2:1 transitions.

    The skin is treated as a structured grid of parametric rectangles.  Cells
    intersecting a window are red-subdivided (2:1 per level, up to 3 levels)
    with a balanced level field; hanging nodes on level boundaries are closed
    with conforming templates: two-opposite -> 2 quads, corner -> 3 quads
    (all-quad), single edge -> 2 quads + 1 tri, three edges -> 3 quads + 1 tri,
    four -> 4 quads.  A single hanging node has an odd cell-boundary edge count
    so at least one triangle is unavoidable there (quad parity).

    Returns an info dict, or ``None`` when the skin is not a clean structured
    quad grid (caller falls back to the graded style).
    """
    if not windows:
        return None
    coords_by_id = {int(n["id"]): [float(c) for c in n["coords"]] for n in nodes if "id" in n}
    skin: list[dict[str, object]] = []
    for shell in shells:
        if "role" in shell:
            continue
        ids = [int(i) for i in shell.get("node_ids", ()) or ()]
        if len(ids) != 4 or any(i not in coords_by_id for i in ids):
            return None
        skin.append(shell)
    if not skin:
        return None

    tol = 1.0e-7 * max(u_span, v_span)

    def wrap_v(v: float) -> float:
        if not periodic_v:
            return v
        wrapped = v % v_span
        # Canonical seam key: v == 0 and v == v_span are the same physical
        # line on a periodic surface.  Both must map to the SAME key or
        # seam-adjacent refinement creates duplicate nodes and unmatched
        # edge signatures -- a slit along the seam.
        if abs(wrapped) < tol or abs(wrapped - v_span) < tol:
            return 0.0
        return wrapped

    # Map each skin quad to an axis-aligned parametric rectangle.
    cells: list[dict[str, object]] = []
    for shell in skin:
        ids = [int(i) for i in shell["node_ids"]]
        params = [param_of_coords(coords_by_id[i]) for i in ids]
        us = sorted({round(p[0], 9) for p in params})
        vs_raw = [p[1] for p in params]
        if periodic_v and (max(vs_raw) - min(vs_raw)) > 0.5 * v_span:
            vs_raw = [v if v > 0.25 * v_span else v + v_span for v in vs_raw]
        vs = sorted({round(v, 9) for v in vs_raw})
        if len(us) != 2 or len(vs) != 2:
            return None
        # Signed area of the quad in (u, v) node order: negative means the
        # original winding is clockwise in parametric space, so emitted
        # sub-elements (built counter-clockwise in (u, v)) must be reversed
        # to keep the surface normal -- and thus the pressure direction --
        # consistent with the untouched base mesh.
        poly = [(params[k][0], vs_raw[k]) for k in range(4)]
        area2 = sum(
            poly[k][0] * poly[(k + 1) % 4][1] - poly[(k + 1) % 4][0] * poly[k][1]
            for k in range(4)
        )
        cells.append(
            {"shell": shell, "u0": us[0], "u1": us[1], "v0": vs[0], "v1": vs[1], "flip": area2 < 0.0}
        )

    cell_sizes = [min(c["u1"] - c["u0"], c["v1"] - c["v0"]) for c in cells]
    base_size = float(np.median(cell_sizes)) if cell_sizes else 0.0
    if base_size <= 0.0:
        return None
    fine = min(float(w["fine"]) for w in windows)
    levels_needed = int(math.ceil(math.log2(max(base_size / max(fine, 1.0e-9), 1.0))))
    max_level = max(1, min(levels_needed, 3))

    def window_hits(cell: dict[str, object]) -> bool:
        for w in windows:
            offsets = (0.0, -v_span, v_span) if periodic_v else (0.0,)
            for off in offsets:
                if cell["u0"] < w["u1"] - tol and cell["u1"] > w["u0"] + tol and \
                        cell["v0"] + off < w["v1"] - tol and cell["v1"] + off > w["v0"] + tol:
                    return True
        return False

    level = [max_level if window_hits(c) else 0 for c in cells]
    if not any(level):
        return None

    def surface_blend(u: float, v: float) -> float:
        """Blend factor between chordal (0) and true-surface (1) placement.

        Purely chordal refinement keeps the patch geometrically identical to
        the faceted base mesh, but a subdivided FLAT facet then buckles like a
        plate strip -- far softer than the real curved shell (spurious local
        modes at a fraction of the true load factor).  Purely true-surface
        placement restores curvature but steps the patch proud of the
        neighbouring facets by the chord sagitta (a static stress dimple).
        The blend ramps from chordal at the window boundary (where emitted
        cells meet untouched facets) to the true surface deep inside, so the
        geometry is smooth AND the fine region carries real shell curvature.
        """
        best = 0.0
        offsets = (0.0, -v_span, v_span) if periodic_v else (0.0,)
        for w in windows:
            for off in offsets:
                margin_u = min(u - float(w["u0"]), float(w["u1"]) - u)
                margin_v = min(v + off - float(w["v0"]), float(w["v1"]) - (v + off))
                depth = min(margin_u, margin_v)
                if depth <= 0.0:
                    continue
                best = max(best, min(1.0, depth / max(base_size, 1.0e-9)))
        return best

    # Edge-neighbour lookup keyed by shared-edge signature.
    def edge_keys(c: dict[str, object]) -> dict[str, tuple]:
        return {
            "u0": ("u", round(c["u0"], 9), round(c["v0"], 9), round(c["v1"], 9)),
            "u1": ("u", round(c["u1"], 9), round(c["v0"], 9), round(c["v1"], 9)),
            "v0": ("v", round(wrap_v(c["v0"]), 9), round(c["u0"], 9), round(c["u1"], 9)),
            "v1": ("v", round(wrap_v(c["v1"]), 9), round(c["u0"], 9), round(c["u1"], 9)),
        }

    edge_map: dict[tuple, list[int]] = {}
    for index, c in enumerate(cells):
        for key in edge_keys(c).values():
            edge_map.setdefault(key, []).append(index)
    neighbours: dict[int, list[int]] = {}
    for members in edge_map.values():
        if len(members) == 2:
            a, b = members
            neighbours.setdefault(a, []).append(b)
            neighbours.setdefault(b, []).append(a)
        elif len(members) > 2:
            return None  # non-manifold skin grid: bail out

    changed = True
    while changed:
        changed = False
        for index in range(len(cells)):
            required = max((level[n] for n in neighbours.get(index, ())), default=0) - 1
            if level[index] < required:
                level[index] = required
                changed = True

    # Node factory in parametric space (exact surface positions via mapping).
    # Seed ONLY from skin corner nodes: member web/flange nodes sit off the
    # skin surface but can map to the same (u, v) (e.g. inner radius on a
    # cylinder), which would alias skin nodes to member nodes.
    max_node_id = max(coords_by_id.keys(), default=0)
    skin_node_ids = {int(i) for shell in skin for i in shell["node_ids"]}
    param_nodes: dict[tuple[float, float], int] = {}
    for node_id_value in skin_node_ids:
        p = param_of_coords(coords_by_id[node_id_value])
        param_nodes[(round(p[0], 9), round(wrap_v(p[1]), 9))] = node_id_value
    new_edge_parents: dict[int, tuple[int, int]] = {}

    def node_at(
        u: float,
        v: float,
        parents: tuple[int, int] | None = None,
        locator=None,
    ) -> int:
        nonlocal max_node_id
        key = (round(u, 9), round(wrap_v(v), 9))
        existing = param_nodes.get(key)
        if existing is not None:
            return existing
        max_node_id += 1
        # New nodes blend between the parent cell's bilinear (chordal) surface
        # and the exact mapped surface via ``surface_blend`` -- see its
        # docstring for why neither extreme works on a coarsely faceted base.
        if locator is not None:
            blend = surface_blend(u, v)
            chord = np.asarray(locator(u, v), dtype=float)
            if blend <= 0.0:
                coords = chord
            else:
                exact = np.asarray(point_of_param(u, wrap_v(v)), dtype=float)
                coords = (1.0 - blend) * chord + blend * exact
        else:
            coords = point_of_param(u, wrap_v(v))
        nodes.append({"id": max_node_id, "coords": [float(coords[0]), float(coords[1]), float(coords[2])]})
        coords_by_id[max_node_id] = [float(coords[0]), float(coords[1]), float(coords[2])]
        param_nodes[key] = max_node_id
        if parents is not None:
            new_edge_parents[max_node_id] = parents
        return max_node_id

    max_shell_id = max((int(s.get("id", 0)) for s in shells), default=0)
    new_shells: list[dict[str, object]] = []
    replaced_ids: set[int] = set()
    tri_count = 0
    quad_count = 0

    emit_flip = [False]  # per-cell winding flag set in the refinement loop

    def emit(shell_template: dict[str, object], node_ids: list[int]) -> None:
        nonlocal max_shell_id, tri_count, quad_count
        max_shell_id += 1
        entry = {key: value for key, value in shell_template.items() if key not in ("id", "node_ids")}
        entry["id"] = max_shell_id
        ordered = list(reversed(node_ids)) if emit_flip[0] else list(node_ids)
        entry["node_ids"] = [int(i) for i in ordered]
        new_shells.append(entry)
        if len(node_ids) == 3:
            tri_count += 1
        else:
            quad_count += 1

    for index, cell in enumerate(cells):
        ell = level[index]
        keys = edge_keys(cell)
        hang_side = {}
        for side, key in keys.items():
            members = edge_map.get(key, [])
            other = [m for m in members if m != index]
            hang_side[side] = bool(other) and level[other[0]] == ell + 1
        if ell == 0 and not any(hang_side.values()):
            continue  # untouched coarse cell
        replaced_ids.add(int(cell["shell"]["id"]))
        emit_flip[0] = bool(cell.get("flip"))
        n = 2 ** ell
        u0, u1, v0, v1 = cell["u0"], cell["u1"], cell["v0"], cell["v1"]
        du = (u1 - u0) / n
        dv = (v1 - v0) / n
        corner_ids = {  # original cell corners for support inheritance
            (0, 0): node_at(u0, v0), (n, 0): node_at(u1, v0),
            (0, n): node_at(u0, v1), (n, n): node_at(u1, v1),
        }
        corner_xyz = {
            key: np.asarray(coords_by_id[node_id], dtype=float)
            for key, node_id in corner_ids.items()
        }

        def cell_point(u: float, v: float) -> np.ndarray:
            # Bilinear (chordal) interpolation of the parent cell corners:
            # shared edges are linear between the shared corner nodes, so
            # adjacent refined cells and unrefined neighbours stay conforming.
            fu = (u - u0) / max(u1 - u0, 1.0e-30)
            fv = (v - v0) / max(v1 - v0, 1.0e-30)
            return (
                (1.0 - fu) * (1.0 - fv) * corner_xyz[(0, 0)]
                + fu * (1.0 - fv) * corner_xyz[(n, 0)]
                + fu * fv * corner_xyz[(n, n)]
                + (1.0 - fu) * fv * corner_xyz[(0, n)]
            )

        def lattice(i: int, j: int) -> int:
            u = u0 + du * i
            v = v0 + dv * j
            parents = None
            if i in (0, n) and 0 < j < n:
                parents = (corner_ids[(i, 0)], corner_ids[(i, n)])
            elif j in (0, n) and 0 < i < n:
                parents = (corner_ids[(0, j)], corner_ids[(n, j)])
            return node_at(u, v, parents, locator=cell_point)

        for i in range(n):
            for j in range(n):
                a = lattice(i, j)
                b = lattice(i + 1, j)
                c = lattice(i + 1, j + 1)
                d = lattice(i, j + 1)
                hang = {
                    "b": hang_side["v0"] and j == 0,      # bottom edge of subcell on cell v0 side
                    "r": hang_side["u1"] and i == n - 1,  # right on cell u1 side
                    "t": hang_side["v1"] and j == n - 1,  # top on cell v1 side
                    "l": hang_side["u0"] and i == 0,      # left on cell u0 side
                }
                # In (u,v): a=(i,j) b=(i+1,j) c=(i+1,j+1) d=(i,j+1); bottom edge = a-b
                # runs in u at constant v; here 'bottom/top' are v0/v1 sides and
                # 'left/right' are u0/u1 sides of the SUBCELL a-b-c-d.
                um = u0 + du * (i + 0.5)
                vm = v0 + dv * (j + 0.5)
                mid = {
                    "b": (lambda: node_at(um, v0 + dv * j, (a, b), locator=cell_point)),
                    "r": (lambda: node_at(u0 + du * (i + 1), vm, (b, c), locator=cell_point)),
                    "t": (lambda: node_at(um, v0 + dv * (j + 1), (d, c), locator=cell_point)),
                    "l": (lambda: node_at(u0 + du * i, vm, (a, d), locator=cell_point)),
                }
                flags = tuple(side for side in ("b", "r", "t", "l") if hang[side])
                template = cell["shell"]
                if not flags:
                    emit(template, [a, b, c, d])
                    continue
                mids = {side: mid[side]() for side in flags}
                center_u = um
                center_v = vm
                if len(flags) == 1:
                    side = flags[0]
                    ring = {
                        "b": (a, b, c, d),
                        "r": (b, c, d, a),
                        "t": (c, d, a, b),
                        "l": (d, a, b, c),
                    }[side]
                    base_first = np.asarray(coords_by_id[ring[2]], dtype=float)
                    base_second = np.asarray(coords_by_id[ring[3]], dtype=float)

                    def preview(candidate_u: float, candidate_v: float) -> np.ndarray:
                        blend = surface_blend(candidate_u, candidate_v)
                        chord = np.asarray(cell_point(candidate_u, candidate_v), dtype=float)
                        if blend <= 0.0:
                            return chord
                        exact = np.asarray(
                            point_of_param(candidate_u, wrap_v(candidate_v)),
                            dtype=float,
                        )
                        return (1.0 - blend) * chord + blend * exact

                    def minimum_triangle_angle(apex: np.ndarray) -> float:
                        points = (base_first, base_second, apex)
                        smallest = 180.0
                        for vertex in range(3):
                            first_edge = points[(vertex - 1) % 3] - points[vertex]
                            second_edge = points[(vertex + 1) % 3] - points[vertex]
                            denominator = float(
                                np.linalg.norm(first_edge) * np.linalg.norm(second_edge)
                            )
                            if denominator <= 0.0:
                                return 0.0
                            cosine = float(first_edge @ second_edge) / denominator
                            angle = math.degrees(
                                math.acos(min(1.0, max(-1.0, cosine)))
                            )
                            smallest = min(smallest, angle)
                        return smallest

                    midpoint_point = np.asarray(coords_by_id[mids[side]], dtype=float)
                    ring_points = tuple(
                        np.asarray(coords_by_id[node_id_value], dtype=float)
                        for node_id_value in ring
                    )

                    def quad_edge_aspect(points: tuple[np.ndarray, ...]) -> float:
                        lengths = tuple(
                            float(np.linalg.norm(points[(index + 1) % 4] - points[index]))
                            for index in range(4)
                        )
                        shortest = min(lengths)
                        if shortest <= 0.0:
                            return math.inf
                        return max(lengths) / shortest

                    candidates: list[tuple[bool, float, float, float, float]] = []
                    for fraction in (0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875):
                        candidate_u = center_u
                        candidate_v = center_v
                        if side in {"b", "t"}:
                            candidate_v = v0 + dv * (j + fraction)
                        else:
                            candidate_u = u0 + du * (i + fraction)
                        candidate_point = preview(candidate_u, candidate_v)
                        triangle_score = minimum_triangle_angle(candidate_point)
                        quad_aspect = max(
                            quad_edge_aspect(
                                (
                                    ring_points[0],
                                    midpoint_point,
                                    candidate_point,
                                    ring_points[3],
                                )
                            ),
                            quad_edge_aspect(
                                (
                                    midpoint_point,
                                    ring_points[1],
                                    ring_points[2],
                                    candidate_point,
                                )
                            ),
                        )
                        candidates.append(
                            (
                                quad_aspect < 4.0,
                                triangle_score,
                                -quad_aspect,
                                candidate_u,
                                candidate_v,
                            )
                        )
                    _admissible, _score, _negative_aspect, center_u, center_v = max(
                        candidates,
                        key=lambda item: (
                            item[0],
                            item[1],
                            item[2],
                            -abs(
                                (
                                    ((item[3] - (u0 + du * i)) / du)
                                    if side in {"l", "r"}
                                    else ((item[4] - (v0 + dv * j)) / dv)
                                )
                                - 0.5
                            ),
                        ),
                    )
                center = node_at(center_u, center_v, locator=cell_point)
                if len(flags) == 4:
                    emit(template, [a, mids["b"], center, mids["l"]])
                    emit(template, [mids["b"], b, mids["r"], center])
                    emit(template, [center, mids["r"], c, mids["t"]])
                    emit(template, [mids["l"], center, mids["t"], d])
                elif len(flags) == 1:
                    side = flags[0]
                    m = mids[side]
                    ring = {"b": (a, b, c, d), "r": (b, c, d, a), "t": (c, d, a, b), "l": (d, a, b, c)}[side]
                    p0, p1, p2, p3 = ring  # hanging edge is p0-p1
                    emit(template, [p0, m, center, p3])
                    emit(template, [m, p1, p2, center])
                    emit(template, [center, p2, p3])
                elif flags in (("b", "t"),):
                    emit(template, [a, mids["b"], mids["t"], d])
                    emit(template, [mids["b"], b, c, mids["t"]])
                elif flags in (("r", "l"),):
                    emit(template, [a, b, mids["r"], mids["l"]])
                    emit(template, [mids["l"], mids["r"], c, d])
                elif len(flags) == 2:
                    # adjacent corner: all-quad 3-element template
                    pair = set(flags)
                    if pair == {"b", "r"}:
                        p, q, r_, s = a, b, c, d
                        m1, m2 = mids["b"], mids["r"]
                    elif pair == {"r", "t"}:
                        p, q, r_, s = b, c, d, a
                        m1, m2 = mids["r"], mids["t"]
                    elif pair == {"t", "l"}:
                        p, q, r_, s = c, d, a, b
                        m1, m2 = mids["t"], mids["l"]
                    else:  # {"l", "b"}
                        p, q, r_, s = d, a, b, c
                        m1, m2 = mids["l"], mids["b"]
                    emit(template, [p, m1, center, s])
                    emit(template, [m1, q, m2, center])
                    emit(template, [center, m2, r_, s])
                else:  # three hanging edges: 3 quads + 1 tri
                    # Rotate the ring so the intact edge is p2-p3; then p0-p1 is
                    # split at m_bottom, p1-p2 at m_right, p3-p0 at m_left.
                    missing = next(side for side in ("b", "r", "t", "l") if side not in flags)
                    rotation = {
                        "t": ((a, b, c, d), "b", "r", "l"),
                        "l": ((b, c, d, a), "r", "t", "b"),
                        "b": ((c, d, a, b), "t", "l", "r"),
                        "r": ((d, a, b, c), "l", "b", "t"),
                    }[missing]
                    (p0, p1, p2, p3), bottom_side, right_side, left_side = rotation
                    m_bottom = mids[bottom_side]
                    m_right = mids[right_side]
                    m_left = mids[left_side]
                    emit(template, [p0, m_bottom, center, m_left])
                    emit(template, [m_bottom, p1, m_right, center])
                    emit(template, [center, m_right, p2, p3])
                    emit(template, [m_left, center, p3])

    shells[:] = [s for s in shells if int(s.get("id", 0)) not in replaced_ids] + new_shells

    # Split 2-node beams whose span now contains new lattice nodes on the same line.
    beam_splits = 0
    new_beams: list[dict[str, object]] = []
    max_beam_id = max((int(b.get("id", 0)) for b in beams), default=0)
    param_of_id = {}
    for key, node_id_value in param_nodes.items():
        param_of_id[node_id_value] = key
    for beam in beams:
        ids = [int(i) for i in beam.get("node_ids", ()) or ()]
        if len(ids) != 2 or any(i not in param_of_id for i in ids):
            new_beams.append(beam)
            continue
        (ua, va), (ub, vb) = param_of_id[ids[0]], param_of_id[ids[1]]
        inner: list[tuple[float, int]] = []
        if abs(ua - ub) < 1.0e-9:  # constant-u line, varying v
            lo, hi = sorted((va, vb))
            if periodic_v and hi - lo > 0.5 * v_span:
                new_beams.append(beam)
                continue
            for (u_key, v_key), nid in param_nodes.items():
                if nid in ids or abs(u_key - ua) > 1.0e-9:
                    continue
                if lo + 1.0e-9 < v_key < hi - 1.0e-9:
                    inner.append((v_key, nid))
        elif abs(va - vb) < 1.0e-9:
            lo, hi = sorted((ua, ub))
            for (u_key, v_key), nid in param_nodes.items():
                if nid in ids or abs(v_key - va) > 1.0e-9:
                    continue
                if lo + 1.0e-9 < u_key < hi - 1.0e-9:
                    inner.append((u_key, nid))
        if not inner:
            new_beams.append(beam)
            continue
        inner.sort()
        forward = (va < vb) if abs(ua - ub) < 1.0e-9 else (ua < ub)
        chain = [ids[0]] + [nid for _pos, nid in (inner if forward else reversed(inner))] + [ids[1]]
        for start, end in zip(chain, chain[1:]):
            max_beam_id += 1
            segment = {key: value for key, value in beam.items() if key not in ("id", "node_ids")}
            segment["id"] = max_beam_id
            segment["node_ids"] = [int(start), int(end)]
            new_beams.append(segment)
        beam_splits += 1
    beams[:] = new_beams

    return {
        "enabled": True,
        "transition": _LOCAL_PATCH_TRANSITION,
        "max_level": int(max_level),
        "fine_element_size_m": float(base_size / (2 ** max_level)),
        "coarse_element_size_m": float(base_size),
        "refined_cells": int(sum(1 for value in level if value > 0)),
        "quad_count": int(quad_count),
        "tri_count": int(tri_count),
        "beam_splits": int(beam_splits),
        "new_edge_parents": {int(k): (int(v[0]), int(v[1])) for k, v in new_edge_parents.items()},
        "windows": [
            {k: w[k] for k in ("u0", "u1", "v0", "v1", "fine", "source", "center_u", "center_v", "extent")}
            for w in windows
        ],
        "sources": [
            {
                "enabled": True,
                "source": str(w["source"]),
                "point_m": [float(w["center_u"]), float(w["center_v"])],
                "impact_point_m": [float(w["center_u"]), float(w["center_v"])] if w["source"] == "impact" else None,
                "fine_radius_m": float(w["extent"]),
                "extent_m": float(w["extent"]),
                "fine_element_size_m": float(base_size / (2 ** max_level)),
                "requested_fine_size_m": float(w.get("requested_fine", 0.0)),
                "floored_at_thickness": bool(w.get("floored", False)),
            }
            for w in windows
        ],
    }


def _collision_impact_point(
    config: "LightweightFEMConfig", length: float, width: float
) -> tuple[float, float] | None:
    """Panel (x, y) where the sphere trajectory crosses the panel plane z = 0.

    Returns ``None`` when the trajectory does not reach the panel plane; the
    result is clamped to the panel extent so a near-miss still refines the
    closest region.
    """
    start = (
        float(config.collision_start_x_m),
        float(config.collision_start_y_m),
        float(config.collision_start_z_m),
    )
    direction = (
        float(config.collision_vector_x),
        float(config.collision_vector_y),
        float(config.collision_vector_z),
    )
    dz = direction[2]
    if abs(dz) < 1.0e-12:
        # travelling parallel to the panel: refine under the start point
        if abs(start[2]) > max(length, width):
            return None
        return (
            min(max(start[0], 0.0), float(length)),
            min(max(start[1], 0.0), float(width)),
        )
    t = -start[2] / dz
    if t < 0.0:
        return None
    impact_x = start[0] + t * direction[0]
    impact_y = start[1] + t * direction[1]
    return (
        min(max(impact_x, 0.0), float(length)),
        min(max(impact_y, 0.0), float(width)),
    )


def _collision_impact_point_cylinder(
    config: "LightweightFEMConfig", radius: float, length: float, circumference: float
) -> tuple[float, float] | None:
    """Cylinder (axial z, arc length) where the sphere trajectory meets the wall.

    The cylinder axis is the global Z from 0 to ``length`` with the wall at
    ``x**2 + y**2 = radius**2``.  The trajectory is intersected with that wall
    (the physically correct impact location, matching where the transient
    contact actually occurs) and mapped to the mesh's parametric coordinates:
    the first value is the axial height, the second is the circumferential
    arc length.  Falls back to the start point's height/angle for a near-miss.
    """
    radius = max(float(radius), 1.0e-9)
    start = (
        float(config.collision_start_x_m),
        float(config.collision_start_y_m),
        float(config.collision_start_z_m),
    )
    direction = (
        float(config.collision_vector_x),
        float(config.collision_vector_y),
        float(config.collision_vector_z),
    )
    sx, sy, sz = start
    dx, dy, dz = direction
    a = dx * dx + dy * dy
    b = 2.0 * (sx * dx + sy * dy)
    c = sx * sx + sy * sy - radius * radius
    t_hit: float | None = None
    if a > 1.0e-12:
        disc = b * b - 4.0 * a * c
        if disc >= 0.0:
            sq = math.sqrt(disc)
            for candidate in sorted(((-b - sq) / (2.0 * a), (-b + sq) / (2.0 * a))):
                if candidate >= -1.0e-9:
                    t_hit = candidate
                    break
    if t_hit is None:
        hit = start
    else:
        hit = (sx + t_hit * dx, sy + t_hit * dy, sz + t_hit * dz)
    axial = min(max(float(hit[2]), 0.0), float(length))
    theta = math.atan2(float(hit[1]), float(hit[0])) % (2.0 * math.pi)
    arc = (theta / (2.0 * math.pi)) * float(circumference)
    arc = min(max(arc, 0.0), float(circumference))
    return (axial, arc)


_ADDED_MASS_LOCATIONS = (
    "none",
    "plate edge x0",
    "plate edge x1",
    "plate edge y0",
    "plate edge y1",
    "plate all edges",
    "cylinder bottom",
    "cylinder top",
)


def _resolve_added_mass_nodes(generated_geometry: dict, geometry: dict, location: str) -> list[int]:
    """Node IDs for an added-mass location (plate edge or cylinder end ring)."""
    location = str(location or "none").strip().lower()
    if location in {"", "none"}:
        return []
    nodes = generated_geometry.get("nodes", ()) or ()
    if not nodes:
        return []
    coords = {int(n["id"]): [float(c) for c in n["coords"]] for n in nodes if "id" in n}
    if not coords:
        return []
    is_cylinder = str(generated_geometry.get("plot_type", "")).lower() == "cylinder" or geometry.get("geometry") == "cylinder"
    xs = [c[0] for c in coords.values()]
    ys = [c[1] for c in coords.values()]
    zs = [c[2] for c in coords.values()]
    tol_x = max((max(xs) - min(xs)) * 1.0e-4, 1.0e-6)
    tol_y = max((max(ys) - min(ys)) * 1.0e-4, 1.0e-6)
    tol_z = max((max(zs) - min(zs)) * 1.0e-4, 1.0e-6)

    def near(value: float, target: float, tol: float) -> bool:
        return abs(value - target) <= tol

    if is_cylinder:
        # Cylinder end rings are the extreme axial (z) coordinates.
        if "top" in location:
            return sorted(nid for nid, c in coords.items() if near(c[2], max(zs), tol_z))
        if "bottom" in location:
            return sorted(nid for nid, c in coords.items() if near(c[2], min(zs), tol_z))
        return []
    # Flat panel edges.
    selected: set[int] = set()
    if "x0" in location or "all edges" in location:
        selected.update(nid for nid, c in coords.items() if near(c[0], min(xs), tol_x))
    if "x1" in location or "all edges" in location:
        selected.update(nid for nid, c in coords.items() if near(c[0], max(xs), tol_x))
    if "y0" in location or "all edges" in location:
        selected.update(nid for nid, c in coords.items() if near(c[1], min(ys), tol_y))
    if "y1" in location or "all edges" in location:
        selected.update(nid for nid, c in coords.items() if near(c[1], max(ys), tol_y))
    return sorted(selected)


def _apply_acceleration_and_masses(model, load_case, generated_geometry: dict, geometry: dict, config: "LightweightFEMConfig") -> dict[str, object]:
    """Apply an acceleration body-load field and any added edge/node masses.

    Returns a small summary for diagnostics/reporting.
    """
    ax = float(config.acceleration_x_m_s2)
    ay = float(config.acceleration_y_m_s2)
    az = float(config.acceleration_z_m_s2)
    summary: dict[str, object] = {"acceleration_m_s2": [ax, ay, az], "added_mass_kg": 0.0, "added_mass_nodes": 0, "added_mass_location": str(config.added_mass_location)}
    if ax == 0.0 and ay == 0.0 and az == 0.0 and float(config.added_mass_kg) <= 0.0:
        return summary
    if ax != 0.0 or ay != 0.0 or az != 0.0:
        existing = getattr(load_case, "gravity", None)
        if existing is not None:
            load_case.set_acceleration(float(existing[0]) + ax, float(existing[1]) + ay, float(existing[2]) + az)
        else:
            load_case.set_acceleration(ax, ay, az)
    total_mass = float(config.added_mass_kg)
    if total_mass > 0.0:
        node_ids = _resolve_added_mass_nodes(generated_geometry, geometry, config.added_mass_location)
        if node_ids:
            # Register on the model so the mass enters the global mass matrix
            # (modal/transient/collision dynamics) as well as the acceleration
            # load; equal split over the selected nodes.
            share = total_mass / float(len(node_ids))
            for node_id in node_ids:
                model.add_point_mass(int(node_id), share)
            summary["added_mass_kg"] = total_mass
            summary["added_mass_nodes"] = len(node_ids)
    return summary


def _positive_spacing(value: object) -> float:
    try:
        spacing = float(value)
    except (TypeError, ValueError):
        return 0.0
    return spacing if spacing > 1.0e-9 else 0.0


def _member_positions(total_length: float, spacing: float, fallback_midpoint: bool = True) -> tuple[float, ...]:
    total_length = max(float(total_length), 1.0e-9)
    spacing = _positive_spacing(spacing)
    tol = max(total_length * 1.0e-9, 1.0e-9)
    positions: list[float] = []
    if spacing > 0.0:
        value = spacing
        while value < total_length - tol and len(positions) < 1000:
            positions.append(value)
            value += spacing
    if not positions and fallback_midpoint:
        positions = [0.5 * total_length]
    return tuple(positions)


def _centered_member_positions(
    total_length: float,
    spacing: float,
    fallback_midpoint: bool = True,
    include_ends: bool = False,
) -> tuple[float, ...]:
    """Return member stations with any cut length shared symmetrically."""

    total_length = max(float(total_length), 1.0e-9)
    spacing = _positive_spacing(spacing)
    tolerance = max(total_length * 1.0e-9, 1.0e-9)
    if spacing <= 0.0:
        return (0.5 * total_length,) if fallback_midpoint else ()

    full_count = int(math.floor(total_length / spacing + 1.0e-9))
    if full_count <= 0:
        return (0.5 * total_length,) if fallback_midpoint else ()

    offset = 0.5 * (total_length - full_count * spacing)
    if offset <= tolerance:
        if include_ends:
            positions = [spacing * index for index in range(full_count + 1)]
            positions[-1] = total_length
        else:
            positions = [spacing * index for index in range(1, full_count)]
    else:
        positions = [offset + spacing * index for index in range(full_count + 1)]

    if not include_ends:
        positions = [
            position
            for position in positions
            if tolerance < position < total_length - tolerance
        ]
    if not positions and fallback_midpoint:
        positions = [0.5 * total_length]
    if len(positions) > 1000:
        last = len(positions) - 1
        indexes = sorted({round(index * last / 999) for index in range(1000)})
        positions = [positions[int(index)] for index in indexes]
    return tuple(float(position) for position in positions)


def _index_of_break(breaks: list[float], value: float) -> int:
    return min(range(len(breaks)), key=lambda index: abs(float(breaks[index]) - float(value)))


def _member_count_from_spacing(total_length: float, spacing: float) -> int:
    try:
        total_length = float(total_length)
        spacing = float(spacing)
    except (TypeError, ValueError):
        return 0
    if total_length <= 0.0 or spacing <= 1.0e-9:
        return 0
    return max(int(round(total_length / spacing)), 1)


def _multiple_at_least(value: int, factor: int) -> int:
    value = max(int(value), 1)
    factor = max(int(factor), 1)
    return max(factor, int(math.ceil(value / factor)) * factor)


def _sorted_positive_factors(base_factor: float, count: int) -> tuple[float, ...]:
    count = max(int(count), 1)
    base = max(float(base_factor), 1.0e-6)
    return tuple(base * (1.0 + 0.35 * mode) for mode in range(count))


def _plate_critical_stress(E: float, nu: float, thickness: float, width: float, k: float = 4.0) -> float:
    slenderness = thickness / max(width, 1.0e-9)
    return k * math.pi**2 * E * slenderness**2 / (12.0 * (1.0 - nu**2))


def _cylinder_critical_pressure(E: float, nu: float, thickness: float, radius: float) -> float:
    radius = max(radius, 1.0e-9)
    thickness = max(thickness, 1.0e-9)
    return 0.605 * E / ((1.0 - nu**2) ** 0.75) * (thickness / radius) ** 2.5


def _grid(rows: int, cols: int, value_at) -> tuple[tuple[float, ...], ...]:
    return tuple(tuple(float(value_at(row, col)) for col in range(cols)) for row in range(rows))


def _flat_visualization(
    length: float,
    width: float,
    displacement: float,
    stress: float,
    div: int,
) -> dict[str, object]:
    rows = div + 1
    cols = div + 1

    def shape(row: int, col: int) -> float:
        x_norm = row / max(rows - 1, 1)
        y_norm = col / max(cols - 1, 1)
        return math.sin(math.pi * x_norm) * math.sin(math.pi * y_norm)

    return {
        "type": "flat",
        "x_m": _grid(rows, cols, lambda row, _col: length * row / max(rows - 1, 1)),
        "y_m": _grid(rows, cols, lambda _row, col: width * col / max(cols - 1, 1)),
        "w_m": _grid(rows, cols, lambda row, col: displacement * shape(row, col)),
        "stress_pa": _grid(rows, cols, lambda row, col: stress * (0.55 + 0.45 * shape(row, col))),
    }


def _cylinder_visualization(
    radius: float,
    length: float,
    displacement: float,
    stress: float,
    circumferential_div: int,
    axial_div: int,
) -> dict[str, object]:
    rows = axial_div + 1
    cols = circumferential_div + 1

    def axial_shape(row: int) -> float:
        x_norm = row / max(rows - 1, 1)
        return math.sin(math.pi * x_norm) ** 2

    def radial_pattern(row: int, col: int) -> float:
        theta = 2.0 * math.pi * col / max(cols - 1, 1)
        return displacement * (0.45 + 0.55 * axial_shape(row)) * (1.0 + 0.08 * math.cos(3.0 * theta))

    return {
        "type": "cylinder",
        "radius_m": radius,
        "axial_m": _grid(rows, cols, lambda row, _col: length * row / max(rows - 1, 1)),
        "theta_rad": _grid(rows, cols, lambda _row, col: 2.0 * math.pi * col / max(cols - 1, 1)),
        "radial_displacement_m": _grid(rows, cols, radial_pattern),
        "stress_pa": _grid(rows, cols, lambda row, col: stress * (0.80 + 0.20 * axial_shape(row)) * (1.0 + 0.03 * math.cos(2.0 * math.pi * col / max(cols - 1, 1)))),
    }


def _beam_section(thickness: float, reference: float, depth_factor: float) -> dict[str, float]:
    depth = max(depth_factor * reference, 6.0 * thickness, 0.05)
    width = max(2.5 * thickness, 0.03)
    area = width * depth
    iy = width * depth**3 / 12.0
    iz = depth * width**3 / 12.0
    return {
        "area": area,
        "Iy": max(iy, 1.0e-10),
        "Iz": max(iz, 1.0e-10),
        "J": max(iy + iz, 1.0e-10),
        "shear_factor_y": 5.0 / 6.0,
        "shear_factor_z": 5.0 / 6.0,
        "web_height": depth,
        "web_thickness": thickness,
        "flange_width": 0.0,
        "flange_thickness": 0.0,
    }


def _section_or_default(section: object, thickness: float, reference: float, depth_factor: float) -> dict[str, float]:
    if isinstance(section, dict):
        web_height = float(section.get("web_height") or section.get("web_h") or 0.0)
        web_thickness = float(section.get("web_thickness") or section.get("web_thk") or 0.0)
        flange_width = float(section.get("flange_width") or section.get("flange_w") or 0.0)
        flange_thickness = float(section.get("flange_thickness") or section.get("flange_thk") or 0.0)
        try:
            area = float(section.get("area", section.get("A", 0.0)))
            iy = float(section.get("Iy", section.get("iy", 0.0)))
            iz = float(section.get("Iz", section.get("iz", 0.0)))
            j = float(section.get("J", section.get("torsion_constant", iy + iz)))
        except (TypeError, ValueError):
            area = 0.0
            iy = 0.0
            iz = 0.0
            j = 0.0
        if area > 0.0 and iy > 0.0 and iz > 0.0:
            result = {
                "area": area,
                "Iy": max(iy, 1.0e-12),
                "Iz": max(iz, 1.0e-12),
                "J": max(j, 1.0e-12),
                "shear_factor_y": float(section.get("shear_factor_y", 5.0 / 6.0)),
                "shear_factor_z": float(section.get("shear_factor_z", 5.0 / 6.0)),
                "web_height": web_height or 0.1,
                "web_thickness": web_thickness or 0.01,
                "flange_width": flange_width,
                "flange_thickness": flange_thickness,
            }
            if section.get("label"):
                result["label"] = str(section.get("label"))
            return result
        if web_height > 0.0 and web_thickness > 0.0:
            web_area = web_height * web_thickness
            flange_area = flange_width * flange_thickness if flange_width > 0.0 and flange_thickness > 0.0 else 0.0
            total_area = web_area + flange_area
            web_centroid = 0.5 * web_height
            flange_centroid = web_height + 0.5 * flange_thickness if flange_area > 0.0 else 0.0
            centroid = (
                (web_area * web_centroid + flange_area * flange_centroid) / total_area
                if total_area > 0.0
                else web_centroid
            )
            iy = web_thickness * web_height ** 3 / 12.0 + web_area * (web_centroid - centroid) ** 2
            iz = web_height * web_thickness ** 3 / 12.0
            if flange_area > 0.0:
                iy += flange_width * flange_thickness ** 3 / 12.0 + flange_area * (flange_centroid - centroid) ** 2
                iz += flange_thickness * flange_width ** 3 / 12.0
            result = {
                "area": total_area,
                "Iy": max(iy, 1.0e-12),
                "Iz": max(iz, 1.0e-12),
                "J": max(iy + iz, 1.0e-12),
                "shear_factor_y": float(section.get("shear_factor_y", 5.0 / 6.0)),
                "shear_factor_z": float(section.get("shear_factor_z", 5.0 / 6.0)),
                "web_height": web_height,
                "web_thickness": web_thickness,
                "flange_width": flange_width,
                "flange_thickness": flange_thickness,
            }
            if section.get("label"):
                result["label"] = str(section.get("label"))
            return result
    return _beam_section(thickness, reference, depth_factor)


def _normalized_choice(value: object, default: str = "auto") -> str:
    text = str(value or default).strip().lower().replace("_", " ").replace("-", " ")
    return " ".join(text.split()) or default


def _normalized_kinematics(value: object) -> str:
    choice = _normalized_choice(value, "von karman")
    if choice in {"corotational", "co rotational", "large rotation", "large rotations"}:
        return "corotational"
    return "von_karman"


def _wants_s8(config: LightweightFEMConfig) -> bool:
    return _normalized_choice(config.shell_element_order, "s4") in {"s8", "s8r", "8 node", "8 node shell", "quadratic"}


def _wants_s3(config: LightweightFEMConfig) -> bool:
    return _normalized_choice(config.shell_element_order, "s4") in {
        "s3",
        "t3",
        "tri3",
        "tria3",
        "shell3",
        "3 node",
        "3 node shell",
        "3 node triangle",
        "linear triangle",
    }


def _wants_s6(config: LightweightFEMConfig) -> bool:
    return _normalized_choice(config.shell_element_order, "s4") in {
        "s6",
        "t6",
        "tri6",
        "tria6",
        "shell6",
        "6 node",
        "6 node shell",
        "6 node triangle",
        "quadratic triangle",
    }


def _wants_b3(config: LightweightFEMConfig) -> bool:
    return _normalized_choice(config.beam_element_order, "b2") in {"b3", "3 node", "3 node beam", "quadratic", "quadratic beam"}


def _shell_order_from_geometry(generated_geometry: dict) -> str:
    for shell in generated_geometry.get("shells", []) or []:
        node_count = len(shell.get("node_ids", []))
        return {3: "S3", 4: "S4", 6: "S6", 8: "S8"}.get(node_count, "S4")
    return "S4"


def _beam_order_from_geometry(generated_geometry: dict) -> str:
    for beam in generated_geometry.get("beams", []) or []:
        return "B3" if len(beam.get("node_ids", [])) == 3 else "B2"
    return "B2"


def _shell_element_type(shell: dict[str, object]) -> str:
    if "type" in shell:
        return str(shell["type"])
    node_count = len(shell.get("node_ids", []))
    return {3: "S3", 4: "S4", 6: "S6", 8: "S8"}.get(node_count, "S4")


def _refined_midpoint_breaks(values: list[float]) -> list[float]:
    refined = [float(values[0])] if values else []
    for start, end in zip(values, values[1:]):
        refined.append(0.5 * (float(start) + float(end)))
        refined.append(float(end))
    return sorted(set(round(float(value), 12) for value in refined))


def _node_lookup(nodes: list[dict[str, object]]) -> dict[int, np.ndarray]:
    return {int(node["id"]): np.asarray(node["coords"], dtype=float) for node in nodes}


def _project_cylinder_midpoint(a: np.ndarray, b: np.ndarray, radius: float) -> np.ndarray:
    midpoint = 0.5 * (a + b)
    if radius <= 0.0:
        return midpoint
    radial = midpoint[:2]
    norm = float(np.linalg.norm(radial))
    if norm > 1.0e-12:
        midpoint[:2] = radial / norm * radius
    return midpoint


def _upgrade_shells_to_s8(nodes: list[dict[str, object]], shells: list[dict[str, object]], radius: float = 0.0, element_type: str = "S8") -> None:
    """Convert generated 4-node quads to 8-node serendipity quads in place."""
    node_coords = _node_lookup(nodes)
    next_node_id = max(node_coords, default=0) + 1
    midside_nodes: dict[tuple[int, int], int] = {}

    def midside_id(n1: int, n2: int) -> int:
        nonlocal next_node_id
        key = tuple(sorted((int(n1), int(n2))))
        if key in midside_nodes:
            return midside_nodes[key]
        a = node_coords[int(n1)]
        b = node_coords[int(n2)]
        coords = _project_cylinder_midpoint(a, b, radius) if radius > 0.0 else 0.5 * (a + b)
        node_id = next_node_id
        next_node_id += 1
        midside_nodes[key] = node_id
        node_coords[node_id] = coords
        nodes.append({"id": node_id, "coords": coords.tolist()})
        return node_id

    for shell in shells:
        node_ids = [int(node_id) for node_id in shell.get("node_ids", [])]
        if len(node_ids) != 4:
            continue
        shell["type"] = element_type
        n1, n2, n3, n4 = node_ids
        shell["node_ids"] = [
            n1,
            n2,
            n3,
            n4,
            midside_id(n1, n2),
            midside_id(n2, n3),
            midside_id(n3, n4),
            midside_id(n4, n1),
        ]


def _qualified_s3_owner_normal(
    node_coords: dict[int, np.ndarray],
    shell: dict[str, object],
    corners: tuple[int, int, int],
    *,
    radius: float = 0.0,
) -> list[float]:
    """Return a facet-normal oriented by the generated surface authority."""

    first, second, third = (node_coords[node_id] for node_id in corners)
    facet = np.cross(second - first, third - first)
    facet_magnitude = float(np.linalg.norm(facet))
    if not math.isfinite(facet_magnitude) or facet_magnitude <= 0.0:
        raise ValueError("runtime-qualified-s3-is-degenerate")

    authority: np.ndarray | None = None
    supplied = shell.get("reference_normal")
    if supplied is not None:
        try:
            candidate = np.asarray(supplied, dtype=float).reshape(3)
        except (TypeError, ValueError):
            candidate = np.empty(0, dtype=float)
        if candidate.shape == (3,) and np.all(np.isfinite(candidate)):
            candidate_magnitude = float(np.linalg.norm(candidate))
            if candidate_magnitude > 0.0:
                authority = candidate / candidate_magnitude
    if authority is None and radius > 0.0:
        centroid = (first + second + third) / 3.0
        radial = np.asarray([centroid[0], centroid[1], 0.0], dtype=float)
        radial_magnitude = float(np.linalg.norm(radial))
        if radial_magnitude > 0.0:
            authority = radial / radial_magnitude
    if authority is None:
        # Flat runtime geometry owns a positive global-Z skin normal.  It
        # supplies orientation only; the returned vector remains exactly
        # normal to the discrete triangle facet.
        authority = np.asarray([0.0, 0.0, 1.0], dtype=float)

    orientation = float(facet @ authority)
    if not math.isfinite(orientation) or abs(orientation) <= 1.0e-15 * facet_magnitude:
        raise ValueError("runtime-qualified-s3-owner-normal-is-not-facet-compatible")
    if orientation < 0.0:
        facet = -facet
    return (facet / facet_magnitude).tolist()


def _bind_runtime_qualified_s3_authority(
    nodes: list[dict[str, object]],
    shells: list[dict[str, object]],
    *,
    radius: float = 0.0,
) -> None:
    """Bind current-policy S3 identity and physical owner-normal authority."""

    node_coords = _node_lookup(nodes)
    for shell in shells:
        corners = tuple(int(node_id) for node_id in shell.get("node_ids", ()))
        if len(corners) != 3:
            continue
        requested = str(
            shell.get("formulation", shell.get("shell_formulation", ""))
        ).strip().lower().replace("_", "-")
        if requested in {"legacy", "legacy-s3"}:
            continue
        shell["formulation"] = "e4-pl-s3-v2d"
        shell["formulation_id"] = "CANDIDATE_E4_PL_S3_V2D_NATIVE_PARITY_V1"
        shell["reference_normal"] = _qualified_s3_owner_normal(
            node_coords,
            shell,
            corners,
            radius=radius,
        )
        shell["owner_normal_authority"] = "PHYSICAL_SURFACE_OWNER_NORMAL_V2D_V1"


def _split_shells_to_triangles(
    nodes: list[dict[str, object]],
    shells: list[dict[str, object]],
    radius: float = 0.0,
    quadratic: bool = False,
    element_type: str = "S3",
) -> None:
    """Convert generated 4-node quads to SESAM-style triangular shells in place."""

    node_coords = _node_lookup(nodes)
    next_node_id = max(node_coords, default=0) + 1
    midside_nodes: dict[tuple[int, int], int] = {}

    def midpoint_coords(n1: int, n2: int) -> np.ndarray:
        a = node_coords[int(n1)]
        b = node_coords[int(n2)]
        if radius <= 0.0:
            return 0.5 * (a + b)
        radial_a = float(np.linalg.norm(a[:2]))
        radial_b = float(np.linalg.norm(b[:2]))
        tol = max(abs(float(radius)) * 1.0e-6, 1.0e-9)
        if abs(radial_a - radius) <= tol and abs(radial_b - radius) <= tol:
            return _project_cylinder_midpoint(a, b, radius)
        return 0.5 * (a + b)

    def midside_id(n1: int, n2: int) -> int:
        nonlocal next_node_id
        key = tuple(sorted((int(n1), int(n2))))
        if key in midside_nodes:
            return midside_nodes[key]
        coords = midpoint_coords(int(n1), int(n2))
        node_id = next_node_id
        next_node_id += 1
        midside_nodes[key] = node_id
        node_coords[node_id] = coords
        nodes.append({"id": node_id, "coords": coords.tolist()})
        return node_id

    converted: list[dict[str, object]] = []
    next_element_id = 1
    for shell in shells:
        node_ids = [int(node_id) for node_id in shell.get("node_ids", [])]
        if len(node_ids) == (6 if quadratic else 3):
            updated = dict(shell)
            updated["id"] = next_element_id
            updated["type"] = element_type
            converted.append(updated)
            next_element_id += 1
            continue
        if len(node_ids) != 4:
            updated = dict(shell)
            updated["id"] = next_element_id
            converted.append(updated)
            next_element_id += 1
            continue

        n1, n2, n3, n4 = node_ids
        tri_corners = ((n1, n2, n3), (n1, n3, n4))
        for corners in tri_corners:
            tri = dict(shell)
            tri["id"] = next_element_id
            tri["type"] = element_type
            if quadratic:
                a, b, c = corners
                tri["node_ids"] = [a, b, c, midside_id(a, b), midside_id(b, c), midside_id(c, a)]
            else:
                tri["node_ids"] = list(corners)
            converted.append(tri)
            next_element_id += 1

    shells[:] = converted


def _axis_symmetry_constraints(axis: str) -> dict[str, float]:
    if axis == "x":
        return {"ux": 0.0, "ry": 0.0, "rz": 0.0}
    if axis == "y":
        return {"uy": 0.0, "rx": 0.0, "rz": 0.0}
    if axis == "z":
        return {"uz": 0.0, "rx": 0.0, "ry": 0.0}
    return {}


def _symmetry_supports(nodes: list[dict[str, object]], config: LightweightFEMConfig) -> list[dict[str, object]]:
    mode = _normalized_choice(config.symmetry_mode, "none")
    if mode in {"none", "off", "cyclic"}:
        return []
    axis_index = {"x": 0, "y": 1, "z": 2}.get(mode)
    constraints = _axis_symmetry_constraints(mode)
    if axis_index is None or not constraints:
        return []
    coords = _node_lookup(nodes)
    values = np.asarray([coord[axis_index] for coord in coords.values()], dtype=float)
    if values.size == 0:
        return []
    span = float(np.max(values) - np.min(values))
    tol = max(span * 1.0e-8, 1.0e-8)
    zero_nodes = [node_id for node_id, coord in coords.items() if abs(float(coord[axis_index])) <= tol]
    if zero_nodes:
        node_ids = zero_nodes
        plane_name = f"global_{mode}0"
    else:
        target = float(np.min(values))
        node_ids = [node_id for node_id, coord in coords.items() if abs(float(coord[axis_index]) - target) <= tol]
        plane_name = f"global_min_{mode}"
    return [{"name": f"symmetry_{plane_name}", "node_ids": sorted(node_ids), "constraints": constraints}]


_DOF_NAMES = ("ux", "uy", "uz", "rx", "ry", "rz")


def _dof_constraint_map(raw: object) -> dict[str, float]:
    """Parse a per-DOF constraint object into {dof: enforced_value}.

    Accepts either a JSON string or an already-decoded dict.  Values may be a
    plain number (constrained at that value) or a nested
    {"on": bool, "value": float}.  Only recognised, active DOFs are returned.
    """
    if isinstance(raw, str):
        try:
            raw = json.loads(raw) if raw.strip() else {}
        except Exception:
            return {}
    if not isinstance(raw, dict):
        return {}
    result: dict[str, float] = {}
    for dof in _DOF_NAMES:
        if dof not in raw:
            continue
        entry = raw[dof]
        if isinstance(entry, dict):
            if not bool(entry.get("on", True)):
                continue
            try:
                result[dof] = float(entry.get("value", 0.0) or 0.0)
            except (TypeError, ValueError):
                result[dof] = 0.0
        elif isinstance(entry, bool):
            if entry:
                result[dof] = 0.0
        else:
            try:
                result[dof] = float(entry)
            except (TypeError, ValueError):
                continue
    return result


_FLAT_EDGE_KEYS = ("x0", "x1", "y0", "y1")
_CYLINDER_EDGE_KEYS = ("lower", "upper")


def _boundary_edge_constraints(config: LightweightFEMConfig) -> dict[str, dict[str, float]]:
    """Per-edge whole-boundary constraints {edge: {dof: value}} from the BC tab.

    Accepts the current schema {"x0": {"uz": 0}, "upper": {"ux": 0.001}, ...}
    with an "all" key meaning every edge.  Backward compatible with the earlier
    flat single-DOF-map schema ({"uz": 0.0, ...}), which is treated as "all".
    Empty/blank => no whole-boundary constraint.
    """
    raw = getattr(config, "boundary_constraint_json", "") or ""
    if isinstance(raw, str):
        try:
            raw = json.loads(raw) if raw.strip() else {}
        except Exception:
            return {}
    if not isinstance(raw, dict) or not raw:
        return {}
    edge_keys = set(_FLAT_EDGE_KEYS) | set(_CYLINDER_EDGE_KEYS) | {"all"}
    if not (set(raw.keys()) & edge_keys):
        # Legacy flat {dof: value} schema -> applies to the whole boundary.
        flat = _dof_constraint_map(raw)
        return {"all": flat} if flat else {}
    result: dict[str, dict[str, float]] = {}
    for edge, spec in raw.items():
        if edge not in edge_keys:
            continue
        dofs = _dof_constraint_map(spec)
        if dofs:
            result[str(edge)] = dofs
    return result


def _boundary_constraint_map(config: LightweightFEMConfig) -> dict[str, float]:
    """Union of all whole-boundary constrained DOFs (for quick 'any?' checks)."""
    merged: dict[str, float] = {}
    for spec in _boundary_edge_constraints(config).values():
        merged.update(spec)
    return merged


def _edge_support_dofs_by_node(edge_supports: list[dict[str, object]]) -> dict[int, set[str]]:
    """Map node id -> set of DOFs already constrained by selected-edge supports."""
    covered: dict[int, set[str]] = {}
    for support in edge_supports or ():
        dofs = set((support.get("constraints") or {}).keys())
        if not dofs:
            continue
        for node_id in support.get("node_ids", ()) or ():
            covered.setdefault(int(node_id), set()).update(dofs)
    return covered


def _whole_boundary_constraint_supports(
    edge_node_map: dict[str, list[int]],
    config: LightweightFEMConfig,
    exclude_dofs_by_node: dict[int, set[str]] | None = None,
) -> list[dict[str, object]]:
    """Support groups per named edge with that edge's per-DOF constraints.

    ``edge_node_map`` maps an edge key (flat: x0/x1/y0/y1; cylinder:
    lower/upper) to its node ids.  Each edge holds its chosen DOFs at their
    enforced values (0 = fixed); the "all" key applies to every edge.  A node
    reached by several specs takes their union (last value wins on a repeat).
    DOFs already constrained on a node by a selected-edge segment are dropped
    so the selected-edge value wins.  Nodes are grouped by resulting DOF
    subset for compact support records.
    """
    edge_constraints = _boundary_edge_constraints(config)
    if not edge_constraints or not edge_node_map:
        return []
    exclude_dofs_by_node = exclude_dofs_by_node or {}
    # Accumulate per-node {dof: value} from the matching edge specs.
    per_node: dict[int, dict[str, float]] = {}
    for edge_key, dof_map in edge_constraints.items():
        target_edges = edge_node_map.keys() if edge_key == "all" else (edge_key,)
        for target in target_edges:
            for node in edge_node_map.get(target, ()) or ():
                per_node.setdefault(int(node), {}).update(dof_map)
    groups: dict[tuple[tuple[str, float], ...], list[int]] = {}
    for node, dof_map in per_node.items():
        excluded = exclude_dofs_by_node.get(node, set())
        active = tuple(sorted((dof, float(value)) for dof, value in dof_map.items() if dof not in excluded))
        if active:
            groups.setdefault(active, []).append(node)
    supports: list[dict[str, object]] = []
    for suffix, (items, node_ids) in enumerate(sorted(groups.items(), key=lambda kv: (len(kv[1]), kv[0]), reverse=True)):
        name = "whole_boundary_dof_constraint" if suffix == 0 else f"whole_boundary_dof_constraint_{suffix}"
        supports.append(
            {
                "name": name,
                "node_ids": sorted(node_ids),
                "constraints": {dof: value for dof, value in items},
            }
        )
    return supports


def _enforced_displacement_supports(
    nodes: list[dict[str, object]],
    config: LightweightFEMConfig,
    plot_type: str,
    exclude_node_ids: set[int] | None = None,
) -> list[dict[str, object]]:
    dx = float(getattr(config, "enforced_displacement_x_m", 0.0))
    dy = float(getattr(config, "enforced_displacement_y_m", 0.0))
    dz = float(getattr(config, "enforced_displacement_z_m", 0.0))

    if abs(dx) <= 0.0 and abs(dy) <= 0.0 and abs(dz) <= 0.0:
        return []

    constraints = {}
    if abs(dx) > 0.0:
        constraints["ux"] = dx
    if abs(dy) > 0.0:
        constraints["uy"] = dy
    if abs(dz) > 0.0:
        constraints["uz"] = dz

    exclude_node_ids = set(exclude_node_ids or set())
    coords = _node_lookup(nodes)
    if not coords:
        return []

    if plot_type == "cylinder":
        z_values = np.asarray([coord[2] for coord in coords.values()], dtype=float)
        target_z = 0.5 * (float(np.min(z_values)) + float(np.max(z_values)))
        tol = max((float(np.max(z_values)) - float(np.min(z_values))) * 1.0e-8, 1.0e-8)
        closest_z = min((float(coord[2]) for coord in coords.values()), key=lambda value: abs(value - target_z))
        supports = []
        for node_id, coord in coords.items():
            if abs(float(coord[2]) - closest_z) > tol:
                continue
            supports.append(
                {
                    "name": f"enforced_displacement_{node_id}",
                    "node_ids": [node_id],
                    "constraints": constraints,
                }
            )
        return supports

    xs = np.asarray([coord[0] for coord in coords.values()], dtype=float)
    ys = np.asarray([coord[1] for coord in coords.values()], dtype=float)
    centre = np.asarray([0.5 * (float(np.min(xs)) + float(np.max(xs))), 0.5 * (float(np.min(ys)) + float(np.max(ys)))])
    candidates = [node_id for node_id in coords if node_id not in exclude_node_ids] or list(coords)
    node_id = min(candidates, key=lambda nid: float(np.linalg.norm(coords[nid][:2] - centre)))
    return [{"name": "enforced_panel_displacement", "node_ids": [node_id], "constraints": constraints}]


def _offset_beam_nodes_and_couplings(
    nodes: list[dict[str, object]],
    beams: list[dict[str, object]],
    config: LightweightFEMConfig,
    normal_at_node,
    start_node_id: int | None = None,
    start_coupling_id: int = 30_001,
    exclude_base_node_ids: set[int] | None = None,
) -> list[dict[str, object]]:
    node_coords = _node_lookup(nodes)
    next_node_id = int(start_node_id or (max(node_coords, default=0) + 1))
    next_coupling_id = int(start_coupling_id)
    offset_nodes: dict[tuple[int, str, float], int] = {}
    couplings: list[dict[str, object]] = []
    exclude_base_node_ids = set(exclude_base_node_ids or set())

    def eccentricity_for(beam: dict[str, object]) -> float:
        section = beam.get("section") or beam.get("cross_section") or {}
        if isinstance(section, dict):
            try:
                return float(section.get("eccentricity_m", 0.0))
            except (TypeError, ValueError):
                return 0.0
        return 0.0

    def offset_node(base_node_id: int, role: str, eccentricity: float) -> int:
        nonlocal next_node_id, next_coupling_id
        key = (int(base_node_id), str(role), round(float(eccentricity), 12))
        if key in offset_nodes:
            return offset_nodes[key]
        base = node_coords[int(base_node_id)]
        normal = np.asarray(normal_at_node(int(base_node_id), base), dtype=float)
        norm = float(np.linalg.norm(normal))
        if norm <= 1.0e-12:
            normal = np.array([0.0, 0.0, 1.0], dtype=float)
        else:
            normal = normal / norm
        offset = normal * float(eccentricity)
        node_id = next_node_id
        next_node_id += 1
        offset_nodes[key] = node_id
        node_coords[node_id] = base + offset
        nodes.append({"id": node_id, "coords": node_coords[node_id].tolist()})
        couplings.append(
            {
                "id": next_coupling_id,
                "beam_node_id": node_id,
                "shell_node_ids": [int(base_node_id)],
                "shape_weights": [1.0],
                "eccentricity": offset.tolist(),
            }
        )
        next_coupling_id += 1
        return node_id

    for beam in beams:
        eccentricity = eccentricity_for(beam)
        if abs(eccentricity) <= 0.0:
            continue
        role = str(beam.get("role", "beam"))
        beam["node_ids"] = [
            int(node_id) if int(node_id) in exclude_base_node_ids else offset_node(int(node_id), role, eccentricity)
            for node_id in beam.get("node_ids", [])
        ]
    return couplings


def _section_with_runtime_options(
    section: object,
    thickness: float,
    reference: float,
    depth_factor: float,
    eccentricity: float,
    orientation: str,
    consistent_mass: bool = False,
) -> dict[str, float]:
    result = dict(_section_or_default(section, thickness, reference, depth_factor))
    try:
        eccentricity = float(eccentricity)
    except (TypeError, ValueError):
        eccentricity = 0.0
    if abs(eccentricity) > 0.0:
        result["eccentricity_m"] = eccentricity
    orientation_key = _normalized_choice(orientation)
    if orientation_key == "global z":
        result["orientation"] = (0.0, 0.0, 1.0)
    elif orientation_key == "global y":
        result["orientation"] = (0.0, 1.0, 0.0)
    if bool(consistent_mass):
        result["consistent_mass"] = True
    return result


def _member_model(config: LightweightFEMConfig) -> str:
    text = _normalized_choice(config.member_model, "beams")
    if "all" in text and "shell" in text:
        return "all_shell"
    if "web" in text and "shell" in text:
        return "web_shell_flange_beam"
    return "beams"


def _member_webs_as_shells(config: LightweightFEMConfig) -> bool:
    return _member_model(config) in {"web_shell_flange_beam", "all_shell"}


def _member_flanges_as_shells(config: LightweightFEMConfig) -> bool:
    return _member_model(config) == "all_shell"


def _member_flanges_as_beams(config: LightweightFEMConfig) -> bool:
    return _member_model(config) == "web_shell_flange_beam"


def _member_shell_length_cap(geometry: dict, config: LightweightFEMConfig, thickness: float) -> float:
    """Target in-plane mesh length when member webs/flanges are meshed as shells."""

    if not _member_webs_as_shells(config):
        return 0.0
    candidates: list[float] = []

    def add_section_cap(section: object, reference: float, depth_factor: float) -> None:
        data = _section_or_default(section, thickness, reference, depth_factor)
        web_height = _member_section_dimension(data, "web_height")
        flange_width = _member_section_dimension(data, "flange_width")
        if web_height > 0.0:
            candidates.append(5.0 * web_height / max(_minimum_member_web_depth_segments(config, web_height), 1))
        if _member_flanges_as_shells(config) and flange_width > 0.0:
            candidates.append(2.5 * flange_width)

    if config.include_stiffeners and geometry.get("has_stiffener"):
        add_section_cap(
            geometry.get("stiffener_section"),
            _positive(geometry.get("stiffener_spacing_m", 0.0), 1.0),
            0.08,
        )
    if config.include_girders and geometry.get("has_girder"):
        add_section_cap(
            geometry.get("girder_section"),
            _positive(geometry.get("girder_spacing_m", 0.0), 1.0),
            0.12,
        )
    return min([value for value in candidates if value > 1.0e-9], default=0.0)


def _generated_shell_role(shell: dict[str, object]) -> str:
    return str(shell.get("role", "skin") or "skin").strip().lower()


def _generated_skin_shell_ids(generated_geometry: dict) -> set[int]:
    return {
        int(shell["id"])
        for shell in generated_geometry.get("shells", []) or []
        if shell.get("id") is not None and _generated_shell_role(shell) in {"", "skin"}
    }


def _generated_non_skin_shell_count(generated_geometry: dict) -> int:
    return sum(
        1
        for shell in generated_geometry.get("shells", []) or []
        if shell.get("id") is not None and _generated_shell_role(shell) not in {"", "skin"}
    )


def _skin_shell_element_ids(model, generated_geometry: dict) -> tuple[int, ...]:
    shell_ids = _shell_element_ids(model)
    skin_ids = _generated_skin_shell_ids(generated_geometry)
    if not skin_ids:
        return shell_ids
    selected = tuple(element_id for element_id in shell_ids if int(element_id) in skin_ids)
    return selected or shell_ids


def _node_cache_from_nodes(nodes: list[dict[str, object]]) -> dict[tuple[float, float, float], int]:
    cache: dict[tuple[float, float, float], int] = {}
    for node in nodes:
        coords = node.get("coords", [])
        if len(coords) >= 3:
            cache[(round(float(coords[0]), 12), round(float(coords[1]), 12), round(float(coords[2]), 12))] = int(node["id"])
    return cache


def _add_cached_node(
        nodes: list[dict[str, object]],
        cache: dict[tuple[float, float, float], int],
        coords: tuple[float, float, float],
) -> int:
    key = (round(float(coords[0]), 12), round(float(coords[1]), 12), round(float(coords[2]), 12))
    existing = cache.get(key)
    if existing is not None:
        return existing
    node_id = max((int(node["id"]) for node in nodes), default=0) + 1
    nodes.append({"id": node_id, "coords": [float(coords[0]), float(coords[1]), float(coords[2])]})
    cache[key] = node_id
    return node_id


def _member_section_dimension(section: dict[str, float], key: str, fallback: float = 0.0) -> float:
    try:
        return max(float(section.get(key, fallback) or 0.0), 0.0)
    except (TypeError, ValueError):
        return max(float(fallback), 0.0)


def _flange_beam_section(section: dict[str, float], fallback_thickness: float) -> dict[str, float]:
    width = _member_section_dimension(section, "flange_width")
    thickness = _member_section_dimension(section, "flange_thickness", fallback_thickness)
    if width <= 0.0 or thickness <= 0.0:
        return {}
    area = width * thickness
    result = {
        "area": area,
        "Iy": width * thickness ** 3 / 12.0,
        "Iz": thickness * width ** 3 / 12.0,
        "J": width * thickness * (width ** 2 + thickness ** 2) / 12.0,
        "web_height": thickness,
        "web_thickness": width,
        "flange_width": 0.0,
        "flange_thickness": 0.0,
        "label": "flange " + str(section.get("label", "")).strip(),
    }
    if bool(section.get("consistent_mass", False)):
        result["consistent_mass"] = True
    return result


def _append_member_shell(
        shells: list[dict[str, object]],
        element_id: int,
        node_ids: list[int],
        thickness: float,
        role: str,
) -> int:
    if len({int(node_id) for node_id in node_ids}) < 4 or thickness <= 0.0:
        return element_id
    shells.append(
        {
            "id": element_id,
            "node_ids": [int(node_id) for node_id in node_ids],
            "thickness": float(thickness),
            "material": "steel",
            "role": role,
        }
    )
    return element_id + 1


def _intersection_height_levels(
        intersection_heights: dict[float, list[float]] | None,
        coordinate: float,
        own_height: float,
) -> list[float]:
    if not intersection_heights:
        return []
    levels = []
    for height in intersection_heights.get(round(float(coordinate), 12), []):
        try:
            level = min(float(height), float(own_height))
        except (TypeError, ValueError):
            continue
        if 1.0e-9 < level < float(own_height) - 1.0e-9:
            levels.append(level)
    return levels


def _minimum_member_web_depth_segments(config: LightweightFEMConfig, web_height: float = 0.0) -> int:
    """Shell rows over a member web depth when webs are meshed as shells.

    Follows the selected mesh fidelity for every webs-as-shells member model
    (not only "all shell"), and honours an explicit mesh-size override so the
    web element height tracks the requested size.
    """

    if not _member_webs_as_shells(config):
        return 1
    segments = max(1, _fidelity_refinement(config.mesh_fidelity))
    mesh_size = _requested_mesh_size(config)
    if web_height > 0.0 and mesh_size > 0.0:
        segments = max(segments, int(math.ceil(web_height / mesh_size - 1.0e-9)))
    return segments


def _member_web_section_depth_levels(section: dict[str, float], config: LightweightFEMConfig) -> list[float]:
    web_height = _member_section_dimension(section, "web_height")
    if web_height <= 0.0:
        return []
    return _member_web_depth_levels(web_height, _minimum_member_web_depth_segments(config, web_height))


def _member_web_depth_levels(own_height: float, min_segments: int = 1, *endpoint_levels: list[float]) -> list[float]:
    levels = {0.0, round(float(own_height), 12)}
    segments = max(int(min_segments), 1)
    for index in range(1, segments):
        levels.add(round(float(own_height) * float(index) / float(segments), 12))
    for values in endpoint_levels:
        for value in values:
            if 1.0e-9 < float(value) < float(own_height) - 1.0e-9:
                levels.add(round(float(value), 12))
    return sorted(levels)


def _support_choice_from_any(value: object) -> str:
    text = _normalized_choice(value, "simply supported")
    if text in {"c", "cl", "clamped", "fixed", "continuous"}:
        return "fixed"
    if text in {"s", "ss", "simple", "simply", "simply supported", "sniped"}:
        return "simply supported"
    if text in {"free", "none", "off"}:
        return "free"
    return "simply supported"


def _normalize_plate_edge_supports(value: object) -> dict[str, str]:
    if isinstance(value, dict):
        return {key: _support_choice_from_any(value.get(key, "simply supported")) for key in ("x0", "x1", "y0", "y1")}
    if isinstance(value, (list, tuple)) and len(value) >= 4:
        return {key: _support_choice_from_any(value[index]) for index, key in enumerate(("x0", "x1", "y0", "y1"))}
    return {key: "simply supported" for key in ("x0", "x1", "y0", "y1")}


def _flat_edge_node_ids(node_id, rows: int, cols: int) -> dict[str, list[int]]:
    return {
        "x0": [node_id(0, col) for col in range(cols)],
        "x1": [node_id(rows - 1, col) for col in range(cols)],
        "y0": [node_id(row, 0) for row in range(rows)],
        "y1": [node_id(row, cols - 1) for row in range(rows)],
    }


def _flat_shell_edge_node_ids(
        nodes: list[dict[str, object]],
        shells: list[dict[str, object]],
        length: float,
        width: float,
) -> dict[str, list[int]]:
    shell_node_ids = {int(node_id) for shell in shells for node_id in shell.get("node_ids", [])}
    tol = max(float(length), float(width), 1.0) * 1.0e-8
    edge_nodes = {"x0": [], "x1": [], "y0": [], "y1": []}
    for node in nodes:
        node_id = int(node.get("id", 0) or 0)
        if node_id not in shell_node_ids:
            continue
        coords = node.get("coords", [0.0, 0.0, 0.0])
        x = float(coords[0])
        y = float(coords[1])
        if abs(x) <= tol:
            edge_nodes["x0"].append(node_id)
        if abs(x - length) <= tol:
            edge_nodes["x1"].append(node_id)
        if abs(y) <= tol:
            edge_nodes["y0"].append(node_id)
        if abs(y - width) <= tol:
            edge_nodes["y1"].append(node_id)
    return {key: sorted(set(value)) for key, value in edge_nodes.items()}


def _member_side_sign(geometry: dict) -> float:
    """+1 places members on the default side, -1 on the opposite side.

    Follows the main-application "Opposite side" checkbox: flat-panel members
    extrude to negative z instead of positive z, cylinder members outward
    instead of inward.
    """
    return -1.0 if bool(geometry.get("members_opposite_side")) else 1.0


def _add_flat_member_shell_model(
        nodes: list[dict[str, object]],
        shells: list[dict[str, object]],
        beams: list[dict[str, object]],
        node_cache: dict[tuple[float, float, float], int],
        element_id: int,
        beam_id: int,
        node_id,
        x_breaks: list[float],
        y_breaks: list[float],
        position: float,
        section: dict[str, float],
        role: str,
        direction: str,
        config: LightweightFEMConfig,
        intersection_heights: dict[float, list[float]] | None = None,
        side_sign: float = 1.0,
) -> tuple[int, int]:
    web_height = _member_section_dimension(section, "web_height")
    web_thickness = _member_section_dimension(section, "web_thickness")
    flange_width = _member_section_dimension(section, "flange_width")
    flange_thickness = _member_section_dimension(section, "flange_thickness")
    if web_height <= 0.0 or web_thickness <= 0.0:
        return element_id, beam_id

    side = 1.0 if float(side_sign) >= 0.0 else -1.0
    flange_section = _flange_beam_section(section, web_thickness)
    if direction == "x":
        col = _index_of_break(y_breaks, position)
        for row in range(len(x_breaks) - 1):
            x0 = float(x_breaks[row])
            x1 = float(x_breaks[row + 1])
            base0 = node_id(row, col)
            base1 = node_id(row + 1, col)
            left_levels = _intersection_height_levels(intersection_heights, x0, web_height)
            right_levels = _intersection_height_levels(intersection_heights, x1, web_height)
            z_levels = _member_web_depth_levels(
                web_height,
                _minimum_member_web_depth_segments(config, web_height),
                left_levels,
                right_levels,
            )

            def web_node(x: float, base_node: int, z: float) -> int:
                if abs(float(z)) <= 1.0e-12:
                    return base_node
                return _add_cached_node(nodes, node_cache, (x, position, side * float(z)))

            for lower, upper in zip(z_levels[:-1], z_levels[1:]):
                lower0 = web_node(x0, base0, lower)
                lower1 = web_node(x1, base1, lower)
                upper0 = web_node(x0, base0, upper)
                upper1 = web_node(x1, base1, upper)
                element_id = _append_member_shell(shells, element_id, [lower0, lower1, upper1, upper0], web_thickness, role + "_web")
            top0 = web_node(x0, base0, web_height)
            top1 = web_node(x1, base1, web_height)
            if _member_flanges_as_beams(config) and flange_section:
                beams.append({"id": beam_id, "node_ids": [top0, top1], "section": flange_section, "role": role + "_flange", "material": "steel"})
                beam_id += 1
            elif _member_flanges_as_shells(config) and flange_width > 0.0 and flange_thickness > 0.0:
                left0 = _add_cached_node(nodes, node_cache, (x0, position - 0.5 * flange_width, side * web_height))
                left1 = _add_cached_node(nodes, node_cache, (x1, position - 0.5 * flange_width, side * web_height))
                right0 = _add_cached_node(nodes, node_cache, (x0, position + 0.5 * flange_width, side * web_height))
                right1 = _add_cached_node(nodes, node_cache, (x1, position + 0.5 * flange_width, side * web_height))
                element_id = _append_member_shell(shells, element_id, [left0, left1, top1, top0], flange_thickness, role + "_flange")
                element_id = _append_member_shell(shells, element_id, [top0, top1, right1, right0], flange_thickness, role + "_flange")
        return element_id, beam_id

    row = _index_of_break(x_breaks, position)
    for col in range(len(y_breaks) - 1):
        y0 = float(y_breaks[col])
        y1 = float(y_breaks[col + 1])
        base0 = node_id(row, col)
        base1 = node_id(row, col + 1)
        lower_levels = _intersection_height_levels(intersection_heights, y0, web_height)
        upper_levels = _intersection_height_levels(intersection_heights, y1, web_height)
        z_levels = _member_web_depth_levels(
            web_height,
            _minimum_member_web_depth_segments(config, web_height),
            lower_levels,
            upper_levels,
        )

        def web_node(y: float, base_node: int, z: float) -> int:
            if abs(float(z)) <= 1.0e-12:
                return base_node
            return _add_cached_node(nodes, node_cache, (position, y, side * float(z)))

        for lower, upper in zip(z_levels[:-1], z_levels[1:]):
            lower0 = web_node(y0, base0, lower)
            lower1 = web_node(y1, base1, lower)
            upper0 = web_node(y0, base0, upper)
            upper1 = web_node(y1, base1, upper)
            element_id = _append_member_shell(shells, element_id, [lower0, lower1, upper1, upper0], web_thickness, role + "_web")
        top0 = web_node(y0, base0, web_height)
        top1 = web_node(y1, base1, web_height)
        if _member_flanges_as_beams(config) and flange_section:
            beams.append({"id": beam_id, "node_ids": [top0, top1], "section": flange_section, "role": role + "_flange", "material": "steel"})
            beam_id += 1
        elif _member_flanges_as_shells(config) and flange_width > 0.0 and flange_thickness > 0.0:
            left0 = _add_cached_node(nodes, node_cache, (position - 0.5 * flange_width, y0, side * web_height))
            left1 = _add_cached_node(nodes, node_cache, (position - 0.5 * flange_width, y1, side * web_height))
            right0 = _add_cached_node(nodes, node_cache, (position + 0.5 * flange_width, y0, side * web_height))
            right1 = _add_cached_node(nodes, node_cache, (position + 0.5 * flange_width, y1, side * web_height))
            element_id = _append_member_shell(shells, element_id, [left0, left1, top1, top0], flange_thickness, role + "_flange")
            element_id = _append_member_shell(shells, element_id, [top0, top1, right1, right0], flange_thickness, role + "_flange")
    return element_id, beam_id


def _flat_edge_supports(edge_nodes: dict[str, list[int]], choices: dict[str, object], node_id, rows: int) -> list[dict[str, object]]:
    supports: list[dict[str, object]] = []
    has_inplane_restraint = False
    for edge_name in ("x0", "x1", "y0", "y1"):
        choice = choices.get(edge_name, "simply supported")
        constraints = _support_constraints(choice, "flat")
        if not constraints:
            continue
        has_inplane_restraint = has_inplane_restraint or any(key in constraints for key in ("ux", "uy"))
        supports.append(
            {
                "name": "plate_" + edge_name + "_" + _normalized_choice(choice, "simply supported").replace(" ", "_"),
                "node_ids": sorted(set(int(node) for node in edge_nodes[edge_name])),
                "constraints": constraints,
            }
        )
    if supports and not has_inplane_restraint:
        supports.extend(
            [
                {"name": "simple_panel_inplane_anchor", "node_ids": [node_id(0, 0)], "constraints": {"ux": 0.0, "uy": 0.0}},
                {"name": "simple_panel_spin_anchor", "node_ids": [node_id(rows - 1, 0)], "constraints": {"uy": 0.0}},
            ]
        )
    return supports


def _flat_supports(
    boundary_nodes: list[int],
    node_id,
    rows: int,
    cols: int,
    config: LightweightFEMConfig,
    geometry: dict | None = None,
    edge_nodes: dict[str, list[int]] | None = None,
) -> list[dict[str, object]]:
    mode = _normalized_choice(config.boundary_condition)
    if mode in {"auto", "free", "none", "nullspace", "nullspace projection"}:
        choices = _normalize_plate_edge_supports((geometry or {}).get("plate_edge_supports"))
        return _flat_edge_supports(edge_nodes or _flat_edge_node_ids(node_id, rows, cols), choices, node_id, rows)
    if mode in {"simply supported", "simple", "ss"}:
        return [
            {"name": "simple_panel_boundary", "node_ids": boundary_nodes, "constraints": {"uz": 0.0}},
            {"name": "simple_panel_inplane_anchor", "node_ids": [node_id(0, 0)], "constraints": {"ux": 0.0, "uy": 0.0}},
            {"name": "simple_panel_spin_anchor", "node_ids": [node_id(rows - 1, 0)], "constraints": {"uy": 0.0}},
        ]
    if mode in {"pinned", "pinned edges"}:
        return [
            {
                "name": "pinned_panel_boundary",
                "node_ids": boundary_nodes,
                "constraints": {"ux": 0.0, "uy": 0.0, "uz": 0.0},
            }
        ]
    return [
        {
            "name": "clamped_panel_boundary",
            "node_ids": boundary_nodes,
            "constraints": {"ux": 0.0, "uy": 0.0, "uz": 0.0, "rx": 0.0, "ry": 0.0, "rz": 0.0},
        }
    ]


def _support_constraints(choice: object, geometry: str = "flat") -> dict[str, float]:
    mode = _normalized_choice(choice, "free")
    if mode in {"free", "none", "off", "nullspace", "nullspace projection"}:
        return {}
    if mode in {"simple", "simply", "simply supported", "ss"}:
        return {"uz": 0.0}
    if geometry == "cylinder" and mode in {"fixed", "clamped"}:
        return {"ux": 0.0, "uy": 0.0, "uz": 0.0}
    if mode in {"fixed", "clamped"}:
        return {"ux": 0.0, "uy": 0.0, "uz": 0.0, "rx": 0.0, "ry": 0.0, "rz": 0.0}
    return {}


def _custom_flat_supports(
        node_id,
        rows: int,
        cols: int,
        config: LightweightFEMConfig,
        edge_nodes: dict[str, list[int]] | None = None,
) -> list[dict[str, object]]:
    if config.custom_use_nullspace_projection:
        return []
    edge_nodes = edge_nodes or _flat_edge_node_ids(node_id, rows, cols)
    edges = (
        ("x0", edge_nodes["x0"], config.plate_edge_x0_support),
        ("x1", edge_nodes["x1"], config.plate_edge_x1_support),
        ("y0", edge_nodes["y0"], config.plate_edge_y0_support),
        ("y1", edge_nodes["y1"], config.plate_edge_y1_support),
    )
    supports = []
    for edge_name, node_ids, choice in edges:
        constraints = _support_constraints(choice, "flat")
        if constraints:
            supports.append(
                {
                    "name": "custom_plate_" + edge_name + "_" + _normalized_choice(choice, "free").replace(" ", "_"),
                    "node_ids": sorted(set(int(node) for node in node_ids)),
                    "constraints": constraints,
                }
            )
    return supports


def _cylinder_supports(
        rows: int,
        cols: int,
        node_id,
        config: LightweightFEMConfig,
        lower_ring: list[int] | None = None,
        upper_ring: list[int] | None = None,
) -> list[dict[str, object]]:
    mode = _normalized_choice(config.boundary_condition)
    if mode in {"free", "none", "nullspace", "nullspace projection"}:
        return []
    if mode in {"clamped", "fixed", "fixed ends"}:
        bottom = lower_ring or [node_id(0, col) for col in range(cols)]
        top = upper_ring or [node_id(rows - 1, col) for col in range(cols)]
        return [
            {
                "name": "clamped_cylinder_ends",
                "node_ids": bottom + top,
                "constraints": {"ux": 0.0, "uy": 0.0, "uz": 0.0, "rx": 0.0, "ry": 0.0, "rz": 0.0},
            }
        ]
    return [
        {"name": "rigid_body_anchor", "node_ids": [node_id(0, 0)], "constraints": {"ux": 0.0, "uy": 0.0, "uz": 0.0}},
        {"name": "rigid_body_spin_anchor", "node_ids": [node_id(0, cols // 4)], "constraints": {"ux": 0.0}},
        {"name": "rigid_body_tilt_anchor", "node_ids": [node_id(1, 0)], "constraints": {"uy": 0.0}},
    ]


def _cylinder_lid_boundary_supports(
        lower_center_nodes: list[int],
        upper_center_nodes: list[int],
        config: LightweightFEMConfig,
) -> list[dict[str, object]]:
    mode = _normalized_choice(config.boundary_condition)
    if mode in {"clamped", "fixed", "fixed ends"}:
        return [
            {
                "name": "clamped_cylinder_lid_references",
                "node_ids": sorted(set(int(node) for node in lower_center_nodes + upper_center_nodes)),
                "constraints": {"ux": 0.0, "uy": 0.0, "uz": 0.0, "rx": 0.0, "ry": 0.0, "rz": 0.0},
            }
        ]
    if mode in {"anchored", "anchor", "rigid body anchor"}:
        # Explicit opt-in: ground the lower lid reference so displacements are
        # measured from a fixed bottom end.
        return [
            {
                "name": "rigid_body_anchor",
                "node_ids": sorted(set(int(node) for node in lower_center_nodes)),
                "constraints": {"ux": 0.0, "uy": 0.0, "uz": 0.0, "rx": 0.0, "ry": 0.0, "rz": 0.0},
            }
        ]
    # auto/free/nullspace: no lid supports.  Balanced free-free cylinders are
    # carried by the automatic rigid-body nullspace projection, preserving the
    # verified symmetric membrane solution: a balanced axial force must give
    # uz = sigma*L/(2E) at each end, not sigma*L/E from an anchored bottom.
    return []


def _custom_cylinder_supports(lower_ring: list[int], upper_ring: list[int], config: LightweightFEMConfig) -> list[dict[str, object]]:
    if config.custom_use_nullspace_projection:
        return []
    supports = []
    for name, ring_nodes, choice in (
        ("lower", lower_ring, config.cylinder_lower_support),
        ("upper", upper_ring, config.cylinder_upper_support),
    ):
        constraints = _support_constraints(choice, "cylinder")
        if constraints:
            supports.append(
                {
                    "name": "custom_cylinder_" + name + "_" + _normalized_choice(choice, "free").replace(" ", "_"),
                    "node_ids": sorted(set(int(node) for node in ring_nodes)),
                    "constraints": constraints,
                }
            )
    return supports


def _cylinder_lid_reference_support_constraints(choice: object) -> dict[str, float]:
    mode = _normalized_choice(choice, "free")
    if mode in {"free", "none", "off", "nullspace", "nullspace projection"}:
        return {}
    if mode in {"simple", "simply", "simply supported", "ss"}:
        return {"uz": 0.0, "rx": 0.0, "ry": 0.0}
    if mode in {"fixed", "clamped"}:
        return {"ux": 0.0, "uy": 0.0, "uz": 0.0, "rx": 0.0, "ry": 0.0, "rz": 0.0}
    return {}


def _custom_cylinder_lid_reference_supports(
        lower_center_nodes: list[int],
        upper_center_nodes: list[int],
        config: LightweightFEMConfig,
) -> list[dict[str, object]]:
    if config.custom_use_nullspace_projection:
        return []
    supports = []
    for name, center_nodes, choice in (
        ("lower", lower_center_nodes, config.cylinder_lower_support),
        ("upper", upper_center_nodes, config.cylinder_upper_support),
    ):
        constraints = _cylinder_lid_reference_support_constraints(choice)
        if constraints:
            supports.append(
                {
                    "name": "custom_cylinder_" + name + "_" + _normalized_choice(choice, "free").replace(" ", "_"),
                    "node_ids": sorted(set(int(node) for node in center_nodes)),
                    "constraints": constraints,
                }
            )
    return supports


def _cylinder_point(radius: float, theta: float, z: float) -> tuple[float, float, float]:
    return (radius * math.cos(theta), radius * math.sin(theta), float(z))


def _add_cylinder_member_shell_model(
        nodes: list[dict[str, object]],
        shells: list[dict[str, object]],
        beams: list[dict[str, object]],
        node_cache: dict[tuple[float, float, float], int],
        element_id: int,
        beam_id: int,
        node_id,
        z_breaks: list[float],
        cols: int,
        reference_radius: float,
        radius_at_z,
        section: dict[str, float],
        role: str,
        index: int,
        config: LightweightFEMConfig,
        intersection_heights: dict[float, list[float]] | None = None,
        arc_breaks: list[float] | None = None,
        side_sign: float = 1.0,
) -> tuple[int, int]:
    web_height = _member_section_dimension(section, "web_height")
    web_thickness = _member_section_dimension(section, "web_thickness")
    flange_width = _member_section_dimension(section, "flange_width")
    flange_thickness = _member_section_dimension(section, "flange_thickness")
    if web_height <= 0.0 or web_thickness <= 0.0:
        return element_id, beam_id
    flange_section = _flange_beam_section(section, web_thickness)
    # +1 extrudes member webs inward (default), -1 outward (opposite side).
    side = 1.0 if float(side_sign) >= 0.0 else -1.0

    def member_radius(base_radius: float, depth: float) -> float:
        return max(float(base_radius) - side * float(depth), 1.0e-6)

    def theta_at_col(col_index: int) -> float:
        if arc_breaks and len(arc_breaks) >= 2:
            index = int(col_index)
            if index >= cols:
                return float(arc_breaks[-1]) / max(reference_radius, 1.0e-9)
            return float(arc_breaks[index % max(cols, 1)]) / max(reference_radius, 1.0e-9)
        return 2.0 * math.pi * int(col_index) / max(cols, 1)

    if role == "stiffener":
        col = int(index) % max(cols, 1)
        theta = theta_at_col(col)
        for row in range(len(z_breaks) - 1):
            z0 = float(z_breaks[row])
            z1 = float(z_breaks[row + 1])
            base0 = node_id(row, col)
            base1 = node_id(row + 1, col)
            start_levels = _intersection_height_levels(intersection_heights, z0, web_height)
            end_levels = _intersection_height_levels(intersection_heights, z1, web_height)
            depth_levels = _member_web_depth_levels(
                web_height,
                _minimum_member_web_depth_segments(config, web_height),
                start_levels,
                end_levels,
            )

            def web_node(z: float, base_node: int, depth: float) -> int:
                if abs(float(depth)) <= 1.0e-12:
                    return base_node
                current_radius = radius_at_z(z)
                return _add_cached_node(nodes, node_cache, _cylinder_point(member_radius(current_radius, depth), theta, z))

            for outer_depth, inner_depth in zip(depth_levels[:-1], depth_levels[1:]):
                outer0 = web_node(z0, base0, outer_depth)
                outer1 = web_node(z1, base1, outer_depth)
                inner0 = web_node(z0, base0, inner_depth)
                inner1 = web_node(z1, base1, inner_depth)
                element_id = _append_member_shell(shells, element_id, [outer0, outer1, inner1, inner0], web_thickness, role + "_web")
            top0 = web_node(z0, base0, web_height)
            top1 = web_node(z1, base1, web_height)
            if _member_flanges_as_beams(config) and flange_section:
                beams.append({"id": beam_id, "node_ids": [top0, top1], "section": flange_section, "role": role + "_flange", "material": "steel"})
                beam_id += 1
            elif _member_flanges_as_shells(config) and flange_width > 0.0 and flange_thickness > 0.0:
                inner_r0 = member_radius(radius_at_z(z0), web_height)
                inner_r1 = member_radius(radius_at_z(z1), web_height)
                dtheta0 = 0.5 * flange_width / inner_r0 if inner_r0 > 0.0 else 0.0
                dtheta1 = 0.5 * flange_width / inner_r1 if inner_r1 > 0.0 else 0.0
                left0 = _add_cached_node(nodes, node_cache, _cylinder_point(inner_r0, theta - dtheta0, z0))
                left1 = _add_cached_node(nodes, node_cache, _cylinder_point(inner_r1, theta - dtheta1, z1))
                right0 = _add_cached_node(nodes, node_cache, _cylinder_point(inner_r0, theta + dtheta0, z0))
                right1 = _add_cached_node(nodes, node_cache, _cylinder_point(inner_r1, theta + dtheta1, z1))
                element_id = _append_member_shell(shells, element_id, [left0, left1, top1, top0], flange_thickness, role + "_flange")
                element_id = _append_member_shell(shells, element_id, [top0, top1, right1, right0], flange_thickness, role + "_flange")
        return element_id, beam_id

    row = int(index)
    z = float(z_breaks[row])
    current_radius = radius_at_z(z)
    inner_radius = member_radius(current_radius, web_height)
    for col in range(cols):
        theta0 = theta_at_col(col)
        theta1 = theta_at_col(col + 1)
        base0 = node_id(row, col)
        base1 = node_id(row, col + 1)
        start_levels = _intersection_height_levels(intersection_heights, float(col % max(cols, 1)), web_height)
        end_levels = _intersection_height_levels(intersection_heights, float((col + 1) % max(cols, 1)), web_height)
        depth_levels = _member_web_depth_levels(
            web_height,
            _minimum_member_web_depth_segments(config, web_height),
            start_levels,
            end_levels,
        )

        def web_node(theta: float, base_node: int, depth: float) -> int:
            if abs(float(depth)) <= 1.0e-12:
                return base_node
            return _add_cached_node(nodes, node_cache, _cylinder_point(member_radius(current_radius, depth), theta, z))

        for outer_depth, inner_depth in zip(depth_levels[:-1], depth_levels[1:]):
            outer0 = web_node(theta0, base0, outer_depth)
            outer1 = web_node(theta1, base1, outer_depth)
            inner0 = web_node(theta0, base0, inner_depth)
            inner1 = web_node(theta1, base1, inner_depth)
            element_id = _append_member_shell(shells, element_id, [outer0, outer1, inner1, inner0], web_thickness, role + "_web")
        top0 = web_node(theta0, base0, web_height)
        top1 = web_node(theta1, base1, web_height)
        if _member_flanges_as_beams(config) and flange_section:
            beams.append({"id": beam_id, "node_ids": [top0, top1], "section": flange_section, "role": role + "_flange", "material": "steel"})
            beam_id += 1
        elif _member_flanges_as_shells(config) and flange_width > 0.0 and flange_thickness > 0.0:
            z_minus = z - 0.5 * flange_width
            z_plus = z + 0.5 * flange_width
            lower0 = _add_cached_node(nodes, node_cache, _cylinder_point(inner_radius, theta0, z_minus))
            lower1 = _add_cached_node(nodes, node_cache, _cylinder_point(inner_radius, theta1, z_minus))
            upper0 = _add_cached_node(nodes, node_cache, _cylinder_point(inner_radius, theta0, z_plus))
            upper1 = _add_cached_node(nodes, node_cache, _cylinder_point(inner_radius, theta1, z_plus))
            element_id = _append_member_shell(shells, element_id, [lower0, lower1, top1, top0], flange_thickness, role + "_flange")
            element_id = _append_member_shell(shells, element_id, [top0, top1, upper1, upper0], flange_thickness, role + "_flange")
    return element_id, beam_id


def _flat_generated_geometry(geometry: dict, config: LightweightFEMConfig) -> dict[str, object]:
    orientation = config.member_orientation
    if _normalized_choice(orientation) == "auto":
        orientation = "global z"
    length = _positive(geometry.get("length_m", 1.0), 1.0)
    width = _positive(geometry.get("width_m", 1.0), 1.0)
    thickness = _positive(geometry.get("thickness_m", 0.01), 0.01)
    base_div = _production_divisions(config.mesh_fidelity)
    stiffener_spacing = _positive_spacing(geometry.get("stiffener_spacing_m", 0.0))
    girder_spacing = _positive_spacing(geometry.get("girder_spacing_m", 0.0))
    active_stiffener_spacing = (
        stiffener_spacing
        if config.include_stiffeners and geometry.get("has_stiffener")
        else 0.0
    )
    active_girder_spacing = (
        girder_spacing
        if config.include_girders and geometry.get("has_girder")
        else 0.0
    )
    member_spacing_cap = min(
        [value for value in (active_stiffener_spacing, active_girder_spacing) if value > 0.0],
        default=0.0,
    )
    member_shell_cap = _member_shell_length_cap(geometry, config, thickness)
    if member_shell_cap > 0.0:
        member_spacing_cap = min([value for value in (member_spacing_cap, member_shell_cap) if value > 0.0], default=member_shell_cap)
    # Members bound their bays: stations are symmetric about the panel centre
    # and sit on the panel edges when the length is an exact multiple, so the
    # generated model matches the calculated span/spacing exactly.
    stiffener_positions = (
        _centered_member_positions(width, stiffener_spacing, fallback_midpoint=True, include_ends=True)
        if config.include_stiffeners and geometry.get("has_stiffener")
        else ()
    )
    girder_positions = (
        _centered_member_positions(length, girder_spacing, fallback_midpoint=True, include_ends=True)
        if config.include_girders and geometry.get("has_girder")
        else ()
    )
    div_x = _line_divisions(length, config, base_div, member_spacing_cap)
    div_y = _line_divisions(width, config, base_div, member_spacing_cap)
    custom_x_breaks = _custom_patch_axis_breaks(config, "a", length) + _thickness_region_axis_breaks(config, "a", length)
    custom_y_breaks = _custom_patch_axis_breaks(config, "b", width) + _thickness_region_axis_breaks(config, "b", width)
    mandatory_x = tuple(girder_positions) + custom_x_breaks
    mandatory_y = tuple(stiffener_positions) + custom_y_breaks
    x_breaks = _axis_breaks(length, div_x, mandatory_x, member_spacing_cap)
    y_breaks = _axis_breaks(width, div_y, mandatory_y, member_spacing_cap)
    global_base_x = length / max(len(x_breaks) - 1, 1)
    global_base_y = width / max(len(y_breaks) - 1, 1)
    mesh_generation: dict[str, object] = {}

    adaptive_sources: list[dict[str, object]] = []
    adaptive_mesh_info: dict[str, object] = {"enabled": False, "sources": adaptive_sources}
    # The local-patch transition keeps the base grid uniform and refines
    # conformally afterwards; it needs plain linear quads and beam members.
    use_local_patch = (
        _wants_local_patch_transition(config)
        and not _member_webs_as_shells(config)
        and not _wants_b3(config)
        and not _wants_s6(config)
        and not _wants_s8(config)
    )
    if bool(config.point_refinement_enabled) and not use_local_patch:
        x_breaks, y_breaks, point_refinement_info = _apply_detail_point_refinement(
            length,
            width,
            thickness,
            x_breaks,
            y_breaks,
            mandatory_x,
            mandatory_y,
            float(config.point_refinement_x_m),
            float(config.point_refinement_y_m),
            float(config.point_refinement_fine_size_m),
            float(config.point_refinement_fine_factor),
            float(config.point_refinement_extent_m),
            float(config.point_refinement_growth_factor),
            "selected_point",
            coarse_x=global_base_x,
            coarse_y=global_base_y,
        )
        adaptive_sources.append(point_refinement_info)
        adaptive_mesh_info = {
            **point_refinement_info,
            "enabled": True,
            "sources": adaptive_sources,
        }

    if not use_local_patch:
        x_breaks, y_breaks, panel_refinement_info = _apply_local_patch_refinement(
            config,
            length,
            width,
            thickness,
            x_breaks,
            y_breaks,
            mandatory_x,
            mandatory_y,
        )
        if panel_refinement_info.get("enabled"):
            adaptive_sources.append(panel_refinement_info)
            adaptive_mesh_info = {
                **panel_refinement_info,
                "enabled": True,
                "sources": adaptive_sources,
            }

    if bool(config.collision_adaptive_mesh_enabled) and bool(config.collision_enabled) and not use_local_patch:
        impact = _collision_impact_point(config, length, width)
        if impact is not None:
            zone_factor = max(float(config.collision_adaptive_zone_factor), 0.5)
            radius = max(float(config.collision_radius_m), 1.0e-6)
            extent = float(config.collision_adaptive_extent_m or 0.0)
            if extent <= 0.0:
                extent = radius * zone_factor
            x_breaks, y_breaks, impact_refinement_info = _apply_detail_point_refinement(
                length,
                width,
                thickness,
                x_breaks,
                y_breaks,
                mandatory_x,
                mandatory_y,
                impact[0],
                impact[1],
                float(config.collision_adaptive_fine_size_m),
                float(config.collision_adaptive_fine_factor),
                extent,
                float(config.collision_adaptive_growth_factor),
                "impact",
                coarse_x=global_base_x,
                coarse_y=global_base_y,
                extra={
                    "impact_point_m": [float(impact[0]), float(impact[1])],
                    "fine_radius_m": float(extent),
                    "sphere_radius_m": float(radius),
                },
            )
            adaptive_sources.append(impact_refinement_info)
            adaptive_mesh_info = {
                **impact_refinement_info,
                "enabled": True,
                "sources": adaptive_sources,
            }

    def add_breakpoint(values: list[float], value: object, limit: float) -> list[float]:
        coordinate = float(value or 0.0)
        if 1.0e-9 < coordinate < limit - 1.0e-9:
            values.append(coordinate)
        return sorted(set(round(float(item), 12) for item in values))

    if config.custom_load_bc_enabled:
        if custom_x_breaks or custom_y_breaks:
            mesh_generation["pressure_patch_boundary_breaks"] = "flat_exact"
        for segment in list(_custom_edge_segments(config)) + list(_custom_bc_segments(config)):
            if str(segment.get("varying_axis", "a")).lower() == "a":
                y_breaks = add_breakpoint(y_breaks, segment.get("fixed_coordinate"), width)
                x_breaks = add_breakpoint(x_breaks, segment.get("start_coordinate"), length)
                x_breaks = add_breakpoint(x_breaks, segment.get("end_coordinate"), length)
            else:
                x_breaks = add_breakpoint(x_breaks, segment.get("fixed_coordinate"), length)
                y_breaks = add_breakpoint(y_breaks, segment.get("start_coordinate"), width)
                y_breaks = add_breakpoint(y_breaks, segment.get("end_coordinate"), width)

    if _wants_b3(config):
        if stiffener_positions:
            x_breaks = _refined_midpoint_breaks(x_breaks)
        if girder_positions:
            y_breaks = _refined_midpoint_breaks(y_breaks)

    rows = len(x_breaks)
    cols = len(y_breaks)

    def node_id(row: int, col: int) -> int:
        return 1 + row * cols + col

    nodes = [
        {
            "id": node_id(row, col),
            "coords": [x_breaks[row], y_breaks[col], 0.0],
        }
        for row in range(rows)
        for col in range(cols)
    ]
    shells = []
    element_id = 1
    for row in range(rows - 1):
        for col in range(cols - 1):
            shells.append(
                {
                    "id": element_id,
                    "node_ids": [
                        node_id(row, col),
                        node_id(row + 1, col),
                        node_id(row + 1, col + 1),
                        node_id(row, col + 1),
                    ],
                    "thickness": thickness,
                    "material": "steel",
                }
            )
            element_id += 1
    thickness_region_info = _apply_thickness_regions(
        shells,
        nodes,
        config,
        lambda coords: (float(coords[0]), float(coords[1])),
    )

    beams = []
    beam_id = 20_001
    node_cache = _node_cache_from_nodes(nodes)
    member_side = _member_side_sign(geometry)
    stiffener_sections: dict[float, dict[str, float]] = {}
    girder_sections: dict[float, dict[str, float]] = {}
    for stiffener_y in stiffener_positions:
        stiffener_sections[float(stiffener_y)] = _section_with_runtime_options(
            geometry.get("stiffener_section"),
            thickness,
            width,
            0.08,
            member_side * config.stiffener_eccentricity_m,
            orientation,
            config.beam_consistent_mass_enabled,
        )
    for girder_x in girder_positions:
        girder_sections[float(girder_x)] = _section_with_runtime_options(
            geometry.get("girder_section"),
            thickness,
            length,
            0.10,
            member_side * config.girder_eccentricity_m,
            orientation,
            config.beam_consistent_mass_enabled,
        )
    stiffener_web_intersections = {
        round(float(girder_x), 12): _member_web_section_depth_levels(section, config)
        for girder_x, section in girder_sections.items()
    }
    girder_web_intersections = {
        round(float(stiffener_y), 12): _member_web_section_depth_levels(section, config)
        for stiffener_y, section in stiffener_sections.items()
    }
    for stiffener_y in stiffener_positions:
        mid_col = _index_of_break(y_breaks, stiffener_y)
        section = stiffener_sections[float(stiffener_y)]
        if _member_webs_as_shells(config):
            element_id, beam_id = _add_flat_member_shell_model(
                nodes,
                shells,
                beams,
                node_cache,
                element_id,
                beam_id,
                node_id,
                x_breaks,
                y_breaks,
                stiffener_y,
                section,
                "stiffener",
                "x",
                config,
                intersection_heights=stiffener_web_intersections,
                side_sign=member_side,
            )
            continue
        row_range = range(0, rows - 2, 2) if _wants_b3(config) else range(rows - 1)
        for row in row_range:
            beam_nodes = (
                [node_id(row, mid_col), node_id(row + 1, mid_col), node_id(row + 2, mid_col)]
                if _wants_b3(config)
                else [node_id(row, mid_col), node_id(row + 1, mid_col)]
            )
            beams.append(
                {
                    "id": beam_id,
                    "node_ids": beam_nodes,
                    "section": section,
                    "role": "stiffener",
                    "material": "steel",
                }
            )
            beam_id += 1
    for girder_x in girder_positions:
        mid_row = _index_of_break(x_breaks, girder_x)
        section = girder_sections[float(girder_x)]
        if _member_webs_as_shells(config):
            element_id, beam_id = _add_flat_member_shell_model(
                nodes,
                shells,
                beams,
                node_cache,
                element_id,
                beam_id,
                node_id,
                x_breaks,
                y_breaks,
                girder_x,
                section,
                "girder",
                "y",
                config,
                intersection_heights=girder_web_intersections,
                side_sign=member_side,
            )
            continue
        col_range = range(0, cols - 2, 2) if _wants_b3(config) else range(cols - 1)
        for col in col_range:
            beam_nodes = (
                [node_id(mid_row, col), node_id(mid_row, col + 1), node_id(mid_row, col + 2)]
                if _wants_b3(config)
                else [node_id(mid_row, col), node_id(mid_row, col + 1)]
            )
            beams.append(
                {
                    "id": beam_id,
                    "node_ids": beam_nodes,
                    "section": section,
                    "role": "girder",
                    "material": "steel",
                }
            )
            beam_id += 1

    local_patch_info: dict[str, object] | None = None
    if use_local_patch:
        patch_windows = _local_patch_detail_windows(
            config,
            length,
            width,
            min(global_base_x, global_base_y),
            thickness,
        )
        if patch_windows:
            local_patch_info = _apply_local_patch_transition(
                nodes,
                shells,
                beams,
                patch_windows,
                length,
                width,
                point_of_param=lambda u, v: (u, v, 0.0),
                param_of_coords=lambda coords: (float(coords[0]), float(coords[1])),
                periodic_v=False,
            )
            if local_patch_info:
                adaptive_sources.extend(local_patch_info["sources"])
                adaptive_mesh_info = {
                    **{k: v for k, v in local_patch_info.items() if k not in ("sources", "new_edge_parents")},
                    "enabled": True,
                    "sources": adaptive_sources,
                }

    if _wants_s6(config):
        _split_shells_to_triangles(nodes, shells, quadratic=True, element_type="S6")
    elif _wants_s3(config):
        _split_shells_to_triangles(nodes, shells, quadratic=False, element_type="S3")
    elif _wants_s8(config):
        elem_type = "S8R" if "s8r" in config.shell_element_order.lower() else "S8"
        _upgrade_shells_to_s8(nodes, shells, element_type=elem_type)
    _bind_runtime_qualified_s3_authority(nodes, shells)

    couplings = _offset_beam_nodes_and_couplings(
        nodes,
        beams,
        config,
        lambda _node_id, _coord: np.array([0.0, 0.0, 1.0], dtype=float),
    )
    edge_nodes = _flat_shell_edge_node_ids(nodes, shells, length, width)
    boundary_nodes = sorted({node for values in edge_nodes.values() for node in values})
    # Boundary construction is independent of the load-source policy.  In
    # particular, enabling custom loads must not bypass the per-edge DOF grid
    # shown on the Boundary conditions tab.
    boundary_map = _boundary_constraint_map(config)
    edge_supports = _custom_bc_segment_supports(nodes, config, length, width)
    custom_nullspace = bool(config.custom_load_bc_enabled and config.custom_use_nullspace_projection)
    if custom_nullspace:
        supports = []
    elif boundary_map:
        supports = _whole_boundary_constraint_supports(
            {key: list(edge_nodes.get(key, [])) for key in _FLAT_EDGE_KEYS},
            config, exclude_dofs_by_node=_edge_support_dofs_by_node(edge_supports))
    elif config.custom_load_bc_enabled and _has_custom_support(config):
        # Preserve legacy custom-support selections when loading an older
        # saved model that has no per-edge boundary map.
        supports = _custom_flat_supports(node_id, rows, cols, config, edge_nodes=edge_nodes)
    elif bool(getattr(config, "boundary_auto_supports", True)):
        supports = _flat_supports(boundary_nodes, node_id, rows, cols, config, geometry, edge_nodes=edge_nodes)
    else:
        supports = []
    supports.extend(edge_supports)
    supports.extend(_symmetry_supports(nodes, config))
    if not boundary_map and not config.custom_load_bc_enabled:
        supports.extend(_enforced_displacement_supports(nodes, config, "flat", exclude_node_ids=set(boundary_nodes)))
    return {
        "name": "ANYsolverFlatPanelFullMesh",
        "thickness_regions": thickness_region_info,
        "nodes": nodes,
        "shells": shells,
        "beams": beams,
        "couplings": couplings,
        "supports": supports,
        "materials": [
            {
                "name": "steel",
                "elastic_modulus": config.elastic_modulus_pa,
                "poisson_ratio": config.poisson_ratio,
                "density": 7850.0,
                "yield_stress": config.yield_stress_pa,
            }
        ],
        "plot_grid": [[node_id(row, col) for col in range(cols)] for row in range(rows)],
        "plot_type": "flat",
        "mesh_generation": mesh_generation,
        "mesh_metrics": _patched_mesh_metrics(
            _mesh_metrics_from_breaks(x_breaks, y_breaks, len(shells), len(nodes)),
            local_patch_info,
            len(shells),
            len(nodes),
        ),
        "adaptive_mesh": adaptive_mesh_info,
    }


def _patched_mesh_metrics(
    metrics: dict[str, float | int],
    local_patch_info: dict[str, object] | None,
    shell_count: int,
    node_count: int,
) -> dict[str, float | int]:
    """Adjust break-based mesh metrics for a local-patch refined mesh."""
    if not local_patch_info:
        return metrics
    fine = float(local_patch_info.get("fine_element_size_m", 0.0) or 0.0)
    adjusted = dict(metrics)
    adjusted["shell_element_count"] = int(shell_count)
    adjusted["node_count"] = int(node_count)
    if fine > 0.0:
        adjusted["min_element_size_m"] = fine
        max_size = float(adjusted.get("max_element_size_m", 0.0) or 0.0)
        if max_size > 0.0:
            adjusted["min_edge_over_max_edge"] = fine / max_size
    return adjusted


def _mesh_metrics_from_breaks(
    x_breaks: list[float], y_breaks: list[float], shell_count: int, node_count: int
) -> dict[str, float | int]:
    """Concrete mesh sizing metrics for GUI display (what 'fine' actually means)."""
    dx = np.diff(np.asarray(x_breaks, dtype=float)) if len(x_breaks) > 1 else np.asarray([0.0])
    dy = np.diff(np.asarray(y_breaks, dtype=float)) if len(y_breaks) > 1 else np.asarray([0.0])
    edges = np.concatenate([dx, dy])
    edges = edges[edges > 0.0]
    if edges.size == 0:
        edges = np.asarray([0.0])
    diagonals = np.sqrt(dx[:, None] ** 2 + dy[None, :] ** 2).reshape(-1) if dx.size and dy.size else edges
    return {
        "shell_element_count": int(shell_count),
        "node_count": int(node_count),
        "nominal_element_size_m": float(np.median(edges)),
        "min_element_size_m": float(edges.min()),
        "max_element_size_m": float(edges.max()),
        "min_edge_over_max_edge": float(edges.min() / edges.max()) if edges.max() > 0.0 else 1.0,
        "max_diagonal_m": float(diagonals.max()),
    }


def _mesh_metrics_from_cylinder_breaks(
    z_breaks: list[float],
    arc_breaks: list[float],
    shell_count: int,
    node_count: int,
) -> dict[str, float | int]:
    dz = np.diff(np.asarray(z_breaks, dtype=float)) if len(z_breaks) > 1 else np.asarray([0.0])
    da = np.diff(np.asarray(arc_breaks, dtype=float)) if len(arc_breaks) > 1 else np.asarray([0.0])
    edges = np.concatenate([dz, da])
    edges = edges[edges > 0.0]
    if edges.size == 0:
        edges = np.asarray([0.0])
    diagonals = np.sqrt(dz[:, None] ** 2 + da[None, :] ** 2).reshape(-1) if dz.size and da.size else edges
    return {
        "shell_element_count": int(shell_count),
        "node_count": int(node_count),
        "nominal_element_size_m": float(np.median(edges)),
        "min_element_size_m": float(edges.min()),
        "max_element_size_m": float(edges.max()),
        "min_edge_over_max_edge": float(edges.min() / edges.max()) if edges.max() > 0.0 else 1.0,
        "max_diagonal_m": float(diagonals.max()) if diagonals.size else 0.0,
    }


def _cylinder_generated_geometry(geometry: dict, config: LightweightFEMConfig) -> dict[str, object]:
    orientation = config.member_orientation
    if _normalized_choice(orientation) == "auto":
        orientation = "radial"
    is_cone = geometry.get("is_cone", False)
    cone_r1 = _positive(geometry.get("cone_r1_m", 1.0), 1.0)
    cone_r2 = _positive(geometry.get("cone_r2_m", 1.0), 1.0)
    cone_length = _positive(geometry.get("cone_length_m", 1.0), 1.0)

    radius = _positive(geometry.get("radius_m", 1.0), 1.0)
    length = _positive(geometry.get("length_m", 1.0), 1.0)

    if is_cone:
        length = cone_length
        radius = (cone_r1 + cone_r2) / 2.0  # Equivalent reference radius

    def radius_at_z(z: float) -> float:
        if not is_cone:
            return radius
        if length <= 1.0e-9:
            return cone_r1
        return cone_r1 + (cone_r2 - cone_r1) * (z / length)

    thickness = _positive(geometry.get("thickness_m", 0.01), 0.01)
    circumference = 2.0 * math.pi * radius
    stiffener_spacing = _positive_spacing(geometry.get("stiffener_spacing_m", 0.0))
    active_stiffener_spacing = (
        stiffener_spacing
        if config.include_stiffeners and geometry.get("has_stiffener")
        else 0.0
    )
    stiffener_count = (
        _member_count_from_spacing(circumference, stiffener_spacing)
        if config.include_stiffeners and geometry.get("has_stiffener")
        else 0
    )
    girder_spacing = (
        _positive_spacing(geometry.get("girder_spacing_m", 0.0))
        if config.include_girders and geometry.get("has_girder")
        else 0.0
    )
    mesh_size = _requested_mesh_size(config)
    mesh_size_cap = min(
        [value for value in (active_stiffener_spacing, girder_spacing) if value > 0.0],
        default=0.0,
    )
    mesh_generation: dict[str, object] = {}
    member_shell_cap = _member_shell_length_cap(geometry, config, thickness)
    if member_shell_cap > 0.0:
        mesh_size_cap = min([value for value in (mesh_size_cap, member_shell_cap) if value > 0.0], default=member_shell_cap)
    patch_width_a = _custom_patch_min_width(config, "a")
    patch_width_b = _custom_patch_min_width(config, "b")
    if patch_width_a > 0.0:
        mesh_size_cap = min([value for value in (mesh_size_cap, 0.5 * patch_width_a) if value > 0.0], default=0.5 * patch_width_a)
        mesh_generation["pressure_patch_min_axial_width_m"] = patch_width_a
    if patch_width_b > 0.0 and circumference > 0.0:
        circumferential_div = max(8, int(math.ceil(circumference / max(0.5 * patch_width_b, 1.0e-9))))
        mesh_generation["pressure_patch_min_circumferential_width_m"] = patch_width_b
    else:
        circumferential_div = 0
    if mesh_size > 0.0:
        if mesh_size_cap > 0.0 and mesh_size > mesh_size_cap:
            mesh_size = mesh_size_cap
        circumferential_div = max(circumferential_div, int(math.ceil(circumference / mesh_size)), 8)
        axial_div = max(int(math.ceil(length / mesh_size)), 2)
    else:
        base_div = _production_divisions(config.mesh_fidelity)
        circumferential_div = max(circumferential_div, base_div * 2, 8)
        axial_div = max(int(length / max(radius, 1.0e-9) * circumferential_div / 4), 2)
        if mesh_size_cap > 0.0:
            target_size = mesh_size_cap / max(_fidelity_refinement(config.mesh_fidelity), 1)
            circumferential_div = max(circumferential_div, int(math.ceil(circumference / target_size)))
            axial_div = max(axial_div, int(math.ceil(length / target_size)))
    if _wants_local_patch_transition(config) and not is_cone and radius > 0.0 and thickness > 0.0:
        # Curvature-adequate base ring for the local-patch transition: the
        # patch subdivides base facets, and if the facet chord sagitta is
        # comparable to the plate thickness the subdivided facet behaves as a
        # FLAT PLATE -- spuriously soft in buckling (plate-strip modes at a
        # fraction of the true shell load factor) or, placed on the true
        # surface, bulged proud of its neighbours (membrane stress dimple).
        # Cap the sagitta at t/4 so both artifacts stay negligible.
        sagitta_limit = 0.25 * thickness
        cos_ratio = min(max(1.0 - sagitta_limit / radius, -1.0), 1.0)
        curvature_div = int(math.ceil(math.pi / max(math.acos(cos_ratio), 1.0e-6)))
        curvature_div = min(max(curvature_div, 8), 96)
        if curvature_div > circumferential_div:
            circumferential_div = curvature_div
            mesh_generation["local_patch_curvature_min_circumferential_div"] = int(curvature_div)
    if stiffener_count > 0:
        circumferential_div = _multiple_at_least(circumferential_div, stiffener_count)
    if _wants_b3(config) and config.include_girders and geometry.get("has_girder"):
        circumferential_div *= 2
    if _wants_local_patch_transition(config) and not is_cone:
        # Curvature resolution can increase the ring count after the original
        # axial count was selected.  Keep the resulting parametric cells
        # shape-regular so every mandatory transition triangle lies within the
        # qualified S3 angle/shape envelope before it reaches the factory.
        arc_size = circumference / max(circumferential_div, 1)
        transition_axial_div = int(
            math.ceil(length / max(1.5 * arc_size, 1.0e-9))
        )
        if transition_axial_div > axial_div:
            axial_div = transition_axial_div
            mesh_generation["local_patch_s3_quality_min_axial_div"] = int(
                transition_axial_div
            )
    girder_positions = []
    if config.include_girders and geometry.get("has_girder"):
        if girder_spacing > 1.0e-9:
            # Ring frames/girders bound the axial bays: symmetric about the
            # shell mid-height, on the shell ends when L is a multiple.
            girder_positions = list(
                _centered_member_positions(length, girder_spacing, fallback_midpoint=True, include_ends=True)
            )
        else:
            girder_positions = [length / 2.0]
    axial_mandatory_breaks = (
        tuple(girder_positions)
        + _custom_patch_axis_breaks(config, "a", length)
        + _thickness_region_axis_breaks(config, "a", length)
    )
    z_breaks = _axis_breaks(length, axial_div, axial_mandatory_breaks)
    if _custom_patch_axis_breaks(config, "a", length) or patch_width_b > 0.0:
        mesh_generation["pressure_patch_boundary_breaks"] = "cylinder_axial_exact_circumferential_refined"
    arc_breaks = _axis_breaks(circumference, circumferential_div, _thickness_region_axis_breaks(config, "b", circumference))
    z_breaks, arc_breaks, adaptive_mesh_info = _apply_cylinder_detail_refinement(
        config,
        length,
        circumference,
        thickness,
        z_breaks,
        arc_breaks,
        axial_mandatory_breaks,
    )
    # Adaptive refinement must run before the B3 midside-node insertion.
    # Otherwise its additional, nonuniform axial breaks destroy the
    # endpoint/midpoint/end triplets required by the straight-sided
    # QuadraticBeamElement formulation.
    if _wants_b3(config) and config.include_stiffeners and geometry.get("has_stiffener"):
        z_breaks = _refined_midpoint_breaks(z_breaks)
    rows = len(z_breaks)
    axial_div = rows - 1
    cols = max(len(arc_breaks) - 1, 1)

    def node_id(row: int, col: int) -> int:
        return 1 + row * cols + (col % cols)

    nodes = []
    for row in range(rows):
        z = z_breaks[row]
        current_radius = radius_at_z(z)
        for col in range(cols):
            theta = float(arc_breaks[col]) / max(radius, 1.0e-9)
            nodes.append({"id": node_id(row, col), "coords": [current_radius * math.cos(theta), current_radius * math.sin(theta), z]})

    shells = []
    element_id = 1
    for row in range(axial_div):
        for col in range(cols):
            next_col = (col + 1) % cols
            shells.append(
                {
                    "id": element_id,
                    "node_ids": [
                        node_id(row, col),
                        node_id(row, next_col),
                        node_id(row + 1, next_col),
                        node_id(row + 1, col),
                    ],
                    "thickness": thickness,
                    "material": "steel",
                }
            )
            element_id += 1
    thickness_region_info = _apply_thickness_regions(
        shells,
        nodes,
        config,
        param_of_coords=lambda coords: (
            float(coords[2]),
            (math.atan2(float(coords[1]), float(coords[0])) % (2.0 * math.pi)) * radius,
        ),
        periodic_b=circumference,
    )

    beams = []
    beam_id = 20_001
    node_cache = _node_cache_from_nodes(nodes)
    member_side = _member_side_sign(geometry)
    stiffener_columns: list[int] = []
    stiffener_sections: dict[int, dict[str, float]] = {}
    if config.include_stiffeners and geometry.get("has_stiffener"):
        base_section = _section_with_runtime_options(
            geometry.get("stiffener_section"),
            thickness,
            radius,
            0.08,
            member_side * config.stiffener_eccentricity_m,
            orientation,
            config.beam_consistent_mass_enabled,
        )
        count = stiffener_count if stiffener_count > 0 else min(8, cols)
        for offset in range(count):
            target_arc = circumference * offset / max(count, 1)
            col = min(range(cols), key=lambda candidate: abs(float(arc_breaks[candidate]) - target_arc)) % cols
            section = dict(base_section)
            if _normalized_choice(orientation) == "radial":
                theta = float(arc_breaks[col]) / max(radius, 1.0e-9)
                section["orientation"] = (math.cos(theta), math.sin(theta), 0.0)
            stiffener_columns.append(col)
            stiffener_sections[col] = section
    ring_rows: list[int] = []
    girder_base_section: dict[str, float] = {}
    if config.include_girders and geometry.get("has_girder"):
        girder_base_section = _section_with_runtime_options(
            geometry.get("girder_section"),
            thickness,
            radius,
            0.12,
            member_side * config.girder_eccentricity_m,
            orientation,
            config.beam_consistent_mass_enabled,
        )
        ring_rows = [_index_of_break(z_breaks, pos) for pos in girder_positions] or [rows // 2]
    stiffener_web_intersections = {
        round(float(z_breaks[row]), 12): _member_web_section_depth_levels(girder_base_section, config)
        for row in ring_rows
        if girder_base_section
    }
    girder_web_intersections = {
        round(float(col), 12): _member_web_section_depth_levels(section, config)
        for col, section in stiffener_sections.items()
    }
    if stiffener_columns:
        for col in stiffener_columns:
            section = stiffener_sections[col]
            if _member_webs_as_shells(config):
                element_id, beam_id = _add_cylinder_member_shell_model(
                    nodes,
                    shells,
                    beams,
                    node_cache,
                    element_id,
                    beam_id,
                    node_id,
                    z_breaks,
                    cols,
                    radius,
                    radius_at_z,
                    section,
                    "stiffener",
                    col,
                    config,
                    intersection_heights=stiffener_web_intersections,
                    arc_breaks=arc_breaks,
                    side_sign=member_side,
                )
                continue
            row_range = range(0, axial_div - 1, 2) if _wants_b3(config) else range(axial_div)
            for row in row_range:
                beam_nodes = (
                    [node_id(row, col), node_id(row + 1, col), node_id(row + 2, col)]
                    if _wants_b3(config)
                    else [node_id(row, col), node_id(row + 1, col)]
                )
                beams.append(
                    {
                        "id": beam_id,
                        "node_ids": beam_nodes,
                        "section": section,
                        "role": "stiffener",
                        "material": "steel",
                    }
                )
                beam_id += 1
    if ring_rows and _wants_b3(config) and not _member_webs_as_shells(config):
        raise ValueError(
            "B3 ring girders are not supported: the current quadratic beam formulation is straight-sided. "
            "Use B2 beam members or model the girder web/flanges with shell elements."
        )
    if ring_rows:
        for row in ring_rows:
            if _member_webs_as_shells(config):
                section = dict(girder_base_section)
                element_id, beam_id = _add_cylinder_member_shell_model(
                    nodes,
                    shells,
                    beams,
                    node_cache,
                    element_id,
                    beam_id,
                    node_id,
                    z_breaks,
                    cols,
                    radius,
                    radius_at_z,
                    section,
                    "girder",
                    row,
                    config,
                    intersection_heights=girder_web_intersections,
                    arc_breaks=arc_breaks,
                    side_sign=member_side,
                )
                continue
            col_range = range(0, cols, 2) if _wants_b3(config) else range(cols)
            for col in col_range:
                section = dict(girder_base_section)
                if _normalized_choice(orientation) == "radial":
                    theta0 = float(arc_breaks[col]) / max(radius, 1.0e-9)
                    theta1 = float(arc_breaks[(col + 1) % len(arc_breaks)]) / max(radius, 1.0e-9)
                    if col + 1 >= len(arc_breaks):
                        theta1 = 2.0 * math.pi
                    theta = 0.5 * (theta0 + theta1)
                    section["orientation"] = (math.cos(theta), math.sin(theta), 0.0)
                beam_nodes = (
                    [node_id(row, col), node_id(row, col + 1), node_id(row, col + 2)]
                    if _wants_b3(config)
                    else [node_id(row, col), node_id(row, col + 1)]
                )
                beams.append(
                    {
                        "id": beam_id,
                        "node_ids": beam_nodes,
                        "section": section,
                        "role": "girder",
                        "material": "steel",
                    }
                )
                beam_id += 1

    local_patch_info: dict[str, object] | None = None
    use_local_patch = (
        _wants_local_patch_transition(config)
        and not is_cone
        and not _member_webs_as_shells(config)
        and not _wants_b3(config)
        and not _wants_s6(config)
        and not _wants_s8(config)
    )
    if use_local_patch:
        base_z_size = length / max(len(z_breaks) - 1, 1)
        base_arc_size = circumference / max(len(arc_breaks) - 1, 1)
        patch_windows = _local_patch_detail_windows(
            config,
            length,
            circumference,
            min(base_z_size, base_arc_size),
            thickness,
            radius=radius,
        )
        if patch_windows:
            local_patch_info = _apply_local_patch_transition(
                nodes,
                shells,
                beams,
                patch_windows,
                length,
                circumference,
                point_of_param=lambda u, v: _cylinder_point(radius, v / max(radius, 1.0e-9), u),
                param_of_coords=lambda coords: (
                    float(coords[2]),
                    (math.atan2(float(coords[1]), float(coords[0])) % (2.0 * math.pi)) * radius,
                ),
                periodic_v=True,
            )
            if local_patch_info:
                adaptive_mesh_info = {
                    **{k: v for k, v in local_patch_info.items() if k not in ("new_edge_parents",)},
                    "enabled": True,
                }

    if _wants_s6(config):
        _split_shells_to_triangles(nodes, shells, radius=radius, quadratic=True, element_type="S6")
    elif _wants_s3(config):
        _split_shells_to_triangles(nodes, shells, radius=radius, quadratic=False, element_type="S3")
    elif _wants_s8(config):
        elem_type = "S8R" if "s8r" in config.shell_element_order.lower() else "S8"
        _upgrade_shells_to_s8(nodes, shells, radius=radius, element_type=elem_type)
    _bind_runtime_qualified_s3_authority(nodes, shells, radius=radius)

    def cylinder_normal(_node_id: int, coord: np.ndarray) -> np.ndarray:
        radial = np.asarray([coord[0], coord[1], 0.0], dtype=float)
        norm = float(np.linalg.norm(radial))
        if norm <= 1.0e-12:
            return np.array([1.0, 0.0, 0.0], dtype=float)
        return radial / norm

    node_coords_after_shell_order = _node_lookup(nodes)
    z_tol = max(length * 1.0e-9, 1.0e-9)
    start_ring = sorted(
        node_id_value
        for node_id_value, coord in node_coords_after_shell_order.items()
        if abs(float(coord[2])) <= z_tol
    )
    end_ring = sorted(
        node_id_value
        for node_id_value, coord in node_coords_after_shell_order.items()
        if abs(float(coord[2]) - length) <= z_tol
    )
    rigid_lids = []
    supports = _cylinder_supports(rows, cols, node_id, config, lower_ring=start_ring, upper_ring=end_ring)
    custom_lid_support_nodes: tuple[list[int], list[int]] | None = None
    if config.include_end_lids:
        next_node_id = max(_node_lookup(nodes), default=0) + 1
        bottom_center = next_node_id
        top_center = bottom_center + 1
        nodes.extend(
            [
                {"id": bottom_center, "coords": [0.0, 0.0, 0.0]},
                {"id": top_center, "coords": [0.0, 0.0, length]},
            ]
        )
        rigid_lids = [
            {"id": 40_001, "name": "bottom_rigid_lid", "center_node_id": bottom_center, "ring_node_ids": start_ring},
            {"id": 40_002, "name": "top_rigid_lid", "center_node_id": top_center, "ring_node_ids": end_ring},
        ]
        supports = []
        custom_lid_support_nodes = ([bottom_center], [top_center])
    rigid_lid_ring_nodes = set(start_ring + end_ring) if config.include_end_lids else set()
    couplings = _offset_beam_nodes_and_couplings(
        nodes,
        beams,
        config,
        cylinder_normal,
        start_node_id=max(_node_lookup(nodes), default=0) + 1,
        exclude_base_node_ids=rigid_lid_ring_nodes,
    )
    # As for flat panels, boundary construction must not depend on whether the
    # Loads tab is replacing or adding to imported loads.
    boundary_map = _boundary_constraint_map(config)
    edge_supports = _custom_bc_segment_supports(nodes, config, length, circumference, radius=radius)
    custom_nullspace = bool(config.custom_load_bc_enabled and config.custom_use_nullspace_projection)
    if custom_nullspace:
        supports = []
    elif boundary_map:
        if custom_lid_support_nodes is not None:
            cyl_edge_map = {"lower": list(custom_lid_support_nodes[0]), "upper": list(custom_lid_support_nodes[1])}
        else:
            cyl_edge_map = {"lower": list(start_ring), "upper": list(end_ring)}
        supports = _whole_boundary_constraint_supports(
            cyl_edge_map, config, exclude_dofs_by_node=_edge_support_dofs_by_node(edge_supports))
    elif config.custom_load_bc_enabled and _has_custom_support(config):
        # Legacy saved custom-support choices remain supported when no new
        # per-edge DOF map is present.
        if custom_lid_support_nodes is not None:
            supports = _custom_cylinder_lid_reference_supports(
                custom_lid_support_nodes[0], custom_lid_support_nodes[1], config)
        else:
            supports = _custom_cylinder_supports(start_ring, end_ring, config)
    elif not bool(getattr(config, "boundary_auto_supports", True)):
        supports = []
    elif custom_lid_support_nodes is not None:
        supports.extend(_cylinder_lid_boundary_supports(custom_lid_support_nodes[0], custom_lid_support_nodes[1], config))
    supports.extend(edge_supports)
    supports.extend(_symmetry_supports(nodes, config))
    if not boundary_map and not config.custom_load_bc_enabled:
        supports.extend(_enforced_displacement_supports(nodes, config, "cylinder"))
    return {
        "name": "ANYsolverCylinderFullMesh",
        "thickness_regions": thickness_region_info,
        "nodes": nodes,
        "shells": shells,
        "beams": beams,
        "couplings": couplings,
        "rigid_lids": rigid_lids,
        "supports": supports,
        "materials": [
            {
                "name": "steel",
                "elastic_modulus": config.elastic_modulus_pa,
                "poisson_ratio": config.poisson_ratio,
                "density": 7850.0,
                "yield_stress": config.yield_stress_pa,
            }
        ],
        "plot_grid": [[node_id(row, col) for col in range(cols)] + [node_id(row, 0)] for row in range(rows)],
        "plot_type": "cylinder",
        "radius_m": radius,
        "length_m": length,
        "bottom_ring_node_ids": start_ring,
        "top_ring_node_ids": end_ring,
        "mesh_generation": mesh_generation,
        "mesh_metrics": _patched_mesh_metrics(
            _mesh_metrics_from_cylinder_breaks(z_breaks, arc_breaks, len(shells), len(nodes)),
            local_patch_info,
            len(shells),
            len(nodes),
        ),
        "adaptive_mesh": adaptive_mesh_info,
    }


def build_generated_geometry(geometry: NormalizedGeometry, config: LightweightFEMConfig) -> GeneratedGeometry:
    """Build the deterministic full shell/beam mesh consumed by the FE backend."""

    if geometry.get("geometry") == "cylinder":
        return _cylinder_generated_geometry(geometry, config)
    return _flat_generated_geometry(geometry, config)


def _nodal_scalar_fields(model, stresses_by_element: dict[int, object]) -> dict[str, dict[int, float]]:
    if not stresses_by_element:
        return {}

    field_mapping = {
        "von_mises_pa": ("von_mises", "von_mises"),
        "stress_x_membrane_pa": ("membrane_xx", "axial_stress"),
        "stress_y_membrane_pa": ("membrane_yy", None),
        "stress_xy_membrane_pa": ("membrane_xy", None),
        "strain_x_membrane": ("membrane_strain_xx", "axial_strain"),
        "strain_y_membrane": ("membrane_strain_yy", None),
        "strain_xy_membrane": ("membrane_strain_xy", None),
    }

    sums = {k: collections.defaultdict(float) for k in field_mapping}
    counts = {k: collections.defaultdict(int) for k in field_mapping}

    for element_id, stress in stresses_by_element.items():
        element = model.mesh.elements.get(element_id)
        if element is None:
            continue

        is_beam = type(element).__name__ in {"BeamElement", "QuadraticBeamElement"}
        if is_beam:
            # Beam stresses are displayed on the member lines themselves.
            # Averaging them into the shared shell nodes contaminates the
            # plate/shell colour fields (an elastic beam peak can massively
            # exceed the plastic shell stresses at the same node).
            continue
        node_ids = element.node_ids

        for field_name, (shell_key, beam_key) in field_mapping.items():
            key = beam_key if is_beam else shell_key
            if key is None or key not in stress:
                continue

            val = stress[key]
            if isinstance(val, (list, tuple)):
                value = sum(val) / len(val)
            elif hasattr(val, "size") and val.size > 0:
                value = float(val.sum()) / val.size
            else:
                value = float(val)

            s_dict = sums[field_name]
            c_dict = counts[field_name]
            for node_id in node_ids:
                nid = int(node_id)
                s_dict[nid] += value
                c_dict[nid] += 1

    result = {}
    for field_name, s_dict in sums.items():
        c_dict = counts[field_name]
        if s_dict:
            result[field_name] = {nid: total / c_dict[nid] for nid, total in s_dict.items()}
    return result


def _mean_stress_value(value: object) -> float:
    if value is None:
        return 0.0
    try:
        array = np.asarray(value, dtype=float).reshape(-1)
    except Exception:
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0
    array = array[np.isfinite(array)]
    if array.size == 0:
        return 0.0
    return float(np.mean(array))


def _shell_global_membrane_components(model, element, stress: object) -> tuple[float, float, float, float, float, float] | None:
    if not isinstance(stress, dict):
        return None
    if not any(key in stress for key in ("membrane_xx", "membrane_yy", "membrane_xy")):
        return None
    try:
        coords = element.get_node_coordinates(model.mesh)
        _shape, dN_dxi, dN_deta = element.compute_shape_functions(0.0, 0.0)
        local_frame, _dN_dx, _dN_dy, _det_j = element._local_frame_and_derivatives(coords, dN_dxi, dN_deta)
    except Exception:
        return None
    local_tensor = np.array(
        [
            [_mean_stress_value(stress.get("membrane_xx")), _mean_stress_value(stress.get("membrane_xy")), 0.0],
            [_mean_stress_value(stress.get("membrane_xy")), _mean_stress_value(stress.get("membrane_yy")), 0.0],
            [0.0, 0.0, 0.0],
        ],
        dtype=float,
    )
    global_tensor = np.asarray(local_frame, dtype=float) @ local_tensor @ np.asarray(local_frame, dtype=float).T
    return (
        float(global_tensor[0, 0]),
        float(global_tensor[1, 1]),
        float(global_tensor[2, 2]),
        float(global_tensor[0, 1]),
        float(global_tensor[1, 2]),
        float(global_tensor[2, 0]),
    )


def _safe_elset_name(prefix: str, role: object, thickness: object) -> str:
    role_text = str(role or "skin").strip().lower()
    role_text = re.sub(r"[^a-z0-9]+", "_", role_text).strip("_") or "skin"
    try:
        thickness_um = int(round(float(thickness or 0.0) * 1.0e6))
    except (TypeError, ValueError):
        thickness_um = 0
    return f"{prefix}_{role_text}_{thickness_um}um"


def _fea_result_import_payload(
    generated_geometry: dict[str, object],
    model,
    stresses_by_element: dict[int, object] | None,
) -> dict[str, object]:
    """Return an INP/FRD-like shell result payload for the FE-results importer."""

    qualified_elements = tuple(model.mesh.elements.values())
    q4_elements = tuple(
        element
        for element in qualified_elements
        if type(element) is _QualifiedE4PLShellElement
    )
    s3_elements = tuple(
        element
        for element in qualified_elements
        if type(element) is _QualifiedE4PLS3ShellElement
    )
    with ExitStack() as stack:
        stack.enter_context(_Q4_TRUSTED_OPERATION_SCOPE(q4_elements))
        stack.enter_context(_S3_TRUSTED_OPERATION_SCOPE(s3_elements))
        return _fea_result_import_payload_under_scope(
            generated_geometry,
            model,
            stresses_by_element,
        )


def _fea_result_import_payload_under_scope(
    generated_geometry: dict[str, object],
    model,
    stresses_by_element: dict[int, object] | None,
) -> dict[str, object]:
    """Build the result payload inside a validated shell-operation bracket."""

    nodes_payload = []
    for node_id, node in sorted(model.mesh.nodes.items()):
        nodes_payload.append(
            {
                "id": int(node_id),
                "coords": (float(node.x), float(node.y), float(node.z)),
            }
        )

    shell_by_id = {
        int(shell.get("id", 0)): shell
        for shell in generated_geometry.get("shells", []) or []
        if shell.get("id") is not None
    }
    shell_payload = []
    elsets: dict[str, list[int]] = collections.defaultdict(list)
    section_meta: dict[str, dict[str, object]] = {}
    for element_id, element in sorted(model.mesh.elements.items()):
        if not isinstance(element, _full_backend.ShellElement):
            continue
        generated_shell = shell_by_id.get(int(element_id), {})
        thickness = float(getattr(element, "thickness", generated_shell.get("thickness", 0.0)) or 0.0)
        role = generated_shell.get("role", "skin")
        material = str(generated_shell.get("material", getattr(element, "material_name", "steel")) or "steel")
        elset = _safe_elset_name("runtime", role, thickness)
        elsets[elset].append(int(element_id))
        section_meta.setdefault(
            elset,
            {
                "elset": elset,
                "material": material,
                "thickness_m": thickness,
                "offset": None,
            },
        )
        element_type = str(
            generated_shell.get("type")
            or {3: "S3", 4: "S4", 6: "S6", 8: "S8"}.get(len(element.node_ids), "S4")
        )
        shell_payload.append(
            {
                "id": int(element_id),
                "node_ids": tuple(int(node_id) for node_id in element.node_ids),
                "type": element_type,
                "elset": elset,
                "thickness_m": thickness,
                "role": str(role or "skin"),
            }
        )
    shell_node_ids = {
        int(node_id)
        for shell in shell_payload
        for node_id in shell.get("node_ids", ())
    }
    nodes_payload = [
        node
        for node in nodes_payload
        if int(node.get("id", 0)) in shell_node_ids
    ]

    stress_sums: dict[int, list[float]] = collections.defaultdict(lambda: [0.0] * 6)
    stress_counts: dict[int, int] = collections.defaultdict(int)
    for element_id, stress in (stresses_by_element or {}).items():
        element = model.mesh.elements.get(int(element_id))
        if element is None or not isinstance(element, _full_backend.ShellElement):
            continue
        components = _shell_global_membrane_components(model, element, stress)
        if components is None:
            continue
        for node_id in element.node_ids:
            nid = int(node_id)
            for index, value in enumerate(components):
                stress_sums[nid][index] += float(value)
            stress_counts[nid] += 1

    nodal_stress = {
        int(node_id): tuple(total / max(stress_counts[node_id], 1) for total in values)
        for node_id, values in stress_sums.items()
        if stress_counts.get(node_id, 0) > 0
    }

    cylinder_geometry = None
    runtime_members = []
    for beam in generated_geometry.get("beams", []) or []:
        role = str(beam.get("role", "member") or "member")
        if not any(token in role.lower() for token in ("stiffener", "girder", "frame")):
            continue
        node_ids = tuple(int(node_id) for node_id in beam.get("node_ids", ()) or ())
        points = []
        for node_id in node_ids:
            node = model.mesh.get_node(node_id)
            if node is not None:
                points.append((float(node.x), float(node.y), float(node.z)))
        if len(points) < 2:
            continue
        runtime_members.append(
            {
                "id": int(beam.get("id", len(runtime_members) + 1) or len(runtime_members) + 1),
                "role": role,
                "node_ids": node_ids,
                "points": tuple(points),
                "section": dict(beam.get("section") or {}),
            }
        )
    if str(generated_geometry.get("plot_type", "")).lower() == "cylinder":
        skin_shell_ids = tuple(
            int(shell["id"])
            for shell in shell_payload
            if str(shell.get("role", "skin")).lower() in {"", "skin"}
        )
        skin_node_ids = {
            int(node_id)
            for shell in shell_payload
            if int(shell["id"]) in skin_shell_ids
            for node_id in shell.get("node_ids", ())
        }
        z_values = [
            float(node.get("coords", (0.0, 0.0, 0.0))[2])
            for node in nodes_payload
            if int(node.get("id", 0)) in skin_node_ids
        ]
        skin_thickness_values = [
            float(shell.get("thickness_m", 0.0) or 0.0)
            for shell in shell_payload
            if int(shell["id"]) in skin_shell_ids
        ]
        cylinder_geometry = {
            "axis_origin": (0.0, 0.0, min(z_values) if z_values else 0.0),
            "axis_direction": (0.0, 0.0, 1.0),
            "radius_m": float(generated_geometry.get("radius_m", 0.0) or 0.0),
            "axial_bounds": (min(z_values), max(z_values)) if z_values else (0.0, 0.0),
            "skin_element_ids": skin_shell_ids,
            "skin_thickness_m": float(np.median(skin_thickness_values)) if skin_thickness_values else None,
            "radial_rms_error_m": 0.0,
            "confidence": 1.0,
            "diagnostics": ("runtime cylinder geometry metadata",),
        }

    return {
        "format": "anystructure-runtime-fe-results-v1",
        "source": "runtime FEM result",
        "geometry_type": str(generated_geometry.get("plot_type", "flat") or "flat"),
        "nodes": tuple(nodes_payload),
        "shells": tuple(shell_payload),
        "elsets": {name: tuple(sorted(set(ids))) for name, ids in elsets.items()},
        "shell_sections": tuple(section_meta[name] for name in sorted(section_meta)),
        "stress_components": ("SXX", "SYY", "SZZ", "SXY", "SYZ", "SZX"),
        "nodal_stress_pa": nodal_stress,
        "units": "Pa",
        "cylinder_geometry": cylinder_geometry,
        "runtime_members": tuple(runtime_members),
    }


def _nodal_engineering_plastic_strain(model, element_states: dict[int, object] | None) -> dict[int, float]:
    if not element_states:
        return {}
    values: dict[int, float] = {}
    for element_id, state in element_states.items():
        element = model.mesh.get_element(int(element_id))
        if element is None or not isinstance(state, dict) or "alpha" not in state:
            continue
        alpha = np.asarray(state.get("alpha"), dtype=float)
        alpha = alpha[np.isfinite(alpha)]
        if alpha.size == 0:
            continue
        # The material return-map stores equivalent true plastic strain.  Use
        # the equivalent engineering strain for display so it is easier to
        # compare with ordinary engineering strain values in the GUI.
        engineering_value = float(np.expm1(max(float(np.max(alpha)), 0.0)))
        for node_id in getattr(element, "node_ids", []):
            node_id = int(node_id)
            values[node_id] = max(values.get(node_id, 0.0), engineering_value)
    return values


def _visualization_member_lines(
    generated_geometry: dict,
    model,
    displacements: np.ndarray,
    stresses_by_element: dict[int, object] | None = None,
) -> tuple[dict[str, object], ...]:
    lines: list[dict[str, object]] = []
    if displacements is None:
        return ()

    stresses = stresses_by_element or {}

    for beam in generated_geometry.get("beams", []) or []:
        node_ids = [int(node_id) for node_id in beam.get("node_ids", [])]
        if len(node_ids) < 2:
            continue
        points = []
        displaced = []
        plot_node_ids = node_ids if len(node_ids) == 3 else node_ids[:2]
        for node_id in plot_node_ids:
            node = model.mesh.get_node(node_id)
            if node is None:
                break
            base = np.asarray(node.coords(), dtype=float)
            translation = np.asarray(displacements[node.dofs[:3]], dtype=float)
            points.append(tuple(float(value) for value in base))
            displaced.append(tuple(float(value) for value in base + translation))
        if len(points) != 2:
            continue

        beam_stresses = {}
        c_y = 0.0
        c_z = 0.0
        element_id = beam.get("id")
        if element_id is not None:
            try:
                element = model.mesh.get_element(int(element_id))
                if element is not None:
                    beam_stresses = stresses.get(int(element_id)) or {}
                    c_y, c_z = element._fiber_distances()
            except Exception:
                pass

        def _safe_stress(val) -> float:
            if val is None: return 0.0
            if hasattr(val, "item"):
                try:
                    return float(val.item(0) if getattr(val, "size", 0) > 0 else val.item())
                except Exception: pass
            if hasattr(val, "__len__") and not isinstance(val, str):
                return float(val[0]) if len(val) > 0 else 0.0
            try: return float(val)
            except Exception: return 0.0

        lines.append(
            {
                "id": int(beam.get("id", 0)),
                "role": str(beam.get("role", "member")),
                "node_ids": tuple(plot_node_ids),
                "points": tuple(points),
                "displaced_points": tuple(displaced),
                "section_label": str((beam.get("section") or {}).get("label", "")),
                # Include cross section dimensions
                "web_height": float((beam.get("section") or {}).get("web_height") or 0.1),
                "web_thickness": float((beam.get("section") or {}).get("web_thickness") or 0.01),
                "flange_width": float((beam.get("section") or {}).get("flange_width") or 0.0),
                "flange_thickness": float((beam.get("section") or {}).get("flange_thickness") or 0.0),
                "c_y": float(c_y),
                "c_z": float(c_z),
                "eccentricity": float((beam.get("section") or {}).get("eccentricity_m") or 0.0),
                # Include stress component results
                "axial_stress": _safe_stress(beam_stresses.get("axial_stress")),
                "bending_stress_y": _safe_stress(beam_stresses.get("bending_stress_y")),
                "bending_stress_z": _safe_stress(beam_stresses.get("bending_stress_z")),
                "shear_stress_y": _safe_stress(beam_stresses.get("shear_stress_y")),
                "shear_stress_z": _safe_stress(beam_stresses.get("shear_stress_z")),
                "torsional_stress": _safe_stress(beam_stresses.get("torsional_stress")),
                "von_mises": _safe_stress(beam_stresses.get("von_mises")),
            }
        )
    return tuple(lines)


def _visualization_surface_boundary_node_ids(node_ids: list[int]) -> list[int]:
    """Return shell boundary nodes in plotting order, including midside nodes."""

    if len(node_ids) == 6:
        return [node_ids[0], node_ids[3], node_ids[1], node_ids[4], node_ids[2], node_ids[5]]
    if len(node_ids) == 8:
        return [
            node_ids[0],
            node_ids[4],
            node_ids[1],
            node_ids[5],
            node_ids[2],
            node_ids[6],
            node_ids[3],
            node_ids[7],
        ]
    return list(node_ids)


def _visualization_shell_surfaces(
    generated_geometry: dict,
    model,
    displacements: np.ndarray,
    fields: dict[str, dict[int, float]],
    element_fields: dict[str, dict[int, float]] | None = None,
    *,
    include_skin: bool = False,
    include_members: bool = True,
) -> tuple[dict[str, object], ...]:
    surfaces: list[dict[str, object]] = []
    if displacements is None:
        return ()
    if element_fields is None:
        element_fields = {}
    shell_lookup = {
        int(shell.get("id", 0)): shell
        for shell in generated_geometry.get("shells", []) or []
        if shell.get("id") is not None
    }
    for shell_id, shell in sorted(shell_lookup.items()):
        role = str(shell.get("role", "skin") or "skin")
        is_skin = role.lower() in {"", "skin"}
        if is_skin and not include_skin:
            continue
        if not is_skin and not include_members:
            continue
        element_node_ids = [int(node_id) for node_id in shell.get("node_ids", [])]
        node_ids = _visualization_surface_boundary_node_ids(element_node_ids)
        if len(node_ids) < 3:
            continue
        points = []
        displaced_points = []
        disp_values = {"disp_x": [], "disp_y": [], "disp_z": [], "disp_mag": []}
        for node_id in node_ids:
            node = model.mesh.get_node(node_id)
            if node is None:
                break
            base = np.asarray(node.coords(), dtype=float)
            translation = np.asarray(displacements[node.dofs[:3]], dtype=float)
            moved = base + translation
            points.append(tuple(float(value) for value in base))
            displaced_points.append(tuple(float(value) for value in moved))
            disp_values["disp_x"].append(float(translation[0]))
            disp_values["disp_y"].append(float(translation[1]))
            disp_values["disp_z"].append(float(translation[2]))
            disp_values["disp_mag"].append(float(np.linalg.norm(translation)))
        if len(points) != len(node_ids):
            continue
        field_values: dict[str, float] = {}
        for field_name, by_node in fields.items():
            values = [float(by_node[node_id]) for node_id in element_node_ids if node_id in by_node]
            if values:
                field_values[field_name] = float(sum(values) / len(values))
        for field_name, values in disp_values.items():
            if values:
                field_values[field_name] = float(sum(values) / len(values))
        for field_name, by_element in element_fields.items():
            if shell_id in by_element:
                field_values[field_name] = float(by_element[shell_id])
        surfaces.append(
            {
                "id": shell_id,
                "role": role,
                "node_ids": tuple(node_ids),
                "element_node_ids": tuple(element_node_ids),
                "points": tuple(points),
                "displaced_points": tuple(displaced_points),
                "field_values": field_values,
            }
        )
    return tuple(surfaces)


def _visualization_from_full_result(
    generated_geometry: dict,
    model,
    displacements: np.ndarray,
    scalar_by_node: dict[int, float] | None = None,
    scalar_label: str = "stress [Pa]",
    stresses_by_element: dict[int, object] | None = None,
    element_scalar_fields: dict[str, dict[int, float]] | None = None,
    *,
    recover_stresses_if_missing: bool = True,
) -> dict[str, object]:
    grid = generated_geometry.get("plot_grid") or []
    has_custom = bool(generated_geometry.get("shells") or generated_geometry.get("beams"))
    if (not grid and not has_custom) or displacements is None:
        return {}

    if stresses_by_element is None:
        stresses_by_element = {}
    if (
        recover_stresses_if_missing
        and not stresses_by_element
        and _backend_compute_stresses is not None
    ):
        stresses_by_element = _backend_compute_stresses(model, displacements)
    if element_scalar_fields is None:
        element_scalar_fields = {}

    fields = _nodal_scalar_fields(model, stresses_by_element)
    if scalar_by_node:
        fields["custom_scalar"] = scalar_by_node
    for field_name, by_element in element_scalar_fields.items():
        nodal_values: dict[int, list[float]] = {}
        for element_id, value in (by_element or {}).items():
            element = model.mesh.elements.get(int(element_id))
            if element is None:
                continue
            for node_id in getattr(element, "node_ids", ()) or ():
                nodal_values.setdefault(int(node_id), []).append(float(value))
        if nodal_values:
            fields[field_name] = {
                int(node_id): float(sum(values) / len(values))
                for node_id, values in nodal_values.items()
                if values
            }

    is_cylinder = generated_geometry.get("plot_type") == "cylinder"
    radius = _positive(generated_geometry.get("radius_m", 1.0), 1.0) if is_cylinder else 0.0

    x_grid, y_grid, w_grid = [], [], []
    disp_grids = {"disp_x": [], "disp_y": [], "disp_z": [], "disp_mag": []}
    field_grids = {k: [] for k in fields}

    get_node = model.mesh.get_node

    if is_cylinder:
        for row in grid:
            x_row, y_row, w_row = [], [], []
            dx_row, dy_row, dz_row, dmag_row = [], [], [], []
            f_rows = {k: [] for k in fields}

            for node_id in row:
                nid = int(node_id)
                node = get_node(nid)
                if node is None:
                    continue

                dofs = node.dofs
                dx = float(displacements[dofs[0]])
                dy = float(displacements[dofs[1]])
                dz = float(displacements[dofs[2]])
                dmag = math.sqrt(dx*dx + dy*dy + dz*dz)

                nx, ny, nz = float(node.x), float(node.y), float(node.z)
                theta = math.atan2(ny, nx)
                rad_disp = dx * math.cos(theta) + dy * math.sin(theta)

                x_row.append(nz)
                y_row.append(theta if theta >= 0.0 else theta + 2.0 * math.pi)
                w_row.append(rad_disp)

                dx_row.append(dx)
                dy_row.append(dy)
                dz_row.append(dz)
                dmag_row.append(dmag)

                for k, field_dict in fields.items():
                    f_rows[k].append(float(field_dict.get(nid, abs(rad_disp))))

            x_grid.append(tuple(x_row))
            y_grid.append(tuple(y_row))
            w_grid.append(tuple(w_row))
            disp_grids["disp_x"].append(tuple(dx_row))
            disp_grids["disp_y"].append(tuple(dy_row))
            disp_grids["disp_z"].append(tuple(dz_row))
            disp_grids["disp_mag"].append(tuple(dmag_row))
            for k, row_list in f_rows.items():
                field_grids[k].append(tuple(row_list))
    else:
        for row in grid:
            x_row, y_row, w_row = [], [], []
            dx_row, dy_row, dz_row, dmag_row = [], [], [], []
            f_rows = {k: [] for k in fields}

            for node_id in row:
                nid = int(node_id)
                node = get_node(nid)
                if node is None:
                    continue

                dofs = node.dofs
                dx = float(displacements[dofs[0]])
                dy = float(displacements[dofs[1]])
                dz = float(displacements[dofs[2]])
                dmag = math.sqrt(dx*dx + dy*dy + dz*dz)

                x_row.append(float(node.x))
                y_row.append(float(node.y))
                w_row.append(dz)

                dx_row.append(dx)
                dy_row.append(dy)
                dz_row.append(dz)
                dmag_row.append(dmag)

                for k, field_dict in fields.items():
                    f_rows[k].append(float(field_dict.get(nid, abs(dz))))

            x_grid.append(tuple(x_row))
            y_grid.append(tuple(y_row))
            w_grid.append(tuple(w_row))
            disp_grids["disp_x"].append(tuple(dx_row))
            disp_grids["disp_y"].append(tuple(dy_row))
            disp_grids["disp_z"].append(tuple(dz_row))
            disp_grids["disp_mag"].append(tuple(dmag_row))
            for k, row_list in f_rows.items():
                field_grids[k].append(tuple(row_list))

    result = {
        "type": "cylinder" if is_cylinder else "flat",
        "radius_m": radius,
        "x_m" if not is_cylinder else "axial_m": tuple(x_grid),
        "y_m" if not is_cylinder else "theta_rad": tuple(y_grid),
        "w_m" if not is_cylinder else "radial_displacement_m": tuple(w_grid),
        "displacements": {k: tuple(v) for k, v in disp_grids.items()},
        "fields": {k: tuple(v) for k, v in field_grids.items()},
        "stress_pa": tuple(field_grids.get("custom_scalar", field_grids.get("von_mises_pa", w_grid))),
        "scalar_label": scalar_label,
        "member_lines": _visualization_member_lines(generated_geometry, model, displacements, stresses_by_element),
        "shell_surfaces": _visualization_shell_surfaces(generated_geometry, model, displacements, fields, element_scalar_fields),
        "skin_shell_surfaces": _visualization_shell_surfaces(
            generated_geometry,
            model,
            displacements,
            fields,
            element_scalar_fields,
            include_skin=True,
            include_members=False,
        ),
    }
    return result


def _buckling_mode_visualizations(generated_geometry: dict, model, buckling_result) -> tuple[dict[str, object], ...]:
    if buckling_result is None:
        return ()
    modes = []
    for mode in getattr(buckling_result, "modes", []) or []:
        mode_shape = np.asarray(mode.mode_shape, dtype=float)
        mode_amplitude_by_node = {
            int(node_id): float(np.linalg.norm(mode_shape[node.dofs[:3]]))
            for node_id, node in model.mesh.nodes.items()
        }
        shape = _visualization_from_full_result(
            generated_geometry,
            model,
            mode_shape,
            scalar_by_node=mode_amplitude_by_node,
            scalar_label="mode amplitude",
            recover_stresses_if_missing=False,
        )
        if not shape:
            continue
        shape["mode_number"] = int(mode.mode_number)
        shape["load_factor"] = float(mode.load_factor)
        modes.append(
            {
                "mode_number": int(mode.mode_number),
                "load_factor": float(mode.load_factor),
                "shape": shape,
            }
        )
    return tuple(modes)


def _resultant_dict(load_resultant) -> dict[str, tuple[float, float, float]]:
    if load_resultant is None:
        return {}
    return {
        "force_n": tuple(float(value) for value in np.asarray(load_resultant.force, dtype=float).reshape(3)),
        "moment_nm": tuple(float(value) for value in np.asarray(load_resultant.moment, dtype=float).reshape(3)),
    }


def _pressure_sign(config: LightweightFEMConfig) -> float:
    side = _normalized_choice(config.pressure_direction, "front")
    return 1.0 if side in {"back", "internal", "inside", "inward side", "positive normal", "outward"} else -1.0


def _runtime_collision_has_fixed_support(config: LightweightFEMConfig, geometry: dict) -> bool:
    # New per-DOF BC model: a whole-boundary DOF constraint or any selected-edge
    # segment provides the required restraint for a collision run.
    if _boundary_constraint_map(config):
        return True
    if any(seg.get("constraints") or seg.get("support") not in (None, "", "free", "none")
           for seg in _custom_bc_segments(config)):
        return True
    if _normalized_choice(config.boundary_condition, "auto") not in {"auto", "free", "none"}:
        return True
    if geometry.get("geometry") == "cylinder":
        supports = (config.cylinder_lower_support, config.cylinder_upper_support)
    else:
        supports = (
            config.plate_edge_x0_support,
            config.plate_edge_x1_support,
            config.plate_edge_y0_support,
            config.plate_edge_y1_support,
        )
    return any(_normalized_choice(support, "free") not in {"free", "none"} for support in supports)


def _runtime_fracture_config(config: LightweightFEMConfig):
    if not config.fracture_enabled or _backend_FractureConfig is None:
        return None
    return _backend_FractureConfig(
        threshold=max(float(config.fracture_strain_threshold), 1.0e-12),
        residual_stiffness_fraction=min(max(float(config.fracture_residual_stiffness_fraction), 0.0), 1.0),
        max_deleted_fraction=min(max(float(config.fracture_max_deleted_fraction), 1.0e-9), 1.0),
        min_load_factor=max(float(config.fracture_min_load_factor), 0.0),
    )


def _collision_save_every(config: LightweightFEMConfig) -> int:
    interval = max(float(config.collision_result_interval_s or 0.0), 0.0)
    dt = max(float(config.collision_dt_s), 1.0e-12)
    if interval <= 0.0:
        return 1
    return max(int(round(interval / dt)), 1)


def _collision_damage_config(config: LightweightFEMConfig):
    if not config.collision_damage_enabled or _backend_ImpactDamageConfig is None:
        return None
    user_capacity = None
    if _normalized_choice(config.collision_damage_capacity_basis, "yield") == "user":
        user_capacity = max(float(config.collision_damage_user_capacity_pa), 1.0e-9)
    return _backend_ImpactDamageConfig(
        mode=str(config.collision_damage_mode or "accumulated_damage"),
        capacity_basis=str(config.collision_damage_capacity_basis or "yield"),
        softening_start=min(max(float(config.collision_damage_softening_start), 0.0), 0.999999),
        delete_at=max(float(config.collision_damage_delete_at), float(config.collision_damage_softening_start) + 1.0e-9),
        min_contact_area=max(float(config.collision_damage_min_contact_area_m2), 1.0e-12),
        neighbor_smoothing=bool(config.collision_damage_neighbor_smoothing),
        residual_stiffness_fraction=min(max(float(config.fracture_residual_stiffness_fraction), 0.0), 1.0),
        max_deleted_fraction=min(max(float(config.collision_damage_max_deleted_fraction), 1.0e-9), 1.0),
        user_capacity=user_capacity,
    )



def _collision_nonlinear_config(config: LightweightFEMConfig):
    if not bool(config.collision_material_nonlinear_enabled) or _backend_NonlinearTransientConfig is None:
        return None
    return _backend_NonlinearTransientConfig(
        enabled=True,
        num_layers=max(int(config.nonlinear_layers or 5), 1),
        max_iterations=max(int(config.collision_nonlinear_max_iterations or 20), int(config.nonlinear_max_iterations or 25), 1),
        residual_tolerance=max(float(config.collision_nonlinear_tolerance or 2.0e-3), 2.0e-3),
        displacement_tolerance=max(float(config.nonlinear_tolerance or 1.0e-6), 1.0e-12),
        contact_force_tolerance=max(float(config.collision_nonlinear_tolerance or 2.0e-3), 2.0e-3),
        max_cutbacks=max(int(config.collision_nonlinear_cutbacks or 0), 12),
        record_element_state_history=True,
        kinematics=_normalized_kinematics(config.collision_nonlinear_kinematics),
    )


def _collision_plastic_damage_config(config: LightweightFEMConfig):
    if (
        not bool(config.collision_damage_enabled)
        or not bool(config.collision_material_nonlinear_enabled)
        or _backend_PlasticImpactDamageConfig is None
    ):
        return None
    criterion = str(config.collision_damage_criterion or "fixed").strip().lower()
    if criterion not in {"fixed", "mesh_scaled_gl", "rtcl", "rtcl_modified"}:
        criterion = "fixed"
    return _backend_PlasticImpactDamageConfig(
        threshold=max(float(config.collision_plastic_damage_threshold or 0.01), 1.0e-12),
        criterion=criterion,
        softening_start=min(max(float(config.collision_damage_softening_start), 0.0), 0.999999),
        delete_at=max(float(config.collision_damage_delete_at), float(config.collision_damage_softening_start) + 1.0e-9),
        residual_stiffness_fraction=min(max(float(config.fracture_residual_stiffness_fraction), 0.0), 1.0),
        max_deleted_fraction=min(max(float(config.collision_damage_max_deleted_fraction), 1.0e-9), 1.0),
        element_scope=("shell", "beam"),
    )


def _collision_energy_summary(diagnostics: dict[str, object]) -> dict[str, float]:
    if not isinstance(diagnostics, dict):
        return {}
    kinetic = np.asarray(diagnostics.get("kinetic_energy", ()), dtype=float).reshape(-1)
    strain = np.asarray(diagnostics.get("strain_energy", ()), dtype=float).reshape(-1)
    sphere = np.asarray(diagnostics.get("sphere_kinetic_energy", ()), dtype=float).reshape(-1)
    count = min(int(kinetic.size), int(strain.size), int(sphere.size))
    if count <= 0:
        return {}
    total = kinetic[:count] + strain[:count] + sphere[:count]
    if total.size <= 0:
        return {}
    return {
        "collision_energy_initial_j": float(total[0]),
        "collision_energy_final_j": float(total[-1]),
        "collision_sphere_kinetic_initial_j": float(sphere[0]),
        "collision_sphere_kinetic_final_j": float(sphere[count - 1]),
        "collision_energy_max_relative_drift": float(diagnostics.get("max_relative_energy_drift", 0.0) or 0.0),
    }


def _plastic_strain_element_fields_from_states(element_states: object) -> dict[str, dict[int, float]]:
    field: dict[int, float] = {}
    if not isinstance(element_states, dict):
        return {"plastic_strain": field}
    for raw_element_id, state in element_states.items():
        if not isinstance(state, dict):
            continue
        try:
            element_id = int(raw_element_id)
        except Exception:
            continue
        alpha = np.asarray(state.get("alpha", ()), dtype=float).reshape(-1)
        if alpha.size:
            value = float(np.max(alpha))
            if math.isfinite(value):
                field[element_id] = max(value, 0.0)
    return {"plastic_strain": field}


def _annotate_plastic_strain_visualization(visualization: dict[str, object]) -> None:
    fields = visualization.get("fields") if isinstance(visualization, dict) else None
    if isinstance(fields, dict) and fields.get("plastic_strain"):
        visualization["plastic_strain"] = fields.get("plastic_strain")
        visualization["plastic_strain_label"] = "equiv. engineering plastic strain [-]"


def _collision_representative_shell_edge(generated_geometry: dict) -> float:
    node_lookup = _node_lookup(list(generated_geometry.get("nodes", ()) or ()))
    lengths: list[float] = []
    for shell in generated_geometry.get("shells", ()) or ():
        node_ids = [int(node_id) for node_id in shell.get("node_ids", ()) or () if int(node_id) in node_lookup]
        corner_count = 3 if len(node_ids) in (3, 6) else 4
        corners = node_ids[:corner_count]
        if len(corners) < 3:
            continue
        for index, node_id in enumerate(corners):
            start = node_lookup[int(node_id)]
            end = node_lookup[int(corners[(index + 1) % len(corners)])]
            length = float(np.linalg.norm(end - start))
            if math.isfinite(length) and length > 0.0:
                lengths.append(length)
    return float(np.median(lengths)) if lengths else 0.0


def _collision_initial_penetration(generated_geometry: dict, config: LightweightFEMConfig) -> dict[str, float]:
    node_lookup = _node_lookup(list(generated_geometry.get("nodes", ()) or ()))
    if not node_lookup:
        return {"penetration_m": 0.0, "clearance_m": 0.0, "closest_distance_m": 0.0}
    center = np.asarray(
        (
            float(config.collision_start_x_m),
            float(config.collision_start_y_m),
            float(config.collision_start_z_m),
        ),
        dtype=float,
    )
    radius = max(float(config.collision_radius_m), 1.0e-9)
    candidate_points: list[np.ndarray] = []
    for shell in generated_geometry.get("shells", ()) or ():
        node_ids = [int(node_id) for node_id in shell.get("node_ids", ()) or () if int(node_id) in node_lookup]
        if not node_ids:
            continue
        points = [node_lookup[node_id] for node_id in node_ids]
        corner_points = points[:4] if len(points) >= 4 else points
        candidate_points.extend(corner_points)
        candidate_points.append(np.mean(np.asarray(corner_points, dtype=float), axis=0))
    if not candidate_points:
        candidate_points = list(node_lookup.values())
    distances = [float(np.linalg.norm(point - center)) for point in candidate_points]
    closest = min(distances) if distances else radius
    penetration = max(radius - closest, 0.0)
    return {
        "penetration_m": float(penetration),
        "clearance_m": float(closest - radius),
        "closest_distance_m": float(closest),
    }


# Contact penalty ceiling as a multiple of the shell contact-stiffness scale
# E*t.  Validated boundary: penalties around E*t converge; ~10*E*t diverges.
# Chosen with margin below the observed failure band.
_COLLISION_PENALTY_STRUCTURAL_FACTOR = 3.0
# Extra softening applied on top of the structural cap when the opt-in
# auto-precondition ("extra-conservative contact") mode is enabled.
_COLLISION_PRECONDITION_EXTRA_SCALE = 0.5


def _collision_contact_stiffness_scale(generated_geometry: dict, config: LightweightFEMConfig) -> float:
    """Shell contact-stiffness scale E*t [N/m] at the (thinnest) skin plate.

    ``E*t`` is the physical normal-contact stiffness scale for a shell and is
    mesh-independent, so it is the right quantity to cap the penalty against.
    Uses the thinnest skin shell (most compliant, governs conditioning) and
    the runtime elastic modulus.
    """
    thicknesses = [
        float(shell.get("thickness", shell.get("thickness_m", 0.0)) or 0.0)
        for shell in generated_geometry.get("shells", ()) or ()
        if "role" not in shell
    ]
    thicknesses = [t for t in thicknesses if t > 0.0]
    if not thicknesses:
        return 0.0
    thickness = min(thicknesses)
    modulus = max(float(getattr(config, "elastic_modulus_pa", 0.0) or 0.0), 1.0)
    return modulus * thickness


def _collision_dynamic_penalty(
    config: LightweightFEMConfig,
    dt: float,
    representative_edge: float = 0.0,
    contact_stiffness_scale: float = 0.0,
) -> dict[str, float | str]:
    radius = max(float(config.collision_radius_m), 1.0e-9)
    mass = max(float(config.collision_mass_kg), 1.0e-9)
    speed = max(float(config.collision_speed_mps), 0.0)
    target_fraction = max(float(config.collision_target_penetration_fraction), 1.0e-6)
    target_penetration = max(radius * target_fraction, 1.0e-9)
    kinetic_energy = 0.5 * mass * speed * speed
    # Penalty that stores the full kinetic energy within the requested target
    # penetration (k = 2*KE/delta^2 = m*v^2/delta^2).
    desired = max(mass * speed * speed / max(target_penetration * target_penetration, 1.0e-18), 1.0)
    # Explicit contact-stability ceiling (oscillation period ~ dt).
    stable = max(mass * (0.16 / max(float(dt), 1.0e-12)) ** 2, 1.0)
    selected = min(desired, stable)

    # High-energy softening.  When the kinetic energy dwarfs the elastic energy
    # the contact spring can hold at the target penetration, the stability
    # ceiling binds and pins the penalty at a very stiff value.  That is not
    # required for the implicit Newmark solve and it makes the contact tangent
    # hypersensitive (large contact-force jumps per penetration increment),
    # destabilising Newton on an already-softening (plastic/buckling) structure.
    # Scale the penalty down with sqrt(severity), bounded, and floored so the
    # sphere still cannot tunnel past a physical penetration cap.
    elastic_at_target = 0.5 * selected * target_penetration * target_penetration
    severity = kinetic_energy / max(elastic_at_target, 1.0e-18)
    softening = 1.0
    if severity > 1.0 and speed > 0.0:
        softening = min(math.sqrt(severity), 4.0)
        penetration_cap = 0.15 * radius
        if representative_edge > 0.0:
            penetration_cap = min(penetration_cap, 1.5 * representative_edge)
        penetration_cap = max(penetration_cap, 4.0 * target_penetration)
        penalty_floor = mass * speed * speed / max(penetration_cap * penetration_cap, 1.0e-18)
        selected = min(max(selected / softening, penalty_floor), selected)
    # Structural contact-stiffness ceiling.  The desired/dt-stable penalties
    # above are set purely by the impact energy and time step and ignore the
    # stiffness of the shell being hit.  When the penalty greatly exceeds the
    # local shell contact stiffness (~ E*t) the structure<->contact staggered
    # fixed point stops contracting: the contact force swings by mega-newtons
    # per Newton iteration and the solve fails ("nonlinear iteration failed")
    # regardless of dt cutbacks.  E*t is the physical contact-stiffness scale
    # for a shell (N/m) and is mesh-independent, so capping the penalty at a
    # small multiple of it keeps the contact well-conditioned at any mesh
    # density.  ``contact_stiffness_scale`` is E*t from the caller; 0 disables.
    structural_cap = 0.0
    if contact_stiffness_scale > 0.0:
        structural_cap = _COLLISION_PENALTY_STRUCTURAL_FACTOR * float(contact_stiffness_scale)
        selected = min(selected, structural_cap)
    selected = max(selected, 1.0)
    effective_penetration = math.sqrt(mass * speed * speed / selected) if speed > 0.0 else target_penetration
    return {
        "penalty_stiffness": float(selected),
        "desired_penalty_stiffness": float(desired),
        "dt_stable_penalty_stiffness": float(stable),
        "structural_penalty_cap": float(structural_cap),
        "target_penetration_m": float(target_penetration),
        "effective_penetration_m": float(effective_penetration),
        "impact_energy_j": float(kinetic_energy),
        "energy_softening_factor": float(softening),
        "basis": "dynamic_auto" if structural_cap <= 0.0 or selected < structural_cap else "dynamic_auto_structural_cap",
    }


def _collision_auto_time_settings(generated_geometry: dict, config: LightweightFEMConfig) -> dict[str, float | str]:
    start = np.asarray(
        (
            float(config.collision_start_x_m),
            float(config.collision_start_y_m),
            float(config.collision_start_z_m),
        ),
        dtype=float,
    )
    direction = np.asarray(
        (
            float(config.collision_vector_x),
            float(config.collision_vector_y),
            float(config.collision_vector_z),
        ),
        dtype=float,
    )
    norm = float(np.linalg.norm(direction))
    speed = max(float(config.collision_speed_mps), 0.0)
    radius = max(float(config.collision_radius_m), 1.0e-9)
    if norm <= 1.0e-14 or speed <= 0.0:
        return {
            "mode": "manual_fallback",
            "dt_s": max(float(config.collision_dt_s), 1.0e-9),
            "total_time_s": max(float(config.collision_total_time_s), 1.0e-9),
            "arrival_time_s": 0.0,
            "reason": "nonpositive speed or zero direction",
        }
    direction = direction / norm
    coords = []
    for node in generated_geometry.get("nodes", ()) or ():
        try:
            coords.append(np.asarray(node.get("coords", ()), dtype=float).reshape(3))
        except Exception:
            continue
    if not coords:
        return {
            "mode": "manual_fallback",
            "dt_s": max(float(config.collision_dt_s), 1.0e-9),
            "total_time_s": max(float(config.collision_total_time_s), 1.0e-9),
            "arrival_time_s": 0.0,
            "reason": "no generated nodes",
        }
    projections = np.asarray([float(coord @ direction) for coord in coords], dtype=float)
    lower = float(np.min(projections)) - radius
    upper = float(np.max(projections)) + radius
    start_projection = float(start @ direction)
    if start_projection < lower:
        arrival = (lower - start_projection) / speed
    elif start_projection <= upper:
        arrival = 0.0
    else:
        # The sphere is already past the model along its travel direction; keep a short run for diagnostics.
        arrival = 0.0
    span_time = max((upper - lower) / speed, 2.0 * radius / speed)
    post_time = max(float(config.collision_auto_post_contact_radii), 0.0) * radius / speed
    requested_total_time = max(arrival + span_time + post_time, radius / speed)
    impact_window = max(0.01, min(0.02, 0.10 * radius / speed))
    total_time = max(arrival + impact_window, impact_window)
    steps_per_radius = max(float(config.collision_auto_steps_per_radius), 2.0)
    representative_edge = _collision_representative_shell_edge(generated_geometry)
    dt = radius / (speed * steps_per_radius)
    if representative_edge > 0.0:
        dt = min(dt, representative_edge / (speed * 4.0))
    if float(config.collision_dt_s or 0.0) > 0.0:
        dt = min(dt, float(config.collision_dt_s))
    if float(config.collision_penalty_stiffness_n_per_m or 0.0) > 0.0:
        period = 2.0 * math.pi * math.sqrt(
            max(float(config.collision_mass_kg), 1.0e-9)
            / max(float(config.collision_penalty_stiffness_n_per_m), 1.0e-9)
        )
        dt = min(dt, period / 30.0)
        penalty_info = {
            "penalty_stiffness": float(config.collision_penalty_stiffness_n_per_m),
            "basis": "user",
        }
    else:
        penalty_info = _collision_dynamic_penalty(
            config, dt, representative_edge,
            contact_stiffness_scale=_collision_contact_stiffness_scale(generated_geometry, config),
        )
    target_steps = max(int(math.ceil(total_time / max(dt, 1.0e-12))), 1)
    if target_steps < 120:
        dt = min(dt, total_time / 120.0)
    elif target_steps > 5000:
        total_time = max(dt, dt * 5000.0)
        target_steps = 5000
    return {
        "mode": "auto",
        "dt_s": max(float(dt), 1.0e-9),
        "total_time_s": max(float(total_time), 1.0e-9),
        "arrival_time_s": max(float(arrival), 0.0),
        "span_time_s": float(span_time),
        "post_time_s": float(post_time),
        "requested_total_time_s": float(requested_total_time),
        "impact_window_s": float(impact_window),
        "auto_time_cap": "impact_window",
        "model_projection_min": lower + radius,
        "model_projection_max": upper - radius,
        "representative_shell_edge_m": float(representative_edge),
        "sphere_travel_per_step_m": float(speed * dt),
        "estimated_steps": float(target_steps),
        "recommended_penalty_stiffness": float(penalty_info.get("penalty_stiffness", 0.0)),
        "desired_penalty_stiffness": float(penalty_info.get("desired_penalty_stiffness", penalty_info.get("penalty_stiffness", 0.0))),
        "dt_stable_penalty_stiffness": float(penalty_info.get("dt_stable_penalty_stiffness", penalty_info.get("penalty_stiffness", 0.0))),
        "target_penetration_m": float(penalty_info.get("target_penetration_m", 0.0)),
        "penalty_basis": str(penalty_info.get("basis", "")),
    }


def _deleted_element_ids_for_time(records: object, time_value: float) -> tuple[int, ...]:
    deleted: list[int] = []
    for record in records or ():
        if not isinstance(record, dict):
            continue
        try:
            record_time = float(record.get("time", record.get("load_factor", 0.0)))
            if record_time <= float(time_value) + 1.0e-12:
                deleted.append(int(record.get("element_id")))
        except Exception:
            continue
    return tuple(sorted(set(deleted)))


def _impact_damage_element_fields_for_time(damage_summary: object, time_value: float) -> dict[str, dict[int, float]]:
    fields = {
        "impact_damage": {},
        "impact_damage_utilization": {},
        "impact_damage_scale": {},
    }
    if not isinstance(damage_summary, dict):
        return fields
    for record in damage_summary.get("records", ()) or ():
        if not isinstance(record, dict):
            continue
        try:
            element_id = int(record.get("element_id"))
        except Exception:
            continue
        damage = float(record.get("damage", 0.0) or 0.0)
        scale = float(record.get("scale", 1.0) or 1.0)
        utilization = float(record.get("max_utilization", 0.0) or 0.0)
        history = tuple(record.get("history", ()) or ())
        if history:
            eligible = []
            for item in history:
                if not isinstance(item, dict):
                    continue
                try:
                    if float(item.get("time", 0.0) or 0.0) <= float(time_value) + 1.0e-12:
                        eligible.append(item)
                except Exception:
                    continue
            if eligible:
                latest = eligible[-1]
                damage = float(latest.get("damage", damage) or damage)
                scale = float(latest.get("scale", scale) or scale)
                utilization = float(latest.get("combined_utilization", latest.get("utilization", utilization)) or utilization)
            else:
                damage = 0.0
                utilization = 0.0
                scale = 1.0
        fields["impact_damage"][element_id] = damage
        fields["impact_damage_utilization"][element_id] = utilization
        fields["impact_damage_scale"][element_id] = scale
    return fields


def _filter_visualization_deleted_elements(visualization: dict[str, object], deleted_element_ids: tuple[int, ...]) -> None:
    if not visualization or not deleted_element_ids:
        return
    deleted = {int(element_id) for element_id in deleted_element_ids}
    for key in ("skin_shell_surfaces", "shell_surfaces"):
        visualization[key] = tuple(
            surface for surface in visualization.get(key, ()) or ()
            if int((surface or {}).get("id", -1)) not in deleted
        )
    visualization["hidden_deleted_element_ids"] = tuple(sorted(deleted))


def _solver_type(config: LightweightFEMConfig) -> str:
    solver = _normalized_choice(config.solver_type, "direct").replace(" ", "")
    return solver if solver in {"direct", "gmres", "minres", "bicgstab"} else "direct"


def _include_imported_loads(config: LightweightFEMConfig) -> bool:
    return (not config.custom_load_bc_enabled) or bool(config.custom_loads_add_to_imported)


def _effective_pressure_pa(config: LightweightFEMConfig) -> float:
    imported = float(config.pressure_pa or 0.0)
    custom = float(config.custom_pressure_pa or 0.0)
    if not config.custom_load_bc_enabled:
        return imported
    if _custom_pressure_load_entries(config):
        return imported if config.custom_loads_add_to_imported else 0.0
    if config.custom_loads_add_to_imported:
        return imported + custom
    return custom


def _custom_has_fixed_support(config: LightweightFEMConfig) -> bool:
    choices = (
        config.plate_edge_x0_support,
        config.plate_edge_x1_support,
        config.plate_edge_y0_support,
        config.plate_edge_y1_support,
        config.cylinder_lower_support,
        config.cylinder_upper_support,
    )
    return any(_normalized_choice(choice, "free") in {"fixed", "clamped"} for choice in choices)


def _has_custom_support(config: LightweightFEMConfig) -> bool:
    choices = (
        config.plate_edge_x0_support,
        config.plate_edge_x1_support,
        config.plate_edge_y0_support,
        config.plate_edge_y1_support,
        config.cylinder_lower_support,
        config.cylinder_upper_support,
    )
    return any(_support_constraints(choice, "flat") for choice in choices)


def _constraint_mode(config: LightweightFEMConfig, geometry: dict | None = None) -> str:
    if not config.custom_use_nullspace_projection:
        return "transformation"
    if config.custom_load_bc_enabled and not (_custom_has_fixed_support(config) or _has_custom_support(config)):
        return "nullspace"
    if config.custom_load_bc_enabled and (_custom_has_fixed_support(config) or _has_custom_support(config)):
        return "transformation"
    if _normalized_choice(config.boundary_condition) in {"nullspace", "nullspace projection"}:
        return "nullspace"
    is_flat = (geometry or {}).get("geometry") != "cylinder"
    if is_flat and _normalized_choice(config.boundary_condition) in {"auto", "simply supported", "simple", "ss", "pinned", "pinned edges", "fixed", "clamped"}:
        return "transformation"
    if not is_flat and _normalized_choice(config.boundary_condition) in {"clamped", "fixed", "fixed ends"}:
        return "transformation"
    if not is_flat and _normalized_choice(config.boundary_condition) in {"auto", "free", "none"}:
        return "nullspace"
    return "auto"


def _allow_unbalanced_free_free(config: LightweightFEMConfig, geometry: dict | None = None) -> bool:
    if bool(config.allow_unbalanced_free_free):
        return True
    return _constraint_mode(config, geometry) == "nullspace"


def _buckling_load_factor_range(config: LightweightFEMConfig) -> tuple[float | None, float | None] | None:
    lower = float(config.buckling_min_load_factor or 0.0)
    upper = float(config.buckling_max_load_factor or 0.0)
    if lower <= 0.0 and upper <= 0.0:
        return None
    return (lower if lower > 0.0 else None, upper if upper > 0.0 else None)


def _buckling_solver_kwargs(config: LightweightFEMConfig) -> dict[str, object]:
    kwargs: dict[str, object] = {
        "repeated_tolerance": max(float(config.buckling_repeated_tolerance or 1.0e-3), 0.0),
        "allow_dense_fallback": bool(config.buckling_allow_dense_fallback),
    }
    shift = float(config.buckling_shift_load_factor or 0.0)
    if shift > 0.0:
        kwargs["shift_load_factor"] = shift
    load_range = _buckling_load_factor_range(config)
    if load_range is not None:
        kwargs["load_factor_range"] = load_range
    return kwargs


def _record_buckling_mesh_adequacy(
        model,
        buckling_result,
        config: LightweightFEMConfig,
        prestress_summary: dict[str, object],
        diagnostics: list[str],
) -> None:
    if _full_backend is None or not hasattr(_full_backend, "evaluate_mode_mesh_adequacy"):
        return
    if buckling_result is None or not getattr(buckling_result, "modes", None):
        return
    try:
        mode_number = _positive_int(config.capacity_buckling_mode_number, 1)
        adequacy = _full_backend.evaluate_mode_mesh_adequacy(
            model,
            buckling_result,
            mode_number=mode_number,
            min_elements_per_half_wave=_positive_int(config.capacity_mesh_min_elements_per_half_wave, 4),
        )
    except Exception as exc:
        diagnostics.append("Buckling mode mesh adequacy check failed: " + str(exc))
        return
    prestress_summary["buckling_mesh_status"] = str(getattr(adequacy, "status", "unknown"))
    prestress_summary["buckling_mesh_active_nodes"] = float(getattr(adequacy, "active_node_count", 0) or 0)
    prestress_summary["buckling_mesh_active_elements"] = float(getattr(adequacy, "active_element_count", 0) or 0)
    prestress_summary["buckling_mesh_estimated_half_waves"] = float(getattr(adequacy, "estimated_half_waves", 0) or 0)
    prestress_summary["buckling_mesh_elements_per_half_wave"] = float(getattr(adequacy, "elements_per_half_wave", 0.0) or 0.0)
    if str(getattr(adequacy, "status", "ok")) != "ok":
        diagnostics.append(
            "Buckling mode mesh adequacy "
            + str(getattr(adequacy, "status", "unknown"))
            + " for mode "
            + str(mode_number)
            + "."
        )
    for warning in getattr(adequacy, "warnings", ()) or ():
        diagnostics.append(str(warning))


def _wants_capacity_workflow(config: LightweightFEMConfig) -> bool:
    choice = _normalized_choice(config.runtime_solver, "stepwise")
    return choice in {
        "anysolver capacity workflow",
        # Legacy serialized ANYstructure selector; retained so saved FEM
        # option state remains readable after the package transfer.
        "anyintelligent capacity workflow",
        "capacity workflow",
        "nonlinear capacity workflow",
        "structured capacity workflow",
    }


def _recovery_config(config: LightweightFEMConfig):
    if _full_backend is None or not hasattr(_full_backend, "RecoveryConfig"):
        return None
    mode = _normalized_choice(config.recovery_history_mode, "full")
    if mode not in {"full", "selected", "envelope"}:
        mode = "full"
    return _full_backend.RecoveryConfig(history_mode=mode, store_full_histories=(mode == "full"))


def _auto_thread_cap() -> int:
    cpu_count = max(int(os.cpu_count() or 1), 1)
    if cpu_count <= 2:
        return 1
    if cpu_count <= 6:
        return max(1, cpu_count // 2)
    return min(8, max(2, cpu_count // 2))


def _auto_assembly_thread_count(config: LightweightFEMConfig, generated_geometry: dict | None = None) -> int | None:
    requested = int(config.nonlinear_assembly_threads or 0)
    if requested > 0:
        return requested
    if generated_geometry is None:
        return None
    element_count = int(len(generated_geometry.get("shells", []) or ())) + int(len(generated_geometry.get("beams", []) or ()))
    node_count = int(len(generated_geometry.get("nodes", []) or ()))
    if element_count <= 0 and node_count <= 0:
        return None
    layers = _nonlinear_layer_count(config.nonlinear_layers)
    work_units = max(float(element_count), 0.5 * float(node_count)) * float(layers)
    cap = _auto_thread_cap()
    if work_units < 2500.0:
        return 1
    if work_units < 10000.0:
        return min(2, cap)
    if work_units < 40000.0:
        return min(4, cap)
    return cap


def _resource_config(
        config: LightweightFEMConfig,
        generated_geometry: dict | None = None,
        *,
        auto_assembly: bool = False,
):
    if _full_backend is None or not hasattr(_full_backend, "ResourceConfig"):
        return None
    recovery_threads = int(config.recovery_threads or 0)
    assembly_threads = (
        _auto_assembly_thread_count(config, generated_geometry)
        if auto_assembly
        else int(config.nonlinear_assembly_threads or 0)
    )
    memory_limit_mb = float(config.memory_limit_mb or 0.0)
    if recovery_threads <= 0 and (assembly_threads is None or assembly_threads <= 0) and memory_limit_mb <= 0.0:
        return None
    return _full_backend.ResourceConfig(
        assembly_threads=assembly_threads if assembly_threads is not None and assembly_threads > 0 else None,
        recovery_threads=recovery_threads if recovery_threads > 0 else None,
        memory_limit_bytes=int(memory_limit_mb * 1024.0 * 1024.0) if memory_limit_mb > 0.0 else None,
        deterministic=True,
        metadata={
            "assembly_threads_policy": (
                "manual"
                if int(config.nonlinear_assembly_threads or 0) > 0
                else ("auto" if auto_assembly and assembly_threads is not None else "backend")
            ),
            "assembly_thread_cap": float(_auto_thread_cap()),
        },
    )


def _resource_assembly_threads(resource_config: object | None, fallback: int = 0) -> int:
    value = getattr(resource_config, "assembly_threads", None)
    if value is None:
        return int(fallback)
    try:
        return int(value)
    except (TypeError, ValueError):
        return int(fallback)


def _wants_nonlinear_analysis(config: LightweightFEMConfig) -> bool:
    return _normalized_choice(config.analysis_type, "linear eigenvalue") not in {
        "linear",
        "linear eigenvalue",
        "linear static eigenvalue",
        "linear static + eigenvalue",
    }


def _wants_nonlinear_buckling(config: LightweightFEMConfig) -> bool:
    return _normalized_choice(config.buckling_analysis_type, "linear eigenvalue") not in {
        "linear eigenvalue",
        "eigenvalue",
    }


def _wants_eigenvalue_buckling(config: LightweightFEMConfig) -> bool:
    choice = _normalized_choice(config.runtime_solver, "stepwise")
    return choice not in {"static only", "nonlinear static"}


def _wants_static_nonlinear_analysis(config: LightweightFEMConfig) -> bool:
    if bool(config.post_buckling_enabled):
        # Post-buckling tracing is an arc-length nonlinear static solve.
        return True
    choice = _normalized_choice(config.analysis_type, "linear eigenvalue")
    runtime = _normalized_choice(config.runtime_solver, "stepwise")
    if runtime == "nonlinear static":
        return True
    return choice in {
        "geometric nonlinear static",
        "material nonlinear static",
        "geom. + material nonlinear static",
        "geom + material nonlinear static",
        "geometric and material nonlinear static",
    }


def _effective_nonlinear_static_kinematics(config: LightweightFEMConfig) -> str:
    if not _wants_static_nonlinear_analysis(config):
        return "von_karman"
    if _wants_capacity_workflow(config):
        return "von_karman"
    if _wants_tangent_stability_analysis(config):
        return "von_karman"
    return _normalized_kinematics(config.nonlinear_static_kinematics)


def _invalid_follower_pressure_reason(config: LightweightFEMConfig) -> str:
    if not bool(config.follower_pressure):
        return ""
    if bool(config.collision_enabled) or bool(config.custom_time_domain_enabled):
        return "Follower pressure is not supported by transient or collision runtime paths."
    if _wants_capacity_workflow(config):
        return "Follower pressure is not supported by the structured capacity workflow."
    if not _wants_static_nonlinear_analysis(config):
        return "Follower pressure requires a nonlinear static or arc-length runtime path."
    if _wants_eigenvalue_buckling(config):
        return (
            "Follower pressure requires the 'static only' or 'nonlinear static' runtime path; "
            "the stepwise eigenvalue-buckling path does not yet include the follower-load "
            "tangent in its stability pencil."
        )
    return ""


def _invalid_corotational_static_fracture(config: LightweightFEMConfig) -> bool:
    return (
        not bool(config.collision_enabled)
        and _effective_nonlinear_static_kinematics(config) == "corotational"
        and bool(config.fracture_enabled)
    )


def _nonlinear_solution_control(config: LightweightFEMConfig) -> str:
    if bool(config.post_buckling_enabled):
        # Post-buckling continuation requires arc-length control: Newton
        # force control cannot pass the limit point.
        return "arc length"
    choice = _normalized_choice(config.nonlinear_solution_control, "newton force control")
    if choice in {"arc", "arc length", "arc-length", "arc length continuation", "crisfield arc length"}:
        return "arc length"
    return "newton force control"


def _arc_length_control(config: LightweightFEMConfig):
    if _backend_arc_length_control is None:
        return None
    max_load = max(float(config.nonlinear_max_load_factor or 1.0), 1.0e-9)
    steps = _positive_int(config.nonlinear_steps, 12)
    initial_increment = max(max_load / float(steps), 1.0e-6)
    minimum_increment = max(initial_increment / 64.0, 1.0e-8)
    maximum_increment = max(initial_increment * 4.0, initial_increment)
    post_buckling = bool(config.post_buckling_enabled)
    stop_fraction = min(max(float(config.post_buckling_stop_load_fraction or 0.5), 0.01), 0.99)
    max_translation = float(config.post_buckling_max_displacement_m or 0.0)
    return _backend_arc_length_control(
        initial_load_increment=initial_increment,
        minimum_load_increment=minimum_increment,
        maximum_load_increment=maximum_increment,
        maximum_absolute_load_factor=max_load,
        # Post-buckling: allow a long descending branch and stop automatically
        # when the load has shed to the configured fraction of the peak (or
        # when the optional displacement guard trips).  The plain arc-length
        # mode keeps the short limit-point confirmation behaviour.
        max_steps=max(steps * (12 if post_buckling else 4), steps + 4),
        stop_after_peak_steps=(10_000 if post_buckling else 4),
        post_peak_load_fraction=(stop_fraction if post_buckling else None),
        max_translation=(max_translation if post_buckling and max_translation > 0.0 else None),
        target_iterations=max(3, min(_positive_int(config.nonlinear_max_iterations, 25) // 3, 10)),
        preload_steps=max(steps, 1),
    )


def _wants_material_nonlinear_analysis(config: LightweightFEMConfig) -> bool:
    if bool(config.post_buckling_enabled):
        # Post-buckling capacity of steel structures is plasticity-governed:
        # an elastic descending branch is non-physical for design work, so
        # the trace always runs geometric + material nonlinear (DNV curve
        # from the steel grade) regardless of the material-model dropdown.
        return True
    choice = _normalized_choice(config.analysis_type, "linear eigenvalue")
    model = _normalized_choice(config.material_model, "linear elastic")
    return "material" in choice or model in {
        "dnv rp c208 steel",
        "dnv c208 steel",
        "dnv rp c208",
        "rp c208 steel",
    }


def resolve_runtime_analysis(
    config: LightweightFEMConfig,
) -> RuntimeAnalysisSelection:
    """Return the normalized solver choices an integration should display.

    This is the supported alternative to importing runtime implementation
    helpers with leading underscores.  It lets a GUI reflect solver auto-
    selections without duplicating the normalization rules.
    """

    return RuntimeAnalysisSelection(
        static_nonlinear=_wants_static_nonlinear_analysis(config),
        material_nonlinear=_wants_material_nonlinear_analysis(config),
        solution_control=_nonlinear_solution_control(config),
        kinematics=_effective_nonlinear_static_kinematics(config),
    )


def _wants_tangent_stability_analysis(config: LightweightFEMConfig) -> bool:
    choice = _normalized_choice(config.analysis_type, "linear eigenvalue")
    buckling_choice = _normalized_choice(config.buckling_analysis_type, "linear eigenvalue")
    if choice == "nonlinear stability":
        return True
    return buckling_choice == "nonlinear limit" and not _wants_static_nonlinear_analysis(config)


def _can_reuse_linear_buckling_session(config: LightweightFEMConfig) -> bool:
    """Whether one immutable operator serves linear prestress and buckling."""

    return bool(
        _wants_eigenvalue_buckling(config)
        and not _wants_capacity_workflow(config)
        and not _wants_static_nonlinear_analysis(config)
        and not _wants_tangent_stability_analysis(config)
        and not config.collision_enabled
    )


def _positive_int(value: object, fallback: int, minimum: int = 1) -> int:
    try:
        number = int(float(value))
    except (TypeError, ValueError):
        number = fallback
    return max(number, minimum)


def _nonlinear_layer_count(value: object) -> int:
    requested = _positive_int(value, 5, 3)
    supported = (3, 5, 7, 9, 11)
    return min(supported, key=lambda item: abs(item - requested))


_MATERIAL_MODEL_C208_CHOICES = {"dnv rp c208 steel", "dnv c208 steel", "dnv rp c208", "rp c208 steel"}


def _auto_set_parameter_notes(config: LightweightFEMConfig) -> list[str]:
    """Explicit 'Auto-set:' diagnostics for parameters the run overrides.

    Whenever the solver silently promotes or coerces a user input (material
    model, solution control, kinematics, layer count, runtime path), the run
    diagnostics must state what was set and why.
    """
    notes: list[str] = []
    analysis_choice = _normalized_choice(config.analysis_type, "linear eigenvalue")
    material_choice = _normalized_choice(config.material_model, "linear elastic")
    material_dropdown_is_linear = material_choice not in _MATERIAL_MODEL_C208_CHOICES

    if _wants_material_nonlinear_analysis(config) and material_dropdown_is_linear:
        if bool(config.post_buckling_enabled):
            reason = "post-buckling continuation always runs with steel plasticity"
        else:
            reason = "the analysis type requests material nonlinearity"
        notes.append(
            "Auto-set: material model 'linear elastic' -> 'DNV-RP-C208 steel' (grade "
            + str(config.steel_grade) + ") because " + reason + "."
        )
    if (
            bool(config.collision_enabled)
            and bool(config.collision_material_nonlinear_enabled)
            and material_dropdown_is_linear
            and not _wants_material_nonlinear_analysis(config)
    ):
        notes.append(
            "Auto-set: DNV-RP-C208 hardening curve (grade " + str(config.steel_grade)
            + ") applied for the material-nonlinear collision transient although the material dropdown is 'linear elastic'."
        )

    if _wants_static_nonlinear_analysis(config):
        control_choice = _normalized_choice(config.nonlinear_solution_control, "newton force control")
        effective_control = _nonlinear_solution_control(config)
        if effective_control == "arc length" and control_choice not in {
            "arc", "arc length", "arc-length", "arc length continuation", "crisfield arc length",
        }:
            notes.append(
                "Auto-set: nonlinear solution control '" + str(config.nonlinear_solution_control)
                + "' -> 'arc length' because post-buckling continuation must pass the limit point."
            )
        kinematics_choice = _normalized_kinematics(config.nonlinear_static_kinematics)
        effective_kinematics = _effective_nonlinear_static_kinematics(config)
        if effective_kinematics != kinematics_choice:
            if _wants_capacity_workflow(config):
                reason = "the ANYsolver capacity workflow solves with Von Karman kinematics"
            elif _wants_tangent_stability_analysis(config):
                reason = "tangent stability solves with Von Karman kinematics"
            else:
                reason = "arc-length control solves with Von Karman kinematics"
            notes.append(
                "Auto-set: kinematics 'corotational' -> 'Von Karman' because " + reason + "."
            )
        if analysis_choice == "linear eigenvalue" and not bool(config.post_buckling_enabled):
            runtime_choice = _normalized_choice(config.runtime_solver, "stepwise")
            if runtime_choice == "nonlinear static":
                notes.append(
                    "Auto-set: analysis runs as a nonlinear static solve because the runtime path is 'nonlinear static' "
                    "although the analysis dropdown is 'linear eigenvalue'."
                )

    if _wants_material_nonlinear_analysis(config):
        requested_layers = _positive_int(config.nonlinear_layers, 5)
        effective_layers = _nonlinear_layer_count(config.nonlinear_layers)
        if effective_layers != requested_layers:
            notes.append(
                "Auto-set: shell integration layers " + str(requested_layers) + " -> "
                + str(effective_layers) + " (supported counts are 3, 5, 7, 9, 11)."
            )
    return notes


def _nonlinear_curve_payload(config: LightweightFEMConfig, geometry: dict) -> tuple[object | None, dict[str, float | str]]:
    if _backend_curve_from_properties is None:
        return None, {}
    # Collision runs with material nonlinearity enabled need the hardening
    # curve on the model even when the static material model dropdown is
    # left at "linear elastic"; without it the "nonlinear" impact transient
    # silently degenerates to an elastic response with unbounded stresses.
    collision_wants_curve = bool(config.collision_enabled) and bool(config.collision_material_nonlinear_enabled)
    if not (_wants_material_nonlinear_analysis(config) or collision_wants_curve):
        return None, {}
    thickness = _positive(geometry.get("thickness_m", 0.0), 0.016)
    properties = dnv_c208_steel_properties(config.steel_grade, thickness, config.steel_thickness_class)
    curve_properties = {
        "sigma_prop": properties["sigma_prop"],
        "sigma_yield": properties["sigma_yield"],
        "sigma_yield_2": properties["sigma_yield_2"],
        "eps_p_y1": properties["eps_p_y1"],
        "eps_p_y2": properties["eps_p_y2"],
        "K": properties["K"],
        "n": properties["n"],
    }
    return _backend_curve_from_properties(curve_properties), properties


def _apply_material_curve_to_model(model, curve: object | None, properties: dict[str, float | str]) -> None:
    if curve is None:
        return
    from .materials import material_symmetry

    isotropic_material_names: set[str] = set()
    for material_name, material in getattr(model, "materials", {}).items():
        # The runtime dropdown supplies an isotropic DNV steel curve.  Preserve
        # orthotropic constitutive data (including an ANYmaterial-provided
        # hardening law) instead of injecting a curve whose reference stress
        # and elastic constants belong to a different material model.
        if material_symmetry(material) != "isotropic":
            continue
        isotropic_material_names.add(str(material_name))
        material.hardening_curve = curve
        if hasattr(material, "elastic_modulus"):
            material.elastic_modulus = float(
                properties.get("E_pa", material.elastic_modulus)
            )
        if hasattr(material, "yield_stress"):
            material.yield_stress = float(
                properties.get("sigma_yield", material.yield_stress)
            )

    for element in getattr(model.mesh, "elements", {}).values():
        if element.__class__.__name__ in {"BeamElement", "QuadraticBeamElement"}:
            if str(getattr(element, "material_name", "")) not in isotropic_material_names:
                # Orthotropic fiber plasticity is an explicit section opt-in
                # and requires Hill X; the isotropic runtime dropdown must not
                # enable it as a side effect.
                continue
            if not hasattr(element, "cross_section") or element.cross_section is None:
                element.cross_section = {}
            if isinstance(element.cross_section, dict):
                element.cross_section["fiber_plasticity"] = True
            if hasattr(element, "_fiber_plasticity"):
                element._fiber_plasticity = True


def _shell_element_ids(model) -> tuple[int, ...]:
    ids: list[int] = []
    for element_id, element in getattr(model.mesh, "elements", {}).items():
        if hasattr(element, "thickness") and hasattr(element, "node_ids"):
            ids.append(int(element_id))
    return tuple(ids)


def _shell_node_ids(model) -> tuple[int, ...]:
    node_ids: set[int] = set()
    for element_id in _shell_element_ids(model):
        element = model.mesh.get_element(element_id)
        if element is not None:
            node_ids.update(int(node_id) for node_id in getattr(element, "node_ids", []))
    return tuple(sorted(node_ids))


def _build_runtime_imperfection(model, generated_geometry: dict, geometry: dict, config: LightweightFEMConfig):
    """Create a stress-free imperfection object for the synced backend."""

    if not config.imperfection_enabled or _full_backend is None:
        return None, {}
    shape = _normalized_choice(config.imperfection_shape, "standard plate/cylinder")
    if shape in {"none", "off", "disabled"}:
        return None, {}
    shell_ids = _shell_element_ids(model)
    if not shell_ids:
        return None, {"status": "no shell elements"}

    amplitude = float(config.imperfection_amplitude_m or 0.0)
    amplitude_value = amplitude if amplitude > 0.0 else None
    wave_a = _positive_int(config.imperfection_wave_a, 1)
    wave_b = _positive_int(config.imperfection_wave_b, 1)

    if generated_geometry.get("plot_type") != "cylinder":
        imperfection = _full_backend.StandardImperfection(
            kind="plate_mode",
            node_ids=shell_ids,
            amplitude=amplitude_value,
            direction=(0.0, 0.0, 1.0),
            axes=(0, 1),
            waves=(wave_a, wave_b),
            name="runtime_plate_half_wave",
        )
        metadata = {
            "kind": "plate half-wave",
            "amplitude_m": amplitude if amplitude > 0.0 else 0.0,
            "amplitude_source": "user" if amplitude > 0.0 else "standard s/200 default",
            "waves_a": wave_a,
            "waves_b": wave_b,
        }
        return imperfection, metadata

    node_ids = _shell_node_ids(model)
    coords_by_node = {}
    for node_id in node_ids:
        node = model.mesh.get_node(int(node_id))
        if node is not None:
            coords_by_node[int(node_id)] = np.asarray(node.coords(), dtype=float)
    if not coords_by_node:
        return None, {"status": "no shell nodes"}
    values = np.asarray(list(coords_by_node.values()), dtype=float)
    z_min = float(np.min(values[:, 2]))
    z_span = max(float(np.max(values[:, 2]) - z_min), 1.0e-12)
    radius = _positive(generated_geometry.get("radius_m", geometry.get("radius_m", 0.0)), 0.0)
    if amplitude <= 0.0:
        spacing = _positive(geometry.get("stiffener_spacing_m", 0.0), 0.0)
        if spacing <= 0.0 and radius > 0.0:
            spacing = 2.0 * math.pi * radius / max(len(set(round(math.atan2(coord[1], coord[0]), 12) for coord in coords_by_node.values())), 1)
        amplitude = max(spacing, z_span) / 200.0 if max(spacing, z_span) > 0.0 else 0.0
    offsets = {}
    for node_id, coord in coords_by_node.items():
        radial = np.array([coord[0], coord[1], 0.0], dtype=float)
        norm = float(np.linalg.norm(radial))
        if norm <= 1.0e-12:
            continue
        radial /= norm
        theta = math.atan2(float(coord[1]), float(coord[0]))
        axial_pos = (float(coord[2]) - z_min) / z_span
        shape_value = math.sin(wave_b * math.pi * axial_pos) * math.cos(wave_a * theta)
        offsets[node_id] = amplitude * shape_value * radial
    imperfection = _full_backend.ImperfectionField(
        offsets,
        name="runtime_cylinder_radial_imperfection",
        metadata={"kind": "cylinder radial", "waves": (wave_a, wave_b), "amplitude": amplitude},
    )
    metadata = {
        "kind": "cylinder radial",
        "amplitude_m": amplitude,
        "amplitude_source": "user" if float(config.imperfection_amplitude_m or 0.0) > 0.0 else "standard spacing/200 default",
        "waves_a": wave_a,
        "waves_b": wave_b,
    }
    return imperfection, metadata


def _apply_runtime_imperfection(model, generated_geometry: dict, geometry: dict, config: LightweightFEMConfig) -> dict[str, object]:
    if _full_backend is None or not hasattr(_full_backend, "apply_imperfection"):
        return {}
    imperfection, metadata = _build_runtime_imperfection(model, generated_geometry, geometry, config)
    if imperfection is None:
        return dict(metadata)
    _full_backend.apply_imperfection(model, imperfection, copy_model=False)
    records = getattr(model, "imperfection_metadata", []) or []
    if records:
        metadata["max_offset_m"] = float(records[-1].get("max_offset", 0.0) or 0.0)
    metadata["status"] = "applied"
    return metadata


def runtime_imperfection_preview_offsets(
    generated_geometry: dict,
    config: LightweightFEMConfig,
    geometry: dict,
) -> dict[int, tuple[float, float, float]]:
    """Nodal offsets the standard runtime imperfection would apply, without solving.

    Builds the backend FE model from the generated geometry and runs the exact
    imperfection path used by the solver, then returns the coordinate deltas per
    node so the mesh preview can display what the analysis will actually use.
    """

    if _full_backend is None or not hasattr(_full_backend, "apply_imperfection"):
        return {}
    if not bool(config.imperfection_enabled):
        return {}
    backend_config = _full_backend.AnyStructureFEMConfig(
        pressure_pa=0.0,
        load_scale=1.0,
        num_buckling_modes=1,
        add_inplane_edge_loads=False,
        auto_idealize_member_plates_as_beams=not _member_webs_as_shells(config),
        exclude_idealized_member_plates=not _member_webs_as_shells(config),
        require_idealized_member_beams=False,
        elastic_modulus=float(config.elastic_modulus_pa),
        poisson_ratio=float(config.poisson_ratio),
        yield_stress=float(config.yield_stress_pa),
    )
    try:
        model = _full_backend.build_fe_model_from_generated_geometry(generated_geometry, backend_config)
    except Exception:
        return {}
    original = {
        int(node_id): np.asarray(node.coords(), dtype=float).copy()
        for node_id, node in model.mesh.nodes.items()
    }
    metadata = _apply_runtime_imperfection(model, generated_geometry, geometry, config)
    if metadata.get("status") != "applied":
        return {}
    offsets: dict[int, tuple[float, float, float]] = {}
    for node_id, before in original.items():
        node = model.mesh.get_node(node_id)
        if node is None:
            continue
        delta = np.asarray(node.coords(), dtype=float) - before
        if float(np.max(np.abs(delta))) > 1.0e-15:
            offsets[node_id] = (float(delta[0]), float(delta[1]), float(delta[2]))
    return offsets


def _element_centroid(model, element_id: int) -> np.ndarray | None:
    element = model.mesh.get_element(int(element_id))
    if element is None or not hasattr(element, "get_node_coordinates"):
        return None
    try:
        return np.mean(np.asarray(element.get_node_coordinates(model.mesh), dtype=float), axis=0)
    except Exception:
        return None


def _custom_load_entries(config: LightweightFEMConfig) -> list[dict[str, object]]:
    try:
        import json
        raw_entries = json.loads(config.custom_loads_json) if config.custom_loads_json else []
    except Exception:
        return []
    if not isinstance(raw_entries, list):
        return []
    return [entry for entry in raw_entries if isinstance(entry, dict)]


def _custom_pressure_load_entries(config: LightweightFEMConfig) -> list[dict[str, object]]:
    entries = [
        entry for entry in _custom_load_entries(config)
        if str(entry.get("type", "")).lower() in {"pressure", "panel_pressure"}
    ]
    return entries


def _custom_edge_load_entries(config: LightweightFEMConfig) -> list[dict[str, object]]:
    entries = [
        entry for entry in _custom_load_entries(config)
        if str(entry.get("type", "")).lower() in {"edge", "edge_load"}
    ]
    return entries


def _normalised_custom_pressure_patches(patches: object) -> list[dict[str, object]]:
    if not isinstance(patches, list):
        return []
    normalised: list[dict[str, object]] = []
    for patch in patches:
        if not isinstance(patch, dict):
            continue
        min_a = float(patch.get("min_a", 0.0))
        max_a = float(patch.get("max_a", 0.0))
        min_b = float(patch.get("min_b", 0.0))
        max_b = float(patch.get("max_b", 0.0))
        if max_a <= min_a or max_b <= min_b:
            continue
        normalised.append({
            "min_a": min_a,
            "max_a": max_a,
            "min_b": min_b,
            "max_b": max_b,
            "axis_a_origin": str(patch.get("axis_a_origin", "") or ""),
        })
    return normalised


def _custom_patch_axis_interval(patch: dict[str, object], axis: str, limit: float) -> tuple[float, float]:
    lower_key, upper_key = ("min_a", "max_a") if axis == "a" else ("min_b", "max_b")
    lower = float(patch.get(lower_key, 0.0))
    upper = float(patch.get(upper_key, 0.0))
    if upper < lower:
        lower, upper = upper, lower
    if axis == "a":
        origin = str(patch.get("axis_a_origin", "") or "").strip().lower()
        centered = origin in {"center", "centered", "mid", "midspan", "middle"}
        half = 0.5 * float(limit)
        tol = max(float(limit) * 1.0e-9, 1.0e-9)
        if centered or (-half - tol <= lower <= half + tol and -half - tol <= upper <= half + tol and lower < 0.0):
            lower += half
            upper += half
    return max(0.0, lower), min(float(limit), upper)


def _custom_pressure_patches(config: LightweightFEMConfig) -> list[dict[str, object]]:
    entries = _custom_pressure_load_entries(config)
    if entries:
        patches: list[dict[str, object]] = []
        for entry in entries:
            patches.extend(_normalised_custom_pressure_patches(entry.get("patches", [])))
        return patches
    try:
        import json
        raw_patches = json.loads(config.custom_pressure_patches_json) if config.custom_pressure_patches_json else []
    except Exception:
        return []
    return _normalised_custom_pressure_patches(raw_patches)


def _custom_patch_axis_breaks(config: LightweightFEMConfig, axis: str, limit: float) -> tuple[float, ...]:
    """Return custom pressure-patch boundaries in local generated-geometry coordinates."""

    if not config.custom_load_bc_enabled:
        return ()
    values: list[float] = []
    tol = max(float(limit) * 1.0e-9, 1.0e-9)
    for patch in _custom_pressure_patches(config):
        try:
            lower, upper = _custom_patch_axis_interval(patch, axis, limit)
        except (TypeError, ValueError):
            continue
        for value in (lower, upper):
            if tol < value < float(limit) - tol:
                values.append(value)
    return tuple(sorted(set(round(value, 12) for value in values)))


def _thickness_regions(config: LightweightFEMConfig) -> list[dict[str, object]]:
    """Parse per-region plate-thickness overrides from the geometry panel.

    Each region is ``{"thickness_m": t, "patches": [{min_a, max_a, min_b,
    max_b}, ...]}`` in the local generated-geometry (a, b) coordinates: flat
    (x, y), cylinder (axial z, circumferential arc).  Regions apply
    independently of the custom load/BC mode.
    """
    try:
        raw = json.loads(config.thickness_regions_json) if config.thickness_regions_json else []
    except Exception:
        return []
    if not isinstance(raw, list):
        return []
    regions: list[dict[str, object]] = []
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        thickness = _optional_positive_float(entry.get("thickness_m"))
        patches = entry.get("patches", [])
        if thickness is None or not isinstance(patches, list):
            continue
        clean = [dict(patch) for patch in patches if isinstance(patch, dict)]
        if clean:
            regions.append({"thickness_m": float(thickness), "patches": clean})
    return regions


def _optional_positive_float(value: object) -> float | None:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(parsed) or parsed <= 0.0:
        return None
    return parsed


def _thickness_region_axis_breaks(config: LightweightFEMConfig, axis: str, limit: float) -> tuple[float, ...]:
    """Region boundary coordinates so elements never straddle a thickness step."""
    values: list[float] = []
    tol = max(float(limit) * 1.0e-9, 1.0e-9)
    for region in _thickness_regions(config):
        for patch in region.get("patches", ()) or ():
            try:
                lower, upper = _custom_patch_axis_interval(patch, axis, limit)
            except (TypeError, ValueError):
                continue
            for value in (lower, upper):
                if tol < value < float(limit) - tol:
                    values.append(value)
    return tuple(sorted(set(round(value, 12) for value in values)))


def _apply_thickness_regions(
    shells: list[dict[str, object]],
    nodes: list[dict[str, object]],
    config: LightweightFEMConfig,
    param_of_coords,
    periodic_b: float = 0.0,
) -> dict[str, object] | None:
    """Assign per-region plate thickness to skin shells by centroid location."""
    regions = _thickness_regions(config)
    if not regions:
        return None
    coords_by_id = {int(n["id"]): [float(c) for c in n["coords"]] for n in nodes if "id" in n}
    assigned = 0
    thicknesses: set[float] = set()
    for shell in shells:
        if "role" in shell:
            continue  # member shells keep their section thickness
        ids = [int(i) for i in shell.get("node_ids", ()) or () if int(i) in coords_by_id]
        if len(ids) < 3:
            continue
        params = [param_of_coords(coords_by_id[i]) for i in ids]
        centroid_a = sum(p[0] for p in params) / len(params)
        if periodic_b > 0.0:
            bs = [p[1] for p in params]
            if max(bs) - min(bs) > 0.5 * periodic_b:
                bs = [b if b >= 0.5 * periodic_b else b + periodic_b for b in bs]
            centroid_b = (sum(bs) / len(bs)) % periodic_b
        else:
            centroid_b = sum(p[1] for p in params) / len(params)
        for region in regions:
            hit = False
            for patch in region.get("patches", ()) or ():
                try:
                    min_a = float(patch.get("min_a", 0.0))
                    max_a = float(patch.get("max_a", 0.0))
                    min_b = float(patch.get("min_b", 0.0))
                    max_b = float(patch.get("max_b", 0.0))
                except (TypeError, ValueError):
                    continue
                if min_a <= centroid_a <= max_a and min_b <= centroid_b <= max_b:
                    hit = True
                    break
            if hit:
                shell["thickness"] = float(region["thickness_m"])
                assigned += 1
                thicknesses.add(float(region["thickness_m"]))
                # regions are applied in order; the last matching region wins
    if assigned == 0:
        return None
    return {
        "regions": len(regions),
        "shells_assigned": int(assigned),
        "thicknesses_m": sorted(thicknesses),
    }


def _custom_bc_segments(config: LightweightFEMConfig) -> list[dict[str, float | str]]:
    """Per-edge-segment boundary conditions from the GUI edge selection."""
    try:
        raw = json.loads(config.custom_bc_segments_json) if config.custom_bc_segments_json else []
    except Exception:
        return []
    if not isinstance(raw, list):
        return []
    segments: list[dict[str, float | str]] = []
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        # Per-DOF constraints (new BC tab) take precedence; fall back to the
        # legacy named "support" ("simply supported"/"fixed") for old saves.
        constraints = _dof_constraint_map(entry.get("constraints"))
        support = _normalized_choice(entry.get("support"), "free")
        if not constraints and support in {"", "free", "none"}:
            continue
        try:
            start = float(entry.get("start_coordinate", 0.0))
            end = float(entry.get("end_coordinate", 0.0))
            fixed = float(entry.get("fixed_coordinate", 0.0))
        except (TypeError, ValueError):
            continue
        if abs(end - start) <= 1.0e-12:
            continue
        segments.append(
            {
                "varying_axis": str(entry.get("varying_axis", "a")).lower(),
                "fixed_coordinate": fixed,
                "start_coordinate": min(start, end),
                "end_coordinate": max(start, end),
                "support": support,
                "constraints": constraints,
            }
        )
    return segments


def _custom_bc_segment_supports(
    nodes: list[dict[str, object]],
    config: LightweightFEMConfig,
    length: float,
    width: float,
    radius: float = 0.0,
) -> list[dict[str, object]]:
    """Support groups for selected-edge boundary conditions.

    Each segment carries either a per-DOF constraints dict (new BC tab) or a
    legacy named support.  Flat panels select on (x, y) at z=0; cylinders map
    the node to (axial z, arc-length) so an edge line is a constant-arc
    generator or a constant-z ring.
    """
    segments = _custom_bc_segments(config)
    if not segments:
        return []
    is_cylinder = float(radius) > 0.0
    span = float(length) + float(width) + (2.0 * math.pi * float(radius) if is_cylinder else 0.0)
    tol = max(span * 1.0e-6, 1.0e-6)
    circumference = 2.0 * math.pi * float(radius) if is_cylinder else 0.0
    supports: list[dict[str, object]] = []
    for index, segment in enumerate(segments):
        constraints = dict(segment.get("constraints") or {})
        if not constraints:
            constraints = _support_constraints(segment.get("support"), "cylinder" if is_cylinder else "flat")
        if not constraints:
            continue
        varying = str(segment.get("varying_axis", "a"))
        fixed = float(segment.get("fixed_coordinate", 0.0))
        start = float(segment.get("start_coordinate", 0.0))
        end = float(segment.get("end_coordinate", 0.0))
        node_ids: list[int] = []
        for node in nodes:
            coords = node.get("coords", (0.0, 0.0, 0.0))
            if is_cylinder:
                r = math.hypot(float(coords[0]), float(coords[1]))
                if abs(r - float(radius)) > max(0.05 * float(radius), tol):
                    continue  # skip member/off-skin nodes
                a_coord = float(coords[2])  # axial
                b_coord = (math.atan2(float(coords[1]), float(coords[0])) % (2.0 * math.pi)) * float(radius)
            else:
                if abs(float(coords[2])) > tol:
                    continue
                a_coord = float(coords[0])
                b_coord = float(coords[1])
            if varying == "a":
                if is_cylinder and circumference > 0.0:
                    delta = abs((b_coord - fixed + 0.5 * circumference) % circumference - 0.5 * circumference)
                    on_fixed = delta <= tol
                else:
                    on_fixed = abs(b_coord - fixed) <= tol
                on_line = on_fixed and (start - tol) <= a_coord <= (end + tol)
            else:
                on_line = abs(a_coord - fixed) <= tol and (start - tol) <= b_coord <= (end + tol)
            if on_line:
                node_ids.append(int(node["id"]))
        if node_ids:
            supports.append(
                {
                    "name": "custom_edge_bc_{index}".format(index=index),
                    "node_ids": sorted(set(node_ids)),
                    "constraints": {dof: float(value) for dof, value in constraints.items()},
                }
            )
    return supports


def _custom_patch_min_width(config: LightweightFEMConfig, axis: str, fallback: float = 0.0) -> float:
    if not config.custom_load_bc_enabled:
        return 0.0
    min_width = 0.0
    keys = ("min_a", "max_a") if axis == "a" else ("min_b", "max_b")
    for patch in _custom_pressure_patches(config):
        try:
            width = float(patch.get(keys[1], 0.0)) - float(patch.get(keys[0], 0.0))
        except (TypeError, ValueError):
            continue
        if width > 1.0e-9:
            min_width = width if min_width <= 0.0 else min(min_width, width)
    if min_width <= 0.0:
        min_width = float(fallback or 0.0)
    return min_width if min_width > 1.0e-9 else 0.0


def _local_refinement_patches(config: LightweightFEMConfig) -> list[dict[str, object]]:
    if not bool(config.local_refinement_enabled):
        return []
    try:
        raw_patches = json.loads(config.local_refinement_patches_json) if config.local_refinement_patches_json else []
    except Exception:
        return []
    return _normalised_custom_pressure_patches(raw_patches)


def _local_refinement_patch_area(patches: list[dict[str, object]]) -> float:
    area = 0.0
    for patch in patches:
        try:
            area += max(0.0, float(patch.get("max_a", 0.0)) - float(patch.get("min_a", 0.0))) * max(
                0.0,
                float(patch.get("max_b", 0.0)) - float(patch.get("min_b", 0.0)),
            )
        except (TypeError, ValueError):
            continue
    return float(area)


def _refinement_fine_size(base_size: float, thickness: float, requested_size: float, fine_factor: float) -> tuple[float, float, bool]:
    base_size = max(float(base_size), 1.0e-9)
    thickness = max(float(thickness), 0.0)
    requested = max(float(requested_size or 0.0), 0.0)
    if requested > 0.0:
        fine_size = requested
    else:
        factor = min(max(float(fine_factor or 0.3), 0.02), 1.0)
        fine_size = base_size * factor
    floored_at_thickness = thickness > 0.0 and fine_size < thickness
    fine_size = min(max(fine_size, thickness, base_size * 1.0e-4), base_size)
    return float(fine_size), float(requested), bool(floored_at_thickness)


def _apply_detail_point_refinement(
    length: float,
    width: float,
    thickness: float,
    x_breaks: list[float],
    y_breaks: list[float],
    mandatory_x: tuple[float, ...],
    mandatory_y: tuple[float, ...],
    point_x: float,
    point_y: float,
    fine_size_m: float,
    fine_factor: float,
    extent_m: float,
    growth_factor: float,
    source: str,
    coarse_x: float | None = None,
    coarse_y: float | None = None,
    extra: dict[str, object] | None = None,
    radius: float | None = None,
) -> tuple[list[float], list[float], dict[str, object]]:
    base_x = float(coarse_x) if coarse_x and coarse_x > 0.0 else float(length) / max(len(x_breaks) - 1, 1)
    base_y = float(coarse_y) if coarse_y and coarse_y > 0.0 else float(width) / max(len(y_breaks) - 1, 1)
    base_size = min(base_x, base_y)
    fine_size, requested_fine, floored = _refinement_fine_size(base_size, thickness, fine_size_m, fine_factor)
    extent = max(float(extent_m or 0.0), fine_size)
    growth = max(float(growth_factor or 1.35), 1.01)
    point = (
        min(max(float(point_x), 0.0), float(length)),
        min(max(float(point_y), 0.0), float(width)),
    )
    candidate_x = _detail_axis_breaks(length, point[0], fine_size, base_x, extent, growth, mandatory_x)
    candidate_y = _detail_axis_breaks(width, point[1], fine_size, base_y, extent, growth, mandatory_y)
    x_breaks = _merge_axis_breaks(length, x_breaks, candidate_x, fine_size, mandatory_x)
    y_breaks = _merge_axis_breaks(width, y_breaks, candidate_y, fine_size, mandatory_y)
    # World-space marker for the refinement origin so the GUI can highlight it.
    if radius and float(radius) > 0.0:
        theta = float(point[1]) / max(float(radius), 1.0e-9)
        marker_xyz = [
            float(radius) * math.cos(theta),
            float(radius) * math.sin(theta),
            float(point[0]),
        ]
    else:
        marker_xyz = [float(point[0]), float(point[1]), 0.0]
    info: dict[str, object] = {
        "enabled": True,
        "source": source,
        "point_m": [float(point[0]), float(point[1])],
        "marker_xyz_m": marker_xyz,
        "fine_element_size_m": float(fine_size),
        "coarse_element_size_m": float(max(base_x, base_y)),
        "extent_m": float(extent),
        "growth_factor": float(growth),
        "requested_fine_size_m": float(requested_fine),
        "floored_at_thickness": bool(floored),
        "plate_thickness_m": float(thickness),
    }
    if extra:
        info.update(extra)
    return x_breaks, y_breaks, info


def _apply_local_patch_refinement(
    config: LightweightFEMConfig,
    length: float,
    width: float,
    thickness: float,
    x_breaks: list[float],
    y_breaks: list[float],
    mandatory_x: tuple[float, ...],
    mandatory_y: tuple[float, ...],
) -> tuple[list[float], list[float], dict[str, object]]:
    patches = _local_refinement_patches(config)
    if not patches:
        return x_breaks, y_breaks, {"enabled": False}

    base_x = float(length) / max(len(x_breaks) - 1, 1)
    base_y = float(width) / max(len(y_breaks) - 1, 1)
    base_size = min(base_x, base_y)
    fine_size, requested_fine, floored = _refinement_fine_size(
        base_size,
        thickness,
        float(config.local_refinement_fine_size_m),
        float(config.local_refinement_fine_factor),
    )
    extent_pad = max(float(config.local_refinement_extent_m or 0.0), 0.0)
    growth_factor = max(float(config.local_refinement_growth_factor or 1.35), 1.01)
    refined_regions: list[dict[str, float]] = []

    for patch in patches:
        min_x, max_x = _custom_patch_axis_interval(patch, "a", length)
        min_y, max_y = _custom_patch_axis_interval(patch, "b", width)
        if max_x <= min_x or max_y <= min_y:
            continue
        patch_width = max_x - min_x
        patch_height = max_y - min_y
        x_mandatory = tuple(mandatory_x) + (min_x, max_x)
        y_mandatory = tuple(mandatory_y) + (min_y, max_y)
        candidate_x = _detail_axis_breaks(
            length,
            0.5 * (min_x + max_x),
            fine_size,
            base_x,
            max(0.5 * patch_width + extent_pad, 0.5 * fine_size),
            growth_factor,
            x_mandatory,
        )
        candidate_y = _detail_axis_breaks(
            width,
            0.5 * (min_y + max_y),
            fine_size,
            base_y,
            max(0.5 * patch_height + extent_pad, 0.5 * fine_size),
            growth_factor,
            y_mandatory,
        )
        x_breaks = _merge_axis_breaks(length, x_breaks, candidate_x, fine_size, x_mandatory)
        y_breaks = _merge_axis_breaks(width, y_breaks, candidate_y, fine_size, y_mandatory)
        refined_regions.append(
            {
                "min_a": float(min_x),
                "max_a": float(max_x),
                "min_b": float(min_y),
                "max_b": float(max_y),
            }
        )

    if not refined_regions:
        return x_breaks, y_breaks, {"enabled": False}
    return x_breaks, y_breaks, {
        "enabled": True,
        "source": "selected_panels",
        "region_count": len(refined_regions),
        "area_m2": _local_refinement_patch_area(refined_regions),
        "fine_element_size_m": float(fine_size),
        "coarse_element_size_m": float(max(base_x, base_y)),
        "requested_fine_size_m": float(requested_fine),
        "floored_at_thickness": bool(floored),
        "plate_thickness_m": float(thickness),
        "extent_m": float(extent_pad),
        "growth_factor": float(growth_factor),
        "regions": refined_regions,
    }


def _apply_cylinder_detail_refinement(
    config: LightweightFEMConfig,
    length: float,
    circumference: float,
    thickness: float,
    z_breaks: list[float],
    arc_breaks: list[float],
    mandatory_z: tuple[float, ...],
    mandatory_arc: tuple[float, ...] = (),
) -> tuple[list[float], list[float], dict[str, object]]:
    if _wants_local_patch_transition(config):
        # Local-patch transition refines conformally after the base grid is
        # built; leave the tensor-grid breaks untouched here.
        return z_breaks, arc_breaks, {"enabled": False, "sources": []}
    base_z = float(length) / max(len(z_breaks) - 1, 1)
    base_arc = float(circumference) / max(len(arc_breaks) - 1, 1)
    radius = float(circumference) / (2.0 * math.pi) if circumference > 0.0 else 0.0
    adaptive_sources: list[dict[str, object]] = []

    if bool(config.point_refinement_enabled):
        z_breaks, arc_breaks, info = _apply_detail_point_refinement(
            length,
            circumference,
            thickness,
            z_breaks,
            arc_breaks,
            mandatory_z,
            mandatory_arc,
            float(config.point_refinement_x_m),
            float(config.point_refinement_y_m),
            float(config.point_refinement_fine_size_m),
            float(config.point_refinement_fine_factor),
            float(config.point_refinement_extent_m),
            float(config.point_refinement_growth_factor),
            "selected_point",
            coarse_x=base_z,
            coarse_y=base_arc,
            extra={"coordinates": "cylinder_axial_arc"},
            radius=radius,
        )
        adaptive_sources.append(info)

    patches = _local_refinement_patches(config)
    if patches:
        fine_size, requested_fine, floored = _refinement_fine_size(
            min(base_z, base_arc),
            thickness,
            float(config.local_refinement_fine_size_m),
            float(config.local_refinement_fine_factor),
        )
        extent_pad = max(float(config.local_refinement_extent_m or 0.0), 0.0)
        growth_factor = max(float(config.local_refinement_growth_factor or 1.35), 1.01)
        regions: list[dict[str, float]] = []
        for patch in patches:
            min_z, max_z = _custom_patch_axis_interval(patch, "a", length)
            min_arc = max(0.0, min(float(patch.get("min_b", 0.0)), circumference))
            max_arc = max(0.0, min(float(patch.get("max_b", 0.0)), circumference))
            if max_z <= min_z or max_arc <= min_arc:
                continue
            z_mandatory = tuple(mandatory_z) + (min_z, max_z)
            arc_mandatory = tuple(mandatory_arc) + (min_arc, max_arc)
            candidate_z = _detail_axis_breaks(
                length,
                0.5 * (min_z + max_z),
                fine_size,
                base_z,
                max(0.5 * (max_z - min_z) + extent_pad, 0.5 * fine_size),
                growth_factor,
                z_mandatory,
            )
            candidate_arc = _detail_axis_breaks(
                circumference,
                0.5 * (min_arc + max_arc),
                fine_size,
                base_arc,
                max(0.5 * (max_arc - min_arc) + extent_pad, 0.5 * fine_size),
                growth_factor,
                arc_mandatory,
            )
            z_breaks = _merge_axis_breaks(length, z_breaks, candidate_z, fine_size, z_mandatory)
            arc_breaks = _merge_axis_breaks(circumference, arc_breaks, candidate_arc, fine_size, arc_mandatory)
            regions.append({"min_a": float(min_z), "max_a": float(max_z), "min_b": float(min_arc), "max_b": float(max_arc)})
        if regions:
            adaptive_sources.append(
                {
                    "enabled": True,
                    "source": "selected_panels",
                    "coordinates": "cylinder_axial_arc",
                    "region_count": len(regions),
                    "area_m2": _local_refinement_patch_area(regions),
                    "fine_element_size_m": float(fine_size),
                    "coarse_element_size_m": float(max(base_z, base_arc)),
                    "requested_fine_size_m": float(requested_fine),
                    "floored_at_thickness": bool(floored),
                    "plate_thickness_m": float(thickness),
                    "extent_m": float(extent_pad),
                    "growth_factor": float(growth_factor),
                    "regions": regions,
                }
            )

    if bool(config.collision_adaptive_mesh_enabled) and bool(config.collision_enabled):
        impact = _collision_impact_point_cylinder(config, radius, length, circumference)
        if impact is not None:
            zone_factor = max(float(config.collision_adaptive_zone_factor), 0.5)
            sphere_radius = max(float(config.collision_radius_m), 1.0e-6)
            extent = float(config.collision_adaptive_extent_m or 0.0)
            if extent <= 0.0:
                extent = sphere_radius * zone_factor
            z_breaks, arc_breaks, info = _apply_detail_point_refinement(
                length,
                circumference,
                thickness,
                z_breaks,
                arc_breaks,
                mandatory_z,
                mandatory_arc,
                float(impact[0]),
                float(impact[1]),
                float(config.collision_adaptive_fine_size_m),
                float(config.collision_adaptive_fine_factor),
                extent,
                float(config.collision_adaptive_growth_factor),
                "impact",
                coarse_x=base_z,
                coarse_y=base_arc,
                extra={
                    "coordinates": "cylinder_axial_arc",
                    "impact_point_m": [float(impact[0]), float(impact[1])],
                    "fine_radius_m": float(extent),
                    "sphere_radius_m": float(sphere_radius),
                },
                radius=radius,
            )
            adaptive_sources.append(info)

    if not adaptive_sources:
        return z_breaks, arc_breaks, {"enabled": False, "sources": []}
    return z_breaks, arc_breaks, {
        **adaptive_sources[-1],
        "enabled": True,
        "sources": adaptive_sources,
    }


def _custom_pressure_patch_element_ids_from_patches(
        model,
        generated_geometry: dict,
        geometry: dict,
        patches: list[dict[str, object]],
) -> tuple[int, ...]:
    shell_ids = _skin_shell_element_ids(model, generated_geometry)
    if not shell_ids:
        return ()

    if not patches:
        return shell_ids

    selected: list[int] = []
    if generated_geometry.get("plot_type") == "cylinder":
        radius = _positive(generated_geometry.get("radius_m", geometry.get("radius_m", 0.0)), 0.0)
        length = _positive(generated_geometry.get("length_m", geometry.get("length_m", 0.0)), 0.0)
        circumference = 2.0 * math.pi * radius if radius > 0.0 else 0.0

        for element_id in shell_ids:
            centroid = _element_centroid(model, element_id)
            if centroid is None:
                continue
            z = float(centroid[2])
            theta = math.atan2(float(centroid[1]), float(centroid[0]))
            arc = (theta % (2.0 * math.pi)) * radius if radius > 0.0 else 0.0

            in_patch = False
            for patch in patches:
                min_a, max_a = _custom_patch_axis_interval(patch, "a", length)
                min_b = float(patch.get("min_b", 0.0))
                max_b = float(patch.get("max_b", 0.0))

                if circumference > 0.0:
                    center_arc = 0.5 * (min_b + max_b)
                    arc_delta = abs((arc - center_arc + 0.5 * circumference) % circumference - 0.5 * circumference)
                    width_b = max_b - min_b
                    inside_b = arc_delta <= 0.5 * width_b + 1.0e-12
                else:
                    inside_b = min_b - 1.0e-12 <= arc <= max_b + 1.0e-12

                if min_a - 1.0e-12 <= z <= max_a + 1.0e-12 and inside_b:
                    in_patch = True
                    break

            if in_patch:
                selected.append(int(element_id))
        return tuple(selected)

    for element_id in shell_ids:
        centroid = _element_centroid(model, element_id)
        if centroid is None:
            continue
        cx = float(centroid[0])
        cy = float(centroid[1])

        in_patch = False
        for patch in patches:
            min_a, max_a = _custom_patch_axis_interval(patch, "a", _positive(geometry.get("length_m", 0.0), 0.0))
            min_b = float(patch.get("min_b", 0.0))
            max_b = float(patch.get("max_b", 0.0))
            if min_a - 1.0e-12 <= cx <= max_a + 1.0e-12 and min_b - 1.0e-12 <= cy <= max_b + 1.0e-12:
                in_patch = True
                break

        if in_patch:
            selected.append(int(element_id))
    return tuple(selected)


def _filter_load_case_pressure_to_skin_shells(load_case, generated_geometry: dict) -> tuple[int, int]:
    pressure_loads = getattr(load_case, "pressure_loads", None)
    if not isinstance(pressure_loads, dict) or not pressure_loads:
        return (0, 0)
    before = len(pressure_loads)
    if _generated_non_skin_shell_count(generated_geometry) <= 0:
        return (before, before)
    skin_ids = _generated_skin_shell_ids(generated_geometry)
    if not skin_ids:
        return (before, before)
    load_case.pressure_loads = {
        int(element_id): float(pressure)
        for element_id, pressure in pressure_loads.items()
        if int(element_id) in skin_ids
    }
    return (before, len(load_case.pressure_loads))


def _custom_pressure_patch_element_ids(
        model,
        generated_geometry: dict,
        geometry: dict,
        config: LightweightFEMConfig,
) -> tuple[int, ...]:
    return _custom_pressure_patch_element_ids_from_patches(
        model,
        generated_geometry,
        geometry,
        _custom_pressure_patches(config),
    )


def _element_history_components(stress: object) -> dict[str, float]:
    if not isinstance(stress, dict):
        return {}
    components: dict[str, float] = {}
    if "von_mises" in stress:
        values = np.asarray(stress.get("von_mises"), dtype=float).reshape(-1)
        values = values[np.isfinite(values)]
        components["von_mises_pa"] = float(np.max(np.abs(values))) if values.size else 0.0
    mapping = {
        "stress_x_membrane_pa": "membrane_xx",
        "stress_y_membrane_pa": "membrane_yy",
        "stress_xy_membrane_pa": "membrane_xy",
        "strain_x_membrane": "membrane_strain_xx",
        "strain_y_membrane": "membrane_strain_yy",
        "strain_xy_membrane": "membrane_strain_xy",
        "disp_mag": None,
    }
    for output_name, stress_key in mapping.items():
        if stress_key is None or stress_key not in stress:
            continue
        components[output_name] = _mean_stress_value(stress.get(stress_key))
    if "axial_stress" in stress:
        components.setdefault("stress_x_membrane_pa", _mean_stress_value(stress.get("axial_stress")))
    if "axial_strain" in stress:
        components.setdefault("strain_x_membrane", _mean_stress_value(stress.get("axial_strain")))
    return components


def _transient_time_history_payload(
        generated_geometry: dict,
        model,
        transient: object,
) -> dict[str, object]:
    times = tuple(float(value) for value in np.asarray(getattr(transient, "times", []), dtype=float).reshape(-1))
    displacements = np.asarray(getattr(transient, "displacements", np.zeros((0, 0))), dtype=float)
    if not times or displacements.ndim != 2 or displacements.shape[0] != len(times):
        return {}
    if str(getattr(transient, "history_storage_mode", "full")) != "full":
        return {"times_s": times, "snapshots": (), "node_histories": {}, "element_histories": {}}

    node_histories: dict[int, dict[str, tuple[float, ...]]] = {}
    for node_id, node in model.mesh.nodes.items():
        dofs = list(getattr(node, "dofs", []))[:3]
        if len(dofs) < 3 or max(dofs) >= displacements.shape[1]:
            continue
        translations = displacements[:, dofs]
        node_histories[int(node_id)] = {
            "disp_x": tuple(float(value) for value in translations[:, 0]),
            "disp_y": tuple(float(value) for value in translations[:, 1]),
            "disp_z": tuple(float(value) for value in translations[:, 2]),
            "disp_mag": tuple(float(np.linalg.norm(row)) for row in translations),
        }

    element_histories: dict[int, dict[str, list[float]]] = collections.defaultdict(lambda: collections.defaultdict(list))
    snapshots: list[dict[str, object]] = []
    for time_value, displacement in zip(times, displacements):
        stresses = (
            _backend_compute_stresses(model, displacement)
            if _backend_compute_stresses is not None
            else {}
        )
        visualization = _visualization_from_full_result(
            generated_geometry,
            model,
            displacement,
            stresses_by_element=stresses,
        )
        if visualization:
            visualization["time_s"] = float(time_value)
            snapshots.append(visualization)
        for element_id, stress in (stresses or {}).items():
            components = _element_history_components(stress)
            for component_name, value in components.items():
                element_histories[int(element_id)][component_name].append(float(value))

    return {
        "times_s": times,
        "snapshots": tuple(snapshots),
        "node_histories": {
            int(node_id): values
            for node_id, values in node_histories.items()
        },
        "element_histories": {
            int(element_id): {
                component_name: tuple(values)
                for component_name, values in component_values.items()
            }
            for element_id, component_values in element_histories.items()
        },
    }


def _run_custom_time_domain_response(
        model,
        load_case,
        generated_geometry: dict,
        geometry: dict,
        config: LightweightFEMConfig,
) -> dict[str, object]:
    if not config.custom_time_domain_enabled:
        return {}
    if _full_backend is None or _backend_solve_transient_newmark is None:
        return {"status": "unavailable"}
    duration = max(float(config.custom_time_domain_duration_s or 0.0), 0.0)
    total_time = max(float(config.custom_time_domain_total_time_s or 0.0), duration)
    dt = max(float(config.custom_time_domain_dt_s or 0.0), 1.0e-9)
    result_interval = max(float(config.custom_time_domain_result_interval_s or 0.0), 0.0)
    pressure_entries = _custom_pressure_load_entries(config)
    pressure_patches = []
    output_element_ids: set[int] = set()
    if pressure_entries:
        for index, entry in enumerate(pressure_entries, start=1):
            pressure = abs(float(entry.get("pressure_pa", 0.0) or 0.0))
            if pressure <= 0.0:
                continue
            patches = _normalised_custom_pressure_patches(entry.get("patches", []))
            patch_ids = _custom_pressure_patch_element_ids_from_patches(model, generated_geometry, geometry, patches)
            if not patch_ids:
                continue
            output_element_ids.update(int(element_id) for element_id in patch_ids)
            pressure_patches.append(_full_backend.PressurePatch.rectangular_pulse(
                name="runtime_custom_pressure_patch_" + str(index),
                pressure=_pressure_sign(config) * pressure,
                start_time=0.0,
                end_time=duration,
                element_ids=patch_ids,
            ))
    else:
        pressure = abs(float(config.custom_pressure_pa or 0.0))
        if pressure > 0.0:
            patch_ids = _custom_pressure_patch_element_ids(model, generated_geometry, geometry, config)
            output_element_ids.update(int(element_id) for element_id in patch_ids)
            if patch_ids:
                pressure_patches.append(_full_backend.PressurePatch.rectangular_pulse(
                    name="runtime_custom_pressure_patch",
                    pressure=_pressure_sign(config) * pressure,
                    start_time=0.0,
                    end_time=duration,
                    element_ids=patch_ids,
                ))
    if not pressure_patches or duration <= 0.0 or total_time <= 0.0:
        return {"status": "skipped", "reason": "custom pressure, duration and total time must be positive"}
    patch_ids = tuple(sorted(output_element_ids))
    if not patch_ids:
        return {"status": "skipped", "reason": "no shell elements selected"}
    if result_interval > 0.0:
        save_every = max(int(round(result_interval / dt)), 1)
    else:
        save_every = max(int(math.ceil(max(total_time / dt, 1.0) / 120.0)), 1)
    transient_recovery = (
        _full_backend.RecoveryConfig(history_mode="full", store_full_histories=True)
        if hasattr(_full_backend, "RecoveryConfig")
        else _recovery_config(config)
    )
    transient_config = _full_backend.TransientConfig(
        dt=dt,
        t_end=total_time,
        save_every=save_every,
        output_elements=patch_ids,
        include_stress_history=False,
        recovery=transient_recovery,
        resource_config=_resource_config(config),
    )
    base_load_case = load_case if config.custom_time_domain_include_static_load else None
    transient = _backend_solve_transient_newmark(
        model,
        transient_config,
        pressure_patches=pressure_patches,
        base_load_case=base_load_case,
    )
    return {
        "status": str(transient.status),
        "pressure_pa": max(abs(float(getattr(patch, "pressure", 0.0))) for patch in pressure_patches),
        "duration_s": duration,
        "total_time_s": total_time,
        "dt_s": dt,
        "result_interval_s": result_interval if result_interval > 0.0 else float(save_every) * dt,
        "saved_steps": float(len(np.asarray(getattr(transient, "times", ()), dtype=float).reshape(-1))),
        "selected_shells": float(len(patch_ids)),
        "peak_displacement_m": float(transient.peak_displacement),
        "peak_von_mises_pa": float(transient.peak_von_mises_stress),
        "force_impulse_n_s": tuple(float(value) for value in np.asarray(transient.force_impulse, dtype=float).reshape(3)),
        "include_static_load": bool(config.custom_time_domain_include_static_load),
        "history": _transient_time_history_payload(generated_geometry, model, transient),
    }


def _ensure_runtime_density(model, density: float = 7850.0) -> None:
    for material in getattr(model, "materials", {}).values():
        if float(getattr(material, "density", 0.0) or 0.0) <= 0.0:
            try:
                material.density = float(density)
            except Exception:
                pass


def _collision_snapshot_stresses(
        model,
        displacement,
        state_von_mises: dict[int, float] | None,
) -> dict[int, dict[str, object]]:
    """Element stresses for a collision snapshot.

    For material-nonlinear runs, the elastic recovery from total
    displacements overshoots the material curve wherever plastic strain has
    accumulated, so the von Mises component is replaced by the true
    (return-mapped) envelope recorded from the committed plastic states.
    Returns an empty dict for linear runs so the caller's elastic recovery
    applies unchanged.
    """
    if not state_von_mises or _backend_compute_stresses is None:
        return {}
    stresses = _backend_compute_stresses(model, np.asarray(displacement, dtype=float))
    for element_id, value in state_von_mises.items():
        entry = stresses.get(int(element_id))
        if isinstance(entry, dict) and "von_mises" in entry:
            entry["von_mises"] = np.asarray([float(value)], dtype=float)
    return stresses


def _run_collision_response(
        model,
        load_case,
        generated_geometry: dict,
        geometry: dict,
        config: LightweightFEMConfig,
        diagnostics: list[str],
        status_callback=None,
) -> LightweightFEMResult:
    if (
        _backend_solve_transient_sphere_impact is None
        or _backend_RigidSphereImpact is None
        or _backend_SphereContactConfig is None
        or _backend_TransientConfig is None
    ):
        return LightweightFEMResult(
            status="backend_unavailable",
            stress_max_pa=0.0,
            stress_p95_pa=0.0,
            displacement_max_m=0.0,
            diagnostics=tuple(diagnostics + ["Rigid-sphere collision backend is not available."]),
            mesh_info={"nodes": int(model.mesh.num_nodes), "shells": len(generated_geometry.get("shells", [])), "beams": len(generated_geometry.get("beams", []))},
            solver_name="ANYsolver production FE mesh",
            visualization=_visualization_from_full_result(generated_geometry, model, None),
        )
    if not _runtime_collision_has_fixed_support(config, geometry):
        return LightweightFEMResult(
            status="invalid_collision_support",
            stress_max_pa=0.0,
            stress_p95_pa=0.0,
            displacement_max_m=0.0,
            diagnostics=tuple(diagnostics + ["Collision runs require at least one fixed, pinned, clamped, or otherwise constrained side/top/bottom. Nullspace projection is not used for collision."]),
            mesh_info={"nodes": int(model.mesh.num_nodes), "shells": len(generated_geometry.get("shells", [])), "beams": len(generated_geometry.get("beams", []))},
            solver_name="ANYsolver production FE mesh",
        )
    if status_callback:
        status_callback("Solving rigid-sphere collision transient...")
    _ensure_runtime_density(model)
    auto_time = _collision_auto_time_settings(generated_geometry, config) if _normalized_choice(config.collision_time_mode, "auto") == "auto" else {}
    dt = max(float(auto_time.get("dt_s", config.collision_dt_s) if auto_time else config.collision_dt_s), 1.0e-9)
    t_end = max(float(auto_time.get("total_time_s", config.collision_total_time_s) if auto_time else config.collision_total_time_s), dt)
    initial_contact = _collision_initial_penetration(generated_geometry, config)
    representative_edge = float(auto_time.get("representative_shell_edge_m", _collision_representative_shell_edge(generated_geometry)) if auto_time else _collision_representative_shell_edge(generated_geometry))
    radius = max(float(config.collision_radius_m), 1.0e-9)
    allowed_initial_penetration = max(
        5.0 * radius * max(float(config.collision_target_penetration_fraction), 1.0e-6),
        0.25 * max(representative_edge, 0.0),
        1.0e-6,
    )
    if float(initial_contact.get("penetration_m", 0.0)) > allowed_initial_penetration:
        penetration = float(initial_contact.get("penetration_m", 0.0))
        clearance = float(initial_contact.get("clearance_m", 0.0))
        return LightweightFEMResult(
            status="invalid_collision_start",
            stress_max_pa=0.0,
            stress_p95_pa=0.0,
            displacement_max_m=0.0,
            diagnostics=tuple(
                diagnostics
                + [
                    "Rigid-sphere collision start is invalid: the sphere initially penetrates the shell by "
                    + str(round(1000.0 * penetration, 3))
                    + " mm.",
                    "Move the sphere centre outside the structure before impact, reduce the radius, or reverse the travel vector. "
                    + "Allowed initial penetration for numerical contact settling is "
                    + str(round(1000.0 * allowed_initial_penetration, 3))
                    + " mm.",
                ]
            ),
            mesh_info={
                "nodes": int(model.mesh.num_nodes),
                "shells": len(generated_geometry.get("shells", [])),
                "beams": len(generated_geometry.get("beams", [])),
            },
            prestress_summary={
                "collision_status": "invalid_collision_start",
                "collision_time_mode": str(auto_time.get("mode", "manual") if auto_time else "manual"),
                "collision_resolved_dt_s": float(dt),
                "collision_resolved_total_time_s": float(t_end),
                "collision_initial_penetration_m": penetration,
                "collision_initial_clearance_m": clearance,
                "collision_allowed_initial_penetration_m": float(allowed_initial_penetration),
                "collision_representative_shell_edge_m": float(representative_edge),
            },
            solver_name="ANYsolver production FE mesh",
        )
    sphere = _backend_RigidSphereImpact(
        name="ANYsolver sphere",
        radius=radius,
        mass=max(float(config.collision_mass_kg), 1.0e-9),
        start_point=(
            float(config.collision_start_x_m),
            float(config.collision_start_y_m),
            float(config.collision_start_z_m),
        ),
        travel_direction=(
            float(config.collision_vector_x),
            float(config.collision_vector_y),
            float(config.collision_vector_z),
        ),
        speed=max(float(config.collision_speed_mps), 0.0),
    )
    if float(config.collision_penalty_stiffness_n_per_m or 0.0) > 0.0:
        resolved_penalty = float(config.collision_penalty_stiffness_n_per_m)
        penalty_basis = "user"
        penalty_info = {
            "penalty_stiffness": resolved_penalty,
            "basis": penalty_basis,
            "target_penetration_m": 0.0,
            "desired_penalty_stiffness": resolved_penalty,
            "dt_stable_penalty_stiffness": resolved_penalty,
        }
    else:
        penalty_info = dict(auto_time) if auto_time else _collision_dynamic_penalty(
            config, dt, representative_edge,
            contact_stiffness_scale=_collision_contact_stiffness_scale(generated_geometry, config),
        )
        auto_penalty = max(float(penalty_info.get("recommended_penalty_stiffness", penalty_info.get("penalty_stiffness", 0.0)) or 0.0), 1.0)
        # The auto penalty is already capped at a multiple of the shell
        # contact stiffness (E*t) so the contact iteration stays conditioned.
        # collision_penalty_scale is a manual multiplier; the opt-in
        # auto-precondition adds an extra conservative factor for stubborn
        # high-energy impacts (softer contact, slightly more penetration).
        penalty_scale = max(float(config.collision_penalty_scale or 1.0), 1.0e-6)
        if bool(config.collision_auto_precondition):
            penalty_scale *= _COLLISION_PRECONDITION_EXTRA_SCALE
        resolved_penalty = max(auto_penalty * penalty_scale, 1.0)
        penalty_basis = str(penalty_info.get("penalty_basis", penalty_info.get("basis", "dynamic_auto")) or "dynamic_auto")
        if bool(penalty_info.get("structural_penalty_cap")) and float(penalty_info.get("structural_penalty_cap", 0.0)) > 0.0:
            if auto_penalty >= float(penalty_info.get("structural_penalty_cap", 0.0)) - 1.0:
                penalty_basis = "dynamic_auto_structural_cap"
        if penalty_scale != 1.0:
            penalty_basis = penalty_basis + f"_scaled_{penalty_scale:.4g}"
            diagnostics.append(
                "Collision contact penalty scaled by "
                + str(round(penalty_scale, 5))
                + " (auto "
                + str(round(auto_penalty, 3))
                + " -> "
                + str(round(resolved_penalty, 3))
                + " N/m) for convergence."
            )
    contact_patch_factor = 2.5 if bool(config.collision_material_nonlinear_enabled) else 2.0
    contact_patch_min_nodes = 12 if bool(config.collision_material_nonlinear_enabled) else 8
    contact_patch_max_nodes = 40 if bool(config.collision_material_nonlinear_enabled) else 24
    contact_config = _backend_SphereContactConfig(
        penalty_stiffness=resolved_penalty,
        contact_damping=max(float(config.collision_contact_damping), 0.0),
        max_contact_iterations=max(int(config.collision_max_iterations or 25), 1),
        penetration_tolerance=max(float(config.collision_penetration_tolerance_m), 1.0e-12),
        force_tolerance=max(float(config.collision_force_tolerance_n), 1.0e-12),
        target_penetration_fraction=max(float(config.collision_target_penetration_fraction), 1.0e-9),
        max_event_substeps=max(int(config.collision_max_event_substeps or 16), 1),
        contact_surface=str(config.collision_contact_surface or "midsurface"),
        post_separation_time=max(float(config.collision_bounce_back_time_s), 0.0),
        load_patch_radius_factor=contact_patch_factor,
        min_load_patch_nodes=contact_patch_min_nodes,
        max_load_patch_nodes=contact_patch_max_nodes,
        beam_contact=bool(config.collision_beam_contact_enabled),
    )
    collision_resource_config = _resource_config(
        config,
        generated_geometry,
        auto_assembly=bool(config.collision_material_nonlinear_enabled),
    )
    transient_config = _backend_TransientConfig(
        dt=dt,
        t_end=t_end,
        save_every=_collision_save_every(config),
        recovery=(
            _full_backend.RecoveryConfig(history_mode="full", store_full_histories=True)
            if hasattr(_full_backend, "RecoveryConfig")
            else _recovery_config(config)
        ),
        resource_config=collision_resource_config,
    )
    nonlinear_config = _collision_nonlinear_config(config)
    collision_kinematics = (
        _normalized_kinematics(config.collision_nonlinear_kinematics)
        if nonlinear_config is not None
        else "von_karman"
    )
    plastic_damage_config = _collision_plastic_damage_config(config)
    damage_config = None if nonlinear_config is not None else _collision_damage_config(config)
    base_load_case = load_case if config.collision_include_static_load else None
    last_live_update = [0.0]

    def live_progress(payload: dict[str, object]) -> None:
        if not callable(status_callback):
            return
        now = time.perf_counter()
        if now - last_live_update[0] < 0.05:
            return
        displacement = payload.get("displacement")
        if displacement is None:
            return
        live_visualization = _visualization_from_full_result(
            generated_geometry,
            model,
            np.asarray(displacement, dtype=float),
            scalar_by_node={},
            scalar_label="live dynamic displacement [m]",
            stresses_by_element={},
        )
        if not live_visualization:
            return
        live_visualization["scalar_kind"] = "raw"
        sphere_position = np.asarray(payload.get("sphere_position", ()), dtype=float).reshape(-1)
        if sphere_position.size >= 3:
            active_contacts = tuple(payload.get("active_contacts", ()) or ())
            live_visualization["rigid_sphere"] = {
                "position": tuple(float(value) for value in sphere_position[:3]),
                "radius": float(payload.get("sphere_radius", config.collision_radius_m)),
                "visible": True,
                "active_contacts": active_contacts,
            }
            live_visualization["active_contacts"] = active_contacts
        live_visualization["time_s"] = float(payload.get("time_s", 0.0) or 0.0)
        last_live_update[0] = now
        contact_force = np.asarray(payload.get("contact_force", ()), dtype=float).reshape(-1)
        status_callback(
            {
                "type": "live_visualization",
                "analysis": "sphere_collision",
                "time_s": float(payload.get("time_s", 0.0) or 0.0),
                "step_index": int(payload.get("step_index", 0) or 0),
                "visualization": live_visualization,
                "displacement_max_m": _max_translation(model, np.asarray(displacement, dtype=float)),
                "contact_force_n": float(np.linalg.norm(contact_force)) if contact_force.size else 0.0,
                "max_equivalent_plastic_strain": float(payload.get("max_equivalent_plastic_strain", 0.0) or 0.0),
            }
        )

    impact = _backend_solve_transient_sphere_impact(
        model,
        transient_config,
        sphere,
        contact_config,
        base_load_case=base_load_case,
        damage_config=damage_config,
        nonlinear_config=nonlinear_config,
        plastic_damage_config=plastic_damage_config,
        progress_callback=live_progress,
    )
    impact_diagnostics = impact.diagnostics or {}
    energy_summary = _collision_energy_summary(impact_diagnostics)
    damage_summary = impact_diagnostics.get("impact_damage_summary", {}) or {}
    strain_summary = impact_diagnostics.get("strain_summary", {}) or {}
    plastic_element_fields = _plastic_strain_element_fields_from_states(impact_diagnostics.get("element_states", {}))
    erosion_summary = impact_diagnostics.get("erosion_summary", {}) or {}
    contact_failure_summary = impact_diagnostics.get("contact_failure_summary", {}) or {}
    nonlinear_failure_summary = impact_diagnostics.get("nonlinear_failure_summary", {}) or {}
    state_vm_history = tuple(impact_diagnostics.get("state_von_mises_history", ()) or ())
    # Snapshot hiding must use the DELETION events, not the per-element damage
    # state records: state records exist for every element with plastic state
    # and carry no time stamp, so feeding them to the per-time deletion filter
    # hid the entire skin from every snapshot on nonlinear runs.
    records = tuple(damage_summary.get("deletion_records", ()) or ())
    if not records:
        records = tuple(
            record
            for record in damage_summary.get("records", ()) or ()
            if isinstance(record, dict) and "trigger_name" in record
        )
    times = np.asarray(getattr(impact, "times", ()), dtype=float).reshape(-1)
    displacements = np.asarray(getattr(impact, "displacements", np.zeros((0, model.mesh.dof_manager.total_dofs))), dtype=float)
    sphere_positions = np.asarray(getattr(impact, "sphere_positions", np.zeros((0, 3))), dtype=float)
    active_contact_history = tuple(getattr(impact, "active_contact_history", ()) or ())
    snapshots: list[dict[str, object]] = []
    for index, time_value in enumerate(times):
        if index >= len(displacements):
            continue
        deleted_ids = _deleted_element_ids_for_time(records, float(time_value))
        element_fields = dict(_impact_damage_element_fields_for_time(damage_summary, float(time_value)))
        for field_name, by_element in plastic_element_fields.items():
            if by_element:
                element_fields[field_name] = by_element
        snapshot_stresses = _collision_snapshot_stresses(
            model,
            displacements[index],
            state_vm_history[index] if index < len(state_vm_history) else None,
        )
        snapshot = _visualization_from_full_result(
            generated_geometry,
            model,
            displacements[index],
            scalar_by_node={},
            scalar_label="dynamic displacement [m]",
            stresses_by_element=snapshot_stresses,
            element_scalar_fields=element_fields,
        )
        if not snapshot:
            continue
        snapshot["scalar_kind"] = "raw"
        if element_fields.get("impact_damage"):
            snapshot["impact_damage_label"] = "impact damage [-]"
            snapshot["impact_damage_utilization_label"] = "impact damage utilization [-]"
            snapshot["impact_damage_scale_label"] = "impact damage stiffness scale [-]"
        _annotate_plastic_strain_visualization(snapshot)
        _filter_visualization_deleted_elements(snapshot, deleted_ids)
        position = sphere_positions[index].tolist() if index < len(sphere_positions) else list(sphere.initial_position)
        active_contacts = tuple(active_contact_history[index]) if index < len(active_contact_history) else tuple()
        snapshot["time_s"] = float(time_value)
        snapshot["active_contacts"] = active_contacts
        snapshot["rigid_sphere"] = {
            "position": tuple(float(value) for value in position),
            "radius": float(sphere.radius),
            "visible": True,
            "active_contacts": active_contacts,
        }
        snapshots.append(snapshot)
    visualization = snapshots[-1] if snapshots else _visualization_from_full_result(
        generated_geometry,
        model,
        np.zeros(model.mesh.dof_manager.total_dofs, dtype=float),
        scalar_by_node={},
        scalar_label="dynamic displacement [m]",
        stresses_by_element={},
        element_scalar_fields={
            **_impact_damage_element_fields_for_time(damage_summary, float(times[-1]) if len(times) else 0.0),
            **{name: values for name, values in plastic_element_fields.items() if values},
        },
    )
    _annotate_plastic_strain_visualization(visualization)
    visualization["scalar_kind"] = "raw"
    final_deleted = tuple(int(element_id) for element_id in erosion_summary.get("all_eroded_element_ids", ()) or ())
    _filter_visualization_deleted_elements(visualization, final_deleted)
    if len(sphere_positions):
        final_index = len(sphere_positions) - 1
        final_contacts = tuple(active_contact_history[final_index]) if final_index < len(active_contact_history) else tuple()
        visualization["active_contacts"] = final_contacts
        visualization["rigid_sphere"] = {
            "position": tuple(float(value) for value in sphere_positions[-1]),
            "radius": float(sphere.radius),
            "visible": True,
            "active_contacts": final_contacts,
        }
    visualization["time_domain"] = {
        "kind": "sphere_collision",
        "times_s": tuple(float(value) for value in times),
        "snapshots": tuple(snapshots),
    }
    visualization["impact_damage_summary"] = damage_summary
    visualization["erosion_summary"] = erosion_summary
    visualization["collision_summary"] = {
        "status": str(impact.status),
        "time_mode": str(auto_time.get("mode", "manual") if auto_time else "manual"),
        "resolved_dt_s": float(dt),
        "resolved_total_time_s": float(t_end),
        "estimated_arrival_time_s": float(auto_time.get("arrival_time_s", 0.0) if auto_time else 0.0),
        "peak_contact_force_n": float(impact.peak_contact_force),
        "max_penetration_m": float(impact.max_penetration),
        "max_penetration_ratio": float(impact.max_penetration_ratio),
        "contact_duration_s": float(impact.contact_duration),
        "sphere_momentum_balance_error": float(impact.sphere_momentum_balance_error),
        "saved_steps": float(len(times)),
        "damage_enabled": bool(config.collision_damage_enabled),
        "material_nonlinear_enabled": nonlinear_config is not None,
        "nonlinear_kinematics": collision_kinematics,
        "beam_contact_enabled": bool(config.collision_beam_contact_enabled),
        "deleted_shell_elements": float(len(final_deleted)),
        "deleted_eroded_elements": float(len(final_deleted)),
        "representative_shell_edge_m": float(auto_time.get("representative_shell_edge_m", 0.0) if auto_time else 0.0),
        "sphere_travel_per_step_m": float(auto_time.get("sphere_travel_per_step_m", float(config.collision_speed_mps) * dt) if auto_time else float(config.collision_speed_mps) * dt),
        "contact_penalty_stiffness_n_per_m": float(resolved_penalty),
        "contact_penalty_basis": str(penalty_basis),
        "adaptive_cutback_retry_count": float(impact_diagnostics.get("adaptive_cutback_retry_count", 0) or 0),
        "solution_control": str(impact_diagnostics.get("solution_control", "implicit_newmark_time_domain")),
        "arc_length_applicability": str(impact_diagnostics.get("arc_length_applicability", "not_applicable_to_dynamic_impact")),
    }
    visualization["collision_summary"].update(energy_summary)
    prestress_summary = {
        "collision_status": str(impact.status),
        "collision_time_mode": str(auto_time.get("mode", "manual") if auto_time else "manual"),
        "collision_resolved_dt_s": float(dt),
        "collision_resolved_total_time_s": float(t_end),
        "collision_estimated_arrival_time_s": float(auto_time.get("arrival_time_s", 0.0) if auto_time else 0.0),
        "collision_peak_contact_force_n": float(impact.peak_contact_force),
        "collision_max_penetration_m": float(impact.max_penetration),
        "collision_max_penetration_ratio": float(impact.max_penetration_ratio),
        "collision_contact_duration_s": float(impact.contact_duration),
        "collision_sphere_momentum_balance_error": float(impact.sphere_momentum_balance_error),
        "collision_saved_steps": float(len(times)),
        "collision_damage_enabled": 1.0 if config.collision_damage_enabled else 0.0,
        "collision_material_nonlinear_enabled": 1.0 if nonlinear_config is not None else 0.0,
        "collision_nonlinear_kinematics": collision_kinematics,
        "collision_nonlinear_assembly_threads": float(_resource_assembly_threads(collision_resource_config)),
        "collision_beam_contact_enabled": 1.0 if bool(config.collision_beam_contact_enabled) else 0.0,
        "collision_nonlinear_status": str(impact_diagnostics.get("status", impact.status)),
        "collision_nonlinear_iterations": float(sum(impact_diagnostics.get("iteration_counts", ()) or ())),
        "collision_nonlinear_cutbacks": float(impact_diagnostics.get("cutback_count", 0) or 0),
        "collision_nonlinear_max_plastic_strain": float(strain_summary.get("max_equivalent_plastic_strain", 0.0) or 0.0),
        "collision_plastic_damage_threshold": float(config.collision_plastic_damage_threshold),
        "collision_deleted_shell_elements": float(len(final_deleted)),
        "collision_deleted_eroded_elements": float(len(final_deleted)),
        "collision_representative_shell_edge_m": float(auto_time.get("representative_shell_edge_m", 0.0) if auto_time else 0.0),
        "collision_sphere_travel_per_step_m": float(auto_time.get("sphere_travel_per_step_m", float(config.collision_speed_mps) * dt) if auto_time else float(config.collision_speed_mps) * dt),
        "collision_estimated_steps": float(auto_time.get("estimated_steps", math.ceil(t_end / max(dt, 1.0e-12))) if auto_time else math.ceil(t_end / max(dt, 1.0e-12))),
        "collision_contact_penalty_stiffness_n_per_m": float(resolved_penalty),
        "collision_contact_penalty_basis": str(penalty_basis),
        "collision_target_penetration_m": float(penalty_info.get("target_penetration_m", 0.0) or 0.0),
        "collision_contact_patch_radius_factor": float(contact_patch_factor),
        "collision_contact_patch_min_nodes": float(contact_patch_min_nodes),
        "collision_contact_patch_max_nodes": float(contact_patch_max_nodes),
        "collision_adaptive_cutback_retries": float(impact_diagnostics.get("adaptive_cutback_retry_count", 0) or 0),
        "collision_solution_control": str(impact_diagnostics.get("solution_control", "implicit_newmark_time_domain")),
        "collision_arc_length_applicability": str(impact_diagnostics.get("arc_length_applicability", "not_applicable_to_dynamic_impact")),
        "collision_stop_reason": str(impact_diagnostics.get("stop_reason", "") or ""),
        "collision_separation_stop_time_s": float(impact_diagnostics.get("separation_stop_time", 0.0) or 0.0),
        "collision_auto_requested_total_time_s": float(auto_time.get("requested_total_time_s", 0.0) if auto_time else 0.0),
        "collision_auto_impact_window_s": float(auto_time.get("impact_window_s", 0.0) if auto_time else 0.0),
        "collision_bounce_back_time_s": float(config.collision_bounce_back_time_s),
        "runtime_solver": "sphere collision transient",
        "allow_unbalanced_free_free": 0.0,
        "recovery_history_mode": "full",
    }
    prestress_summary.update(energy_summary)
    failure_summary = contact_failure_summary or nonlinear_failure_summary
    if failure_summary:
        prestress_summary["collision_failure_time_s"] = float(failure_summary.get("time", 0.0) or 0.0)
        prestress_summary["collision_failure_dt_s"] = float(failure_summary.get("dt", 0.0) or 0.0)
        prestress_summary["collision_failure_iterations"] = float(failure_summary.get("contact_iterations", failure_summary.get("iterations", 0)) or 0)
        prestress_summary["collision_failure_force_change_n"] = float(failure_summary.get("force_change_norm", failure_summary.get("contact_force_change", 0.0)) or 0.0)
        prestress_summary["collision_failure_effective_force_tolerance_n"] = float(failure_summary.get("effective_force_tolerance", 0.0) or 0.0)
        prestress_summary["collision_failure_effective_residual_tolerance_n"] = float(failure_summary.get("effective_residual_tolerance", 0.0) or 0.0)
        prestress_summary["collision_failure_penetration_change_m"] = float(failure_summary.get("penetration_change", 0.0) or 0.0)
        prestress_summary["collision_failure_max_penetration_m"] = float(failure_summary.get("max_penetration", 0.0) or 0.0)
        prestress_summary["collision_failure_residual_norm"] = float(failure_summary.get("residual_norm", 0.0) or 0.0)
        prestress_summary["collision_failure_displacement_increment_m"] = float(failure_summary.get("displacement_increment", 0.0) or 0.0)
        active_ids = failure_summary.get("active_element_ids", ()) or ()
        prestress_summary["collision_failure_active_element_ids"] = ",".join(str(int(element_id)) for element_id in active_ids[:8])
    if damage_summary:
        prestress_summary["impact_damage_max_utilization"] = float(damage_summary.get("max_utilization", 0.0) or 0.0)
        prestress_summary["impact_damage_deleted_count"] = float(damage_summary.get("deleted_count", 0.0) or 0.0)
    diagnostics.append("Ran rigid-sphere collision transient: " + str(impact.status) + ".")
    if auto_time:
        diagnostics.append(
            "Automatic collision time setup: dt="
            + str(round(dt, 9))
            + " s, total="
            + str(round(t_end, 6))
            + " s, estimated arrival="
            + str(round(float(auto_time.get("arrival_time_s", 0.0)), 6))
            + " s."
        )
        if float(auto_time.get("representative_shell_edge_m", 0.0) or 0.0) > 0.0:
            diagnostics.append(
                "Automatic collision dt cap used representative shell edge "
                + str(round(float(auto_time.get("representative_shell_edge_m", 0.0)), 6))
                + " m and sphere travel per step "
                + str(round(float(auto_time.get("sphere_travel_per_step_m", 0.0)), 6))
                + " m."
            )
        if str(auto_time.get("auto_time_cap", "") or ""):
            diagnostics.append(
                "Automatic collision total time capped to impact window "
                + str(round(float(auto_time.get("impact_window_s", 0.0) or 0.0), 6))
                + " s; uncapped estimate was "
                + str(round(float(auto_time.get("requested_total_time_s", t_end) or t_end), 6))
                + " s. Use manual time mode for longer post-impact free-flight."
            )
    diagnostics.append(
        "Collision contact penalty: "
        + str(round(float(resolved_penalty), 6))
        + " N/m ("
        + str(penalty_basis)
        + ")."
    )
    diagnostics.append(
        "Collision contact patch spread: radius factor "
        + str(round(float(contact_patch_factor), 3))
        + ", nodes "
        + str(int(contact_patch_min_nodes))
        + "-"
        + str(int(contact_patch_max_nodes))
        + "."
    )
    if str((impact.diagnostics or {}).get("stop_reason", "") or "") == "completed_after_contact_separation":
        diagnostics.append(
            "Collision transient stopped automatically after contact separation; separation hold time="
            + str(round(float((impact.diagnostics or {}).get("separation_stop_time", 0.0) or 0.0), 9))
            + " s."
        )
    diagnostics.append("Collision uses fixed/constrained supports only; rigid-body nullspace projection is disabled.")
    diagnostics.append("Collision solution control is implicit Newmark time-domain integration; static arc-length continuation is not used for collision impact.")
    if bool(config.collision_beam_contact_enabled):
        diagnostics.append("Direct beam/stiffener contact is enabled for the rigid sphere.")
    if nonlinear_config is not None:
        diagnostics.append(
            "Material nonlinear impact is enabled with "
            + collision_kinematics.replace("_", " ")
            + " kinematics: implicit Newmark/Newton with committed plastic state."
        )
        diagnostics.append("Nonlinear impact max equivalent plastic strain: " + str(round(float(strain_summary.get("max_equivalent_plastic_strain", 0.0) or 0.0), 8)) + ".")
    if config.collision_damage_enabled:
        if nonlinear_config is not None:
            diagnostics.append("Impact plastic-damage erosion is enabled for shell and beam elements where the backend damage scope applies.")
        elif bool(config.collision_beam_contact_enabled):
            diagnostics.append("Capacity-based impact damage/erosion is shell-contact based; use material nonlinear plastic damage for beam erosion.")
        else:
            diagnostics.append("Capacity-based impact damage/erosion is enabled for shell contact elements.")
    if failure_summary:
        diagnostics.append(
            "Contact failure detail: time="
            + str(round(float(failure_summary.get("time", 0.0) or 0.0), 9))
            + " s, dt="
            + str(round(float(failure_summary.get("dt", 0.0) or 0.0), 9))
            + " s, iterations="
            + str(int(failure_summary.get("contact_iterations", failure_summary.get("iterations", 0)) or 0))
            + ", residual="
            + str(round(float(failure_summary.get("residual_norm", 0.0) or 0.0), 6))
            + ", displacement increment="
            + str(round(float(failure_summary.get("displacement_increment", 0.0) or 0.0), 9))
            + " m, force change="
            + str(round(float(failure_summary.get("force_change_norm", failure_summary.get("contact_force_change", 0.0)) or 0.0), 6))
            + " N, effective force tolerance="
            + str(round(float(failure_summary.get("effective_force_tolerance", 0.0) or 0.0), 6))
            + " N, penetration change="
            + str(round(1000.0 * float(failure_summary.get("penetration_change", 0.0) or 0.0), 6))
            + " mm."
        )
        if failure_summary.get("active_element_ids"):
            diagnostics.append(
                "Contact failure active element(s): "
                + ", ".join(str(int(element_id)) for element_id in (failure_summary.get("active_element_ids", ()) or ())[:8])
                + "."
            )
        diagnostics.append("Contact failure suggestion: " + str(failure_summary.get("suggestion", "")))
    for warning in impact_diagnostics.get("warnings", ()) or ():
        diagnostics.append(str(warning))
    return LightweightFEMResult(
        status="ok" if str(impact.status) in {"completed", "no_contact", "max_deleted_fraction_reached"} else str(impact.status),
        stress_max_pa=0.0,
        stress_p95_pa=0.0,
        displacement_max_m=float(impact.peak_displacement),
        buckling_factors=(),
        diagnostics=tuple(diagnostics),
        mesh_info={
            "nodes": int(model.mesh.num_nodes),
            "shells": int(len(generated_geometry.get("shells", []))),
            "beams": int(len(generated_geometry.get("beams", []))),
            "rigid_lids": int(len(generated_geometry.get("rigid_lids", []))),
            **_mesh_size_diagnostics(generated_geometry),
        },
        prestress_summary=prestress_summary,
        load_resultant={},
        visualization=visualization,
        solver_name="ANYsolver production FE mesh",
    )


def _mesh_quality_diagnostics(
    generated_geometry: dict,
    nodes: dict[int, tuple[float, float, float]] | None = None,
) -> dict[str, float | int | str]:
    """Return bounded shell mesh quality metrics for runtime diagnostics."""

    if nodes is None:
        nodes = {
            int(node["id"]): tuple(float(value) for value in node["coords"])
            for node in generated_geometry.get("nodes", [])
        }
    aspect_ratios: list[float] = []
    skew_degrees: list[float] = []
    warps: list[float] = []
    areas: list[float] = []
    invalid_count = 0
    role_counts: collections.Counter[str] = collections.Counter()

    for shell in generated_geometry.get("shells", []) or []:
        all_node_ids = [int(node_id) for node_id in shell.get("node_ids", [])]
        if len(all_node_ids) in {3, 6}:
            corner_count = 3
        elif len(all_node_ids) in {4, 8}:
            corner_count = 4
        else:
            corner_count = len(all_node_ids)
        node_ids = all_node_ids[:corner_count]
        role_counts[_generated_shell_role(shell)] += 1
        if len(node_ids) not in {3, 4} or any(node_id not in nodes for node_id in node_ids):
            invalid_count += 1
            continue
        coords = np.asarray([nodes[node_id] for node_id in node_ids], dtype=float)
        if not np.all(np.isfinite(coords)):
            invalid_count += 1
            continue
        edges = [coords[(index + 1) % len(node_ids)] - coords[index] for index in range(len(node_ids))]
        lengths = [float(np.linalg.norm(edge)) for edge in edges]
        min_length = min(lengths) if lengths else 0.0
        max_length = max(lengths) if lengths else 0.0
        if min_length <= 1.0e-15:
            invalid_count += 1
            continue
        aspect_ratios.append(max_length / min_length)

        angle_deviation = 0.0
        ideal_angle = 60.0 if len(node_ids) == 3 else 90.0
        for index in range(len(node_ids)):
            a = -edges[index - 1]
            b = edges[index]
            denom = float(np.linalg.norm(a) * np.linalg.norm(b))
            if denom <= 1.0e-15:
                angle_deviation = 90.0
                break
            cosine = float(np.clip(np.dot(a, b) / denom, -1.0, 1.0))
            angle = math.degrees(math.acos(cosine))
            angle_deviation = max(angle_deviation, abs(ideal_angle - angle))
        skew_degrees.append(angle_deviation)

        triangle_area_1 = 0.5 * float(np.linalg.norm(np.cross(coords[1] - coords[0], coords[2] - coords[0])))
        if len(node_ids) == 3:
            area = triangle_area_1
        else:
            triangle_area_2 = 0.5 * float(np.linalg.norm(np.cross(coords[2] - coords[0], coords[3] - coords[0])))
            area = triangle_area_1 + triangle_area_2
        if area <= 1.0e-18:
            invalid_count += 1
            continue
        areas.append(area)

        normal = np.cross(coords[1] - coords[0], coords[2] - coords[0])
        normal_norm = float(np.linalg.norm(normal))
        if normal_norm > 1.0e-15 and len(node_ids) == 4:
            normal /= normal_norm
            out_of_plane = abs(float(np.dot(coords[3] - coords[0], normal)))
            warps.append(out_of_plane / max(sum(lengths) / 4.0, 1.0e-15))
        else:
            warps.append(0.0)

    shell_count = sum(role_counts.values())
    skin_count = role_counts.get("skin", 0) + role_counts.get("", 0)
    diagnostics: dict[str, float | int | str] = {
        "shell_quality_count": int(shell_count),
        "skin_shells": int(skin_count),
        "member_shells": int(shell_count - skin_count),
        "invalid_shell_quality_count": int(invalid_count),
    }
    if aspect_ratios:
        diagnostics["max_shell_aspect_ratio"] = float(max(aspect_ratios))
        diagnostics["mean_shell_aspect_ratio"] = float(sum(aspect_ratios) / len(aspect_ratios))
    if skew_degrees:
        diagnostics["max_shell_skew_deg"] = float(max(skew_degrees))
    if warps:
        diagnostics["max_shell_warp"] = float(max(warps))
    if areas:
        diagnostics["min_shell_area_m2"] = float(min(areas))

    warnings: list[str] = []
    if invalid_count:
        warnings.append(f"{invalid_count} invalid shell element(s)")
    if float(diagnostics.get("max_shell_aspect_ratio", 1.0)) > 5.0:
        warnings.append("high shell aspect ratio")
    if float(diagnostics.get("max_shell_skew_deg", 0.0)) > 30.0:
        warnings.append("high shell skew")
    if float(diagnostics.get("max_shell_warp", 0.0)) > 0.05:
        warnings.append("warped shell element")
    if warnings:
        diagnostics["mesh_quality_warnings"] = "; ".join(warnings)
    return diagnostics


def _mesh_size_diagnostics(generated_geometry: dict) -> dict[str, float | int | str]:
    nodes = {int(node["id"]): tuple(float(value) for value in node["coords"]) for node in generated_geometry.get("nodes", [])}
    grid = generated_geometry.get("plot_grid") or []
    diagnostics: dict[str, float | int | str] = {"shell_order": _shell_order_from_geometry(generated_geometry)}
    diagnostics["beam_order"] = _beam_order_from_geometry(generated_geometry)
    diagnostics.update(_mesh_quality_diagnostics(generated_geometry, nodes))
    mesh_generation = generated_geometry.get("mesh_generation") or {}
    if isinstance(mesh_generation, dict):
        for key, value in mesh_generation.items():
            if isinstance(value, (int, float, str)):
                diagnostics["mesh_" + str(key)] = value
    if not grid:
        return diagnostics
    if generated_geometry.get("plot_type") == "cylinder":
        row = list(grid[0][:-1])
        z_values = sorted({nodes[node_id][2] for line in grid for node_id in line if node_id in nodes})
        radius = _positive(generated_geometry.get("radius_m", 0.0), 0.0)
        if row and radius > 0.0:
            diagnostics["circumferential_divisions"] = len(row)
            diagnostics["max_circumferential_edge_m"] = 2.0 * math.pi * radius / max(len(row), 1)
        if len(z_values) > 1:
            diagnostics["axial_divisions"] = len(z_values) - 1
            diagnostics["max_axial_edge_m"] = max(b - a for a, b in zip(z_values, z_values[1:]))
        return diagnostics
    x_values = sorted({nodes[node_id][0] for line in grid for node_id in line if node_id in nodes})
    y_values = sorted({nodes[node_id][1] for line in grid for node_id in line if node_id in nodes})
    if len(x_values) > 1:
        diagnostics["x_divisions"] = len(x_values) - 1
        diagnostics["max_x_edge_m"] = max(b - a for a, b in zip(x_values, x_values[1:]))
    if len(y_values) > 1:
        diagnostics["y_divisions"] = len(y_values) - 1
        diagnostics["max_y_edge_m"] = max(b - a for a, b in zip(y_values, y_values[1:]))
    return diagnostics


def _ring_tributary_fractions(model, node_ids: list[int]) -> dict[int, float]:
    """Tributary circumference fraction per node of a closed end ring.

    End loads must be distributed proportionally to the arc each node
    represents: refined meshes cluster ring nodes locally, and an equal
    per-node split then concentrates the resultant on the refined side,
    turning a pure axial force into a spurious global bending moment.
    """
    entries: list[tuple[float, int]] = []
    for node_id in node_ids:
        node = model.mesh.get_node(int(node_id))
        if node is None:
            continue
        coords = node.coords()
        theta = math.atan2(float(coords[1]), float(coords[0])) % (2.0 * math.pi)
        entries.append((theta, int(node.id)))
    if not entries:
        return {}
    if len(entries) == 1:
        return {entries[0][1]: 1.0}
    entries.sort()
    full = 2.0 * math.pi
    count = len(entries)
    fractions: dict[int, float] = {}
    for index, (theta, node_id) in enumerate(entries):
        gap_prev = (theta - entries[index - 1][0]) % full
        gap_next = (entries[(index + 1) % count][0] - theta) % full
        fractions[node_id] = 0.5 * (gap_prev + gap_next) / full
    return fractions


def _edge_tributary_fractions(nodes: list[object], axis: int = 1) -> dict[int, float]:
    """Tributary length fraction per node of an open panel edge."""
    weights = _line_node_weights(list(nodes), axis)
    total = sum(weights.values())
    if total <= 0.0:
        return {node_id: 1.0 / max(len(weights), 1) for node_id in weights}
    return {node_id: weight / total for node_id, weight in weights.items()}


def _add_generated_axial_force(model, load_case, generated_geometry: dict, axial_force_n: float) -> None:
    try:
        axial_force = float(axial_force_n)
    except (TypeError, ValueError):
        return
    if abs(axial_force) <= 0.0:
        return
    if generated_geometry.get("plot_type") == "cylinder":
        bottom = [int(node_id) for node_id in generated_geometry.get("bottom_ring_node_ids", [])]
        top = [int(node_id) for node_id in generated_geometry.get("top_ring_node_ids", [])]
        if not bottom or not top:
            return
        for ring, sign in ((bottom, 1.0), (top, -1.0)):
            fractions = _ring_tributary_fractions(model, ring)
            for node_id, fraction in fractions.items():
                load_case.add_nodal_load(
                    node_id, forces=np.array([0.0, 0.0, sign * axial_force * fraction], dtype=float)
                )
        return
    shell_node_ids = sorted({node_id for shell in generated_geometry.get("shells", []) for node_id in shell.get("node_ids", [])})
    nodes = [model.mesh.get_node(int(node_id)) for node_id in shell_node_ids]
    nodes = [node for node in nodes if node is not None]
    if not nodes:
        return
    xs = [float(node.x) for node in nodes]
    xmin = min(xs)
    xmax = max(xs)
    tol = max((xmax - xmin) * 1.0e-9, 1.0e-9)
    left = [node for node in nodes if abs(float(node.x) - xmin) <= tol]
    right = [node for node in nodes if abs(float(node.x) - xmax) <= tol]
    if not left or not right:
        return
    for edge, sign in ((left, 1.0), (right, -1.0)):
        fractions = _edge_tributary_fractions(edge, axis=1)
        for node_id, fraction in fractions.items():
            load_case.add_nodal_load(
                int(node_id), forces=np.array([sign * axial_force * fraction, 0.0, 0.0], dtype=float)
            )


def _line_node_weights(nodes: list[object], axis: int, closed_length: float = 0.0) -> dict[int, float]:
    if not nodes:
        return {}
    if closed_length > 0.0:
        return {int(node.id): float(closed_length) / len(nodes) for node in nodes}
    if len(nodes) == 1:
        return {int(nodes[0].id): 1.0}
    ordered = sorted(nodes, key=lambda node: float(node.coords()[axis]))
    coords = [float(node.coords()[axis]) for node in ordered]
    weights: dict[int, float] = {}
    for index, node in enumerate(ordered):
        if index == 0:
            weight = 0.5 * abs(coords[1] - coords[0])
        elif index == len(ordered) - 1:
            weight = 0.5 * abs(coords[-1] - coords[-2])
        else:
            weight = 0.5 * abs(coords[index + 1] - coords[index - 1])
        weights[int(node.id)] = float(weight)
    return weights


def _apply_weighted_edge_load(load_case, weights: dict[int, float], force_per_length: np.ndarray,
                              moment_per_length: np.ndarray | None = None) -> None:
    if not weights:
        return
    vector = np.asarray(force_per_length, dtype=float)
    moment = None if moment_per_length is None else np.asarray(moment_per_length, dtype=float)
    for node_id, weight in weights.items():
        load_case.add_nodal_load(
            int(node_id),
            forces=vector * float(weight),
            moments=None if moment is None else moment * float(weight),
        )


def _edge_load_components(payload: object) -> tuple[np.ndarray, np.ndarray] | None:
    """Parse {fx..mz} per-length components into (forces, moments) on global axes.

    Forces are N/m and moments Nm/m; returns None when the payload holds no
    non-zero component so callers can fall back to the legacy scalar loads.
    """
    if not isinstance(payload, dict):
        return None
    try:
        forces = np.array([float(payload.get(key, 0.0) or 0.0) for key in ("fx", "fy", "fz")], dtype=float)
        moments = np.array([float(payload.get(key, 0.0) or 0.0) for key in ("mx", "my", "mz")], dtype=float)
    except (TypeError, ValueError):
        return None
    if not np.any(np.abs(forces) > 0.0) and not np.any(np.abs(moments) > 0.0):
        return None
    return forces, moments


def _edge_load_component_specs(config: LightweightFEMConfig) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Whole-edge component loads keyed by edge (x0/x1/y0/y1, lower/upper, all)."""
    try:
        raw = json.loads(config.edge_load_components_json or "{}")
    except (TypeError, ValueError, json.JSONDecodeError):
        return {}
    if not isinstance(raw, dict):
        return {}
    specs: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    for edge_key, payload in raw.items():
        components = _edge_load_components(payload)
        if components is not None:
            specs[str(edge_key).strip().lower()] = components
    return specs


def _selected_edge_load_config_components(config: LightweightFEMConfig) -> tuple[np.ndarray, np.ndarray] | None:
    try:
        payload = json.loads(config.custom_selected_edge_load_components_json or "null")
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    return _edge_load_components(payload)


def _custom_pressure_patch_count(config: LightweightFEMConfig) -> int:
    return len(_custom_pressure_patches(config))


def _custom_pressure_uses_selected_patches(config: LightweightFEMConfig) -> bool:
    return bool(config.custom_load_bc_enabled) and _custom_pressure_patch_count(config) > 0


def _add_custom_panel_pressure_loads(
        model,
        load_case,
        generated_geometry: dict,
        geometry: dict,
        config: LightweightFEMConfig,
) -> int:
    if not _custom_pressure_uses_selected_patches(config):
        return 0
    pressure_entries = _custom_pressure_load_entries(config)
    if pressure_entries:
        applied = 0
        for entry in pressure_entries:
            pressure = abs(float(entry.get("pressure_pa", 0.0) or 0.0))
            if pressure <= 0.0:
                continue
            patches = _normalised_custom_pressure_patches(entry.get("patches", []))
            element_ids = _custom_pressure_patch_element_ids_from_patches(
                model,
                generated_geometry,
                geometry,
                patches,
            )
            for element_id in element_ids:
                load_case.add_pressure_load(int(element_id), _pressure_sign(config) * pressure * float(config.load_scale))
            applied += len(element_ids)
        return applied

    pressure = abs(float(config.custom_pressure_pa or 0.0))
    if pressure <= 0.0:
        return 0
    element_ids = _custom_pressure_patch_element_ids(model, generated_geometry, geometry, config)
    for element_id in element_ids:
        load_case.add_pressure_load(int(element_id), _pressure_sign(config) * pressure * float(config.load_scale))
    return len(element_ids)


def _custom_edge_segments(config: LightweightFEMConfig) -> list[dict[str, float | str]]:
    edge_entries = _custom_edge_load_entries(config)
    if edge_entries:
        raw_segments: list[object] = []
        for entry in edge_entries:
            edges = entry.get("edges", [])
            if isinstance(edges, list):
                raw_segments.extend(edges)
    else:
        try:
            import json
            raw_segments = json.loads(config.custom_edge_segments_json) if config.custom_edge_segments_json else []
        except Exception:
            return []
    if not isinstance(raw_segments, list):
        return []
    segments: list[dict[str, float | str]] = []
    for raw in raw_segments:
        if not isinstance(raw, dict):
            continue
        start = float(raw.get("start_coordinate", 0.0))
        end = float(raw.get("end_coordinate", 0.0))
        if abs(end - start) <= 1.0e-12:
            continue
        segments.append({
            "varying_axis": str(raw.get("varying_axis", "a")).lower(),
            "fixed_coordinate": float(raw.get("fixed_coordinate", 0.0)),
            "start_coordinate": min(start, end),
            "end_coordinate": max(start, end),
        })
    return segments


def _flat_segment_nodes(nodes: list, segment: dict[str, float | str], tol: float) -> tuple[list, int, np.ndarray]:
    varying_axis = str(segment.get("varying_axis", "a")).lower()
    fixed = float(segment.get("fixed_coordinate", 0.0))
    start = float(segment.get("start_coordinate", 0.0))
    end = float(segment.get("end_coordinate", 0.0))
    if varying_axis == "a":
        selected = [
            node for node in nodes
            if abs(float(node.y) - fixed) <= tol and start - tol <= float(node.x) <= end + tol
        ]
        return selected, 0, np.array([0.0, 1.0, 0.0])
    selected = [
        node for node in nodes
        if abs(float(node.x) - fixed) <= tol and start - tol <= float(node.y) <= end + tol
    ]
    return selected, 1, np.array([float(1.0), 0.0, 0.0])


def _add_custom_selected_edge_loads(model, load_case, nodes: list, generated_geometry: dict, config: LightweightFEMConfig, tol: float) -> None:
    if not config.custom_load_bc_enabled:
        return
    if generated_geometry.get("plot_type") != "flat":
        return
    edge_entries = _custom_edge_load_entries(config)
    load_groups: list[tuple[np.ndarray, np.ndarray | None, list[dict[str, float | str]]]] = []
    if edge_entries:
        for entry in edge_entries:
            raw_edges = entry.get("edges", [])
            if not isinstance(raw_edges, list):
                continue
            edge_config = LightweightFEMConfig(custom_edge_segments_json=json.dumps(raw_edges))
            segments = _custom_edge_segments(edge_config)
            components = _edge_load_components(entry.get("components"))
            if components is not None:
                # fx..mz per unit length, entered on global axes.
                load_groups.append((components[0], components[1], segments))
                continue
            line_load = float(entry.get("line_load_n_per_m", 0.0) or 0.0)
            if abs(line_load) <= 0.0:
                continue
            # Legacy scalar: direction implied by the segment orientation.
            load_groups.append((np.array([line_load]), None, segments))
    else:
        components = _selected_edge_load_config_components(config)
        if components is not None:
            load_groups = [(components[0], components[1], _custom_edge_segments(config))]
        else:
            line_load = float(config.custom_selected_edge_load_n_per_m or 0.0)
            if abs(line_load) <= 0.0:
                return
            load_groups = [(np.array([line_load]), None, _custom_edge_segments(config))]

    for forces, moments, segments in load_groups:
        if not segments:
            continue
        for segment in segments:
            segment_nodes, weight_axis, direction = _flat_segment_nodes(nodes, segment, tol)
            weights = _line_node_weights(segment_nodes, weight_axis)
            if moments is None:
                # Legacy scalar entry: the single value acts along the implied
                # in-plane direction normal to the segment.
                _apply_weighted_edge_load(load_case, weights, direction * float(forces[0]))
            else:
                _apply_weighted_edge_load(load_case, weights, forces, moments)


def _add_custom_edge_loads(model, load_case, generated_geometry: dict, config: LightweightFEMConfig) -> None:
    if not config.custom_load_bc_enabled:
        return
    nodes = [model.mesh.get_node(int(node["id"])) for node in generated_geometry.get("nodes", [])]
    nodes = [node for node in nodes if node is not None]
    if not nodes:
        return
    coords = np.asarray([node.coords() for node in nodes], dtype=float)
    tol = max(float(np.ptp(coords[:, 0]) + np.ptp(coords[:, 1]) + np.ptp(coords[:, 2])) * 1.0e-9, 1.0e-9)
    component_specs = _edge_load_component_specs(config)

    def _apply_component_specs(edge_key: str, weights: dict[int, float]) -> None:
        for spec_key in ("all", edge_key):
            spec = component_specs.get(spec_key)
            if spec is not None:
                _apply_weighted_edge_load(load_case, weights, spec[0], spec[1])

    if generated_geometry.get("plot_type") == "cylinder":
        lower_ids = set(int(node_id) for node_id in generated_geometry.get("bottom_ring_node_ids", []))
        upper_ids = set(int(node_id) for node_id in generated_geometry.get("top_ring_node_ids", []))
        lower = [node for node in nodes if int(node.id) in lower_ids]
        upper = [node for node in nodes if int(node.id) in upper_ids]
        radius = _positive(generated_geometry.get("radius_m", 0.0), 0.0)
        circumference = 2.0 * math.pi * radius if radius > 0.0 else 0.0
        lower_weights = _line_node_weights(lower, 0, circumference)
        upper_weights = _line_node_weights(upper, 0, circumference)
        _apply_weighted_edge_load(load_case, lower_weights, np.array([0.0, 0.0, -float(config.cylinder_lower_edge_load_n_per_m)]))
        _apply_weighted_edge_load(load_case, upper_weights, np.array([0.0, 0.0, float(config.cylinder_upper_edge_load_n_per_m)]))
        _apply_component_specs("lower", lower_weights)
        _apply_component_specs("upper", upper_weights)
        return
    xmin = float(np.min(coords[:, 0]))
    xmax = float(np.max(coords[:, 0]))
    ymin = float(np.min(coords[:, 1]))
    ymax = float(np.max(coords[:, 1]))
    x0_nodes = [node for node in nodes if abs(float(node.x) - xmin) <= tol]
    x1_nodes = [node for node in nodes if abs(float(node.x) - xmax) <= tol]
    y0_nodes = [node for node in nodes if abs(float(node.y) - ymin) <= tol]
    y1_nodes = [node for node in nodes if abs(float(node.y) - ymax) <= tol]
    x0_weights = _line_node_weights(x0_nodes, 1)
    x1_weights = _line_node_weights(x1_nodes, 1)
    y0_weights = _line_node_weights(y0_nodes, 0)
    y1_weights = _line_node_weights(y1_nodes, 0)
    _apply_weighted_edge_load(load_case, x0_weights, np.array([-float(config.plate_edge_x0_load_n_per_m), 0.0, 0.0]))
    _apply_weighted_edge_load(load_case, x1_weights, np.array([float(config.plate_edge_x1_load_n_per_m), 0.0, 0.0]))
    _apply_weighted_edge_load(load_case, y0_weights, np.array([0.0, -float(config.plate_edge_y0_load_n_per_m), 0.0]))
    _apply_weighted_edge_load(load_case, y1_weights, np.array([0.0, float(config.plate_edge_y1_load_n_per_m), 0.0]))
    _apply_component_specs("x0", x0_weights)
    _apply_component_specs("x1", x1_weights)
    _apply_component_specs("y0", y0_weights)
    _apply_component_specs("y1", y1_weights)
    _add_custom_selected_edge_loads(model, load_case, nodes, generated_geometry, config, tol)


def _add_generated_end_moments(model, load_case, generated_geometry: dict, moment_nm: float) -> None:
    moment = float(moment_nm or 0.0)
    if abs(moment) <= 0.0:
        return
    if generated_geometry.get("plot_type") == "flat":
        shell_node_ids = sorted({node_id for shell in generated_geometry.get("shells", []) for node_id in shell.get("node_ids", [])})
        nodes = [model.mesh.get_node(int(node_id)) for node_id in shell_node_ids]
        nodes = [node for node in nodes if node is not None]
        if not nodes:
            return
        xs = [float(node.x) for node in nodes]
        xmin = min(xs)
        xmax = max(xs)
        tol = max((xmax - xmin) * 1.0e-9, 1.0e-9)
        left = [node for node in nodes if abs(float(node.x) - xmin) <= tol]
        right = [node for node in nodes if abs(float(node.x) - xmax) <= tol]
        if not left or not right:
            return
        for edge, sign in ((left, 1.0), (right, -1.0)):
            fractions = _edge_tributary_fractions(edge, axis=1)
            for node_id, fraction in fractions.items():
                load_case.add_nodal_load(
                    int(node_id), moments=np.array([0.0, sign * moment * fraction, 0.0], dtype=float)
                )
        return

    bottom_ring = [int(node_id) for node_id in generated_geometry.get("bottom_ring_node_ids", [])]
    top_ring = [int(node_id) for node_id in generated_geometry.get("top_ring_node_ids", [])]
    if not bottom_ring or not top_ring:
        return

    def add_ring_moment(node_ids: list[int], sign: float) -> None:
        # Tributary-weighted linear axial distribution p_i = w_i (a + b x_i)
        # with the two constraints sum(p) = 0 (no spurious net axial force on
        # clustered rings) and sum(p x) = M (exact bending moment).
        fractions = _ring_tributary_fractions(model, node_ids)
        if not fractions:
            return
        coords = {node_id: model.mesh.get_node(node_id).coords() for node_id in fractions}
        s_x = sum(w * float(coords[nid][0]) for nid, w in fractions.items())
        s_xx = sum(w * float(coords[nid][0]) ** 2 for nid, w in fractions.items())
        denominator = s_xx - s_x * s_x
        if denominator <= 1.0e-12:
            return
        b = moment / denominator
        a = -b * s_x
        for node_id, w in fractions.items():
            axial_force = -sign * w * (a + b * float(coords[node_id][0]))
            load_case.add_nodal_load(int(node_id), forces=np.array([0.0, 0.0, axial_force], dtype=float))

    add_ring_moment(bottom_ring, -1.0)
    add_ring_moment(top_ring, 1.0)


def _add_generated_shear_force(model, load_case, generated_geometry: dict, shear_force_n: float) -> None:
    shear = float(shear_force_n or 0.0)
    if abs(shear) <= 0.0:
        return
    if generated_geometry.get("plot_type") == "flat":
        shell_node_ids = sorted({node_id for shell in generated_geometry.get("shells", []) for node_id in shell.get("node_ids", [])})
        nodes = [model.mesh.get_node(int(node_id)) for node_id in shell_node_ids]
        nodes = [node for node in nodes if node is not None]
        if not nodes:
            return
        xs = [float(node.x) for node in nodes]
        xmin = min(xs)
        xmax = max(xs)
        tol = max((xmax - xmin) * 1.0e-9, 1.0e-9)
        left = [node for node in nodes if abs(float(node.x) - xmin) <= tol]
        right = [node for node in nodes if abs(float(node.x) - xmax) <= tol]
        if not left or not right:
            return
        for edge, sign in ((left, -1.0), (right, 1.0)):
            fractions = _edge_tributary_fractions(edge, axis=1)
            for node_id, fraction in fractions.items():
                load_case.add_nodal_load(
                    int(node_id), forces=np.array([0.0, sign * shear * fraction, 0.0], dtype=float)
                )
        return

    bottom_ring = [int(node_id) for node_id in generated_geometry.get("bottom_ring_node_ids", [])]
    top_ring = [int(node_id) for node_id in generated_geometry.get("top_ring_node_ids", [])]
    if not bottom_ring or not top_ring:
        return
    for ring, sign in ((bottom_ring, -1.0), (top_ring, 1.0)):
        fractions = _ring_tributary_fractions(model, ring)
        for node_id, fraction in fractions.items():
            load_case.add_nodal_load(
                node_id, forces=np.array([0.0, sign * shear * fraction, 0.0], dtype=float)
            )


def _add_generated_torsional_moment(model, load_case, generated_geometry: dict, moment_nm: float) -> None:
    moment = float(moment_nm or 0.0)
    if abs(moment) <= 0.0:
        return
    if generated_geometry.get("plot_type") == "flat":
        shell_node_ids = sorted({node_id for shell in generated_geometry.get("shells", []) for node_id in shell.get("node_ids", [])})
        nodes = [model.mesh.get_node(int(node_id)) for node_id in shell_node_ids]
        nodes = [node for node in nodes if node is not None]
        if not nodes:
            return
        xs = [float(node.x) for node in nodes]
        xmin = min(xs)
        xmax = max(xs)
        tol = max((xmax - xmin) * 1.0e-9, 1.0e-9)
        left = [node for node in nodes if abs(float(node.x) - xmin) <= tol]
        right = [node for node in nodes if abs(float(node.x) - xmax) <= tol]
        if not left or not right:
            return
        for edge, sign in ((left, 1.0), (right, -1.0)):
            fractions = _edge_tributary_fractions(edge, axis=1)
            for node_id, fraction in fractions.items():
                load_case.add_nodal_load(
                    int(node_id), moments=np.array([sign * moment * fraction, 0.0, 0.0], dtype=float)
                )
        return

    bottom_ring = [int(node_id) for node_id in generated_geometry.get("bottom_ring_node_ids", [])]
    top_ring = [int(node_id) for node_id in generated_geometry.get("top_ring_node_ids", [])]
    if not bottom_ring or not top_ring:
        return

    def add_ring_torsion(node_ids: list[int], sign: float) -> None:
        # Tributary-weighted tangential traction: exact torque on clustered
        # rings without a spurious net in-plane force.
        fractions = _ring_tributary_fractions(model, node_ids)
        if not fractions:
            return
        coords = {node_id: model.mesh.get_node(node_id).coords() for node_id in fractions}
        denominator = sum(
            w * (float(coords[nid][0]) ** 2 + float(coords[nid][1]) ** 2)
            for nid, w in fractions.items()
        )
        if denominator <= 1.0e-12:
            return
        for node_id, w in fractions.items():
            fx = sign * moment * w * float(coords[node_id][1]) / denominator
            fy = -sign * moment * w * float(coords[node_id][0]) / denominator
            load_case.add_nodal_load(int(node_id), forces=np.array([fx, fy, 0.0], dtype=float))

    add_ring_torsion(bottom_ring, -1.0)
    add_ring_torsion(top_ring, 1.0)



def _stress_statistics_from_model(model, displacements: np.ndarray, percentile: float = 95.0) -> dict[str, float]:
    if _backend_compute_stresses is None:
        return {"max": 0.0, "percentile": 0.0}
    return _stress_statistics_from_stresses(_backend_compute_stresses(model, displacements), percentile)


def _stress_statistics_from_stresses(
    stresses_by_element: dict[int, object],
    percentile: float = 95.0,
    *,
    component: str = "von_mises",
) -> dict[str, float]:
    values = []
    for stress in (stresses_by_element or {}).values():
        if not isinstance(stress, dict):
            continue
        if component in stress:
            values.extend(
                np.asarray(stress[component], dtype=float).reshape(-1).tolist()
            )
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return {"max": 0.0, "percentile": 0.0}
    return {"max": float(np.max(arr)), "percentile": float(np.percentile(arr, percentile))}


def _runtime_display_stresses(
    model,
    displacements: np.ndarray,
    nonlinear_static_result: object | None,
) -> tuple[dict[int, object], set[int], dict[str, object]]:
    """Return display stresses and ids backed by committed element states."""
    recovery = _recover_stress_result(
        model,
        displacements,
        nonlinear_result=nonlinear_static_result,
        copy_committed_states=False,
    )
    return (
        recovery.element_stresses,
        set(recovery.provenance.history_aware_element_ids),
        recovery.provenance.to_dict(),
    )


def _max_translation(model, displacements: np.ndarray) -> float:
    value = 0.0
    for node in model.mesh.nodes.values():
        value = max(value, float(np.linalg.norm(displacements[node.dofs[:3]])))
    return value


def _cylinder_pressure_prestress_states(model, pressure: float, radius: float) -> dict[int, dict[str, float]]:
    compression = abs(float(pressure)) * max(float(radius), 1.0e-9)
    states: dict[int, dict[str, float]] = {}
    if compression <= 0.0:
        return states
    for element_id, element in model.mesh.elements.items():
        if isinstance(element, _full_backend.ShellElement):
            states[int(element_id)] = {
                "membrane_compression_x": compression,
                "membrane_compression_y": 0.5 * compression,
                "membrane_compression_xy": 0.0,
            }
    return states


def _add_cylinder_buckling_gauge(model, generated_geometry: dict) -> bool:
    """Add minimal buckling-only constraints that remove free rigid-body drift."""
    rigid_lids = list(generated_geometry.get("rigid_lids") or [])
    if not rigid_lids or getattr(model, "boundary_conditions", None):
        return False
    try:
        bottom_center = int(rigid_lids[0]["center_node_id"])
        top_center = int(rigid_lids[-1]["center_node_id"])
    except (KeyError, TypeError, ValueError):
        return False
    if model.mesh.get_node(bottom_center) is None or model.mesh.get_node(top_center) is None:
        return False
    model.add_boundary_condition(
        _full_backend.BoundaryCondition(
            "buckling_gauge_bottom_lid",
            [bottom_center],
            {"ux": 0.0, "uy": 0.0, "uz": 0.0, "rz": 0.0},
        )
    )
    model.add_boundary_condition(
        _full_backend.BoundaryCondition(
            "buckling_gauge_top_lid",
            [top_center],
            {"ux": 0.0, "uy": 0.0},))
def apply_mode_shape_imperfections(
    generated_geometry: GeneratedGeometry,
    config: LightweightFEMConfig,
    geometry: NormalizedGeometry,
) -> GeneratedGeometry:
    """Build mesh, run linear buckling, extract mode shapes, and perturb the mesh."""
    import copy
    import json
    import numpy as np
    import dataclasses

    try:
        mode_factors = json.loads(config.imperfection_mode_shapes_json)
    except Exception:
        mode_factors = []

    if not mode_factors or _full_backend is None:
        return generated_geometry

    max_mode = max(int(item["mode"]) for item in mode_factors)
    temp_config = dataclasses.replace(config, num_buckling_modes=max(int(config.num_buckling_modes), max_mode))

    result = run_production_fem(geometry, temp_config, precomputed_generated_geometry=generated_geometry)

    if not result.buckling_modes:
        raise RuntimeError(
            "The buckling analysis returned no mode shapes for this load state. "
            "Linear buckling needs membrane compression from the applied loads "
            "(axial force, in-plane stresses or pressure); check the run "
            "diagnostics for the buckling solver status."
        )

    perturbed_geometry = copy.deepcopy(generated_geometry)

    first_mode = result.buckling_modes[0]
    total_disp = np.zeros_like(first_mode.mode_shape)

    for item in mode_factors:
        mode_num = int(item["mode"])
        factor = float(item["factor"])

        mode = next((m for m in result.buckling_modes if m.mode_number == mode_num), None)
        if mode is None:
            raise RuntimeError(f"Mode {mode_num} was not found in buckling results.")

        total_disp += np.asarray(mode.mode_shape, dtype=float) * factor

    effective_elastic_modulus = float(config.elastic_modulus_pa)
    effective_yield_stress = float(config.yield_stress_pa)
    effective_pressure = _effective_pressure_pa(config)
    symmetric_pressure = effective_pressure
    if _custom_pressure_uses_selected_patches(config):
        symmetric_pressure = float(config.pressure_pa or 0.0) if _include_imported_loads(config) else 0.0

    backend_config = _full_backend.AnyStructureFEMConfig(
        pressure_pa=abs(float(symmetric_pressure)),
        pressure_sign=_pressure_sign(config),
        load_scale=float(config.load_scale),
        num_buckling_modes=int(config.num_buckling_modes),
        solver_type=_solver_type(config),
        stress_percentile=min(max(float(config.stress_percentile), 0.0), 100.0),
        add_inplane_edge_loads=False,
        auto_idealize_member_plates_as_beams=not _member_webs_as_shells(config),
        exclude_idealized_member_plates=not _member_webs_as_shells(config),
        require_idealized_member_beams=False,
        elastic_modulus=effective_elastic_modulus,
        poisson_ratio=config.poisson_ratio,
        yield_stress=effective_yield_stress,
    )

    model = _full_backend.build_fe_model_from_generated_geometry(perturbed_geometry, backend_config)

    for n in perturbed_geometry.get("nodes", []):
        nid = n["id"]
        backend_node = model.mesh.nodes.get(nid)
        if backend_node is None:
            continue
        dofs = backend_node.dofs
        dx = float(total_disp[dofs[0]])
        dy = float(total_disp[dofs[1]])
        dz = float(total_disp[dofs[2]])

        n["coords"][0] += dx
        n["coords"][1] += dy
        n["coords"][2] += dz

    return perturbed_geometry

def run_production_fem(
    geometry: NormalizedGeometry,
    config: LightweightFEMConfig,
    status_callback: StatusCallback | None = None,
    imported_fem_model: object | None = None,
    precomputed_generated_geometry: GeneratedGeometry | None = None,
    analysis_context: RuntimeAnalysisContext | None = None,
) -> LightweightFEMResult:
    """Run the production FE mesh backend for normalized generated geometry."""

    runtime_started = time.perf_counter()
    phase_timings: dict[str, float] = {}
    recovery_evaluations = 0
    if _full_backend is None or _backend_solve_linear is None or _backend_solve_buckling is None or _backend_load_case_resultant is None:
        return LightweightFEMResult(
            status="backend_unavailable",
            stress_max_pa=0.0,
            stress_p95_pa=0.0,
            displacement_max_m=0.0,
            diagnostics=("Production FE backend is not available.",),
            solver_name="ANYsolver production FE mesh",
        )

    if status_callback: status_callback("Building generated geometry...")
    if precomputed_generated_geometry is not None:
        generated_geometry = precomputed_generated_geometry
    elif imported_fem_model is not None:
        nodes = []
        for nid, n in imported_fem_model.mesh.nodes.items():
            nodes.append({"id": nid, "coords": list(n.coords())})
        shells = []
        beams = []
        for eid, el in imported_fem_model.mesh.elements.items():
            if isinstance(el, _full_backend.ShellElement):
                shells.append({"id": eid, "node_ids": list(el.node_ids), "role": "skin"})
            elif el.__class__.__name__ == "BeamElement":
                beams.append({"id": eid, "node_ids": list(el.node_ids), "role": "stiffener"})
        generated_geometry = {"geometry": "flat panel", "plot_grid": [], "nodes": nodes, "shells": shells, "beams": beams}
    else:
        generated_geometry = build_generated_geometry(geometry, config)
    phase_timings["geometry_preparation"] = float(
        time.perf_counter() - runtime_started
    )
    material_curve, material_properties = _nonlinear_curve_payload(config, geometry)
    effective_elastic_modulus = float(material_properties.get("E_pa", config.elastic_modulus_pa)) if material_properties else config.elastic_modulus_pa
    effective_yield_stress = float(material_properties.get("sigma_yield", config.yield_stress_pa)) if material_properties else config.yield_stress_pa
    include_imported_loads = _include_imported_loads(config)
    effective_pressure = _effective_pressure_pa(config)
    symmetric_pressure = effective_pressure
    if _custom_pressure_uses_selected_patches(config):
        symmetric_pressure = float(config.pressure_pa or 0.0) if include_imported_loads else 0.0
    backend_config = _full_backend.AnyStructureFEMConfig(
        pressure_pa=abs(float(symmetric_pressure)),
        pressure_sign=_pressure_sign(config),
        load_scale=float(config.load_scale),
        num_buckling_modes=int(config.num_buckling_modes),
        solver_type=_solver_type(config),
        stress_percentile=min(max(float(config.stress_percentile), 0.0), 100.0),
        add_inplane_edge_loads=False,
        auto_idealize_member_plates_as_beams=not _member_webs_as_shells(config),
        exclude_idealized_member_plates=not _member_webs_as_shells(config),
        require_idealized_member_beams=False,
        elastic_modulus=effective_elastic_modulus,
        poisson_ratio=config.poisson_ratio,
        yield_stress=effective_yield_stress,
    )
    diagnostics = [
        "ANYsolver production FE mesh backend.",
        (
            "Generated shells and selected stiffener/girder shell member parts from active-line geometry."
            if _member_webs_as_shells(config)
            else "Generated shells and stiffener/girder beams from active-line geometry."
        ),
    ]
    _mesh_metrics = generated_geometry.get("mesh_metrics", {}) or {}
    _adaptive_mesh = generated_geometry.get("adaptive_mesh", {}) or {}
    if _mesh_metrics:
        diagnostics.append(
            "Mesh: {count} shell elements, size {lo:.0f}-{hi:.0f} mm (nominal {nom:.0f} mm).".format(
                count=int(_mesh_metrics.get("shell_element_count", 0)),
                lo=float(_mesh_metrics.get("min_element_size_m", 0.0)) * 1000.0,
                hi=float(_mesh_metrics.get("max_element_size_m", 0.0)) * 1000.0,
                nom=float(_mesh_metrics.get("nominal_element_size_m", 0.0)) * 1000.0,
            )
        )
    if _adaptive_mesh.get("enabled"):
        if str(_adaptive_mesh.get("transition", "")) == _LOCAL_PATCH_TRANSITION:
            diagnostics.append(
                "Local patch transition: {cells} base cells subdivided (max level {lvl}, 2:1 per level), "
                "{quads} quads + {tris} transition triangles, {splits} beam segment(s) split; "
                "mesh outside the detail windows is untouched.".format(
                    cells=int(_adaptive_mesh.get("refined_cells", 0)),
                    lvl=int(_adaptive_mesh.get("max_level", 0)),
                    quads=int(_adaptive_mesh.get("quad_count", 0)),
                    tris=int(_adaptive_mesh.get("tri_count", 0)),
                    splits=int(_adaptive_mesh.get("beam_splits", 0)),
                )
            )
        elif _wants_local_patch_transition(config):
            diagnostics.append(
                "Local patch transition was requested but is unavailable for this model "
                "(needs linear S4/S3 shells, B2 beam members, non-conical geometry); using the graded grid."
            )
        _sources = _adaptive_mesh.get("sources") or [_adaptive_mesh]
        for _source in _sources:
            if not isinstance(_source, dict):
                continue
            if _source.get("source") == "selected_panels":
                diagnostics.append(
                    "Local mesh refinement: {count} selected panel region(s), refined to {fine:.1f} mm.".format(
                        count=int(_source.get("region_count", 0)),
                        fine=float(_source.get("fine_element_size_m", 0.0)) * 1000.0,
                    )
                )
            elif _source.get("source") == "selected_point":
                _point = _source.get("point_m", [0.0, 0.0])
                diagnostics.append(
                    "Point mesh refinement: refined to {fine:.1f} mm inside radius {extent:.0f} mm at ({x:.2f}, {y:.2f}) m.".format(
                        fine=float(_source.get("fine_element_size_m", 0.0)) * 1000.0,
                        extent=float(_source.get("extent_m", 0.0)) * 1000.0,
                        x=float(_point[0]), y=float(_point[1]),
                    )
                )
            elif _source.get("impact_point_m"):
                _impact = _source.get("impact_point_m", [0.0, 0.0])
                diagnostics.append(
                    "Impact mesh preset: refined to {fine:.1f} mm inside radius {extent:.0f} mm at ({x:.2f}, {y:.2f}) m.".format(
                        fine=float(_source.get("fine_element_size_m", 0.0)) * 1000.0,
                        extent=float(_source.get("extent_m", _source.get("fine_radius_m", 0.0))) * 1000.0,
                        x=float(_impact[0]), y=float(_impact[1]),
                    )
                )
            if _source.get("floored_at_thickness"):
                diagnostics.append(
                    "Requested local fine size {req:.1f} mm was floored at the plate thickness {t:.1f} mm.".format(
                        req=float(_source.get("requested_fine_size_m", 0.0)) * 1000.0,
                        t=float(_source.get("plate_thickness_m", 0.0)) * 1000.0,
                    )
                )
    _thickness_info = generated_geometry.get("thickness_regions")
    if _thickness_info:
        diagnostics.append(
            "Plate thickness regions: {regions} region(s), {count} shells assigned, thicknesses {values} mm.".format(
                regions=int(_thickness_info.get("regions", 0)),
                count=int(_thickness_info.get("shells_assigned", 0)),
                values=", ".join(f"{t * 1000.0:.1f}" for t in _thickness_info.get("thicknesses_m", ())),
            )
        )
    if _custom_bc_segments(config):
        diagnostics.append(
            "Applied {count} selected-edge boundary condition segment(s).".format(
                count=len(_custom_bc_segments(config))
            )
        )
    if config.include_end_lids and geometry.get("geometry") == "cylinder":
        diagnostics.append("Applied stress-free rigid top/bottom lid diaphragms at cylinder ends.")
    _support_boundary_specs = _boundary_edge_constraints(config)
    _custom_nullspace = bool(config.custom_load_bc_enabled and config.custom_use_nullspace_projection)
    if _support_boundary_specs and not _custom_nullspace:
        diagnostics.append(
            "Applied per-edge DOF constraints from the Boundary Conditions tab ("
            + str(len(_support_boundary_specs)) + " edge spec(s)); automatic edge supports are bypassed."
        )
    elif (not config.custom_load_bc_enabled) and geometry.get("geometry") != "cylinder":
        if bool(getattr(config, "boundary_auto_supports", True)):
            diagnostics.append(
                "Auto-set: no edge DOF is constrained, so automatic well-posed edge supports were applied "
                "(from line properties, defaulting to simply supported edges when unspecified)."
            )
        else:
            diagnostics.append(
                "No edge constraints and automatic supports are off: the boundary is free "
                "(nullspace projection or balanced loads must carry the rigid-body modes)."
            )
    if include_imported_loads and config.top_bottom_moment_nm:
        diagnostics.append("Applied top/bottom shell bending moment: " + str(round(float(config.top_bottom_moment_nm), 3)) + " Nm.")
    if include_imported_loads and abs(float(config.axial_force_n or 0.0)) > 0.0:
        diagnostics.append("Applied balanced axial force: " + str(round(float(config.axial_force_n), 3)) + " N.")
    if (not config.custom_load_bc_enabled) and (abs(float(getattr(config, "enforced_displacement_x_m", 0.0))) > 0.0 or abs(float(getattr(config, "enforced_displacement_y_m", 0.0))) > 0.0 or abs(float(getattr(config, "enforced_displacement_z_m", 0.0))) > 0.0):
        diagnostics.append("Applied prescribed displacement constraints from the enforced displacement input.")
    if _wants_s6(config):
        diagnostics.append("Generated S6 triangular shell elements with shared midside nodes.")
    elif _wants_s3(config):
        diagnostics.append("Generated S3 triangular shell elements.")
    elif _wants_s8(config):
        elem_type = "S8R" if "s8r" in config.shell_element_order.lower() else "S8"
        diagnostics.append(f"Generated {elem_type} shell elements with shared midside nodes.")
    if bool(geometry.get("members_opposite_side")):
        diagnostics.append(
            "Members are placed on the opposite side (main-application 'Opposite side' setting): "
            "flat-panel members extrude to negative z, cylinder members outward."
        )
    if _member_webs_as_shells(config):
        if _member_flanges_as_shells(config):
            diagnostics.append("Member modelling: plate, web and flange parts are generated as shell elements.")
        else:
            diagnostics.append("Member modelling: webs are generated as shell elements and flanges as beam elements.")
    if _normalized_choice(config.symmetry_mode) == "cyclic":
        diagnostics.append("Cyclic symmetry requested; generated runtime geometry is a full 360-degree model, so no sector coupling was added.")
    elif _normalized_choice(config.symmetry_mode) not in {"none", "off"}:
        diagnostics.append("Applied generated global symmetry boundary conditions.")
    if _normalized_choice(config.member_orientation) == "radial" or (_normalized_choice(config.member_orientation) == "auto" and geometry.get("geometry") == "cylinder"):
        diagnostics.append("Applied radial member section orientation for cylinder beams where applicable.")
    if abs(float(config.stiffener_eccentricity_m or 0.0)) > 0.0 or abs(float(config.girder_eccentricity_m or 0.0)) > 0.0:
        diagnostics.append("Applied eccentric beam-shell MPC offsets for generated member beams.")
    if config.custom_load_bc_enabled:
        diagnostics.append("Using custom load and boundary-condition mode.")
        if include_imported_loads:
            diagnostics.append("Custom loads are added to the imported/generated pressure, axial force and end moment inputs.")
        else:
            diagnostics.append("Custom loads replace imported/generated pressure, axial force and end moment inputs.")
        custom_load_count = len(_custom_load_entries(config))
        if custom_load_count:
            diagnostics.append("Using " + str(custom_load_count) + " saved custom pressure/edge load item(s).")
        if not custom_load_count and abs(float(config.custom_pressure_pa or 0.0)) > 0.0:
            diagnostics.append("Applied custom manual pressure: " + str(round(float(config.custom_pressure_pa), 3)) + " Pa.")
        if config.custom_use_nullspace_projection:
            diagnostics.append("Custom boundary condition is rigid-body nullspace projection with automatic generalized load balancing.")
    if _allow_unbalanced_free_free(config, geometry):
        diagnostics.append("Unbalanced free-free/nullspace static loads are explicitly allowed and will be carried as generalized balancing reactions.")
    if _wants_capacity_workflow(config):
        diagnostics.append("Using ANYsolver structured nonlinear capacity workflow after the reference static solve.")
    buckling_range = _buckling_load_factor_range(config)
    if float(config.buckling_shift_load_factor or 0.0) > 0.0 or buckling_range is not None or bool(config.buckling_allow_dense_fallback):
        diagnostics.append("Buckling validity controls are active: shift/range filtering and dense fallback are passed to the backend.")
    if material_properties:
        diagnostics.append(
            "Using DNV-RP-C208 material curve "
            + str(material_properties.get("grade", ""))
            + ", "
            + str(material_properties.get("thickness_class", ""))
            + " for nonlinear static shell plasticity."
        )
    diagnostics.extend(_auto_set_parameter_notes(config))
    if config.imperfection_enabled:
        diagnostics.append("Geometric imperfection input is enabled; offsets are applied as stress-free reference geometry.")
    if _custom_pressure_uses_selected_patches(config):
        diagnostics.append("Custom pressure is applied only to the selected panel patches.")
    if (
            (_custom_edge_load_entries(config) and _custom_edge_segments(config))
            or (abs(float(config.custom_selected_edge_load_n_per_m or 0.0)) > 0.0 and _custom_edge_segments(config))
            or (_selected_edge_load_config_components(config) is not None and _custom_edge_segments(config))
    ):
        diagnostics.append("Custom selected edge segments receive an additional line load.")
    if config.custom_load_bc_enabled and _edge_load_component_specs(config):
        diagnostics.append(
            "Whole-edge component loads (fx/fy/fz in N/m, mx/my/mz in Nm/m on global axes) are applied to the named edges."
        )
    if config.custom_time_domain_enabled:
        diagnostics.append("Custom time-domain pressure response is enabled and solved with the linear Newmark pressure-patch solver.")
    follower_pressure_error = _invalid_follower_pressure_reason(config)
    if follower_pressure_error:
        return LightweightFEMResult(
            status="invalid_follower_pressure",
            stress_max_pa=0.0,
            stress_p95_pa=0.0,
            displacement_max_m=0.0,
            diagnostics=tuple(diagnostics + [follower_pressure_error]),
            mesh_info={
                "nodes": int(len(generated_geometry.get("nodes", []))),
                "shells": int(len(generated_geometry.get("shells", []))),
                "beams": int(len(generated_geometry.get("beams", []))),
                "rigid_lids": int(len(generated_geometry.get("rigid_lids", []))),
                **_mesh_size_diagnostics(generated_geometry),
            },
            solver_name="ANYsolver production FE mesh",
        )
    if _invalid_corotational_static_fracture(config):
        message = (
            "Corotational nonlinear static does not support fracture/erosion; "
            + "use Von Karman kinematics or disable strain-triggered erosion."
        )
        return LightweightFEMResult(
            status="invalid_static_kinematics",
            stress_max_pa=0.0,
            stress_p95_pa=0.0,
            displacement_max_m=0.0,
            diagnostics=tuple(diagnostics + [message]),
            mesh_info={
                "nodes": int(len(generated_geometry.get("nodes", []))),
                "shells": int(len(generated_geometry.get("shells", []))),
                "beams": int(len(generated_geometry.get("beams", []))),
                "rigid_lids": int(len(generated_geometry.get("rigid_lids", []))),
                **_mesh_size_diagnostics(generated_geometry),
            },
            prestress_summary={
                "nonlinear_static_kinematics": "corotational",
                "fracture_enabled": 1.0,
            },
            solver_name="ANYsolver production FE mesh",
        )

    model = None
    analysis_session = None
    context_reused = False
    context_owned_session = False
    model_preparation_started = time.perf_counter()
    try:
        if status_callback: status_callback("Building FE model...")
        if imported_fem_model is not None:
            model = imported_fem_model
        elif analysis_context is not None and _runtime_context_eligible(
            config,
            geometry,
        ):
            context_key = _runtime_context_key(
                generated_geometry,
                config,
                material_properties,
            )
            model, analysis_session, context_reused = analysis_context.acquire(
                context_key,
                lambda: _full_backend.build_fe_model_from_generated_geometry(
                    generated_geometry,
                    backend_config,
                ),
            )
            context_owned_session = True
            diagnostics.append(
                "Runtime analysis context reused the prepared model and factors."
                if context_reused
                else "Runtime analysis context captured a prepared model."
            )
        else:
            model = _full_backend.build_fe_model_from_generated_geometry(generated_geometry, backend_config)
        if not context_reused:
            _apply_material_curve_to_model(model, material_curve, material_properties)
            if analysis_context is not None and context_owned_session:
                analysis_context.capture_finalized_structure(model)
        imperfection_info = {}
        if not _wants_capacity_workflow(config):
            imperfection_info = _apply_runtime_imperfection(model, generated_geometry, geometry, config)
        elif config.imperfection_enabled:
            imperfection_info = {"status": "deferred", "kind": "capacity workflow imperfection"}
            diagnostics.append("Geometric imperfection input is deferred to the capacity workflow nonlinear model.")
        if imperfection_info.get("status") == "applied":
            diagnostics.append(
                "Applied "
                + str(imperfection_info.get("kind", "geometric"))
                + " imperfection, max offset "
                + str(round(float(imperfection_info.get("max_offset_m", 0.0)) * 1000.0, 4))
                + " mm."
            )
        elif imperfection_info:
            diagnostics.append("Imperfection input was not applied: " + str(imperfection_info.get("reason", imperfection_info.get("status", "unknown"))))
        if imported_fem_model is not None and getattr(model, "load_cases", None):
            load_case = model.load_cases[0]
            diagnostics.append("Using primary load case imported from the external FEM file.")
        elif abs(float(symmetric_pressure)) > 0.0:
            load_case = _full_backend.build_symmetric_load_case(None, model, backend_config)
            pressure_before, pressure_after = _filter_load_case_pressure_to_skin_shells(load_case, generated_geometry)
            if pressure_before > pressure_after:
                diagnostics.append(
                    "Applied generated pressure to plating skin only; skipped "
                    + str(pressure_before - pressure_after)
                    + " internal member shell pressure load(s)."
                )
        else:
            load_case = _full_backend.LoadCase("custom_fem_loads" if config.custom_load_bc_enabled else "anystructure_symmetric_load")
        selected_pressure_shells = _add_custom_panel_pressure_loads(model, load_case, generated_geometry, geometry, config)
        if selected_pressure_shells:
            diagnostics.append("Applied selected custom pressure to " + str(selected_pressure_shells) + " shell elements.")
        if include_imported_loads:
            _add_generated_axial_force(model, load_case, generated_geometry, float(config.axial_force_n))
            _add_generated_end_moments(model, load_case, generated_geometry, float(config.top_bottom_moment_nm))
            _add_generated_shear_force(model, load_case, generated_geometry, float(config.shear_force_n))
            _add_generated_torsional_moment(
                model, load_case, generated_geometry, float(config.torsional_moment_nm)
            )
        _add_custom_edge_loads(model, load_case, generated_geometry, config)
        if bool(config.follower_pressure):
            load_case.follower_pressure = True
            diagnostics.append(
                "Current-area follower pressure is active; nonlinear equilibrium includes "
                "the exact external-load tangent."
            )
        added_mass_summary = _apply_acceleration_and_masses(model, load_case, generated_geometry, geometry, config)
        accel_vec = added_mass_summary.get("acceleration_m_s2", [0.0, 0.0, 0.0])
        if any(abs(float(component)) > 0.0 for component in accel_vec):
            diagnostics.append(
                "Applied acceleration body load [{:g}, {:g}, {:g}] m/s2 over the structural and added mass.".format(
                    float(accel_vec[0]), float(accel_vec[1]), float(accel_vec[2])
                )
            )
        if added_mass_summary.get("added_mass_kg", 0.0) and not added_mass_summary.get("added_mass_nodes"):
            diagnostics.append("Added mass requested but no nodes matched the selected location; mass ignored.")
        elif added_mass_summary.get("added_mass_nodes"):
            diagnostics.append(
                "Applied " + str(added_mass_summary["added_mass_kg"]) + " kg added mass over "
                + str(added_mass_summary["added_mass_nodes"]) + " node(s) at " + str(config.added_mass_location)
                + "; added to the mass matrix (affects modal/dynamic response)."
            )
        linear_solve_started = time.perf_counter()
        phase_timings["model_and_load_preparation"] = float(
            linear_solve_started - model_preparation_started
        )
        if config.collision_enabled:
            return _run_collision_response(
                model,
                load_case,
                generated_geometry,
                geometry,
                config,
                diagnostics,
                status_callback=status_callback,
            )
        constraint_mode = _constraint_mode(config, geometry)
        if status_callback:
            if _wants_static_nonlinear_analysis(config) or _wants_capacity_workflow(config):
                status_callback("Solving reference linear static system...")
            else:
                status_callback("Solving linear static system...")
        if analysis_session is None and _can_reuse_linear_buckling_session(config):
            # Materials, geometry, supports and element state are now final
            # for this immutable linear/buckling sequence.  Keep one bounded
            # session so stiffness, constraints and direct-solver factors are
            # assembled once.  Nonlinear/capacity paths remain deliberately
            # excluded because they can change the live state.
            analysis_session = _backend_AnalysisSession(model)
        displacements, solver_info = _backend_solve_linear(
            model,
            load_case,
            solver_type=backend_config.solver_type,
            constraint_mode=constraint_mode,
            allow_unbalanced_free_free=_allow_unbalanced_free_free(config, geometry),
            session=analysis_session,
        )
        assembled_load_vector = solver_info.pop("_assembled_load_vector", None)
        load_resultant = (
            _backend_load_vector_resultant(model, assembled_load_vector)
            if assembled_load_vector is not None
            else _backend_load_case_resultant(model, load_case)
        )
        phase_timings["linear_system"] = float(
            time.perf_counter() - linear_solve_started
        )
    except Exception as exc:
        if analysis_context is not None and context_owned_session:
            analysis_context.invalidate()
            analysis_session = None
        elif analysis_session is not None:
            analysis_session.close()
        return LightweightFEMResult(
            status="production_failed",
            stress_max_pa=0.0,
            stress_p95_pa=0.0,
            displacement_max_m=0.0,
            diagnostics=tuple(diagnostics + ["Backend status: " + str(exc)]),
            solver_name="ANYsolver production FE mesh",
            visualization=_visualization_from_full_result(generated_geometry, model, None),
        )

    static_status = str((solver_info.get("convergence_info") or {}).get("status", "unknown"))

    # Extract the backend name from convergence_info -> backend -> backend
    backend_info = (solver_info.get("convergence_info") or {}).get("backend") or {}
    backend_name = str(backend_info.get("backend", "unknown backend"))
    diagnostics.append(f"Linear solver backend used: {backend_name}")

    if static_status != "converged":
        if analysis_context is not None and context_owned_session:
            analysis_context.invalidate()
            analysis_session = None
        elif analysis_session is not None:
            analysis_session.close()
        diagnostics.append("Static solve status: " + static_status)
        return LightweightFEMResult(
            status="static_failed",
            stress_max_pa=0.0,
            stress_p95_pa=0.0,
            displacement_max_m=0.0,
            diagnostics=tuple(diagnostics),
            mesh_info={"nodes": model.mesh.num_nodes, "shells": len(generated_geometry.get("shells", [])), "beams": len(generated_geometry.get("beams", []))},
            load_resultant=_resultant_dict(load_resultant),
            solver_name="ANYsolver production FE mesh",
            visualization=_visualization_from_full_result(generated_geometry, model, None),
        )

    recovery_started = time.perf_counter()
    (
        runtime_stresses_by_element,
        history_element_ids,
        recovery_provenance,
    ) = _runtime_display_stresses(model, displacements, None)
    recovery_evaluations += 1
    recovery_cache_key = (id(model), id(displacements), id(None))
    prestress_states, prestress_summary = _full_backend.recover_prestress_from_static_result(
        model,
        displacements,
        recovered_stresses=runtime_stresses_by_element,
        recovery_provenance=recovery_provenance,
    )
    phase_timings["recovery"] = float(time.perf_counter() - recovery_started)
    if imperfection_info:
        prestress_summary["imperfection_status"] = str(imperfection_info.get("status", ""))
        prestress_summary["imperfection_kind"] = str(imperfection_info.get("kind", ""))
        prestress_summary["imperfection_amplitude_m"] = float(imperfection_info.get("amplitude_m", 0.0) or 0.0)
        prestress_summary["imperfection_max_offset_m"] = float(imperfection_info.get("max_offset_m", 0.0) or 0.0)
        prestress_summary["imperfection_waves_a"] = float(imperfection_info.get("waves_a", 0.0) or 0.0)
        prestress_summary["imperfection_waves_b"] = float(imperfection_info.get("waves_b", 0.0) or 0.0)
    transient_summary: dict[str, object] = {}
    if config.custom_time_domain_enabled:
        if status_callback: status_callback("Solving custom time-domain pressure response...")
        try:
            transient_summary = _run_custom_time_domain_response(model, load_case, generated_geometry, geometry, config)
            if transient_summary:
                prestress_summary["custom_time_domain_status"] = str(transient_summary.get("status", ""))
                prestress_summary["custom_time_domain_pressure_pa"] = float(transient_summary.get("pressure_pa", 0.0) or 0.0)
                prestress_summary["custom_time_domain_selected_shells"] = float(transient_summary.get("selected_shells", 0.0) or 0.0)
                prestress_summary["custom_time_domain_peak_displacement_m"] = float(transient_summary.get("peak_displacement_m", 0.0) or 0.0)
                prestress_summary["custom_time_domain_peak_von_mises_pa"] = float(transient_summary.get("peak_von_mises_pa", 0.0) or 0.0)
                prestress_summary["custom_time_domain_result_interval_s"] = float(transient_summary.get("result_interval_s", 0.0) or 0.0)
                prestress_summary["custom_time_domain_saved_steps"] = float(transient_summary.get("saved_steps", 0.0) or 0.0)
                diagnostics.append(
                    "Custom time-domain response "
                    + str(transient_summary.get("status", "unknown"))
                    + "; selected shells "
                    + str(int(float(transient_summary.get("selected_shells", 0.0) or 0.0)))
                    + ", peak displacement "
                    + str(round(float(transient_summary.get("peak_displacement_m", 0.0) or 0.0) * 1000.0, 4))
                    + " mm."
                )
        except Exception as exc:
            prestress_summary["custom_time_domain_status"] = "failed"
            diagnostics.append("Custom time-domain solve failed: " + str(exc))
    prestress_summary["constraint_method"] = str(solver_info.get("constraint_method", ""))
    prestress_summary["constraint_mode"] = str(solver_info.get("constraint_mode", ""))
    nullspace_info = solver_info.get("nullspace_info") or {}
    if solver_info.get("constraint_method") == "transformation_fixed_plus_mpc_nullspace":
        convergence_info = solver_info.get("convergence_info") or {}
        prestress_summary["nullspace_projection"] = 1.0
        prestress_summary["nullspace_rank"] = float(convergence_info.get("nullspace_rank", nullspace_info.get("reduced_rank", 0)))
        prestress_summary["relative_rigid_body_load_imbalance"] = float(convergence_info.get("relative_rigid_body_load_imbalance", 0.0) or 0.0)
        prestress_summary["rigid_body_load_imbalance_norm"] = float(convergence_info.get("rigid_body_load_imbalance_norm", 0.0) or 0.0)
        diagnostics.append("Linear solve used rigid-body nullspace projection for the remaining unsupported rigid-body modes.")
        for warning in convergence_info.get("warnings", []) or []:
            diagnostics.append(str(warning))
    else:
        prestress_summary["nullspace_projection"] = 0.0
    if material_properties:
        prestress_summary["material_model"] = "DNV-RP-C208"
        prestress_summary["steel_grade"] = str(material_properties.get("grade", ""))
        prestress_summary["steel_thickness_class"] = str(material_properties.get("thickness_class", ""))
        prestress_summary["sigma_prop_pa"] = float(material_properties.get("sigma_prop", 0.0))
        prestress_summary["sigma_yield_pa"] = float(material_properties.get("sigma_yield", 0.0))
        prestress_summary["sigma_yield_2_pa"] = float(material_properties.get("sigma_yield_2", 0.0))
        prestress_summary["eps_p_y1"] = float(material_properties.get("eps_p_y1", 0.0))
        prestress_summary["eps_p_y2"] = float(material_properties.get("eps_p_y2", 0.0))
        prestress_summary["hardening_K_pa"] = float(material_properties.get("K", 0.0))
        prestress_summary["hardening_n"] = float(material_properties.get("n", 0.0))

    analysis_model = model
    capacity_workflow_result = None
    nonlinear_result = None
    nonlinear_factor = None
    nonlinear_static_factor = None
    nonlinear_static_result = None
    runtime_result_status = "ok"
    plastic_strain_by_node: dict[int, float] = {}
    if _wants_capacity_workflow(config):
        if status_callback: status_callback("Solving nonlinear capacity workflow...")
        if not hasattr(_full_backend, "run_nonlinear_capacity_workflow"):
            diagnostics.append("ANYsolver capacity workflow is unavailable in this backend.")
        else:
            try:
                selected_imperfection = None
                if config.imperfection_enabled:
                    selected_imperfection, _imperfection_metadata = _build_runtime_imperfection(model, generated_geometry, geometry, config)
                nonlinear_resource_config = _resource_config(config, generated_geometry, auto_assembly=True)
                workflow_config = _full_backend.CapacityWorkflowConfig(
                    num_buckling_modes=int(config.num_buckling_modes),
                    buckling_mode_number=_positive_int(config.capacity_buckling_mode_number, 1),
                    eigenmode_imperfection_amplitude=max(float(config.imperfection_amplitude_m or 0.0), 0.0) if config.imperfection_enabled else 0.0,
                    nonlinear_num_steps=_positive_int(config.nonlinear_steps, 12),
                    nonlinear_max_load_factor=max(float(config.nonlinear_max_load_factor), 1.0e-9),
                    nonlinear_max_iterations=_positive_int(config.nonlinear_max_iterations, 25),
                    nonlinear_tolerance=max(float(config.nonlinear_tolerance), 1.0e-12),
                    nonlinear_num_layers=_nonlinear_layer_count(config.nonlinear_layers),
                    nonlinear_convergence_settings=str(config.nonlinear_convergence_profile or "auto"),
                    nonlinear_resource_config=nonlinear_resource_config,
                    mesh_min_elements_per_half_wave=_positive_int(config.capacity_mesh_min_elements_per_half_wave, 4),
                    copy_model=True,
                )
                capacity_workflow_result = _full_backend.run_nonlinear_capacity_workflow(
                    model,
                    load_case,
                    imperfection=selected_imperfection,
                    config=workflow_config,
                    status_callback=status_callback,
                )
                nonlinear_static_result = capacity_workflow_result.nonlinear_result
                nonlinear_static_factor = float(nonlinear_static_result.capacity_estimate)
                buckling_result_from_workflow = capacity_workflow_result.buckling_result
                if getattr(buckling_result_from_workflow, "modes", None):
                    prestress_states = capacity_workflow_result.prestress_states
                if nonlinear_static_result.converged:
                    analysis_model = capacity_workflow_result.imperfect_model
                    displacements = np.asarray(nonlinear_static_result.displacements, dtype=float)
                    (
                        runtime_stresses_by_element,
                        history_element_ids,
                        recovery_provenance,
                    ) = _runtime_display_stresses(
                        analysis_model,
                        displacements,
                        nonlinear_static_result,
                    )
                    recovery_evaluations += 1
                    recovery_cache_key = (
                        id(analysis_model),
                        id(displacements),
                        id(nonlinear_static_result),
                    )
                    prestress_states, recovered = _full_backend.recover_prestress_from_static_result(
                        analysis_model,
                        displacements,
                        nonlinear_result=nonlinear_static_result,
                        recovered_stresses=runtime_stresses_by_element,
                        recovery_provenance=recovery_provenance,
                    )
                    prestress_summary.update(recovered)
                prestress_summary["capacity_workflow_status"] = str(capacity_workflow_result.status)
                prestress_summary["capacity_workflow_capacity_factor"] = float(capacity_workflow_result.capacity_factor)
                if capacity_workflow_result.critical_load_factor is not None:
                    prestress_summary["capacity_workflow_critical_load_factor"] = float(capacity_workflow_result.critical_load_factor)
                prestress_summary["capacity_workflow_mesh_status"] = str(capacity_workflow_result.mesh_adequacy.status)
                prestress_summary["capacity_workflow_elements_per_half_wave"] = float(capacity_workflow_result.mesh_adequacy.elements_per_half_wave)
                prestress_summary["nonlinear_static_status"] = str(nonlinear_static_result.status)
                prestress_summary["nonlinear_static_load_factor"] = nonlinear_static_factor
                prestress_summary["nonlinear_static_steps"] = float(len(nonlinear_static_result.steps))
                prestress_summary["nonlinear_static_kinematics"] = "von_karman"
                prestress_summary["nonlinear_static_total_iterations"] = float((nonlinear_static_result.info or {}).get("total_newton_iterations", 0.0))
                _nl_info = nonlinear_static_result.info or {}
                _nl_settings = _nl_info.get("convergence_settings", {}) if isinstance(_nl_info, dict) else {}
                prestress_summary["nonlinear_static_convergence_profile"] = str(_nl_settings.get("profile", config.nonlinear_convergence_profile)) if isinstance(_nl_settings, dict) else str(config.nonlinear_convergence_profile)
                prestress_summary["nonlinear_static_assembly_threads"] = float(_resource_assembly_threads(nonlinear_resource_config))
                prestress_summary["nonlinear_static_layers"] = float((nonlinear_static_result.info or {}).get("num_layers", _nonlinear_layer_count(config.nonlinear_layers)))
                if nonlinear_static_result.steps:
                    prestress_summary["nonlinear_static_max_plastic_strain"] = float(
                        max(step.max_equivalent_plastic_strain for step in nonlinear_static_result.steps)
                    )
                plastic_strain_by_node = _nodal_engineering_plastic_strain(analysis_model, nonlinear_static_result.element_states)
                diagnostics.append(
                    "ANYsolver capacity workflow "
                    + str(capacity_workflow_result.status)
                    + "; mesh mode adequacy "
                    + str(capacity_workflow_result.mesh_adequacy.status)
                    + "."
                )
                for warning in getattr(capacity_workflow_result.mesh_adequacy, "warnings", ()) or ():
                    diagnostics.append(str(warning))
            except Exception as exc:
                prestress_summary["capacity_workflow_status"] = "failed"
                diagnostics.append("ANYsolver capacity workflow failed: " + str(exc))

    if _wants_static_nonlinear_analysis(config) and capacity_workflow_result is None:
        nonlinear_control = _nonlinear_solution_control(config)
        static_kinematics = _effective_nonlinear_static_kinematics(config)
        if status_callback: status_callback("Solving nonlinear static system (" + nonlinear_control + ")...")
        if nonlinear_control == "arc length":
            solver_available = _backend_solve_static_arc_length is not None
            unavailable_message = "Arc-length nonlinear static solver is unavailable in this backend."
        else:
            solver_available = _backend_solve_static_nonlinear is not None
            unavailable_message = "Incremental geometric/material nonlinear static solver is unavailable in this backend."
        if not solver_available:
            diagnostics.append(unavailable_message)
            prestress_summary["nonlinear_static_status"] = "unavailable"
            runtime_result_status = "nonlinear_static_failed"
        else:
            try:
                nonlinear_resource_config = None
                # Structured per-increment progress for the GUI live graph:
                # the runtime status callback already carries dict payloads
                # for collision runs, so equilibrium-path points reuse it.
                nonlinear_progress = status_callback if callable(status_callback) else None
                if nonlinear_control == "arc length":
                    if bool(config.post_buckling_enabled):
                        diagnostics.append(
                            "Post-buckling continuation is enabled: arc-length tracing continues past the limit "
                            "point and stops automatically when the load factor falls to "
                            + str(round(min(max(float(config.post_buckling_stop_load_fraction or 0.5), 0.01), 0.99), 3))
                            + " of the recorded peak"
                            + (
                                " or the max displacement guard of "
                                + str(round(float(config.post_buckling_max_displacement_m), 4))
                                + " m trips"
                                if float(config.post_buckling_max_displacement_m or 0.0) > 0.0
                                else ""
                            )
                            + "."
                        )
                    nonlinear_static_result = _backend_solve_static_arc_length(
                        model,
                        load_case,
                        control=_arc_length_control(config),
                        max_iterations=_positive_int(config.nonlinear_max_iterations, 25),
                        tolerance=max(float(config.nonlinear_tolerance), 1.0e-12),
                        arc_tolerance=max(float(config.nonlinear_tolerance), 1.0e-12),
                        num_layers=_nonlinear_layer_count(config.nonlinear_layers),
                        kinematics=static_kinematics,
                        progress_callback=nonlinear_progress,
                    )
                else:
                    nonlinear_resource_config = _resource_config(config, generated_geometry, auto_assembly=True)
                    nonlinear_static_result = _backend_solve_static_nonlinear(
                        model,
                        load_case,
                        max_load_factor=max(float(config.nonlinear_max_load_factor), 1.0e-9),
                        num_steps=_positive_int(config.nonlinear_steps, 12),
                        max_iterations=_positive_int(config.nonlinear_max_iterations, 25),
                        tolerance=max(float(config.nonlinear_tolerance), 1.0e-12),
                        num_layers=_nonlinear_layer_count(config.nonlinear_layers),
                        convergence_settings=str(config.nonlinear_convergence_profile or "auto"),
                        resource_config=nonlinear_resource_config,
                        fracture_config=_runtime_fracture_config(config),
                        kinematics=static_kinematics,
                        status_callback=status_callback,
                        progress_callback=nonlinear_progress,
                    )
                nonlinear_static_factor = float(nonlinear_static_result.capacity_estimate)
                _nl_info = nonlinear_static_result.info or {}
                prestress_summary["nonlinear_static_control"] = nonlinear_control
                prestress_summary["nonlinear_static_status"] = str(nonlinear_static_result.status)
                prestress_summary["nonlinear_static_load_factor"] = nonlinear_static_factor
                prestress_summary["nonlinear_static_steps"] = float(len(nonlinear_static_result.steps))
                prestress_summary["nonlinear_static_kinematics"] = str(_nl_info.get("kinematics", static_kinematics)) if isinstance(_nl_info, dict) else static_kinematics
                prestress_summary["nonlinear_static_total_iterations"] = float(_nl_info.get("total_newton_iterations", 0.0)) if isinstance(_nl_info, dict) else 0.0
                _nl_settings = _nl_info.get("convergence_settings", {}) if isinstance(_nl_info, dict) else {}
                prestress_summary["nonlinear_static_convergence_profile"] = str(_nl_settings.get("profile", config.nonlinear_convergence_profile)) if isinstance(_nl_settings, dict) else str(config.nonlinear_convergence_profile)
                prestress_summary["nonlinear_static_assembly_threads"] = float(_resource_assembly_threads(nonlinear_resource_config))
                prestress_summary["nonlinear_static_layers"] = float((nonlinear_static_result.info or {}).get("num_layers", _nonlinear_layer_count(config.nonlinear_layers)))
                fracture_summary_data = (nonlinear_static_result.info or {}).get("fracture_summary", {})
                if isinstance(fracture_summary_data, dict):
                    prestress_summary["fracture_enabled"] = 1.0 if config.fracture_enabled else 0.0
                    prestress_summary["fracture_deleted_count"] = float(fracture_summary_data.get("deleted_count", 0.0) or 0.0)
                    prestress_summary["fracture_max_utilization"] = float(fracture_summary_data.get("max_utilization", 0.0) or 0.0)
                    prestress_summary["fracture_first_deletion_load_factor"] = float(fracture_summary_data.get("first_deletion_load_factor", 0.0) or 0.0)
                if nonlinear_control == "arc length":
                    prestress_summary["nonlinear_static_peak_load_factor"] = float(getattr(nonlinear_static_result, "peak_load_factor", nonlinear_static_factor))
                    peak_step = getattr(nonlinear_static_result, "peak_step_index", None)
                    if peak_step is not None:
                        prestress_summary["nonlinear_static_peak_step"] = float(peak_step)
                    arc_settings = _nl_info.get("control", {}) if isinstance(_nl_info, dict) else {}
                    if isinstance(arc_settings, dict):
                        prestress_summary["nonlinear_static_initial_arc_increment"] = float(arc_settings.get("initial_load_increment", 0.0) or 0.0)
                if nonlinear_static_result.steps:
                    prestress_summary["nonlinear_static_max_plastic_strain"] = float(
                        max(step.max_equivalent_plastic_strain for step in nonlinear_static_result.steps)
                )
                plastic_strain_by_node = _nodal_engineering_plastic_strain(model, nonlinear_static_result.element_states)
                diagnostics.append(
                    "Ran "
                    + nonlinear_control
                    + " geometric/material nonlinear static solve: "
                    + str(nonlinear_static_result.status)
                    + "."
                )
                if nonlinear_static_result.converged:
                    displacements = np.asarray(nonlinear_static_result.displacements, dtype=float)
                    (
                        runtime_stresses_by_element,
                        history_element_ids,
                        recovery_provenance,
                    ) = _runtime_display_stresses(
                        model,
                        displacements,
                        nonlinear_static_result,
                    )
                    recovery_evaluations += 1
                    recovery_cache_key = (
                        id(model),
                        id(displacements),
                        id(nonlinear_static_result),
                    )
                    prestress_states, recovered = _full_backend.recover_prestress_from_static_result(
                        model,
                        displacements,
                        nonlinear_result=nonlinear_static_result,
                        recovered_stresses=runtime_stresses_by_element,
                        recovery_provenance=recovery_provenance,
                    )
                    recovered.update({key: value for key, value in prestress_summary.items() if str(key).startswith("nonlinear_static")})
                    for key in (
                        "constraint_method",
                        "constraint_mode",
                        "nullspace_projection",
                        "nullspace_rank",
                        "material_model",
                        "steel_grade",
                        "steel_thickness_class",
                        "sigma_prop_pa",
                        "sigma_yield_pa",
                        "sigma_yield_2_pa",
                        "eps_p_y1",
                        "eps_p_y2",
                        "hardening_K_pa",
                        "hardening_n",
                        "fracture_enabled",
                        "fracture_deleted_count",
                        "fracture_max_utilization",
                        "fracture_first_deletion_load_factor",
                    ):
                        if key in prestress_summary:
                            recovered[key] = prestress_summary[key]
                    prestress_summary = recovered
                else:
                    runtime_result_status = "nonlinear_static_failed"
            except Exception as exc:
                prestress_summary["nonlinear_static_status"] = "failed"
                runtime_result_status = "nonlinear_static_failed"
                diagnostics.append("Incremental nonlinear static solver failed: " + str(exc))

    if _wants_tangent_stability_analysis(config) and capacity_workflow_result is None:
        if _backend_solve_nonlinear_limit is None:
            diagnostics.append("Nonlinear load-step solver is unavailable in this backend.")
        else:
            try:
                nonlinear_result = _backend_solve_nonlinear_limit(
                    model,
                    load_case,
                    prestress_states,
                    max_load_factor=3.0,
                    num_steps=12,
                    stability_tolerance=1.0e-3,
                    stop_at_limit=True,
                )
                nonlinear_factor = nonlinear_result.critical_load_factor_estimate
                if nonlinear_factor is None:
                    nonlinear_factor = nonlinear_result.last_load_factor if nonlinear_result.steps else None
                prestress_summary["nonlinear_status"] = nonlinear_result.status
                if nonlinear_factor is not None:
                    prestress_summary["nonlinear_limit_factor"] = float(nonlinear_factor)
                prestress_summary["nonlinear_steps"] = len(nonlinear_result.steps)
                diagnostics.append("Ran nonlinear tangent-stability load stepping: " + str(nonlinear_result.status) + ".")
                if _wants_nonlinear_analysis(config) and nonlinear_result.converged:
                    displacements = np.asarray(nonlinear_result.final_displacements, dtype=float)
                    recovery_cache_key = None
            except Exception as exc:
                diagnostics.append("Nonlinear load-step solver failed: " + str(exc))
    if (
        _wants_eigenvalue_buckling(config)
        and geometry.get("geometry") == "cylinder"
        and config.include_end_lids
        and _add_cylinder_buckling_gauge(model, generated_geometry)
    ):
        diagnostics.append("Applied buckling-only rigid-body gauge constraints to the lid center nodes.")
    buckling_kwargs = _buckling_solver_kwargs(config)
    if analysis_session is not None:
        buckling_kwargs["session"] = analysis_session
    buckling_started = time.perf_counter()
    try:
        if capacity_workflow_result is not None:
            buckling_result = capacity_workflow_result.buckling_result
        elif _wants_eigenvalue_buckling(config):
            buckling_result = _backend_solve_buckling(model, prestress_states, num_modes=int(config.num_buckling_modes), **buckling_kwargs)
        else:
            # Dummy result if buckling is explicitly skipped by runtime path
            class DummyBucklingResult:
                modes = ()
                failed = False
                status = "skipped by runtime path"
                diagnostics = ()
            buckling_result = DummyBucklingResult()
        if (
            _wants_eigenvalue_buckling(config)
            and not buckling_result.modes
            and geometry.get("geometry") == "cylinder"
            and abs(float(effective_pressure)) > 0.0
        ):
            pressure_states = _cylinder_pressure_prestress_states(
                model,
                float(effective_pressure) * float(config.load_scale),
                _positive(geometry.get("radius_m", generated_geometry.get("radius_m", 1.0)), 1.0),
            )
            if pressure_states:
                pressure_buckling_result = _backend_solve_buckling(model, pressure_states, num_modes=int(config.num_buckling_modes), **buckling_kwargs)
                if pressure_buckling_result.modes:
                    buckling_result = pressure_buckling_result
                    diagnostics.append("Buckling modes use equivalent external-pressure membrane prestress because the full mixed prestress returned no positive modes.")
    finally:
        if analysis_session is not None and not context_owned_session:
            session_diagnostics = analysis_session.diagnostics()
            prestress_summary["analysis_session"] = session_diagnostics
            diagnostics.append(
                "Reused one analysis session across linear prestress and "
                "eigenvalue buckling."
            )
            analysis_session.close()
            analysis_session = None
    phase_timings["buckling"] = float(time.perf_counter() - buckling_started)
    if capacity_workflow_result is None:
        _record_buckling_mesh_adequacy(model, buckling_result, config, prestress_summary, diagnostics)
    if _wants_nonlinear_buckling(config) and nonlinear_static_factor is not None and float(nonlinear_static_factor) > 0.0:
        buckling_factors = (float(nonlinear_static_factor),)
        diagnostics.append("Buckling factors report the incremental nonlinear static load-factor estimate for the selected buckling mode.")
    elif _wants_nonlinear_buckling(config) and nonlinear_factor is not None and float(nonlinear_factor) > 0.0:
        buckling_factors = (float(nonlinear_factor),)
        diagnostics.append("Buckling factors report the nonlinear limit-load estimate for the selected buckling mode.")
    else:
        buckling_factors = tuple(float(mode.load_factor) for mode in buckling_result.modes)
    prestress_summary["runtime_solver"] = _normalized_choice(config.runtime_solver, "stepwise")
    prestress_summary["allow_unbalanced_free_free"] = 1.0 if _allow_unbalanced_free_free(config, geometry) else 0.0
    prestress_summary["recovery_history_mode"] = _normalized_choice(config.recovery_history_mode, "full")
    prestress_summary["recovery_threads"] = float(max(int(config.recovery_threads or 0), 0))
    prestress_summary["memory_limit_mb"] = float(max(float(config.memory_limit_mb or 0.0), 0.0))
    prestress_summary["buckling_solver_status"] = str(getattr(buckling_result, "solver_status", ""))
    prestress_summary["buckling_modes_returned"] = float(len(getattr(buckling_result, "modes", []) or []))
    prestress_summary["buckling_repeated_groups"] = float(((getattr(buckling_result, "diagnostics", {}) or {}).get("num_repeated_mode_groups", 0)) or 0)
    buckling_diagnostics = dict(
        getattr(buckling_result, "diagnostics", {}) or {}
    )
    prestress_summary["buckling_performance"] = {
        "solver": str(buckling_diagnostics.get("solver", "")),
        "phase_timings_seconds": dict(
            buckling_diagnostics.get("phase_timings_seconds", {}) or {}
        ),
        "matrix_diagnostics": dict(
            buckling_diagnostics.get("matrix_diagnostics", {}) or {}
        ),
        "elastic_inverse": bool(
            buckling_diagnostics.get("elastic_inverse", False)
        ),
        "elastic_inverse_factorization": dict(
            buckling_diagnostics.get("elastic_inverse_factorization", {}) or {}
        ),
        "elastic_inverse_cache": dict(
            buckling_diagnostics.get("elastic_inverse_cache", {}) or {}
        ),
        "elastic_inverse_persistence": str(
            buckling_diagnostics.get("elastic_inverse_persistence", "")
        ),
    }
    prestress_summary["buckling_shift_load_factor"] = float(config.buckling_shift_load_factor or 0.0)
    load_factor_range = _buckling_load_factor_range(config)
    if load_factor_range is not None:
        prestress_summary["buckling_min_load_factor"] = 0.0 if load_factor_range[0] is None else float(load_factor_range[0])
        prestress_summary["buckling_max_load_factor"] = 0.0 if load_factor_range[1] is None else float(load_factor_range[1])
    prestress_summary["buckling_allow_dense_fallback"] = 1.0 if bool(config.buckling_allow_dense_fallback) else 0.0
    result_preparation_started = time.perf_counter()
    stress_percentile = min(max(float(config.stress_percentile), 0.0), 100.0)
    final_recovery_key = (
        id(analysis_model),
        id(displacements),
        id(nonlinear_static_result),
    )
    if recovery_cache_key != final_recovery_key:
        (
            runtime_stresses_by_element,
            history_element_ids,
            recovery_provenance,
        ) = _runtime_display_stresses(
            analysis_model,
            displacements,
            nonlinear_static_result,
        )
        recovery_evaluations += 1
    prestress_summary["stress_recovery"] = recovery_provenance
    for warning in recovery_provenance.get("warnings", ()) or ():
        diagnostics.append("Stress recovery: " + str(warning))
    if history_element_ids and material_curve is not None:
        # Committed elastoplastic states (shell layers and beam fiber
        # sections) respect the material curve; any remaining elements only
        # have elastic recovery and must not dominate the reported stresses.
        stress_stats = _stress_statistics_from_stresses(
            {
                eid: stress
                for eid, stress in runtime_stresses_by_element.items()
                if eid in history_element_ids
            },
            stress_percentile,
        )
        elastic_member_stats = _stress_statistics_from_stresses(
            {
                eid: stress
                for eid, stress in runtime_stresses_by_element.items()
                if eid not in history_element_ids
            },
            stress_percentile,
        )
        mixed_reconstruction_stats = _stress_statistics_from_stresses(
            {
                eid: stress
                for eid, stress in runtime_stresses_by_element.items()
                if eid in history_element_ids
            },
            stress_percentile,
            component="mixed_reconstruction_von_mises",
        )
        prestress_summary["elastic_member_peak_von_mises_pa"] = float(elastic_member_stats["max"])
        prestress_summary["mixed_reconstruction_peak_von_mises_pa"] = float(
            mixed_reconstruction_stats["max"]
        )
        diagnostics.append(
            "Material-nonlinear equivalent stresses are recovered from committed "
            "elastoplastic states (shell in-plane layers and beam fibers) and respect "
            "the material curve; transverse shear and torsion remain separately "
            "labelled elastic reconstructions."
        )
        if mixed_reconstruction_stats["max"] > stress_stats["max"] * (
            1.0 + 100.0 * np.finfo(float).eps
        ):
            diagnostics.append(
                "Model-scope warning: the mixed stress diagnostic that combines "
                "committed material history with elastic transverse shear/torsion reaches "
                f"{mixed_reconstruction_stats['max'] / 1.0e6:.0f} MPa; it is retained "
                "for review but excluded from material-curve equivalent-stress statistics. "
                "The corresponding shear/torsion modes are outside the current plastic "
                "return map and must not be interpreted as plastically redistributed."
            )
        if elastic_member_stats["max"] > 0.0:
            diagnostics.append(
                "Some members carry only elastic stress recovery; their peak von Mises "
                f"{elastic_member_stats['max'] / 1.0e6:.0f} MPa is a fictitious elastic value "
                "and is reported separately from the statistics."
            )
    else:
        stress_stats = _stress_statistics_from_stresses(runtime_stresses_by_element, stress_percentile)
    visualization = _visualization_from_full_result(
        generated_geometry,
        analysis_model,
        displacements,
        stresses_by_element=runtime_stresses_by_element,
    )
    visualization["stress_recovery_provenance"] = recovery_provenance
    if visualization:
        visualization["fea_result_import"] = _fea_result_import_payload(
            generated_geometry,
            analysis_model,
            runtime_stresses_by_element,
        )
    if plastic_strain_by_node:
        plastic_visualization = _visualization_from_full_result(
            generated_geometry,
            analysis_model,
            displacements,
            scalar_by_node=plastic_strain_by_node,
            scalar_label="equiv. engineering plastic strain [-]",
        )
        if plastic_visualization:
            visualization["plastic_strain"] = plastic_visualization.get("stress_pa", ())
            visualization["plastic_strain_label"] = "equiv. engineering plastic strain [-]"
    if isinstance(transient_summary, dict) and transient_summary.get("history"):
        visualization["time_domain"] = transient_summary.get("history")
    mode_visualization_started = time.perf_counter()
    visualization["buckling_modes"] = _buckling_mode_visualizations(
        generated_geometry,
        model,
        buckling_result,
    )
    phase_timings["mode_visualization"] = float(
        time.perf_counter() - mode_visualization_started
    )
    phase_timings["result_preparation_and_visualization"] = float(
        time.perf_counter() - result_preparation_started
    )

    if not prestress_states:
        diagnostics.append("Prestress recovery returned no element states.")
    if not buckling_factors:
        if runtime_result_status == "ok":
            diagnostics.append("Static solve converged; no positive buckling modes were returned for this load state.")
        else:
            diagnostics.append(
                "The reference linear static solve converged, but the requested nonlinear static solve did not complete."
            )

    if analysis_context is not None and context_owned_session:
        try:
            analysis_context.finalize(model)
        except Exception as exc:
            return LightweightFEMResult(
                status="production_failed",
                stress_max_pa=0.0,
                stress_p95_pa=0.0,
                displacement_max_m=0.0,
                diagnostics=tuple(
                    diagnostics
                    + ["Runtime analysis context finalization failed: " + str(exc)]
                ),
                solver_name="ANYsolver production FE mesh",
            )
        prestress_summary["runtime_analysis_context"] = analysis_context.diagnostics()
    phase_timings["total"] = float(time.perf_counter() - runtime_started)
    performance_assembly = dict(solver_info.get("assembly", {}) or {})
    performance_assembly.pop("element_times", None)
    for component_name in ("stiffness", "load", "mass"):
        component = performance_assembly.get(component_name)
        if isinstance(component, dict):
            component = dict(component)
            component.pop("element_times", None)
            performance_assembly[component_name] = component
    prestress_summary["performance"] = {
        "phase_timings_seconds": dict(phase_timings),
        "linear_solver_phase_timings_seconds": dict(
            solver_info.get("phase_timings_seconds", {}) or {}
        ),
        "assembly": performance_assembly,
        "thread_policy": dict(solver_info.get("thread_policy", {}) or {}),
        "backend": backend_name,
        "prepared_model_cache_hit": bool(context_reused),
        "shared_recovery_evaluations": int(recovery_evaluations),
    }

    return LightweightFEMResult(
        status=runtime_result_status,
        stress_max_pa=float(stress_stats["max"]),
        stress_p95_pa=float(stress_stats["percentile"]),
        displacement_max_m=_max_translation(analysis_model, displacements),
        buckling_factors=buckling_factors,
        # Raw eigenmode objects (mode_number/load_factor/mode_shape) so the
        # mode-shape imperfection workflow can perturb the mesh.
        buckling_modes=list(getattr(buckling_result, "modes", []) or []),
        diagnostics=tuple(diagnostics),
        mesh_info={
            "nodes": int(model.mesh.num_nodes),
            "shells": int(len(generated_geometry.get("shells", []))),
            "beams": int(len(generated_geometry.get("beams", []))),
            "rigid_lids": int(len(generated_geometry.get("rigid_lids", []))),
            **_mesh_size_diagnostics(generated_geometry),
        },
        prestress_summary=dict(prestress_summary or {}),
        load_resultant=_resultant_dict(load_resultant),
        visualization=visualization,
        solver_name="ANYsolver production FE mesh",
    )


def _run_flat_panel(geometry: dict, config: LightweightFEMConfig, status_callback=None) -> LightweightFEMResult:
    if status_callback: status_callback("Running basic lightweight analytic FEM approximation...")
    length = _positive(geometry.get("length_m", 1.0), 1.0)
    width = _positive(geometry.get("width_m", 1.0), 1.0)
    thickness = _positive(geometry.get("thickness_m", 0.01), 0.01)
    pressure = abs(float(_effective_pressure_pa(config)) * float(config.load_scale))
    short_span = min(length, width)

    pressure_bending = 0.125 * pressure * short_span**2 / max(thickness**2, 1.0e-12)
    direct_pressure = pressure
    stress = max(pressure_bending, direct_pressure)
    if config.include_stiffeners and geometry.get("has_stiffener"):
        stress *= 0.72
    if config.include_girders and geometry.get("has_girder"):
        stress *= 0.82

    D = config.elastic_modulus_pa * thickness**3 / (12.0 * (1.0 - config.poisson_ratio**2))
    displacement = pressure * short_span**4 / max(64.0 * D, 1.0e-12)
    sigma_cr = _plate_critical_stress(config.elastic_modulus_pa, config.poisson_ratio, thickness, short_span)
    buckling_factor = sigma_cr / max(stress, 1.0)
    div = _mesh_divisions(config.mesh_fidelity)
    spacing_cap = _positive_spacing(geometry.get("stiffener_spacing_m", 0.0)) if geometry.get("has_stiffener") else 0.0
    if spacing_cap > 0.0:
        div = max(div, int(math.ceil(max(length, width) / spacing_cap)))
    area = length * width
    return LightweightFEMResult(
        status="ok",
        stress_max_pa=stress,
        stress_p95_pa=0.92 * stress,
        displacement_max_m=displacement,
        buckling_factors=_sorted_positive_factors(buckling_factor, config.num_buckling_modes),
        diagnostics=("ANYsolver compact solver: flat shell/beam idealization.",),
        mesh_info={"nodes": (div + 1) ** 2, "shells": div * div, "beams": int(bool(geometry.get("has_stiffener"))) + int(bool(geometry.get("has_girder")))},
        prestress_summary={
            "membrane_compression_pa": pressure,
            "bending_stress_pa": pressure_bending,
            "critical_stress_pa": sigma_cr,
        },
        load_resultant={"force_n": (0.0, 0.0, pressure * area), "moment_nm": (0.0, 0.0, 0.0)},
        visualization=_flat_visualization(length, width, displacement, stress, div),
    )


def _run_cylinder(geometry: dict, config: LightweightFEMConfig, status_callback=None) -> LightweightFEMResult:
    if status_callback: status_callback("Running basic cylinder analytic FEM approximation...")
    radius = _positive(geometry.get("radius_m", 1.0), 1.0)
    length = _positive(geometry.get("length_m", 1.0), 1.0)
    thickness = _positive(geometry.get("thickness_m", 0.01), 0.01)
    pressure = abs(float(_effective_pressure_pa(config)) * float(config.load_scale))

    hoop = pressure * radius / thickness
    axial = hoop / 2.0
    von_mises = math.sqrt(max(hoop**2 - hoop * axial + axial**2, 0.0))
    if config.include_stiffeners and geometry.get("has_stiffener"):
        von_mises *= 0.82
    if config.include_girders and geometry.get("has_girder"):
        von_mises *= 0.90

    displacement = pressure * radius**2 / max(config.elastic_modulus_pa * thickness, 1.0e-12)
    pcr = _cylinder_critical_pressure(config.elastic_modulus_pa, config.poisson_ratio, thickness, radius)
    buckling_factor = pcr / max(pressure, 1.0)
    div = _mesh_divisions(config.mesh_fidelity)
    spacing_cap = _positive_spacing(geometry.get("stiffener_spacing_m", 0.0)) if geometry.get("has_stiffener") else 0.0
    if spacing_cap > 0.0:
        div = max(div, int(math.ceil((2.0 * math.pi * radius) / spacing_cap)))
    axial_div = max(int(length / max(radius, 1.0e-9) * div / 4), 1)
    if spacing_cap > 0.0:
        axial_div = max(axial_div, int(math.ceil(length / spacing_cap)))
    area = 2.0 * math.pi * radius * length
    return LightweightFEMResult(
        status="ok",
        stress_max_pa=von_mises,
        stress_p95_pa=0.90 * von_mises,
        displacement_max_m=displacement,
        buckling_factors=_sorted_positive_factors(buckling_factor, config.num_buckling_modes),
        diagnostics=("ANYsolver compact solver: cylindrical shell membrane idealization.",),
        mesh_info={"nodes": div * (axial_div + 1), "shells": div * axial_div, "beams": int(bool(geometry.get("has_stiffener"))) + int(bool(geometry.get("has_girder")))},
        prestress_summary={
            "hoop_stress_pa": hoop,
            "axial_stress_pa": axial,
            "critical_pressure_pa": pcr,
        },
        load_resultant={"force_n": (0.0, 0.0, pressure * area), "moment_nm": (0.0, 0.0, 0.0)},
        visualization=_cylinder_visualization(radius, length, displacement, von_mises, div, axial_div),
    )

def run_lightweight_fem(
    geometry: NormalizedGeometry,
    config: LightweightFEMConfig,
    status_callback: StatusCallback | None = None,
) -> LightweightFEMResult:
    """Run the local lightweight solver for a normalized geometry summary."""

    if status_callback: status_callback("Running basic lightweight analytic FEM approximation...")
    if geometry.get("geometry") == "cylinder":
        return _run_cylinder(geometry, config, status_callback=status_callback)
    return _run_flat_panel(geometry, config, status_callback=status_callback)

def full_backend_available() -> bool:
    """Return whether the ANYsolver backend is available."""

    return _full_backend is not None


def full_backend_api() -> ModuleType:
    """Return the ANYsolver backend module for future integration."""

    if _full_backend is None:
        raise RuntimeError("The ANYsolver backend is not available.")
    return _full_backend


def warm_fe_solver_kernels(
    shell_orders: Sequence[str] = ("S4", "Q8", "Q8R"),
    *,
    include_nonlinear_impact: bool = False,
    include_nonlinear_static: bool = False,
) -> dict[str, object]:
    """Warm optional compiled FE backend kernels for runtime use."""

    if _backend_warm_fe_solver_kernels is None:
        return {
            "status": "backend_unavailable",
            "shell_orders": {},
            "message": "The ANYsolver backend warmup helper is not available.",
        }
    return _backend_warm_fe_solver_kernels(
        shell_orders,
        include_nonlinear_impact=include_nonlinear_impact,
        include_nonlinear_static=include_nonlinear_static,
    )
