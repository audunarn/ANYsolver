"""One bounded development diagnostic for the existing simultaneous-history test."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

import psutil


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ATTEMPT = HERE / "installed-v4-a1"
PYTHON = Path("C:/Python/Python314/python.exe")
CAP_SECONDS = 120.0
CAP_BYTES = 2 * 1024**3
CASE = "tests/test_stiffened_shell_physical_fibre_j2_history.py::test_two_stiffener_simultaneous_history_restart_rebase_and_atomicity"


def main() -> None:
    ATTEMPT.mkdir(exist_ok=False)
    child_code = (
        "import os,sys,json;"
        f"sys.path[:0]=[{str(ROOT / '.development/s3-v2d-surface-recovery-20261008/site')!r},{str(ROOT)!r},{str(ROOT / 'tests')!r}];"
        "import psutil;psutil.Process().cpu_affinity([0]);"
        "import numpy,numba,threadpoolctl;"
        "print(json.dumps({'affinity':psutil.Process().cpu_affinity(),"
        "'jit_disabled':numba.config.DISABLE_JIT,"
        "'numba_threads':numba.get_num_threads(),"
        "'threadpools':threadpoolctl.threadpool_info()}),flush=True);"
        "import anysolver;assert anysolver.__file__.replace(chr(92),'/').startswith('C:/Github/ANYsolver/.perf2-worktrees/stiffened-rev8-20261008/.development/s3-v2d-surface-recovery-20261008/site/anysolver');"
        "print(json.dumps({'anysolver_installed':anysolver.__file__}),flush=True);"
        "import pytest;"
        f"raise SystemExit(pytest.main({['-x', '-q', '-p', 'no:cacheprovider', '-o', 'addopts=', '--basetemp='+str(ATTEMPT/'pytest-temp'), '--junitxml='+str(ATTEMPT/'junit.xml'), CASE]!r}))"
    )
    cmd = [str(PYTHON), "-I", "-B", "-c", child_code]
    env = os.environ.copy()
    env.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1",
               NUMEXPR_NUM_THREADS="1", NUMBA_DISABLE_JIT="1", NUMBA_NUM_THREADS="1",
               VECLIB_MAXIMUM_THREADS="1", BLIS_NUM_THREADS="1",
               PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTHONDONTWRITEBYTECODE="1")
    for name in ("PYTEST_ADDOPTS", "PYTEST_PLUGINS", "PYTHONPATH"):
        env.pop(name, None)
    started = time.perf_counter_ns()
    peak = 0
    status = "started"
    with (ATTEMPT / "stdout.log").open("wb") as out, (ATTEMPT / "stderr.log").open("wb") as err:
        child = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=out, stderr=err)
        process = psutil.Process(child.pid)
        try:
            while child.poll() is None:
                tree = [process, *process.children(recursive=True)]
                try:
                    peak = max(peak, sum(item.memory_info().rss for item in tree))
                except psutil.NoSuchProcess:
                    pass
                if peak > CAP_BYTES:
                    status = "memory_limit"
                    break
                if (time.perf_counter_ns() - started) / 1e9 >= CAP_SECONDS:
                    status = "timeout"
                    break
                time.sleep(.05)
            if status != "started":
                for item in reversed([process, *process.children(recursive=True)]):
                    try:
                        item.kill()
                    except psutil.NoSuchProcess:
                        pass
                child.wait(timeout=2)
            else:
                status = "passed" if child.returncode == 0 else "failed"
        finally:
            elapsed = (time.perf_counter_ns() - started) / 1e9
            receipt = {
                "status": status, "exit_code": child.returncode,
                "process_wall_seconds": elapsed, "cap_seconds": CAP_SECONDS,
                "peak_tree_rss_bytes": peak, "command": cmd, "cwd": str(ROOT),
                "case": CASE, "qualification": False,
                "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "test_sha256": hashlib.sha256((ROOT / CASE.split("::")[0]).read_bytes()).hexdigest(),
            }
            (ATTEMPT / "receipt.json").write_text(
                json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": status, "wall": elapsed, "peak": peak,
                      "evidence": str(ATTEMPT)}))
    if status != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
