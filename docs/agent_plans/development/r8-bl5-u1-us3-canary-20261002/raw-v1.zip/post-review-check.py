from pathlib import Path
import hashlib, importlib.util, json, re
root = Path(__file__).resolve().parent
source = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/scripts/r8_bl5_ccx_user_canary.py')
spec = importlib.util.spec_from_file_location('canary_readcheck', source)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
stdout = (root/'stdout.log').read_text()
stderr = (root/'stderr.log').read_text()
assert not stderr.strip() and 'Job finished' in stdout
assert re.search(r'\b(?:warning|error|fatal)\b', stdout+stderr, re.IGNORECASE) is None
result = json.loads(json.dumps(m.parse(root/'canary.dat', m.rows())))
original = json.loads((root/'result.json').read_text())
assert all(original[k] == v for k, v in result.items())
text, meta = m.deck()
assert text.encode('ascii') == (root/'canary.inp').read_bytes()
cpus = [int(v) for v in re.findall(r'up to\s+(\d+)\s+cpu', stdout, re.IGNORECASE)]
cpus += [int(v) for v in re.findall(r'\bUsing\s+(\d+)\s+cpu', stdout, re.IGNORECASE)]
assert cpus and max(cpus) == 1
record = dict(delivered_runner_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    executed_runner_sha256=hashlib.sha256((root/'runner.py').read_bytes()).hexdigest(),
    unchanged_deck=True, saved_parser_result_identical=True, saved_logs_pass_stricter_warning_guard=True,
    effective_cpu_reports=cpus, numerical_rerun=False, sampled_memory_available=False,
    historical_zero_sample_is_not_measured_peak=True,
    readcheck_initial_failure='JSON object integer keys serialize as strings; compared after JSON normalization')
(root/'post-review-check.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
