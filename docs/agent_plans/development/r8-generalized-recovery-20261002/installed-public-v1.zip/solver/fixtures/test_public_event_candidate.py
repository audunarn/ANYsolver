from pathlib import Path
import json
import numpy as np
import pytest
from anysolver import stiffened_shell as ss
from test_stiffened_shell_bl5_coupled_material import coupled
from test_stiffened_shell_bl5_material import make
from test_stiffened_shell_bl5_finite import _action

def test_public_event_candidate(request):
    owner=make(request,coupled())
    owner.restore((Path(__file__).parent/'force-seed.bin').read_bytes())
    kw=dict(displacement_control=ss.DisplacementControl('beam',105,2,
        trial_policy=ss.GENERALIZED_BRANCH_EVENT_TRIAL),max_iterations=20,max_backtracks=12)
    first=owner.solve(_action(-15.625),(-66e-6,),**kw)
    raw=owner.checkpoint()
    restored=make(request,coupled());restored.restore(raw)
    assert restored.checkpoint()==raw
    final=owner.solve(_action(-15.625),(-68e-6,),**kw)
    repeated=restored.solve(_action(-15.625),(-68e-6,),**kw)
    assert owner.checkpoint()==restored.checkpoint()
    assert final.trial_policy==ss.GENERALIZED_BRANCH_EVENT_TRIAL
    assert final.event_cell_evaluations>first.event_cell_evaluations
    assert final.free_equilibrium_ratio<=1e-8 and final.constraint_max<=1e-9
    dof=owner._shell_count+6*owner._beam_index[105]+2
    np.testing.assert_allclose(final.applied_dead_load[dof],-487.09113664022675,rtol=1e-9,atol=1e-8)
    (Path.cwd()/'public-candidate.json').write_text(json.dumps(dict(
        status=final.status,target=final.target,amplitude=final.amplitude,
        load=float(final.applied_dead_load[dof]),equilibrium=final.free_equilibrium_ratio,
        gap=final.constraint_max,event_cell_evaluations=final.event_cell_evaluations,
        first_event_cell_evaluations=first.event_cell_evaluations,restart_exact=True)))
