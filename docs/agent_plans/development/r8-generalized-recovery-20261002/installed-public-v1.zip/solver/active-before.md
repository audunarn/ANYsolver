# B3-GE / E4-PL / B2 — active state, 2 October 2026

## Authority and restart

Revision8 plan/goal in ../b3-ge-e4-pl-coupling remains active. Full G0–G6,
F01–F13,V01–V28,B01–B18 scope and scientific criteria remain binding.
Solver: C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001,
branch codex/stiffened-main-reconcile-20261001. Slice base47fb532a; resolve latest
local commit with git log. ANYfem: C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer,
branch codex/experimental-ge-panel-consumer, slice base51e5298.
Local scoped commits only; no push/main merge/publication or contact-worker messages.
Main untouched. No owned runs or workers remain active after this slice.

Formal F03 UNCONSUMED; protected original script SHA256
c908b1f3e4d9467deb3a96876126d5488cd040503cc6c6ec485b8aeaecef9481.
Pressure assessment amendment still awaits user decision. Preserve existing failed
science and frozen evidence. Ceiling100krows/600s/8GiB/8threads; one heavy job at a
time. This slice used600s/1GiB/1thread/JIT off. Local/Mistral unavailable earlier;
OpenAI review is not cross-family scientific qualification.
Security: old tracked us3-modal-canary-v1.zip contains credentials. Do not print,
copy, disseminate or push affected history. User informed; no history-rewrite
permission. New archives contain whitelisted metadata, never environment maps.

## Delivered behavior

Experimental multi-element GE/B2 and coupled Q4-J2/generalized BL5 workflows,
adaptive displacement, selective physical/material recovery, chart rebase and
snapshot restart remain available. Original evidence is linked in the acceptance
matrix; no aggregate gate is claimed closed.

New explicit GENERALIZED_BRANCH_EVENT_TRIAL policy is selected with
DisplacementControl.trial_policy from an accepted force seed. It estimates native
generalized-beam branch events after the full predictor; no shell-J2 event detection,
constitutive change, tolerance change or budget increase. V3 displacement and
ANYSSDCA2 adaptive identities bind the method even at zero event work. Defaults
retain V1/V2/ANYSSDCA1. Restarts reject policy changes; rebase adds no event work.
Accepted cumulative event-cell work and rejected-attempt work remain separate.

Source25checks and installed35solver+2consumer checks passed. Public force-seed to
-66um to -68um succeeds at -487.0911366314N with equilibrium1.51e-11; restored
continuation is byte-exact. Extra event-only work44cell responses across both
accepted steps. No -70/-72um targets or -500N completion attempted.
Independent code review fixed the zero-history event-baseline loophole and closed
its finding. Initial installed fixture-collection failure preserved and repaired.
[Artifact hashes, outputs, review and prior note](development/r8-event-public-20261002/results.md).
Previous active-note bytes remain in that immutable archive. Consumer uses the
same installed solver; default and event-policy cancellation/rebase/restart both
pass. No performance improvement or scientific qualification claim.

## Decision and next action

Public branch-event integration is complete experimentally. Default signed route
still has its historical -68um/-500N failures; new method resolves only the bounded
-68um endpoint. The private discriminator/event evidence remains in
r8-displacement-rebase-20261002 and r8-branch-event-20261002; do not rerun it.
Before further physical targets, choose one bounded material-history/branch
validation slice and state which uncertainty it resolves. Do not automatically
extend targets, enlarge backtrack budgets or restart axial/U1 refinement campaigns.
Full reversal/material, F03 connection transfer, spectra/capacity, scale, external,
platform and complete consumer/release obligations remain open. Implementation,
testing, scientific acceptance and release are distinct.


## In-progress slice: accepted generalized material recovery

Decision: expose existing evaluated station strain/resultants and last-increment
stored energy/dissipation for BL5 material routes, without another constitutive
solve during recovery. Cache is bound to exact trial state and predecessor tuple;
publication/restoration format only validated response bytes. Scope excludes
legacy routes without saved last-increment predecessors. No equations/criteria
change. Check constitutive identities, station/frame mapping, actual accepted
history, ownership, stale cache, force/displacement/chart restart and selected
recovery without evaluation. This enables meaningful material-history assessment;
it does not substitute for required signed reversal or global energy balance.
