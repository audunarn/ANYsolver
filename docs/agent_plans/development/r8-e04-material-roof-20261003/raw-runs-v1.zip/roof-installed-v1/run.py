from pathlib import Path
import importlib.util,os,sys,json
root=Path(__file__).parent;site=root.parent/'r8-native-retained-scale-installed-v1/site';fixtures=root/'fixtures'
if len(sys.argv)>1 and sys.argv[1]=='tests-child':
 sys.path.insert(0,str(fixtures))
 import anysolver,pytest,numba,threadpoolctl
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 code=pytest.main(['-q','-p','no:cacheprovider','--basetemp=temporary','--junitxml=result.xml',str(fixtures/'test_stiffened_shell_e04_material.py'),str(fixtures/'test_stiffened_shell_e04_geometry.py')+'::test_roof_public_definition_preserves_geometry_and_centroidal_section'])
 pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools);assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
 Path('runtime.json').write_text(json.dumps(dict(solver=str(Path(anysolver.__file__).resolve()),pools=pools,jit_disabled=True),indent=2));raise SystemExit(code)
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(site,fixtures)));s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
if len(sys.argv)>1 and sys.argv[1]=='roof':
 command=[sys.executable,'-u',str(fixtures/'roof.py'),'--output',str(root/'material-path'),'--size','4','--density','1','--seed-force','100','--radius','.003','--steps','20','--restart-after','5','--shell-proportional-limit-pa','3102750','--beam-resultant-limits','500,300,300,1,2,.5','--beam-hardening-n','25000'];label='roof'
else:command=[sys.executable,str(Path(__file__)),'tests-child'];label='inputs'
r=s.supervised(command,root/label);print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
