from pathlib import Path
import importlib.util,json,os,sys,shutil
root=Path(__file__).parent;fixtures=root/'fixtures';repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001');site=root.parent/'r8-native-retained-scale-installed-v1/site'
if len(sys.argv)>1:
 import anysolver,pytest,numba,threadpoolctl
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 code=pytest.main(['-q','-p','no:cacheprovider','--basetemp=temporary','--junitxml=result.xml',str(fixtures/'test_stiffened_shell_e04_material.py')+'::test_declared_roof_strength_preserves_reference_and_section',str(fixtures/'test_stiffened_shell_e04_geometry.py')+'::test_roof_public_definition_preserves_geometry_and_centroidal_section'])
 pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools);assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
 Path('runtime.json').write_text(json.dumps(dict(solver=str(Path(anysolver.__file__).resolve()),pools=pools,jit_disabled=True),indent=2));raise SystemExit(code)
for name in ('test_stiffened_shell_e04_material.py','test_stiffened_shell_e04_geometry.py'):shutil.copyfile(repo/'tests'/name,fixtures/name)
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(site,fixtures)));s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
r=s.supervised([sys.executable,str(Path(__file__)),'child'],root/'canonical-inputs');print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
