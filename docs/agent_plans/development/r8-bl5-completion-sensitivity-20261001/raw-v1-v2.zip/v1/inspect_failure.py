from pathlib import Path
import os
import sys
import json
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['NUMBA_DISABLE_JIT']='1'
os.environ['NUMBA_NUM_THREADS']='1'
sys.path.insert(0,'C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-staged-load-installed-v1/site')
import numpy as np
from scipy import sparse
from anysolver._stiffened_shell_ge_experimental import _linear_equilibrium, _scaled_constraint_gap
from anysolver._b2_physical_linear_batch_dev import _accurate_sparse_residual
r=Path(__file__).resolve().parent
s=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/docs/agent_plans/development/r8-bl5-matched-comparison-20261001/refinement-v1-raw/native/n64')
with np.load(s/'operators.npz') as v:
    K,C,A=[sparse.csr_matrix((v[n+'_data'],v[n+'_indices'],v[n+'_indptr']),shape=tuple(v[n+'_shape'])) for n in ('K','C','A')]
    free,scales,rs=v['free'].copy(),v['coordinate_scale'].copy(),v['constraint_scale'].copy()
with np.load(s/'mz/raw-state.npz') as v:q,load=v['q'].copy(),v['load'].copy()
with np.load(r/'raw/derivative.npz') as v:
    dq,dl,numerical,res=[v[n].copy() for n in ('dq','multipliers','numerical_action','reactions')]
with np.load(r/'raw/solve-raw.npz') as v:
    solution,rhs=v['derivative'].copy(),v['rhs'].copy()
defect=K@dq+numerical+C.T@dl
accurate=_accurate_sparse_residual(A,solution[:,None],rhs[:,None])[:,0]
data={'ordinary_equilibrium':_linear_equilibrium(defect[free],-numerical[free],scales[free]),
      'accurate_equilibrium':_linear_equilibrium(accurate[:len(free)],rhs[:len(free)],scales[free]),
      'gap':_scaled_constraint_gap(C@dq,rs),
      'max_work_rhs':float(np.max(np.abs(numerical[free]*scales[free]))),
      'max_ordinary_work_defect':float(np.max(np.abs(defect[free]*scales[free]))),
      'max_accurate_work_defect':float(np.max(np.abs(accurate[:len(free)]*scales[free]))),
      'applied_work':float(load@q),'work_derivative':float(load@dq),
      'work_relative_derivative':float((load@dq)/(load@q)), 'signed_completion_pairing':float(q@numerical),
      'max_dq':float(np.max(np.abs(dq))), 'max_dlambda':float(np.max(np.abs(dl)))}
(r/'failure-inspection.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data))
