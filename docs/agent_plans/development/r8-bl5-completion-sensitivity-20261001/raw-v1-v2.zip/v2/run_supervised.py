from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
import psutil
root = Path(__file__).resolve().parent
source = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/scripts/b3_e4_bl5_completion_sensitivity_dev.py')
runner = root/source.name
assert not runner.exists(), 'Preserve consumed runner'
runner.write_bytes(source.read_bytes())
env = os.environ.copy()
env.update(PYTHONPATH='', PYTHONNOUSERSITE='1', NUMBA_DISABLE_JIT='1', OPENBLAS_NUM_THREADS='1',
           MKL_NUM_THREADS='1', OMP_NUM_THREADS='1', NUMBA_NUM_THREADS='1')
command = [sys.executable, '-u', str(runner), '--site',
    'C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-staged-load-installed-v1/site', '--saved',
    'C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/docs/agent_plans/development/r8-bl5-matched-comparison-20261001/refinement-v1-raw/native/n64',
    '--output', str(root/'raw'), '--reuse-solve',
    'C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-bl5-completion-sensitivity-20261001-v1/raw']
start, peak, limit, tree = time.monotonic(), 0, None, []
with (root/'execution.log').open('w') as out:
    process = subprocess.Popen(command, cwd=root, env=env, stdout=out, stderr=subprocess.STDOUT)
    parent = psutil.Process(process.pid)
    while process.poll() is None:
        try:
            tree = [parent]+parent.children(recursive=True)
            peak = max(peak, sum(p.memory_info().rss for p in tree if p.is_running()))
        except (psutil.NoSuchProcess, psutil.AccessDenied): pass
        if time.monotonic()-start > 600 or peak > 8*1024**3:
            limit = 'time' if time.monotonic()-start > 600 else 'memory'
            for p in reversed(tree):
                try: p.kill()
                except psutil.NoSuchProcess: pass
            break
        time.sleep(.1)
    code = process.wait()
record = dict(command=command, source_sha256=hashlib.sha256(runner.read_bytes()).hexdigest(), exit_code=code,
    process_tree_peak_rss_bytes=peak, elapsed_seconds=time.monotonic()-start, timeout_seconds=600,
    memory_limit_bytes=8*1024**3, resource_limit=limit, status='completed' if code == 0 and limit is None else 'failed')
(root/'execution.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
print('\n'.join((root/'execution.log').read_text().splitlines()[-15:]))
sys.exit(code if limit is None else 124)
