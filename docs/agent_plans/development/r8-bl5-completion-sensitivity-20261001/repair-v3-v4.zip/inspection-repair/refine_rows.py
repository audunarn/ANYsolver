from pathlib import Path
import json
import math
import os
import time
for name in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS'):
    os.environ[name] = '1'
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu
from threadpoolctl import threadpool_info

started = time.perf_counter()
saved = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/docs/agent_plans/development/r8-bl5-matched-comparison-20261001/refinement-v1-raw/native/n64')
prior = Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-bl5-completion-sensitivity-20261001-v2/raw')
with np.load(saved/'operators.npz', allow_pickle=False) as data:
    A = sparse.csr_matrix((data['A_data'], data['A_indices'], data['A_indptr']), shape=tuple(data['A_shape']))
with np.load(prior/'solve-raw.npz', allow_pickle=False) as data:
    x, b = data['derivative'].copy(), data['rhs'].copy()
assert all(p['num_threads'] == 1 for p in threadpool_info())
factor = splu(A.tocsc())
history = []
for step in range(5):
    residual = np.empty_like(b)
    for row in range(A.shape[0]):
        start, stop = A.indptr[row:row+2]
        terms = [-float(b[row])]
        for value, column in zip(A.data[start:stop], A.indices[start:stop]):
            product = float(value)*float(x[column])
            terms.extend((product, math.fma(float(value), float(x[column]), -product)))
        residual[row] = math.fsum(terms)
    denominator = abs(A)@abs(x)+abs(b)
    assert np.all(residual[denominator == 0] == 0)
    ratio = np.divide(abs(residual), denominator, out=np.zeros_like(b), where=denominator != 0)
    history.append(dict(corrections=step, backward_error=float(ratio.max()),
                        failing_rows=int(np.sum(ratio > 1e-8))))
    np.savez(Path(__file__).parent/f'iterate-{step}.npz', solution=x, rhs=b, residual=residual)
    if ratio.max() <= 1e-8 or step == 4:
        break
    revised = x-factor.solve(residual)
    assert np.isfinite(revised).all()
    if np.array_equal(revised, x):
        history[-1]['stagnation'] = True
        break
    x = revised
result = dict(classification='bounded same-system numerical repair screen; full physical controls pending',
              history=history, factor_count=1, correction_count=history[-1]['corrections'],
              criterion=1e-8, elapsed_seconds=time.perf_counter()-started, pools=threadpool_info())
(Path(__file__).parent/'refinement.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('history','factor_count','elapsed_seconds')}))
