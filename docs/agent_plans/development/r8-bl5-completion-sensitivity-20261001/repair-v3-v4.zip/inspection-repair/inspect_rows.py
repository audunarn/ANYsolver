from pathlib import Path
import hashlib
import json
import math
import os
import time
from fractions import Fraction

for name in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS'):
    os.environ[name] = '1'
import numpy as np
from scipy import sparse
from threadpoolctl import threadpool_info

started = time.perf_counter()
saved = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/docs/agent_plans/development/r8-bl5-matched-comparison-20261001/refinement-v1-raw/native/n64')
prior = Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-bl5-completion-sensitivity-20261001-v2/raw')
with np.load(saved/'operators.npz', allow_pickle=False) as data:
    A = sparse.csr_matrix((data['A_data'], data['A_indices'], data['A_indptr']), shape=tuple(data['A_shape']))
    free = data['free'].copy()
with np.load(prior/'solve-raw.npz', allow_pickle=False) as data:
    x, b = data['derivative'].copy(), data['rhs'].copy()
assert A.shape == (len(x), len(x)) and len(x) < 100000
assert all(p['num_threads'] == 1 for p in threadpool_info())
residual = np.empty_like(b)
for row in range(A.shape[0]):
    start, stop = A.indptr[row:row+2]
    terms = [-float(b[row])]
    for value, column in zip(A.data[start:stop], A.indices[start:stop]):
        product = float(value)*float(x[column])
        terms.extend((product, math.fma(float(value), float(x[column]), -product)))
    residual[row] = math.fsum(terms)
denominator = abs(A)@abs(x)+abs(b)
assert np.all(residual[denominator == 0] == 0)
ratio = np.divide(abs(residual), denominator, out=np.zeros_like(b), where=denominator != 0)
physical_nodes = 6*(1105+129)
def role(row):
    if row >= len(free):
        return 'constraint'
    full = int(free[row])
    if full >= physical_nodes:
        return 'beam_retained'
    return ('shell_' if full < 6630 else 'beam_')+('ux','uy','uz','rx','ry','rz')[full % 6]
top = np.argsort(ratio)[-12:][::-1]
rows = []
for index in top:
    row = int(index)
    start, stop = A.indptr[row:row+2]
    exact = -Fraction(float(b[row]))
    for value, column in zip(A.data[start:stop], A.indices[start:stop]):
        exact += Fraction(float(value))*Fraction(float(x[column]))
    assert float(exact) == residual[row]
    rows.append(dict(row=row, full_slot=int(free[row]) if row < len(free) else None,
                     role=role(row), backward_error=float(ratio[row]), residual=float(residual[row]),
                     denominator=float(denominator[row]), rhs=float(b[row]), nnz=int(stop-start)))
failures = np.flatnonzero(ratio > 1e-8)
counts = {}
for row in failures:
    name = role(int(row))
    counts[name] = counts.get(name, 0)+1
result = dict(classification='retained failed-solve inspection; no new solve or acceptance',
              factor_count=0, assembly_count=0, max_backward_error=float(ratio.max()),
              failed_rows=int(len(failures)), failure_roles=counts, top_rows=rows,
              rows=A.shape[0], nnz=A.nnz, pools=threadpool_info(),
              input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                            (saved/'operators.npz', prior/'solve-raw.npz')},
              elapsed_seconds=time.perf_counter()-started)
(Path(__file__).parent/'rows.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('max_backward_error','failed_rows','failure_roles','elapsed_seconds')}))
