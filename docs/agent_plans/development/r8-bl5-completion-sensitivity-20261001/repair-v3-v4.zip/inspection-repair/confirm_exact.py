from pathlib import Path
import hashlib
import json
import math
import os
from fractions import Fraction
for name in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS'):
    os.environ[name] = '1'
import numpy as np
from scipy import sparse

root = Path(__file__).resolve().parent
saved = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/docs/agent_plans/development/r8-bl5-matched-comparison-20261001/refinement-v1-raw/native/n64')
assessment = Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-bl5-completion-sensitivity-20261001-v4/raw')
with np.load(saved/'operators.npz', allow_pickle=False) as data:
    A = sparse.csr_matrix((data['A_data'], data['A_indices'], data['A_indptr']), shape=tuple(data['A_shape']))
    free, scale = data['free'].copy(), data['coordinate_scale'].copy()
with np.load(root/'iterate-0.npz', allow_pickle=False) as data:
    old = data['solution'].copy()
with np.load(root/'iterate-1.npz', allow_pickle=False) as data:
    x, b = data['solution'].copy(), data['rhs'].copy()
with np.load(assessment/'solve-raw.npz', allow_pickle=False) as data:
    assert np.array_equal(x, data['derivative']) and np.array_equal(b, data['rhs'])
residual = []
for row in range(len(x)):
    start, stop = A.indptr[row:row+2]
    terms = [-float(b[row])]
    for value, column in zip(A.data[start:stop], A.indices[start:stop]):
        p = float(value)*float(x[column])
        terms.extend((p, math.fma(float(value), float(x[column]), -p)))
    residual.append(math.fsum(terms))
denominator = abs(A)@abs(x)+abs(b)
ratio = np.divide(abs(np.array(residual)), denominator, out=np.zeros_like(b), where=denominator != 0)
rows = sorted(set([8861,8864]+np.argsort(ratio)[-12:].tolist()))
checks = []
for row in rows:
    start, stop = A.indptr[row:row+2]
    exact_r, exact_d = -Fraction(float(b[row])), abs(Fraction(float(b[row])))
    for value, column in zip(A.data[start:stop], A.indices[start:stop]):
        term = Fraction(float(value))*Fraction(float(x[column]))
        exact_r += term
        exact_d += abs(term)
    assert float(exact_r) == residual[row]
    exact_ratio = float(abs(exact_r)/exact_d) if exact_d else 0.
    assert exact_ratio <= 1e-8
    checks.append(dict(row=row, exact_residual=float(exact_r), exact_positive_sum=float(exact_d),
                       exact_backward_error=exact_ratio, float_backward_error=float(ratio[row])))
final = json.loads((assessment/'result.json').read_text())
assert ratio.max() == final['derivative_diagnostic_controls']['componentwise_backward_error']
with np.load(saved/'mz/raw-state.npz', allow_pickle=False) as data:
    load = data['load'].copy()
delta = x[:len(free)]-old[:len(free)]
result = dict(exact_rows=checks, max_recomputed_backward_error=float(ratio.max()),
              relative_physical_step_change=float(np.linalg.norm(delta*scale[free])/np.linalg.norm(x[:len(free)]*scale[free])),
              applied_work_derivative_change_j=float(load[free]@delta),
              total_repair_factors=1, additional_corrections=1, assessment_factors=0,
              bindings={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                        (saved/'operators.npz', root/'inspect_rows.py', root/'refine_rows.py',
                         root/'refinement.json', root/'iterate-0.npz', root/'iterate-1.npz', assessment/'result.json')})
(root/'confirmation.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('max_recomputed_backward_error','relative_physical_step_change','applied_work_derivative_change_j')}))
