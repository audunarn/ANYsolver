from pathlib import Path
import hashlib,importlib.util,json,os,sys,time
root=Path(__file__).parent
solver_site=root.parent/'r8-curved-material-staged-installed-v2/site'
consumer_site=root/'consumer-site'
mode=sys.argv[1]
if mode.endswith("-child"):
    import numpy as np,numba,threadpoolctl
    from anyfem.io.project_file import load_project
    from anyfem.solve.stiffened_shell import load_case
    from scripts.experimental_stiffened_ge_multi_member_panel import actions_for,check_balance
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p["num_threads"]==1 for p in pools)
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items()
             if n.startswith(("anysolver","anyfem")) and getattr(m,"__file__",None)}
    for n,p in imports.items():
        assert Path(p).is_relative_to((consumer_site if n.startswith("anyfem") else solver_site).resolve()),(n,p)
    Path("runtime-start.json").write_text(json.dumps(dict(imports=imports,pools=pools,
        jit_disabled=True,numba_threads=1,python=sys.version),indent=2),encoding="utf-8")
    started=time.perf_counter()
    record=dict(status="IN_PROGRESS",qualification="NOT_QUALIFIED",mode=mode,seconds={})
    def phase(name,before):
        record["seconds"][name]=time.perf_counter()-before
        Path("progress.json").write_text(json.dumps(record,indent=2),encoding="utf-8")
        print(name,record["seconds"][name],flush=True)
    before=time.perf_counter()
    # Unchanged persisted input from v1; no model substitution or new size.
    input_path=root/"large-v1/large.anyfem-ge.json"
    project_path=root/"large-v1/large.anyfem"
    case=load_case(input_path)
    project=load_project(project_path)
    analysis=next(iter(project.analyses.values()))
    assert analysis.beam_formulation_options["panel"]==case.to_dict()
    definition=case.definition()
    actions=actions_for(definition)
    record.update(input_sha256=hashlib.sha256(input_path.read_bytes()).hexdigest(),
        project_sha256=hashlib.sha256(project_path.read_bytes()).hexdigest(),
        shell_elements=len(definition.shell.q4_elements),beam_elements=len(definition.beams),
        point_connections=len(definition.points))
    assert record["shell_elements"]==10000 and record["beam_elements"]==1000
    phase("reopen",before)
    before=time.perf_counter()
    owner=analysis.create_point_panel_analysis()
    preflight=owner.preflight()
    rows=preflight["physical_dofs"]+preflight["retained_dofs"]+preflight["constraints"]-len(definition.fixed)
    assert rows==97320 and rows<=100000
    record.update(matrix_rows=rows,preflight=preflight)
    phase("compile",before)
    try:
        if mode=="checkpoint-child":
            before=time.perf_counter()
            first=owner.solve_linear(actions)
            assert first.status=="completed" and not first.production_qualified
            force,moment=check_balance(definition,first,actions)
            record.update(equilibrium_ratio=first.free_equilibrium_ratio,constraint_max=first.constraint_max,
                force_balance_ratio=force,moment_balance_ratio=moment)
            assert force<=1e-8 and moment<=1e-8
            phase("first_solve",before)
            before=time.perf_counter()
            checkpoint=owner.checkpoint()
            assert checkpoint[:10]==bytes((65,78,89,83,71,69,67,80,50,0))
            Path("accepted.bin").write_bytes(checkpoint)
            for name in ("shell_displacement","beam_coordinates","multipliers","reactions"):
                np.testing.assert_array_equal(getattr(first,name),getattr(owner.recover(),name))
            np.savez("first.npz",**{name:getattr(first,name) for name in
                ("shell_displacement","beam_coordinates","multipliers","reactions")})
            record.update(checkpoint_bytes=len(checkpoint),checkpoint_sha256=hashlib.sha256(checkpoint).hexdigest())
            phase("recovery_checkpoint",before)
            before=time.perf_counter()
            second=owner.solve_linear(actions_for(definition,200.))
            assert owner.preflight()["reference_linear_factorizations"]==1
            np.savez("second.npz",**{name:getattr(second,name) for name in
                ("shell_displacement","beam_coordinates","multipliers","reactions")})
            record["unchanged_operator_factorizations"]=1
            phase("continued_load",before)
        else:
            before=time.perf_counter()
            checkpoint=(root/"checkpoint-v2/accepted.bin").read_bytes()
            first=np.load(root/"checkpoint-v2/first.npz")
            second=np.load(root/"checkpoint-v2/second.npz")
            owner.restore(checkpoint)
            assert owner.checkpoint()==checkpoint
            restored=owner.recover()
            for name in first.files:
                np.testing.assert_array_equal(first[name],getattr(restored,name))
            record.update(checkpoint_bytes=len(checkpoint),checkpoint_sha256=hashlib.sha256(checkpoint).hexdigest(),
                equilibrium_ratio=restored.free_equilibrium_ratio,constraint_max=restored.constraint_max)
            phase("snapshot_restore",before)
            before=time.perf_counter()
            continued=owner.solve_linear(actions_for(definition,200.))
            for name in second.files:
                np.testing.assert_array_equal(second[name],getattr(continued,name))
            assert owner.preflight()["reference_linear_factorizations"]==1
            record["unchanged_operator_factorizations"]=1
            phase("restarted_continuation",before)
    finally:
        owner.close()
    record.update(status="COMPLETED",route_seconds=time.perf_counter()-started)
    Path("result.json").write_text(json.dumps(record,indent=2),encoding="utf-8")
    print(json.dumps(dict(status=record["status"],seconds=record["route_seconds"])),flush=True)
    raise SystemExit()
spec=importlib.util.spec_from_file_location("supervisor",root/"size-supervisor.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(solver_site,consumer_site,root/"fixtures")))
s.ENV["PYTEST_DISABLE_PLUGIN_AUTOLOAD"]="1"
r=s.supervised([sys.executable,"-u",str(Path(__file__)),mode+"-child"],root/(mode+"-v2"))
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
