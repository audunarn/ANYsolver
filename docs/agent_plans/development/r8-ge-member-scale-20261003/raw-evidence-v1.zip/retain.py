from pathlib import Path
import hashlib,json,zipfile,shutil,xml.etree.ElementTree as ET
root=Path(__file__).parent
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
consumer=Path("C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer")
target=repo/"docs/agent_plans/development/r8-ge-member-scale-20261003"
target.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[]
for name in ("run.py","large.py","large-fixed.py","large-staged.py","profile-reference.py",
             "size-supervisor.py","retain.py","independent-development-review.txt",
             "prepare-solver-identity.json","prepare-consumer-identity.json","final-identity.json",
             "anyfem-build.log","anyfem-install.log","dependencies.py","dependencies.json","baseline-cap.py"):
    p=root/name
    if p.exists():files.append((p,name))
runs={}
for name in ("solver","solver-repair","solver-mixed","consumer-repair","consumer-mixed",
             "large-v1","checkpoint-v2","restore-v2","profile-v1","geometry-final","geometry-default-final","baseline-cap-v1"):
    folder=root/name
    if not folder.exists():continue
    info={}
    for basename in ("stdout.log","stderr.log","execution.json","runtime.json","runtime-start.json",
                     "result.xml","result.json","progress.json","panel-screen.json","consumer-screen.json",
                     "accepted.bin","first.npz","second.npz","compile.pstats",
                     "large.anyfem","large.anyfem-ge.json"):
        p=folder/basename
        if p.exists():files.append((p,name+"/"+basename))
    for basename in ("execution.json","result.json","panel-screen.json","consumer-screen.json"):
        p=folder/basename
        if p.exists():info[basename]=json.loads(p.read_text(encoding="utf-8"))
    p=folder/"result.xml"
    if p.exists():
        element=ET.parse(p).getroot()
        info["pytest"]=[dict(e.attrib) for e in element.iter("testsuite")]
    runs[name]=info
for base,rels in ((repo,("scripts/experimental_stiffened_ge_multi_member_panel.py",
                        "tests/test_stiffened_shell_multi_member_panel.py")),
                  (consumer,("src/anyfem/solve/stiffened_shell.py","tests/test_ge_member_count_consumer.py",
                              "docs/EXPERIMENTAL_STIFFENED_SHELL_CONSUMER.md"))):
    for rel in rels:files.append((base/rel,("solver-source/" if base==repo else "consumer-source/")+rel))
for package,folder in (("anysolver",root.parent/"r8-curved-material-staged-installed-v2/wheels"),
                       ("anyfem",root/"consumer-wheels")):
    p=next(folder.glob("*.whl"));files.append((p,"wheels/"+package+"/"+p.name))
# Generated inputs, explicit source and whitelisted diagnostics only.
# No inherited environment dump and no historical archives are opened.
manifest={rel:dict(sha256=sha(p),bytes=p.stat().st_size) for p,rel in files}
archive=target/"raw-evidence-v1.zip"
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED) as z:
    for p,rel in files:z.write(p,rel)
summary=dict(scope="experimental point-bond size and consumer development only",
             source_parent="f58abf96",consumer_source_parent="c78b55c",
             archive_sha256=sha(archive),files=manifest,runs=runs)
(target/"summary-v1.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
shutil.copyfile(root/"independent-development-review.txt",target/"independent-development-review.txt")
print(json.dumps(dict(archive_sha256=sha(archive),files=len(files),runs=len(runs))))
