from pathlib import Path
import hashlib,importlib.util,json,os,sys
root=Path(__file__).parent
old=root.parent/"r8-curved-material-staged-installed-v1/consumer-site"
if len(sys.argv)>1:
    from anyfem.solve import stiffened_shell as consumer
    from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
    assert Path(consumer.__file__).resolve().is_relative_to(old.resolve())
    d=make_definition(8,4)
    try:
        consumer.ExperimentalGEPointPanel(d.shell,d.beams,d.points,d.fixed,actions=actions_for(d))
    except ValueError as error:
        assert "beam count exceeds file limit" in str(error),str(error)
        Path("result.json").write_text(json.dumps(dict(status="EXPECTED_REJECTION",
            beam_elements=len(d.beams),error=str(error),import_path=consumer.__file__,
            module_sha256=hashlib.sha256(Path(consumer.__file__).read_bytes()).hexdigest()),indent=2),encoding="utf-8")
    else:
        raise AssertionError("old consumer unexpectedly admitted 32 beams")
    raise SystemExit()
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(root.parent/"r8-curved-material-staged-installed-v2/site",old,root/"fixtures")))
r=s.supervised([sys.executable,"-u",str(Path(__file__)),"child"],root/"baseline-cap-v1")
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
