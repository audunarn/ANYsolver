from pathlib import Path
import hashlib, importlib.util, json, os, sys, time
root=Path(__file__).parent
solver_site=root.parent/'r8-curved-material-staged-installed-v2/site'
consumer_site=root/'consumer-site'
if len(sys.argv)>1 and sys.argv[1]=='child':
    import numpy as np
    import numba,threadpoolctl
    from anysolver import stiffened_shell as ss
    from anyfem.io.project_file import load_project,save_project
    from anyfem.model.project import Project
    from anyfem.model.records import AnalysisDefinition
    from anyfem.solve.stiffened_shell import ExperimentalGEPointPanel,save_case,load_case
    from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for,check_balance
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p["num_threads"]==1 for p in pools)
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    Path("runtime-start.json").write_text(json.dumps(dict(pools=pools,jit_disabled=True,
        numba_threads=1,python=sys.version),indent=2),encoding="utf-8")
    started=time.perf_counter()
    record=dict(status="IN_PROGRESS",qualification="NOT_QUALIFIED",scope="matching sparse point-bond resource feasibility",seconds={})
    def phase(name,before):
        record["seconds"][name]=time.perf_counter()-before
        Path("progress.json").write_text(json.dumps(record,indent=2),encoding="utf-8")
        print(name,record["seconds"][name],flush=True)
    before=time.perf_counter()
    definition=make_definition(100,10,shell_transverse_cells=100,tie_stride=10)
    assert len(definition.shell.q4_elements)==10000 and len(definition.beams)==1000
    assert len(definition.points)==110 and len(definition.fixed)==606
    actions=actions_for(definition)
    assert len(actions)==10
    phase("definition",before)
    before=time.perf_counter()
    case=ExperimentalGEPointPanel(definition.shell,definition.beams,definition.points,definition.fixed,actions=actions)
    reopened=load_case(save_case(case,Path("large.anyfem-ge.json")))
    assert reopened.to_dict()==case.to_dict()
    project=Project("10k Q4 1k native B3 point screen",mesh_only=True)
    analysis=AnalysisDefinition.experimental_point_panel("10 straight stiffeners",reopened)
    project.add_analysis(analysis)
    project_reopened=load_project(save_project(project,Path("large.anyfem")))
    loaded=project_reopened.analyses[analysis.id]
    assert loaded.beam_formulation_options["panel"]==case.to_dict()
    record.update(shell_elements=10000,beam_elements=1000,physical_stiffener_lines=10,
        point_connections=110,point_stride=10,expected_mixed_rows=97320,
        project_bytes=Path("large.anyfem").stat().st_size,
        input_record_bytes=Path("large.anyfem-ge.json").stat().st_size)
    phase("consumer_roundtrip",before)
    before=time.perf_counter()
    owner=loaded.create_point_panel_analysis()
    preflight=owner.preflight()
    rows=preflight["physical_dofs"]+preflight["retained_dofs"]+preflight["constraints"]-len(definition.fixed)
    assert rows==97320 and rows<=100000
    record.update(matrix_rows=rows,preflight=preflight)
    phase("compile",before)
    try:
        before=time.perf_counter()
        first=owner.solve_linear(actions)
        assert first.status=="completed" and not first.production_qualified
        force,moment=check_balance(definition,first,actions)
        record.update(equilibrium_ratio=first.free_equilibrium_ratio,constraint_max=first.constraint_max,
                      force_balance_ratio=force,moment_balance_ratio=moment)
        assert force<=1e-8 and moment<=1e-8
        phase("first_solve",before)
        before=time.perf_counter()
        checkpoint=owner.checkpoint()
        assert checkpoint[:10] == bytes((65,78,89,83,71,69,67,80,50,0))
        Path("accepted.bin").write_bytes(checkpoint)
        for name in ("shell_displacement","beam_coordinates","multipliers","reactions"):
            np.testing.assert_array_equal(getattr(first,name),getattr(owner.recover(),name))
        record.update(checkpoint_bytes=len(checkpoint),checkpoint_sha256=hashlib.sha256(checkpoint).hexdigest())
        phase("recovery_checkpoint",before)
        before=time.perf_counter()
        second=owner.solve_linear(actions_for(definition,200.))
        assert owner.preflight()["reference_linear_factorizations"]==1
        record["unchanged_operator_factorizations"]=1
        phase("continued_load",before)
    finally:
        owner.close()
    del owner
    before=time.perf_counter()
    resumed=loaded.create_point_panel_analysis()
    phase("restore_compile",before)
    try:
        before=time.perf_counter()
        resumed.restore(checkpoint)
        assert resumed.checkpoint()==checkpoint
        for name in ("shell_displacement","beam_coordinates","multipliers","reactions"):
            np.testing.assert_array_equal(getattr(first,name),getattr(resumed.recover(),name))
        phase("snapshot_restore",before)
        before=time.perf_counter()
        continued=resumed.solve_linear(actions_for(definition,200.))
        for name in ("shell_displacement","beam_coordinates","multipliers","reactions"):
            np.testing.assert_array_equal(getattr(second,name),getattr(continued,name))
        assert resumed.preflight()["reference_linear_factorizations"]==1
        phase("restarted_continuation",before)
    finally:
        resumed.close()
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p["num_threads"]==1 for p in pools)
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items()
             if n.startswith(("anysolver","anyfem")) and getattr(m,"__file__",None)}
    for n,p in imports.items():
        assert Path(p).is_relative_to((consumer_site if n.startswith("anyfem") else solver_site).resolve()),(n,p)
    Path("runtime.json").write_text(json.dumps(dict(imports=imports,pools=pools,
        jit_disabled=True,numba_threads=1,python=sys.version),indent=2),encoding="utf-8")
    record.update(status="COMPLETED",full_route_seconds=time.perf_counter()-started)
    Path("result.json").write_text(json.dumps(record,indent=2),encoding="utf-8")
    print(json.dumps(dict(status=record["status"],seconds=record["full_route_seconds"])),flush=True)
    raise SystemExit()
spec=importlib.util.spec_from_file_location("supervisor",root/"size-supervisor.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(solver_site,consumer_site,root/"fixtures")))
s.ENV["PYTEST_DISABLE_PLUGIN_AUTOLOAD"]="1"
r=s.supervised([sys.executable,"-u",str(Path(__file__)),"child"],root/"large-v2")
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
