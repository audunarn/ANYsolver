from pathlib import Path
import cProfile,importlib.util,json,os,pstats,sys,time
root=Path(__file__).parent
solver_site=root.parent/'r8-curved-material-staged-installed-v2/site'
consumer_site=root/'consumer-site'
if len(sys.argv)>1:
    import numba,threadpoolctl
    from anysolver import stiffened_shell as ss
    from scripts.experimental_stiffened_ge_multi_member_panel import make_definition
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p["num_threads"]==1 for p in pools)
    assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
    definition=make_definition(20,6,shell_transverse_cells=20,tie_stride=4)
    profiler=cProfile.Profile()
    before=time.perf_counter();profiler.enable()
    owner=ss.create_analysis(definition=definition)
    profiler.disable();elapsed=time.perf_counter()-before
    profiler.dump_stats("compile.pstats")
    stats=pstats.Stats(profiler)
    needles=("assemble_shell","assemble_beam","qualified_linear_correction",
             "compute_nonlinear_response","nonlinear_geometry","rotation_sensitivity",
             "shell_center_frame","corotational_cache","tocsr","revision_signature","extend","_nonlinear_internal","compute_stiffness_matrix")
    selected=[]
    for (path,line,name),(cc,nc,tt,ct,callers) in stats.stats.items():
        if any(needle in name for needle in needles):
            selected.append(dict(path=path,line=line,name=name,primitive_calls=cc,calls=nc,
                                 self_seconds=tt,cumulative_seconds=ct))
    selected.sort(key=lambda row:row["cumulative_seconds"],reverse=True)
    Path("result.json").write_text(json.dumps(dict(scope="profiling only, no timing or speedup claim",
        shell_elements=400,beam_elements=120,elapsed_seconds=elapsed,preflight=owner.preflight(),
        effective_pools=pools,numba_threads=1,jit_disabled=True,functions=selected),indent=2),encoding="utf-8")
    owner.close()
    print(json.dumps(dict(profiled_seconds=elapsed,functions=len(selected))),flush=True)
    raise SystemExit()
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(solver_site,consumer_site,root/"fixtures")))
r=s.supervised([sys.executable,"-u",str(Path(__file__)),"child"],root/"profile-v1")
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
