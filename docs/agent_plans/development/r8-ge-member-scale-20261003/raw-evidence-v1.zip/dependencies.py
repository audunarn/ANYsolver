from pathlib import Path
import importlib,importlib.metadata as md,hashlib,json,os,subprocess,sys
root=Path(__file__).parent
if len(sys.argv)>1:
    records={}
    for name in ("anysolver","anyfem","anymaterial","numpy","scipy","numba","threadpoolctl","psutil"):
        m=importlib.import_module(name)
        p=Path(m.__file__).resolve()
        records[name]=dict(version=md.version(name),import_path=str(p),
            entry_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    import numpy,numba,threadpoolctl
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    assert all(p["num_threads"]==1 for p in threadpoolctl.threadpool_info())
    (root/"dependencies.json").write_text(json.dumps(records,indent=2),encoding="utf-8")
    raise SystemExit()
env=os.environ.copy()
env.update(OMP_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",MKL_NUM_THREADS="1",
           NUMBA_NUM_THREADS="1",NUMBA_DISABLE_JIT="1",
           PYTHONPATH=os.pathsep.join(map(str,(root.parent/"r8-curved-material-staged-installed-v2/site",root/"consumer-site"))))
subprocess.run([sys.executable,str(Path(__file__)),"child"],env=env,check=True)
