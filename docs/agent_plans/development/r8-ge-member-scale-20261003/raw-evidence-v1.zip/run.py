from pathlib import Path
import ast, hashlib, importlib.util, json, os, shutil, subprocess, sys, zipfile
root=Path(__file__).parent
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
consumer=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
solver_root=root.parent/'r8-curved-material-staged-installed-v2'
solver_site=solver_root/'site'
consumer_site=root/'consumer-site'
fixtures=root/'fixtures'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mode=sys.argv[1]
if mode in ('prepare-solver','prepare-consumer'):
    fixtures.mkdir(exist_ok=True)
    records={}
    if mode=='prepare-consumer':
        wheels=root/'consumer-wheels'
        with (root/'anyfem-build.log').open('w') as log:
            subprocess.run([sys.executable,'-m','pip','wheel','--no-deps','--no-build-isolation',
                '--no-cache-dir','--no-index','--wheel-dir',str(wheels),str(consumer)],
                stdout=log,stderr=subprocess.STDOUT,check=True)
        wheel=next(wheels.glob('*.whl'))
        with (root/'anyfem-install.log').open('w') as log:
            subprocess.run([sys.executable,'-m','pip','install','--no-deps','--no-index',
                '--no-cache-dir','--target',str(consumer_site),str(wheel)],
                stdout=log,stderr=subprocess.STDOUT,check=True)
        entries=((repo,solver_site,'anysolver',next((solver_root/'wheels').glob('*.whl'))),
                 (consumer,consumer_site,'anyfem',wheel))
        selected=['test_ge_member_count_consumer']
        pending=list(selected);seen=set()
        while pending:
            name=pending.pop()
            if name in seen:continue
            seen.add(name)
            p=consumer/'tests'/(name+'.py')
            shutil.copyfile(p,fixtures/p.name)
            for node in ast.walk(ast.parse(p.read_text(encoding='utf-8-sig'))):
                if isinstance(node,ast.ImportFrom) and node.module and node.module.startswith('test_'):
                    pending.append(node.module)
    else:
        entries=((repo,solver_site,'anysolver',next((solver_root/'wheels').glob('*.whl'))),)
        shutil.copyfile(repo/'tests/test_stiffened_shell_multi_member_panel.py',
                        fixtures/'test_stiffened_shell_multi_member_panel.py')
        (fixtures/'scripts').mkdir(exist_ok=True)
        shutil.copyfile(repo/'scripts/experimental_stiffened_ge_multi_member_panel.py',
                        fixtures/'scripts/experimental_stiffened_ge_multi_member_panel.py')
    for source,site,package,wheel in entries:
        modules={}
        with zipfile.ZipFile(wheel) as z:
            for p in (source/'src'/package).rglob('*.py'):
                rel=p.relative_to(source/'src').as_posix()
                assert p.read_bytes()==z.read(rel)==(site/rel).read_bytes(),rel
                modules[rel]=sha(p)
        records[package]=dict(wheel_sha256=sha(wheel),site=str(site),modules=modules)
    records['fixtures']={str(p.relative_to(fixtures)):sha(p) for p in fixtures.rglob('*.py')}
    (root/(mode+'-identity.json')).write_text(json.dumps(records,indent=2),encoding='utf-8')
    print(json.dumps({k:dict(modules=len(v['modules']),wheel_sha256=v['wheel_sha256']) for k,v in records.items() if k!='fixtures'}))
    raise SystemExit()
if mode in ('solver-child','consumer-child','geometry-child'):
    import anysolver, numba, threadpoolctl, pytest
    assert Path(anysolver.__file__).resolve().is_relative_to(solver_site.resolve())
    selected=['test_stiffened_shell_multi_member_panel.py::test_fixture_reference_axis_and_identity_are_explicit'] if mode=='geometry-child' else ['test_stiffened_shell_multi_member_panel.py::test_connected_four_stiffener_reference_route','test_stiffened_shell_multi_member_panel.py::test_independent_shell_resolution_and_sparse_point_layout'] if mode=='solver-child' else ['test_ge_member_count_consumer.py::test_seventeen_members_reopen_through_shared_modal_binding_parser','test_installed_multi_member_project.py']
    code=pytest.main(['-q','-p','no:cacheprovider','--basetemp=temporary','--junitxml=result.xml',
                     *[str(fixtures/v) for v in selected]])
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p['num_threads']==1 for p in pools)
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items()
             if n.startswith(('anysolver','anyfem')) and getattr(m,'__file__',None)}
    for n,p in imports.items():
        assert Path(p).is_relative_to((consumer_site if n.startswith('anyfem') else solver_site).resolve()),(n,p)
    Path('runtime.json').write_text(json.dumps(dict(imports=imports,pools=pools,jit_disabled=True,
        numba_threads=numba.get_num_threads(),python=sys.version),indent=2),encoding='utf-8')
    for p in Path('temporary').rglob('panel-screen.json'):
        shutil.copyfile(p,'panel-screen.json')
    raise SystemExit(code)
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(solver_site,consumer_site,fixtures)))
s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
r=s.supervised([sys.executable,'-u',str(Path(__file__)),mode+'-child'],root/(mode+'-default-final'))
print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
