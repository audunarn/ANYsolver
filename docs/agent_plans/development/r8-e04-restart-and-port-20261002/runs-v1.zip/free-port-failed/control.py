"""Finite rigid-port mapping control, not a flexible beam/shell reference.

CalculiX *RIGID BODY is supported for these element-free marker nodes, not
original beam/shell nodes. A separate grounded spring keeps one solved equation.
The marker triad represents the declared E04 rectangular section frame only;
it supplies no beam or shell stiffness. Execute under the existing supervisor.
"""
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation

ANGLE=.05
OFFSET=(.0127+.0254)/2
ROTATION=np.array((.4,-.3,.2))
TRANSLATION=np.array((.01,-.02,.03))
FORCE=np.array((7.,-3.,5.))
BEAM_FRAME=Rotation.from_rotvec((-ANGLE,0.,0.)).as_matrix()
BEAM_POSITION=OFFSET*BEAM_FRAME[:,2]
MARKERS=np.array((BEAM_POSITION,BEAM_POSITION+.05*BEAM_FRAME[:,0],
                  BEAM_POSITION+.00635*BEAM_FRAME[:,1]))
SPRING_STIFFNESS=100.


def deck():
    nodes={i+1:p for i,p in enumerate(MARKERS)}
    nodes.update({100:np.zeros(3),101:np.zeros(3),200:np.array((1.,0.,0.))})
    lines=['*HEADING','E04 finite rigid port development control','*NODE']
    lines += [','.join((str(i),*(f'{v:.17g}' for v in p))) for i,p in nodes.items()]
    lines += ['*NSET,NSET=Markers','1,2,3','*NSET,NSET=Ports','1,2,3,100,101,200',
        '*ELEMENT,TYPE=SPRING1,ELSET=Control','1,200','*SPRING,ELSET=Control','1','1000.',
        '*RIGID BODY,NSET=Markers,REF NODE=100,ROT NODE=101','*BOUNDARY',
        '100,1,3,0.','101,1,3,0.','200,2,3,0.',
        '*STEP,NLGEOM,INC=100','*STATIC','.1,1.,1e-6,.1','*BOUNDARY']
    for node,value in ((100,TRANSLATION),(101,ROTATION)):
        lines += [f'{node},{j+1},{j+1},{v:.17g}' for j,v in enumerate(value)]
    lines += ['*CLOAD',*(f'1,{j+1},{v:.17g}' for j,v in enumerate(FORCE)),
        '200,1,1.','*NODE PRINT,NSET=Ports,FREQUENCY=1','U,RF','*END STEP']
    return '\n'.join(lines)+'\n'


def expected():
    matrix=Rotation.from_rotvec(ROTATION).as_matrix()
    positions=MARKERS@matrix.T+TRANSLATION
    angle=np.linalg.norm(ROTATION)
    cross=np.array(((0.,-ROTATION[2],ROTATION[1]),(ROTATION[2],0.,-ROTATION[0]),
                    (-ROTATION[1],ROTATION[0],0.)))
    jacobian=np.eye(3)+(1-np.cos(angle))/angle**2*cross+(angle-np.sin(angle))/angle**3*cross@cross
    spatial_moment=np.cross(matrix@BEAM_POSITION,FORCE)
    return dict(marker_displacements=(positions-MARKERS).tolist(),
        reference_displacement=TRANSLATION.tolist(),rotation_coordinate=ROTATION.tolist(),
        reference_reaction=(-FORCE).tolist(),
        rotation_coordinate_reaction=(-jacobian.T@spatial_moment).tolist(),
        spatial_reaction_moment=(-spatial_moment).tolist(),control_displacement=.001)


def free_spring_deck():
    """Free six-DOF rigid carrier on nine linear Cartesian grounded springs."""
    lines=['*HEADING','E04 free finite rigid carrier on known springs','*NODE']
    lines += [','.join((str(i+1),*(f'{v:.17g}' for v in p))) for i,p in enumerate(MARKERS)]
    lines += ['100,0.,0.,0.','101,0.,0.,0.','*NSET,NSET=Markers','1,2,3',
              '*NSET,NSET=Ports','1,2,3,100,101']
    for direction in (1,2,3):
        lines += [f'*ELEMENT,TYPE=SPRING1,ELSET=D{direction}']
        lines += [f'{3*(direction-1)+node},{node}' for node in (1,2,3)]
        lines += [f'*SPRING,ELSET=D{direction}',str(direction),str(SPRING_STIFFNESS)]
    lines += ['*RIGID BODY,NSET=Markers,REF NODE=100,ROT NODE=101',
        '*STEP,NLGEOM,INC=200','*STATIC','.05,1.,1e-6,.05','*CLOAD',
        *(f'1,{j+1},{v:.17g}' for j,v in enumerate(FORCE)),
        '*NODE PRINT,NSET=Ports,FREQUENCY=1','U,RF','*END STEP']
    return '\n'.join(lines)+'\n'


def free_spring_expected():
    """Global minimizer of 1/2 k sum|R r_i+t-r_i|² - F·u_1.

    Eliminating translation leaves maximization of tr(R A), where
    A=k sum p_i p_i^T+p_1 F^T and p_i=r_i-mean(r). Proper orthogonal
    Procrustes supplies the remaining finite rotation without Newton iteration.
    """
    center=MARKERS.mean(axis=0);centered=MARKERS-center
    action=SPRING_STIFFNESS*centered.T@centered+np.outer(centered[0],FORCE)
    u,s,vh=np.linalg.svd(action)
    sign=np.linalg.det(vh.T@u.T)
    matrix=vh.T@np.diag((1.,1.,sign))@u.T
    translation=FORCE/(3*SPRING_STIFFNESS)-(matrix-np.eye(3))@center
    positions=MARKERS@matrix.T+translation
    displacement=positions-MARKERS
    net_force=FORCE-SPRING_STIFFNESS*displacement.sum(axis=0)
    net_moment=np.cross(positions[0],FORCE)-SPRING_STIFFNESS*np.cross(positions,displacement).sum(axis=0)
    assert np.linalg.norm(net_force)<1e-12 and np.linalg.norm(net_moment)<1e-12
    return dict(marker_displacements=displacement.tolist(),reference_displacement=translation.tolist(),
        rotation_coordinate=Rotation.from_matrix(matrix).as_rotvec().tolist(),
        net_force=net_force.tolist(),net_moment=net_moment.tolist(),singular_values=s.tolist(),
        energy=float(.5*SPRING_STIFFNESS*np.sum(displacement**2)-FORCE@displacement[0]))


if __name__=='__main__':
    import argparse,json
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--free-springs',action='store_true')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=False)
    (args.output/'pose.inp').write_text(free_spring_deck() if args.free_springs else deck(),encoding='ascii')
    (args.output/'expected.json').write_text(json.dumps(free_spring_expected() if args.free_springs else expected(),indent=2))
