from pathlib import Path
import importlib.util,hashlib,os,sys,json,shutil
r=Path(os.environ['TEMP'])/'r8-e04-ccx-pose-v1'
p=Path('C:/Github/ANYsolver/.qualification/b3-ge-e4-pl/calculix-223/CalculiX-2.23.0-win-x64/bin/ccx.exe')
assert hashlib.sha256(p.read_bytes()).hexdigest()=='27a9426a1ee2f72c38fbe892e0ffaf38e14867628ffd0235770261b6f3ec9c5f'
spec=importlib.util.spec_from_file_location('supervisor',r.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
# Supervisor creates the execution folder; stage input immediately after creation.
original=s.subprocess.Popen
def start(command,**kwargs):
 shutil.copy2(r/'input/pose.inp',Path(kwargs['cwd'])/'pose.inp')
 return original(command,**kwargs)
s.subprocess.Popen=start
record=s.supervised([str(p),'-i','pose'],r/'execute')
print(json.dumps({k:record[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
