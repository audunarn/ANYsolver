from pathlib import Path
from dataclasses import asdict
import hashlib,json,sys,zipfile
import numpy as np,numba,threadpoolctl
from anyfem.solve.stiffened_shell_b2 import ExperimentalB2PointPanel,save_case,load_case
from test_experimental_b2_stiffened_shell_consumer import _panel
r=Path.cwd();site=Path(sys.argv[1]).resolve();artifact=site.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((artifact/'prepared-manifest.json').read_text())
wheels={}
for package,files in manifest['modules'].items():
    wheel=next((artifact/'wheels').glob(package+'-*.whl'));wheels[wheel.name]=sha(wheel)
    with zipfile.ZipFile(wheel) as z:
        assert {p for p in z.namelist() if p.startswith(package+'/') and p.endswith('.py')}==set(files)
        for p,h in files.items():assert sha(site/p)==h and z.read(p)==(site/p).read_bytes(),p
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
import runpy,io,contextlib
example=Path(sys.argv[3]).resolve();mode=sys.argv[4]
sys.argv=[str(example)]+(['--supported'] if mode=='supported' else [])
output=io.StringIO()
with contextlib.redirect_stdout(output):runpy.run_path(str(example),run_name='__main__')
result=json.loads(output.getvalue())
assert result['status']=='completed' and result['factorization_count']==1
assert result['production_qualified'] is False
assert result['rigid_mode_count']==(0 if mode=='supported' else 6)
assert len(result['frequencies_hz'])==result['request']['count']
(r/'result.json').write_text(json.dumps(result,indent=2))
(r/'example-source.py').write_bytes(example.read_bytes())
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0] in ('anysolver','anyfem') and getattr(m,'__file__',None)}
assert all(Path(p).is_relative_to(site) for p in imports.values())
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
(r/'identity.json').write_text(json.dumps({'wheels':wheels,'modules':{p:len(f) for p,f in manifest['modules'].items()},'imports':imports,'threads':pools,'numba_threads':1,'jit_disabled':True,'fixture_sha256':sha(example)},indent=2))
print(json.dumps({'status':'passed','onsite_imports':len(imports),'mode':mode,'rigid_mode_count':result['rigid_mode_count'],'frequencies_hz':result['frequencies_hz']}))
