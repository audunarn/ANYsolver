from pathlib import Path
from dataclasses import asdict
import hashlib,json,sys,zipfile
import numpy as np,numba,threadpoolctl
from anyfem.solve.stiffened_shell_b2 import ExperimentalB2PointPanel,save_case,load_case
from test_experimental_b2_stiffened_shell_consumer import _panel
r=Path.cwd();site=Path(sys.argv[1]).resolve();artifact=site.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((artifact/'prepared-manifest.json').read_text())
wheels={}
for package,files in manifest['modules'].items():
    wheel=next((artifact/'wheels').glob(package+'-*.whl'));wheels[wheel.name]=sha(wheel)
    with zipfile.ZipFile(wheel) as z:
        assert {p for p in z.namelist() if p.startswith(package+'/') and p.endswith('.py')}==set(files)
        for p,h in files.items():assert sha(site/p)==h and z.read(p)==(site/p).read_bytes(),p
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
from dataclasses import replace
from anysolver import stiffened_shell as api
from anyfem.solve.stiffened_shell import save_case as save_ge,load_case as load_ge
from test_experimental_stiffened_shell_consumer import _case,_j2_fibre_case,_bl5_case
from test_stiffened_shell_staged_load_consumer import _panel as _staged
from test_stiffened_shell_nodal_footprint_consumer import _footprint
records={'point-v1':_case(),'j2-fibre-v2':_j2_fibre_case(False,False),
 'q4-pullback-v3':replace(_case(),q4_pullback_policy=api.Q4_ALGORITHMIC_PULLBACK_V1),
 'staged-v4':_staged(),'q4-footprint':_footprint(),
 'mixed-footprint':_footprint(True),'bl5':_bl5_case()}
for name,record in records.items():
 path=r/(name+'.anyfem-ge.json');save_ge(record,path);reopened=load_ge(path)
 assert reopened.to_dict()==record.to_dict()
(r/'payloads-identity.json').write_text(json.dumps({name:sha(r/(name+'.anyfem-ge.json')) for name in records},indent=2))
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0] in ('anysolver','anyfem') and getattr(m,'__file__',None)}
assert all(Path(p).is_relative_to(site) for p in imports.values())
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
(r/'identity.json').write_text(json.dumps({'wheels':wheels,'modules':{p:len(f) for p,f in manifest['modules'].items()},'imports':imports,'threads':pools,'numba_threads':1,'jit_disabled':True,'fixture_sha256':sha(Path(sys.argv[2])/'test_experimental_b2_stiffened_shell_consumer.py')},indent=2))
print(json.dumps({'status':'passed','onsite_imports':len(imports),'legacy_input_records':len(records)}))
