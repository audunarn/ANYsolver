from pathlib import Path
import hashlib,json,zipfile
r=Path('C:/Users/AUDUNA~1/AppData/Local/Temp');out=r/'r8-ge-modal-consumer-evidence-v1.zip';assert not out.exists()
files={}
def add(p,key):
 if p.is_file():
  assert key not in files,key
  files[key]=p
for name in ('r8-ge-modal-consumer-source-v1','r8-ge-modal-consumer-source-v2','r8-ge-modal-consumer-installed-v1','r8-ge-modal-consumer-payload-old-v1','r8-ge-modal-consumer-payload-new-v1','r8-ge-modal-consumer-example-free-v1','r8-ge-modal-consumer-example-free-v2','r8-ge-modal-consumer-example-supported-v1','r8-ge-modal-consumer-example-prepared-v1'):
 base=r/name;assert base.is_dir(),base
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if any(v in ('site','build-source','__pycache__','.pytest_cache') for v in rel.parts):continue
  if p.suffix in ('.pyc','.nbc','.nbi'):continue
  add(p,name+'/'+rel.as_posix())
 if (base/'build-source').exists():
  for n in ('stiffened_shell.py','stiffened_shell_project.py'):
   add(base/'build-source/src/anyfem/solve'/n,name+'/runtime-source/anyfem/solve/'+n)
for pattern in ('r8-ge-modal-consumer*.py','r8-ge-modal-consumer*.json','r8-ge-modal-consumer*.md','r8-prepare-ge-modal-consumer*.py'):
 for p in sorted(r.glob(pattern)):add(p,'notes-and-runners/'+p.name)
for n in ('r8-nodal-footprint-command-bounded.py','r8-nodal-footprint-run-bounded.py','r8-nodal-footprint-consumer-run-installed.py'):
 add(r/n,'notes-and-runners/reused-'+n)
base=r/'r8-b2-footprint-consumer-installed-v1';add(base/'prepared-manifest.json','legacy-baseline/prepared-manifest.json')
for p in (base/'wheels').glob('*.whl'):add(p,'legacy-baseline/wheels/'+p.name)
review=r/'r8-ge-modal-consumer-independent-review-v1.md';assert review.exists()
manifest={k:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'original_path':str(p.resolve())} for k,p in sorted(files.items())}
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for k,p in sorted(files.items()):z.write(p,k)
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(out) as z:
 for k,v in manifest.items():assert hashlib.sha256(z.read(k)).hexdigest()==v['sha256'],k
identity={'files':len(manifest),'raw_bytes':sum(v['bytes'] for v in manifest.values()),'archive_bytes':out.stat().st_size,'archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'scope':'explicit supported/free-free virgin Q4/generalized-GE modal input persistence/public dispatch; no wider spectral/consumer/engineering or aggregate qualification'}
(r/'r8-ge-modal-consumer-evidence-v1-identity.json').write_text(json.dumps(identity,indent=2));print(json.dumps(identity))
