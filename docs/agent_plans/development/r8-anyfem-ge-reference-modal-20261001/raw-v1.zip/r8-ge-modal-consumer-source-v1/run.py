import os,sys,json,hashlib
from pathlib import Path
root=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
solver=Path('C:/Github/ANYsolver/.perf2-worktrees/b3-ge-e4-pl-coupling')
out=Path(__file__).parent
sys.path[:0]=[str(root/'src'),str(solver/'src')]; os.chdir(root)
assert hashlib.sha256((solver/'src/anysolver/_stiffened_shell_ge_reference_modal.py').read_bytes()).hexdigest()=='eade169b9fbae1ad11b28c02d7068c8eacd6d72a6c3f8950608f971ecc9d778b'
import numpy,scipy,numba,pytest
from threadpoolctl import threadpool_limits,threadpool_info
numba.set_num_threads(1)
with threadpool_limits(limits=1):
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    code=pytest.main(['-q','tests/test_stiffened_shell_ge_reference_modal_consumer.py','--junitxml='+str(out/'inventory.xml'),'--basetemp='+str(out/'pytest-tmp')])
    pools=threadpool_info(); assert pools and all(p['num_threads']==1 for p in pools)
    imports={k:str(Path(v.__file__).resolve()) for k,v in sys.modules.items()
             if (k=='anyfem' or k.startswith('anyfem.') or k=='anysolver' or k.startswith('anysolver.')) and getattr(v,'__file__',None)}
    assert all(Path(p).is_relative_to((root if k.startswith('anyfem') else solver)/'src') for k,p in imports.items())
    (out/'runtime.json').write_text(json.dumps(dict(pools=pools,numba_threads=numba.get_num_threads(),jit_disabled=bool(numba.config.DISABLE_JIT),executable=sys.executable),indent=2))
    (out/'imports.json').write_text(json.dumps(imports,indent=2))
    raise SystemExit(code)
