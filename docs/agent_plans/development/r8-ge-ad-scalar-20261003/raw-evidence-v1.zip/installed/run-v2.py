from pathlib import Path
import ast, hashlib, importlib.util, json, os, shutil, subprocess, sys, zipfile
root=Path(__file__).parent
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
site=root/"site"; fixtures=root/"fixtures"
old=root.parent/"r8-q4-correction-installed-v1"
consumer=root.parent/"r8-ge-member-scale-installed-v1/consumer-site"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mode=sys.argv[1]
if mode=="prepare":
 fixtures.mkdir()
 for name,cmd in (("build",[sys.executable,"-m","pip","wheel","--no-deps","--no-build-isolation","--no-index","--no-cache-dir","--wheel-dir",str(root/"wheels"),str(repo)]),("install",None)):
  if cmd is None:
   wheel=next((root/"wheels").glob("*.whl"));cmd=[sys.executable,"-m","pip","install","--no-deps","--no-index","--no-cache-dir","--target",str(site),str(wheel)]
  with (root/(name+".log")).open("x") as out:subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,check=True)
 modules={}
 with zipfile.ZipFile(wheel) as z:
  for p in (repo/"src/anysolver").rglob("*.py"):
   n=p.relative_to(repo/"src").as_posix();assert p.read_bytes()==z.read(n)==(site/n).read_bytes(),n;modules[n]=sha(p)
 baseline=json.loads((old/"identity.json").read_text())
 assert baseline["wheel_sha256"]=="ad81df530f1eb8759b556af20adc125f464767939510dbd5aaab200d71683253"
 assert sha(Path(baseline["wheel"]))==baseline["wheel_sha256"]
 with zipfile.ZipFile(baseline["wheel"]) as z:
  for n,h in baseline["modules"].items():assert hashlib.sha256(z.read(n)).hexdigest()==h==sha(old/"site"/n),n
 pending=["test_ge_beam3_mixed_ad_scalars", "test_ge_beam3_mixed_core", "test_ge_beam3_variational_shell","test_stiffened_shell_q4_correction_reuse","test_stiffened_shell_q4_algorithmic_pullback","test_qualified_q4_assembly_authority","test_stiffened_shell_q4_rotation_arithmetic","test_stiffened_shell_ge_finite_experimental"]
 seen=set()
 while pending:
  n=pending.pop()
  if n in seen:continue
  seen.add(n);p=repo/"tests"/(n+".py");shutil.copyfile(p,fixtures/p.name)
  for x in ast.walk(ast.parse(p.read_text(encoding="utf-8-sig"))):
   if isinstance(x,ast.ImportFrom) and x.module and x.module.startswith("test_"):pending.append(x.module)
 (fixtures/"scripts").mkdir()
 for n in ("experimental_stiffened_ge_multi_member_panel","experimental_stiffened_ge_finite_panel"):
  shutil.copyfile(repo/"scripts"/(n+".py"),fixtures/"scripts"/(n+".py"))
 shutil.copytree(repo/"tests/data/stiffened_shell_q4_legacy",fixtures/"data/stiffened_shell_q4_legacy")
 (root/"pytest.ini").write_text("[pytest]\n",encoding="utf-8")
 (root/"identity.json").write_text(json.dumps(dict(source_commit="bccd4952",wheel=str(wheel),wheel_sha256=sha(wheel),site=str(site),modules=modules,baseline=baseline,fixtures={str(p.relative_to(fixtures)):sha(p) for p in fixtures.rglob("*.py")}),indent=2))
 print(json.dumps(dict(modules=len(modules),wheel_sha256=sha(wheel))));raise SystemExit()
if mode=="checks-child":
 import anysolver,anyfem,numba,threadpoolctl,pytest
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 targets=["test_ge_beam3_mixed_ad_scalars.py", "test_ge_beam3_mixed_core.py", "test_ge_beam3_variational_shell.py","test_stiffened_shell_q4_correction_reuse.py","test_stiffened_shell_q4_algorithmic_pullback.py","test_qualified_q4_assembly_authority.py","test_stiffened_shell_q4_rotation_arithmetic.py",
 "test_stiffened_shell_ge_finite_experimental.py::test_elastic_unload_uses_new_checkpoint_without_changing_legacy_format",
 "test_stiffened_shell_ge_finite_experimental.py::test_binary_checkpoint_restores_finite_prefix_and_continues",
 "test_stiffened_shell_ge_finite_experimental.py::test_generalized_beam_unload_reload_preserves_history_across_restart",
 "test_stiffened_shell_ge_finite_experimental.py::test_q4_shell_and_beam_yield_atomically_and_restart",
 "test_stiffened_shell_ge_finite_experimental.py::test_rejected_and_cancelled_finite_trials_keep_accepted_prefix",
 "test_stiffened_shell_ge_finite_experimental.py::test_finite_mixed_and_s3_panels_restart_and_continue",
 "test_corotational.py::test_consistent_corotational_tangent_matches_force_jacobian",
 "test_corotational.py::test_legacy_corotational_shell_preserves_registered_900n_comparison"]
 code=pytest.main(["-q","-p","no:cacheprovider","-c",str(root/"pytest.ini"),"--basetemp=temporary","--junitxml=result.xml",*[str(fixtures/t) for t in targets]])
 pools=threadpoolctl.threadpool_info();assert pools and all(p["num_threads"]==1 for p in pools)
 assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
 imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith(("anysolver","anyfem")) and getattr(m,"__file__",None)}
 for n,p in imports.items():assert Path(p).is_relative_to((consumer if n.startswith("anyfem") else site).resolve()),(n,p)
 Path("runtime.json").write_text(json.dumps(dict(imports=imports,pools=pools,jit_disabled=True,numba_threads=1,python=sys.version),indent=2));raise SystemExit(code)
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(site,consumer,fixtures)))
r=s.supervised([sys.executable,"-u",str(Path(__file__)),mode+"-child"],root/(mode+"-v2"))
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
