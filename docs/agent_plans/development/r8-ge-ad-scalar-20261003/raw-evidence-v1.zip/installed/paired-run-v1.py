from pathlib import Path
import hashlib,importlib.util,json,os,statistics,sys,time
root=Path(__file__).parent; mode=sys.argv[1]
fixtures=root/"fixtures";candidate=root/"site";baseline=root.parent/"r8-q4-correction-installed-v1/site"
if mode in ("child","probe-child"):
 label,case,index=sys.argv[2:]; site=candidate if label=="candidate" else baseline
 import anysolver,numpy as np,numba,threadpoolctl
 from dataclasses import replace
 from anysolver import stiffened_shell as ss
 from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
 from scripts.experimental_stiffened_ge_finite_panel import physical_balance
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 pools=threadpoolctl.threadpool_info();assert pools and all(p["num_threads"]==1 for p in pools)
 assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
 def route(spec,warm=False):
  start=time.perf_counter();definition=replace(make_definition(*spec[:2],**spec[2]),q4_pullback_policy=ss.Q4_ALGORITHMIC_PULLBACK_V1)
  actions=actions_for(definition);owner=ss.create_analysis(definition=definition);history=[]
  setup=time.perf_counter()-start
  def accepted(r):history.append(dict(factor=r.load_factor,generation=r.generation,iterations=r.iterations))
  try:
   result=owner.solve(actions,(.01,.02),max_iterations=8,max_backtracks=4,on_accepted=accepted)
   recovered=owner.recover();raw=owner.checkpoint();elapsed=time.perf_counter()-start
   assert result.status=="completed" and not result.production_qualified
   force,moment=physical_balance(definition,result,actions)
   assert force<=1e-8 and moment<=1e-8
   assert result.free_equilibrium_ratio<=1e-8 and result.constraint_max<=1e-9
   if not warm:
    np.savez("physical.npz",**{n:getattr(result,n) for n in ("shell_displacement","beam_positions","beam_frames","cell_frames","cell_resultants","multipliers","support_reactions")})
    Path("checkpoint.bin").write_bytes(raw)
    return dict(label=label,case=case,pair=int(index),complete_route_seconds=elapsed,setup_seconds=setup,
     history=history,status=result.status,qualified=False,eq=result.free_equilibrium_ratio,gap=result.constraint_max,
     force_balance=force,moment_balance=moment,preflight=owner.preflight(),pools=pools,jit_disabled=True,
     numba_threads=1,import_location=str(anysolver.__file__))
  finally:owner.close()
 route((2,2,{}),True)
 spec=(8,4,{}) if case=="screen" else (20,6,dict(shell_transverse_cells=20,tie_stride=2)) if case=="middle" else (4,3,{})
 if mode=="probe-child":
  import cProfile,pstats
  profile=cProfile.Profile();profile.enable()
  try:report=route(spec)
  finally:profile.disable();profile.dump_stats("route.pstats")
  counts=[]
  for (filename,line,name),(primitive,total,selftime,cumulative,callers) in pstats.Stats(profile).stats.items():
   if name in ("_qualified_linear_correction","_assemble","evaluate","_advance","_factorize","spatial_response","response") and "anysolver" in filename:
    counts.append(dict(file=filename,line=line,name=name,primitive=primitive,total=total,self_seconds=selftime,cumulative_seconds=cumulative))
  Path("work.json").write_text(json.dumps(counts,indent=2))
 else:report=route(spec)
 Path("result.json").write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True);raise SystemExit()
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
case=sys.argv[2];first=int(sys.argv[3]);last=int(sys.argv[4])
for i in range(first,last+1):
 for label in (("baseline","candidate") if i%2 else ("candidate","baseline")):
  site=candidate if label=="candidate" else baseline
  s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(site,fixtures)))
  folder=root/f"{mode}-{case}-{i}-{label}"
  if folder.exists():
   r=json.loads((folder/"execution.json").read_text())
   prior=json.loads((folder/"result.json").read_text())
   assert r["exit_code"]==0 and r["resource_limit"] is None and prior["label"]==label and prior["case"]==case and prior["pair"]==i
  else:r=s.supervised([sys.executable,"-u",str(Path(__file__)),("probe-child" if mode=="probe" else "child"),label,case,str(i)],folder)
  a=json.loads((root/f"{mode}-{case}-{i}-{label}/result.json").read_text());print(json.dumps(dict(case=case,pair=i,label=label,seconds=a["complete_route_seconds"],peak=r["sampled_peak_tree_bytes"])),flush=True)
 import numpy as np
 a=root/f"{mode}-{case}-{i}-baseline";b=root/f"{mode}-{case}-{i}-candidate"
 ar,br=(json.loads((p/"result.json").read_text()) for p in (a,b))
 assert ar["history"]==br["history"] and ar["preflight"]==br["preflight"]
 with np.load(a/"physical.npz") as aa,np.load(b/"physical.npz") as bb:
  for name in aa.files:np.testing.assert_array_equal(aa[name],bb[name])
 assert (a/"checkpoint.bin").read_bytes()==(b/"checkpoint.bin").read_bytes()
print(json.dumps(dict(status="PASSED",case=case,first=first,last=last,exact_physical_and_checkpoint=True)),flush=True)
