from pathlib import Path
import importlib.util,json,os,sys
root=Path(__file__).parent;installed=root.parent/"r8-q4-correction-installed-v1";site=installed/"site";fixtures=installed/"fixtures"
if len(sys.argv)>1:
 import numpy as np,anysolver,numba,threadpoolctl,time,hashlib
 from dataclasses import replace
 from collections import Counter
 from anysolver import stiffened_shell as ss
 from anysolver._ge_beam3_mixed_ad import Jet2
 from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
 from scripts.experimental_stiffened_ge_finite_panel import physical_balance
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 binding=json.loads((installed/"artifact-binding-v1.json").read_text(encoding="utf-8"))
 for p,h in binding["dependency_modules"].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
 for n,h in binding["modules"].items():assert hashlib.sha256((site/n).read_bytes()).hexdigest()==h
 pools=threadpoolctl.threadpool_info();assert pools and all(p["num_threads"]==1 for p in pools)
 assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
 codes={getattr(Jet2,n).__code__:n for n in ("__add__","__sub__","__rsub__","__mul__","__truediv__","__rtruediv__")}
 counts=Counter();dimensions=Counter()
 def constant(j):return not np.count_nonzero(j.gradient) and not np.count_nonzero(j.hessian)
 def profile(frame,event,arg):
  if event!="call":return
  name=codes.get(frame.f_code)
  if name is None:return
  other=frame.f_locals["other"];left=frame.f_locals["self"]
  dimensions[str(left.gradient.size)]+=1
  if isinstance(other,Jet2):
   kind="both_constant" if constant(left) and constant(other) else "left_constant" if constant(left) else "right_constant" if constant(other) else "both_varying"
  else:kind="raw_scalar"
  counts[name+":"+kind]+=1
 definition=replace(make_definition(4,3),q4_pullback_policy=ss.Q4_ALGORITHMIC_PULLBACK_V1)
 owner=ss.create_analysis(definition=definition)
 try:
  start=time.perf_counter();sys.setprofile(profile)
  try:result=owner.solve(actions_for(definition),(.01,.02),max_iterations=8,max_backtracks=4)
  finally:sys.setprofile(None)
  elapsed=time.perf_counter()-start;force,moment=physical_balance(definition,result,actions_for(definition))
  assert result.status=="completed" and not result.production_qualified and force<=1e-8 and moment<=1e-8
  report=dict(status=result.status,qualified=False,diagnostic_seconds=elapsed,counts=dict(sorted(counts.items())),dimensions=dict(dimensions),accepted_factors=result.accepted_factors,iterations=result.iterations,eq=result.free_equilibrium_ratio,gap=result.constraint_max,force_balance=force,moment_balance=moment,pools=pools,jit_disabled=True,numba_threads=1,solver_site=str(site),wheel_sha256=binding["wheel_sha256"],method_code_unmodified=True)
  Path("result.json").write_text(json.dumps(report,indent=2),encoding="utf-8");print(json.dumps(report),flush=True)
 finally:owner.close()
 raise SystemExit()
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(site,fixtures)))
r=s.supervised([sys.executable,"-u",str(Path(__file__)),"child"],root/"census-v1")
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
