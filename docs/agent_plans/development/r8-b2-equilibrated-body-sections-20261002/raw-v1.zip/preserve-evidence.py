from pathlib import Path
import hashlib, json, os, zipfile

temp = Path(__file__).resolve().parent.parent
root = Path(__file__).resolve().parent
repo = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
home = repo/'docs/agent_plans/development/r8-b2-equilibrated-body-sections-20261002'
home.mkdir(exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
payload = {}
for version in ('v1','v2','v3','v4','v5'):
    folder=temp/('r8-b2-loaded-sections-source-'+version)
    for path in sorted(folder.rglob('*')):
        if path.is_file(): payload['source-'+version+'/'+path.relative_to(folder).as_posix()]=path.read_bytes()
for version in ('v1','v2'):
    installed=temp/('r8-b2-loaded-sections-installed-'+version)
    for name in ('coordinator.log','build-solver.py','run-installed.py','installed-check.py',
                 'body-example.py','solver-source-manifest.json','solver-wheel-identity.json','fixture-manifest.json'):
        payload['installed-'+version+'/'+name]=(installed/name).read_bytes()
    for name in ('build','tests','example-q4','example-mixed','example-s3','fixtures','solver-artifact/wheels'):
        for path in sorted((installed/name).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                payload['installed-'+version+'/'+path.relative_to(installed).as_posix()]=path.read_bytes()
payload['preserve-evidence.py']=Path(__file__).read_bytes()
supervisor=temp/'r8-b2-panel-resolution-installed-v1/matched-run.py'
payload['supervisor/matched-run.py']=supervisor.read_bytes()
for name in ('src/anysolver/_b2_physical_flexibility_linear.py', 'src/anysolver/_b2_f10_f11_point_attachment.py', 'tests/test_b2_equilibrated_body_sections.py', 'src/anysolver/_stiffened_shell_b2_q4_panel_experimental.py',
             'src/anysolver/stiffened_shell.py','tests/test_stiffened_shell_b2_body_acceleration.py',
             'examples/stiffened_shell_b2_body_acceleration.py'):
    payload['candidate/'+name]=(repo/name).read_bytes()
# Inspect known inherited credentials entirely in memory; never print values or
# redistribute the protected historical source. Scan nested wheel contents too.
historical=repo/'docs/agent_plans/development/r8-b2-mixed-reference-modes-20261002/us3-modal-canary-v1.zip'
with zipfile.ZipFile(historical) as archive:
    name,= [name for name in archive.namelist() if name.endswith('execution-identity.json')]
    metadata=json.loads(archive.read(name))
    environment=metadata['environment']
    secrets=[str(v).encode() for k,v in environment.items() if v and k.endswith('API_KEY')]
secrets += [v.encode() for k,v in os.environ.items() if v and k.endswith('API_KEY')]
for name,data in payload.items():
    if any(value in data for value in secrets):
        raise RuntimeError('credential scan failed: '+name)
    if name.endswith('.whl'):
        from io import BytesIO
        with zipfile.ZipFile(BytesIO(data)) as wheel:
            if any(value in wheel.read(member) for member in wheel.namelist() for value in secrets):
                raise RuntimeError('credential scan failed in wheel')
inventory={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(payload.items())}
archive=home/'raw-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as output:
    for name,data in sorted(payload.items()): output.writestr(name,data)
identity=dict(archive_sha256=sha(archive.read_bytes()),members=len(payload),bytes=archive.stat().st_size,
              credential_value_scan='clear; historical credentials inspected in memory, original archive not copied',
              source_base='7c91e4a5',wheel=json.loads((root/'solver-wheel-identity.json').read_text()),
              inventory=inventory)
(home/'raw-v1.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:identity[k] for k in ('archive_sha256','members','bytes','credential_value_scan')}))
