from pathlib import Path
import ast, hashlib, importlib.util, json, os, shutil, sys

root = Path(__file__).resolve().parent
source = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
supervisor = Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-panel-resolution-installed-v1/matched-run.py')
spec = importlib.util.spec_from_file_location('bounded_supervisor', supervisor)
service = importlib.util.module_from_spec(spec); spec.loader.exec_module(service)
service.supervised([sys.executable, str(root/'build-solver.py')], root/'build')
fixtures = root/'fixtures'
(fixtures/'tests').mkdir(parents=True)
(fixtures/'scripts').mkdir()
targets = ['test_b2_equilibrated_body_sections', 'test_b2_physical_flexibility_linear', 'test_b2_f10_f11_point_attachment', 'test_b2_f10_f11_s3_point_attachment', 'test_b2_f13_affine_batch_dev', 'test_stiffened_shell_b2_q4_panel_experimental', 'test_stiffened_shell_b2_nodal_rigid_footprint', 'test_stiffened_shell_b2_body_acceleration', 'test_stiffened_shell_b2_reference_modes',
           'test_stiffened_shell_b2_mixed_reference_modes', 'test_stiffened_shell_b2_footprint_reference_modes',
           'test_stiffened_shell_b2_mixed_panel_experimental']
pending, copied = list(targets), set()
while pending:
    name = pending.pop()
    if name in copied:
        continue
    path = source/'tests'/(name+'.py')
    shutil.copy2(path, fixtures/'tests'/path.name); copied.add(name)
    for item in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
        if isinstance(item, ast.ImportFrom) and item.module and item.module.startswith('test_'):
            pending.append(item.module)
        elif isinstance(item, ast.Import):
            pending.extend(x.name for x in item.names if x.name.startswith('test_'))
probe = 'probe_b3_ge_e4_pl_g0_f09_graph_reversal.py'
shutil.copy2(source/'scripts'/probe, fixtures/'scripts'/probe)
(fixtures/'pytest.ini').write_text('[pytest]\n', encoding='utf-8')
shutil.copy2(source/'examples/stiffened_shell_b2_body_acceleration.py', root/'body-example.py')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
(root/'fixture-manifest.json').write_text(json.dumps({p.relative_to(root).as_posix(): sha(p)
    for p in sorted(fixtures.rglob('*')) if p.is_file()}, indent=2), encoding='utf-8')
service.ENV.update(PYTHONPATH=os.pathsep.join((str(root/'solver-artifact/site'), str(fixtures/'tests'))),
                   PYTHONNOUSERSITE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
service.supervised([sys.executable, str(root/'installed-check.py')], root/'tests')
for mesh in ('q4', 'mixed', 's3'):
    service.supervised([sys.executable, str(root/'body-example.py'), '--mesh', mesh], root/('example-'+mesh))
print(json.dumps({'tests': str(root/'tests/identity.json'), 'examples': ['q4','mixed','s3']}))
