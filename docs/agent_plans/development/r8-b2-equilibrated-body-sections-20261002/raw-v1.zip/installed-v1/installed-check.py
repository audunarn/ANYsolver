from pathlib import Path
import hashlib, importlib.metadata, json, sys, zipfile
import numpy as np
import numba
from threadpoolctl import threadpool_info
import anysolver
from anysolver import stiffened_shell as api
import anysolver._b2_physical_flexibility_linear
import anysolver._b2_physical_linear_definition
import pytest

root = Path(__file__).resolve().parent
site = (root/'solver-artifact/site').resolve()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((root/'solver-source-manifest.json').read_text())
wheel, = (root/'solver-artifact/wheels').glob('*.whl')
with zipfile.ZipFile(wheel) as archive:
    for name, digest in manifest.items():
        relative = name.removeprefix('src/')
        assert hashlib.sha256(archive.read(relative)).hexdigest() == digest, relative
        assert sha(site/relative) == digest, relative
assert Path(anysolver.__file__).resolve().is_relative_to(site)
assert numba.get_num_threads() == 1 and numba.config.DISABLE_JIT == 1
assert all(p['num_threads'] == 1 for p in threadpool_info())
targets = ['test_b2_equilibrated_body_sections', 'test_b2_physical_flexibility_linear', 'test_b2_f10_f11_point_attachment', 'test_b2_f10_f11_s3_point_attachment', 'test_b2_f13_affine_batch_dev', 'test_stiffened_shell_b2_q4_panel_experimental', 'test_stiffened_shell_b2_nodal_rigid_footprint', 'test_stiffened_shell_b2_body_acceleration', 'test_stiffened_shell_b2_reference_modes',
           'test_stiffened_shell_b2_mixed_reference_modes', 'test_stiffened_shell_b2_footprint_reference_modes',
           'test_stiffened_shell_b2_mixed_panel_experimental']
arguments = ['-q', '-c', str(root/'fixtures/pytest.ini'), '--junitxml='+str(Path.cwd()/'junit.xml')]
arguments += [str(root/'fixtures/tests'/(name+'.py')) for name in targets]
code = pytest.main(arguments)
imported = {name: str(Path(module.__file__).resolve()) for name,module in sys.modules.items()
            if name.startswith('anysolver') and getattr(module,'__file__',None)}
assert all(Path(path).is_relative_to(site) for path in imported.values())
assert numba.get_num_threads() == 1 and numba.config.DISABLE_JIT == 1
assert all(p['num_threads'] == 1 for p in threadpool_info())
record = dict(exit_code=code, python=sys.version, source_modules=len(manifest), wheel_sha256=sha(wheel),
              imported_anysolver=imported, jit_disabled=int(numba.config.DISABLE_JIT),
              numba_threads=numba.get_num_threads(), threadpools=threadpool_info(),
              dependencies={name:importlib.metadata.version(name) for name in
                            ('numpy','scipy','numba','ANYmaterial','pytest','threadpoolctl','psutil')})
(Path.cwd()/'identity.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
sys.exit(code)
