from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).parent
source=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
artifact=root/'solver-artifact';artifact.mkdir()
build=root/'solver-build-source';build.mkdir()
shutil.copytree(source/'src',build/'src',ignore=shutil.ignore_patterns('__pycache__','*.egg-info'))
for name in ('pyproject.toml','MANIFEST.in','README.md','LICENSE','COPYRIGHT','LICENSING.md','THIRD_PARTY_NOTICES.md','dependency-licenses.json','CHANGELOG.md','MIGRATION.md'):
 shutil.copy2(source/name,build/name)
for line in (source/'MANIFEST.in').read_text().splitlines():
 if line.startswith('include docs/'):
  name=Path(line.removeprefix('include '));(build/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,build/name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p.relative_to(source).as_posix():sha(p) for p in sorted((source/'src/anysolver').rglob('*.py'))}
(root/'solver-source-manifest.json').write_text(json.dumps(manifest,indent=2))
(artifact/'wheels').mkdir()
subprocess.run([sys.executable,'-m','pip','wheel','--no-index','--no-deps','--no-build-isolation','--no-cache-dir','--wheel-dir',str(artifact/'wheels'),str(build)],check=True,timeout=120)
wheel,=(artifact/'wheels').glob('*.whl')
subprocess.run([sys.executable,'-m','pip','install','--no-index','--no-deps','--no-cache-dir','--target',str(artifact/'site'),str(wheel)],check=True,timeout=60)
(root/'solver-wheel-identity.json').write_text(json.dumps({'wheel_sha256':sha(wheel),'source_modules':len(manifest)},indent=2))
print(json.dumps({'wheel_sha256':sha(wheel),'source_modules':len(manifest)}))
