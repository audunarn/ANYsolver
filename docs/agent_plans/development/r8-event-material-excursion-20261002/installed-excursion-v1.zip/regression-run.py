from pathlib import Path
import sys,json,hashlib,importlib.util,os
r=Path(__file__).parent;old=r.parent/'r8-generalized-recovery-installed-v1'
if len(sys.argv)>1:
 import anysolver,numba,threadpoolctl,pytest
 assert Path(anysolver.__file__).resolve().is_relative_to((old/'site').resolve())
 artifact=json.loads((old/'artifact.json').read_text())
 for name,digest in artifact['modules'].items():assert hashlib.sha256((old/'site'/name).read_bytes()).hexdigest()==digest
 code=pytest.main(['-q','-p','no:cacheprovider','--basetemp='+str(Path.cwd()/'basetemp'),'--junitxml=result.xml',str(r/'regression/test_stiffened_shell_event_material_excursion.py')])
 imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith('anysolver') and getattr(m,'__file__',None)}
 assert all(Path(p).is_relative_to((old/'site').resolve()) for p in imports.values())
 pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
 assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
 Path('runtime.json').write_text(json.dumps(dict(imports=imports,pools=pools,jit_disabled=True,python=sys.version),indent=2))
 raise SystemExit(code)
else:
 spec=importlib.util.spec_from_file_location('supervisor',r.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV['PYTHONPATH']=str(old/'site')+os.pathsep+str(old/'fixtures');s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
 v=s.supervised([sys.executable,str(Path(__file__)),'child'],r/'regression-v1')
 print(json.dumps({k:v[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
