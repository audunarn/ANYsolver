from pathlib import Path
import sys,json,hashlib,importlib.util
root=Path(__file__).parent;installed=root.parent/'r8-generalized-recovery-installed-v1'
if len(sys.argv)>1:
 import numpy as np
 from math import fsum
 from decimal import Decimal,localcontext
 from dataclasses import asdict
 sys.path.insert(0,str(installed/'fixtures'))
 import anysolver,numba,threadpoolctl
 from anysolver import stiffened_shell as ss
 from test_stiffened_shell_bl5_coupled_material import coupled
 from test_stiffened_shell_bl5_finite import _action
 assert Path(anysolver.__file__).resolve().is_relative_to((installed/'site').resolve())
 owner=ss.create_analysis(definition=coupled());restored=None
 seed=(root.parent/'r8-event-material-excursion-v1/step-1.bin').read_bytes();owner.restore(seed)
 restored=ss.create_analysis(definition=coupled());restored.restore(seed)
 artifact=json.loads((installed/'artifact.json').read_text())
 for name,digest in artifact['modules'].items():assert hashlib.sha256((installed/'site'/name).read_bytes()).hexdigest()==digest
 kw=dict(displacement_control=ss.DisplacementControl('beam',105,2,trial_policy=ss.GENERALIZED_BRANCH_EVENT_TRIAL),max_iterations=20,max_backtracks=12)
 data=dict(wheel_sha256=json.loads((installed/'artifact.json').read_text())['wheel_sha256'],seed_sha256=hashlib.sha256(seed).hexdigest(),targets=[-70e-6,-72e-6],rows=[])
 def capture(result,index):
  records=[row for element in result.beam_generalized_material for row in element.stations]
  alpha=np.array([row.accumulated for row in records]);shell=np.array(result.shell_layer_alpha)
  np.savez(root/f'state-{index}.npz',beam_accumulated=alpha,shell_alpha=shell,
   strain=np.array([r.local_strain+r.local_strain_low for r in records]),
   resultants=np.array([r.local_resultants+r.local_resultants_low for r in records]),
   plastic=np.array([r.plastic_strain+r.plastic_strain_low for r in records]),
   dissipation=np.array([r.dissipation_per_length for r in records]),
   stored=np.array([r.stored_energy_per_length for r in records]),
   measure=np.array([r.measure for r in records]),beam_positions=result.beam_positions,applied_load=result.applied_dead_load)
  dof=owner._shell_count+6*owner._beam_index[105]+2
  row=dict(target=result.target,load=float(result.applied_dead_load[dof]),amplitude=result.amplitude,
   generation=result.generation,equilibrium=result.free_equilibrium_ratio,gap=result.constraint_max,
   event_cell_evaluations=result.event_cell_evaluations,
   beam_stored_j=fsum(r.measure*fsum(r.stored_energy_per_length) for r in records),
   beam_incremental_dissipation_j=fsum(r.measure*fsum(r.dissipation_per_length) for r in records),
   beam_branches=[r.branch for r in records],shell_alpha_max=float(np.max(shell)))
  assert result.free_equilibrium_ratio<=1e-8 and result.constraint_max<=1e-9
  assert all(fsum(r.dissipation_per_length)>=0 for r in records)
  if index:
   previous=np.load(root/f'state-{index-1}.npz')
   with localcontext() as c:
    c.prec=80
    changes=[sum(map(Decimal.from_float,a))-sum(map(Decimal.from_float,b)) for a,b in zip(alpha,previous['beam_accumulated'])]
   row['beam_min_accumulated_increment']=float(min(changes))
   floor=64*np.finfo(float).eps*max(np.max(abs(alpha)),np.max(abs(previous['beam_accumulated'])),np.finfo(float).tiny)
   assert min(changes)>=-Decimal.from_float(float(floor))
   changes=shell-previous['shell_alpha'];row['shell_min_alpha_increment']=float(np.min(changes))
   floor=64*np.finfo(float).eps*max(np.max(abs(shell)),np.max(abs(previous['shell_alpha'])),np.finfo(float).tiny)
   assert np.min(changes)>=-floor
  return row
 try:
  for index,target in enumerate(data['targets']):
   before=owner.checkpoint()
   try:result=owner.solve(_action(-15.625),(target,),**kw)
   except Exception:
    assert owner.checkpoint()==before
    (root/'failure-prefix.bin').write_bytes(before)
    raise
   raw=owner.checkpoint();(root/f'step-{index}.bin').write_bytes(raw)
   row=capture(result,index)
   if restored is not None:
    resumed=restored.solve(_action(-15.625),(target,),**kw)
    records=[r for e in resumed.beam_generalized_material for r in e.stations]
    np.savez(root/f'restored-{index}.npz',beam_accumulated=np.array([r.accumulated for r in records]),
     shell_alpha=np.array(resumed.shell_layer_alpha),
     strain=np.array([r.local_strain+r.local_strain_low for r in records]),
     resultants=np.array([r.local_resultants+r.local_resultants_low for r in records]),
     plastic=np.array([r.plastic_strain+r.plastic_strain_low for r in records]),
     dissipation=np.array([r.dissipation_per_length for r in records]),
     stored=np.array([r.stored_energy_per_length for r in records]),
     measure=np.array([r.measure for r in records]),beam_positions=resumed.beam_positions,applied_load=resumed.applied_dead_load)
    assert restored.checkpoint()==raw
    row['restart_exact']=True
   data['rows'].append(row);(root/'result.json').write_text(json.dumps(data,indent=2))
   if False:
    restored=ss.create_analysis(definition=coupled());restored.restore(raw)
    assert restored.checkpoint()==raw
  data['status']='completed'
 except Exception as error:
  data['status']='failed';data['failure']=dict(type=type(error).__name__,message=str(error))
  if getattr(error,'detail',None) is not None:data['failure']['detail']=asdict(error.detail)
  raise
 finally:
  pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
  assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
  data['runtime']=dict(pools=pools,jit_disabled=True,python=sys.version)
  (root/'result.json').write_text(json.dumps(data,indent=2));owner.close()
  if restored is not None:restored.close()
else:
 spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV['PYTHONPATH']=str(installed/'site');s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
 v=s.supervised([sys.executable,str(Path(__file__)),'child'],root/'run-v1')
 print(json.dumps({k:v[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
