import sys,json
import anysolver,anyfem,pytest
from threadpoolctl import threadpool_info
print(json.dumps(dict(imports=dict(anysolver=anysolver.__file__,anyfem=anyfem.__file__))),flush=True)
code=pytest.main(["-q",*sys.argv[1:]])
print(json.dumps(dict(pools=threadpool_info())),flush=True)
assert all(p["num_threads"]==1 for p in threadpool_info())
raise SystemExit(code)
