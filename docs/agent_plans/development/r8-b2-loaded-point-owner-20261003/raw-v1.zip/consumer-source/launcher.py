from pathlib import Path
import os,importlib.util,sys
tmp=Path(os.environ["TEMP"]);root=tmp/"r8-b2-loaded-consumer-source-v1";root.mkdir(exist_ok=False)
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
fem=Path("C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer")
spec=importlib.util.spec_from_file_location("sup",tmp/"r8-b2-panel-resolution-installed-v1/matched-run.py")
sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)
sup.ENV["PYTHONPATH"]=os.pathsep.join(str(x) for x in (repo/"src",fem/"src",fem/"tests"))
targets=[fem/"tests"/n for n in ("test_experimental_b2_loaded_point_consumer.py","test_experimental_b2_body_acceleration_consumer.py","test_experimental_b2_stiffened_shell_consumer.py")]
child=root/"check.py";child.write_text('''import sys,json\nimport anysolver,anyfem,pytest\nfrom threadpoolctl import threadpool_info\nprint(json.dumps(dict(imports=dict(anysolver=anysolver.__file__,anyfem=anyfem.__file__))),flush=True)\ncode=pytest.main(["-q",*sys.argv[1:]])\nprint(json.dumps(dict(pools=threadpool_info())),flush=True)\nassert all(p["num_threads"]==1 for p in threadpool_info())\nraise SystemExit(code)\n''')
r=sup.supervised([sys.executable,str(child),*[str(p) for p in targets]],root/"run-v1")
print(r)

