from pathlib import Path
import os,importlib.util,sys,shutil,hashlib,json
tmp=Path(os.environ["TEMP"]);root=tmp/"r8-b2-loaded-owner-installed-v1"
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
scripts=root/"scripts";scripts.mkdir(exist_ok=False)
name="probe_b3_ge_e4_pl_g0_f09_graph_reversal.py";shutil.copy2(repo/"scripts"/name,scripts/name)
(root/"fixture-addition-v2.json").write_text(json.dumps(dict(path="scripts/"+name,
    sha256=hashlib.sha256((scripts/name).read_bytes()).hexdigest(),reason="existing imported F09 fixture helper; no main execution"),indent=2)+"\n")
s=(root/"check.py").read_text();s=s.replace("code=pytest.main", "from anysolver import _b2_physical_flexibility_linear,_b2_physical_linear_definition\ncode=pytest.main")
s=s.replace("raise SystemExit(code)","for name,m in tuple(sys.modules.items()):\n    if name.startswith(('anysolver.','anyfem.')) and getattr(m,'__file__',None):assert Path(m.__file__).resolve().is_relative_to(site),name\nraise SystemExit(code)")
child=root/"check-v2.py";child.write_text(s)
spec=importlib.util.spec_from_file_location("sup",tmp/"r8-b2-panel-resolution-installed-v1/matched-run.py")
sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)
sup.ENV["PYTHONPATH"]=os.pathsep.join(str(p) for p in (root/"site",root/"fixtures",root/"examples"))
names=["test_b2_loaded_point_owner.py","test_stiffened_shell_b2_q4_panel_experimental.py","test_b2_equilibrated_body_sections.py","test_stiffened_shell_b2_body_acceleration.py","test_experimental_b2_loaded_point_consumer.py","test_experimental_b2_body_acceleration_consumer.py","test_experimental_b2_stiffened_shell_consumer.py"]
r=sup.supervised([sys.executable,str(child),str(root/"site"),*[str(root/"fixtures"/n) for n in names]],root/"checks-v2")
print(json.dumps(dict(checks=r)),flush=True)
r=sup.supervised([sys.executable,str(root/"examples/stiffened_shell_b2_loaded_points.py"),"--cases","10","--consumer-path",str(root/"public-panel.anyfem-b2.json")],root/"example-v1")
print(json.dumps(dict(example=r)),flush=True)

