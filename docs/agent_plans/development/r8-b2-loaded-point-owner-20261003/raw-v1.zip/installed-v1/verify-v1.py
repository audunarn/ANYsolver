from pathlib import Path
import os,hashlib,zipfile,json,ast,shutil,importlib.util,sys
tmp=Path(os.environ["TEMP"]);root=tmp/"r8-b2-loaded-owner-installed-v1";site=root/"site"
solver=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
fem=Path("C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
bindings=[]
for label,repo,sub in (("anysolver",solver,"solver-dist"),("anyfem",fem,"fem-dist")):
    wheel=next((root/sub).glob("*.whl"))
    with zipfile.ZipFile(wheel) as z:
        names=sorted(n for n in z.namelist() if n.startswith(label+"/") and n.endswith(".py"))
        for n in names:
            if z.read(n)!=(repo/"src"/n).read_bytes() or z.read(n)!=(site/n).read_bytes():
                raise RuntimeError("source/wheel/site mismatch "+n)
    bindings.append(dict(package=label,wheel=str(wheel),sha256=sha(wheel),module_count=len(names),modules=names))
fixtures=root/"fixtures";fixtures.mkdir(exist_ok=False)
solver_names=["test_b2_loaded_point_owner.py","test_stiffened_shell_b2_q4_panel_experimental.py","test_b2_equilibrated_body_sections.py","test_stiffened_shell_b2_body_acceleration.py"]
fem_names=["test_experimental_b2_loaded_point_consumer.py","test_experimental_b2_body_acceleration_consumer.py","test_experimental_b2_stiffened_shell_consumer.py"]
todo=[solver/"tests"/n for n in solver_names]+[fem/"tests"/n for n in fem_names];copied={}
while todo:
    p=todo.pop()
    if p.name in copied:
        if copied[p.name]!=p:raise RuntimeError("ambiguous fixture name "+p.name)
        continue
    copied[p.name]=p;shutil.copy2(p,fixtures/p.name)
    for node in ast.walk(ast.parse(p.read_text(encoding="utf-8-sig"))):
        module=node.module if isinstance(node,ast.ImportFrom) and node.level==0 else None
        if module and module.startswith("test_"):
            candidates=[d/"tests"/(module+".py") for d in (solver,fem)]
            matches=[q for q in candidates if q.exists()]
            if len(matches)!=1:raise RuntimeError("fixture dependency ambiguous "+module)
            todo.extend(matches)
examples=root/"examples";examples.mkdir(exist_ok=False)
for n in ("stiffened_shell_b2_loaded_points.py","stiffened_shell_b2_body_acceleration.py"):
    shutil.copy2(solver/"examples"/n,examples/n)
binding=dict(source_commits=dict(anysolver="4bc228c8",anyfem="2ede338"),artifacts=bindings,
    tests={n:dict(source=str(p),sha256=sha(p)) for n,p in sorted(copied.items())},
    examples={n:sha(examples/n) for n in ("stiffened_shell_b2_loaded_points.py","stiffened_shell_b2_body_acceleration.py")})
(root/"binding-v1.json").write_text(json.dumps(binding,indent=2)+"\n")
spec=importlib.util.spec_from_file_location("sup",tmp/"r8-b2-panel-resolution-installed-v1/matched-run.py")
sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)
sup.ENV["PYTHONPATH"]=os.pathsep.join(str(p) for p in (site,fixtures,examples))
child=root/"check.py";child.write_text('''import sys,json\nfrom pathlib import Path\nimport anysolver,anyfem,anymaterial,numpy,scipy,numba,pytest\nfrom threadpoolctl import threadpool_info\nsite=Path(sys.argv[1]).resolve()\nfor m in (anysolver,anyfem):assert Path(m.__file__).resolve().is_relative_to(site)\nprint(json.dumps(dict(imports={m.__name__:m.__file__ for m in (anysolver,anyfem,anymaterial,numpy,scipy,numba,pytest)},versions={m.__name__:getattr(m,"__version__",None) for m in (numpy,scipy,numba,pytest)},numba_threads=numba.get_num_threads(),jit_disabled=numba.config.DISABLE_JIT)),flush=True)\ncode=pytest.main(["-q",*sys.argv[2:]])\nprint(json.dumps(dict(pools=threadpool_info())),flush=True)\nassert all(p["num_threads"]==1 for p in threadpool_info())\nraise SystemExit(code)\n''')
targets=[str(fixtures/n) for n in solver_names+fem_names]
r=sup.supervised([sys.executable,str(child),str(site),*targets],root/"checks-v1")
print(json.dumps(dict(bindings=[{k:v for k,v in b.items() if k!="modules"} for b in bindings],checks=r)),flush=True)
r=sup.supervised([sys.executable,str(examples/"stiffened_shell_b2_loaded_points.py"),"--cases","10","--consumer-path",str(root/"public-panel.anyfem-b2.json")],root/"example-v1")
print(json.dumps(dict(example=r)),flush=True)

