from pathlib import Path
import os,sys,shutil,importlib.util,hashlib,json
tmp=Path(os.environ["TEMP"]);root=tmp/"r8-b2-loaded-owner-installed-v1";examples=root/"examples-v2";examples.mkdir(exist_ok=False)
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
for n in ("stiffened_shell_b2_loaded_points.py","stiffened_shell_b2_body_acceleration.py"):
    shutil.copy2(repo/"examples"/n,examples/n)
(root/"example-binding-v2.json").write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in examples.iterdir()},indent=2)+"\n")
spec=importlib.util.spec_from_file_location("sup",tmp/"r8-b2-panel-resolution-installed-v1/matched-run.py")
sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)
sup.ENV["PYTHONPATH"]=os.pathsep.join(str(p) for p in (root/"site",examples))
r=sup.supervised([sys.executable,str(examples/"stiffened_shell_b2_loaded_points.py"),"--cases","10","--consumer-path",str(root/"public-panel.anyfem-b2.json")],root/"example-v2")
print(json.dumps(r))

