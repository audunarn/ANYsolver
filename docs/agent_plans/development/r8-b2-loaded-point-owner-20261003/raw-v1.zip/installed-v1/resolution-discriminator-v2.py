from pathlib import Path
from fractions import Fraction as Q
import os,sys,json,numpy as np
from anysolver import stiffened_shell as api
from stiffened_shell_b2_loaded_points import definition
from anysolver._b2_physical_flexibility_linear import _matmul,_transpose,_array
base=definition("q4")
d=api.B2Q4PanelDefinition(base.profile,base.shell_nodes_m,base.shells,base.members,base.points,base.transformation,base.prescribed_offset,point_trace_policy=api.B2_FIXED_END_LOADED_POINT_TRACE_V1_DEV)
a=api.create_analysis(definition=d);load=a.body_acceleration_load((0.,0.,-9.81));F=np.asarray(load.load)
bg=np.zeros(a._C.shape[0])
for m in a._loaded_members.values():
    v,_=m.body_constraint(load.acceleration_m_s2)
    ix=[6*i+c for i in m.point_indices for c in range(6)];bg[ix]=v
rhs=np.r_[a._project(F-a._ku0),-a._cu0-bg]
answer=a._factor_scale*a._handle.solve(a._factor_scale*rhs)
q,lam=answer[:a._T.shape[1]],answer[a._T.shape[1]:];u=a._T@q+a._u0
scale=np.asarray(a._abs_K@abs(u)+a._abs_Ct@abs(lam)+abs(F)).reshape(-1)
n=scale.reshape(-1,6);roundoff=np.tile((np.max(n[:,:3]),)*3+(np.max(n[:,3:]),)*3,len(n))
floor=len(rhs)*np.finfo(float).eps*np.asarray(a._abs_Tt@roundoff).reshape(-1)
project=a._project(F);bad=np.flatnonzero((abs(project)>0)&(floor>1e-9*abs(project)))
print(json.dumps(dict(certificate=a._explicit_load_resolved(answer,rhs,abs(project)),bad_rows=[dict(row=int(i),applied=float(project[i]),resolution_floor=float(floor[i])) for i in bad])))
def rat(m):return tuple(tuple(Q(float(v)) for v in row) for row in m)
differences=[]
for key,(m,slots) in a._members:
    body=rat(m.definition.mass.matrix_at_reference_axis()[:,:3])
    exact=_array(_matmul(_matmul(_matmul(_transpose(rat(m.local_dof_map())),m.operator._uniform_load_map),body),rat(m.definition.local_frame_rows())))
    old=a._body_map[slots] # contains shell/shared-member action, so separately compute private old member map
    from anysolver._stiffened_shell_b2_q4_panel_experimental import _beam_body_map
    oldlocal=_beam_body_map(m,m.local_dof_map())
    differences.append(dict(member=key,max_local_map_diff=float(np.max(abs(exact-oldlocal))),old_end_my=(oldlocal[4,2],oldlocal[10,2]),exact_end_my=(exact[4,2],exact[10,2])))
print(json.dumps(dict(member_maps=differences)))
np.savez(Path(sys.argv[1]),body_map=a._body_map,F=F,rhs=rhs,answer=answer,bad=bad)
a.close()

