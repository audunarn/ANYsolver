import sys,json
from pathlib import Path
import anysolver,anyfem,anymaterial,numpy,scipy,numba,pytest
from threadpoolctl import threadpool_info
site=Path(sys.argv[1]).resolve()
for m in (anysolver,anyfem):assert Path(m.__file__).resolve().is_relative_to(site)
print(json.dumps(dict(imports={m.__name__:m.__file__ for m in (anysolver,anyfem,anymaterial,numpy,scipy,numba,pytest)},versions={m.__name__:getattr(m,"__version__",None) for m in (numpy,scipy,numba,pytest)},numba_threads=numba.get_num_threads(),jit_disabled=numba.config.DISABLE_JIT)),flush=True)
from anysolver import _b2_physical_flexibility_linear,_b2_physical_linear_definition
code=pytest.main(["-q",*sys.argv[2:]])
print(json.dumps(dict(pools=threadpool_info())),flush=True)
assert all(p["num_threads"]==1 for p in threadpool_info())
for name,m in tuple(sys.modules.items()):
    if name.startswith(('anysolver.','anyfem.')) and getattr(m,'__file__',None):assert Path(m.__file__).resolve().is_relative_to(site),name
raise SystemExit(code)
