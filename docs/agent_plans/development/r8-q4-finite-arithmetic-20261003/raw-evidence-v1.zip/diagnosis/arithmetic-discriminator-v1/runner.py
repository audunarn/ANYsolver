from pathlib import Path
import importlib.util,json,os,sys
root=Path(__file__).parent
installed=root.parent/'r8-q4-reference-installed-v1';site=installed/'site'
if len(sys.argv)>1:
 import numpy as np,numba,threadpoolctl,anysolver
 from dataclasses import replace
 from scipy.sparse.linalg import spsolve
 from anysolver import stiffened_shell as ss
 from anysolver import corotational as c
 from anysolver._stiffened_shell_ge_finite_experimental import FinitePointDriver,_owned
 from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
 assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
 saved=np.load(root/'residual-direction-v2/last-trial.npz')
 owner=ss.create_analysis(definition=make_definition(8,4));driver=FinitePointDriver(owner)
 state=replace(driver._state,**{k:_owned(saved[k]) for k in ('q','frames','cells','resultants','multipliers')})
 pattern=driver._load(actions_for(owner._definition));free=np.r_[owner._free,np.arange(owner._K.shape[0],owner._K.shape[0]+len(state.multipliers))]
 original=c._corotational_deformation_state;rows=[]
 def deformation(centered,stable):
  def changed(ref,element,values):
   if ref.category!='shell':return original(ref,element,values)
   u=np.asarray(values).reshape(int(element.num_nodes),6);t=u[:,:3];rot=u[:,3:]
   arm=ref.coordinates-ref.centroid;offset=t-t.mean(axis=0)
   deformed=arm+offset if centered else ref.coordinates+t
   R=c._shell_center_frame(element,deformed)@ref.frame.T
   if stable:
    v=c.rotation_vector_from_matrix(R);angle=np.linalg.norm(v);hat=c._skew(v)
    difference=(np.sinc(angle/np.pi)*hat+.5*np.sinc(angle/(2*np.pi))**2*(hat@hat)).T
   else:difference=R.T-np.eye(3)
   out=np.zeros_like(u)
   for i in range(len(u)):
    out[i,:3]=R.T@offset[i]+difference@arm[i]
    out[i,3:]=c.rotation_vector_from_matrix(R.T@c.rotation_matrix_from_vector(rot[i]))
   return out.ravel(),R,deformed
  return changed
 try:
  for centered,stable in ((False,False),(False,True),(True,False),(True,True)):
   c._corotational_deformation_state=deformation(centered,stable)
   r,K,eq,gap,_=driver._assemble(state,.01,driver._shell_origins,driver._beam_origins,pattern=pattern)
   delta=np.zeros_like(r);delta[free]=spsolve(K[free,:][:,free],-r[free])
   nextstate=driver._advance(state,delta,1.)
   rn,Kn,eqn,gapn,_=driver._assemble(nextstate,.01,driver._shell_origins,driver._beam_origins,pattern=pattern)
   weights=owner._coordinate_scale[owner._free]
   row=dict(centered=centered,stable_rotation_difference=stable,equilibrium=eq,gap=gap,corrected_equilibrium=eqn,corrected_gap=gapn,relative_saved_residual_difference=float(np.linalg.norm((r-saved['residual'])[owner._free]*weights)/np.linalg.norm(saved['applied'][owner._free]*weights)))
   rows.append(row);print(json.dumps(row),flush=True)
  Path('result.json').write_text(json.dumps(dict(status='DIAGNOSTIC_COMPLETED',no_commit=True,generation=owner._generation,rows=rows,pools=pools,jit_disabled=True),indent=2),encoding='utf-8')
 finally:c._corotational_deformation_state=original;owner.close()
 raise SystemExit()
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(site,installed/'fixtures-v2')))
r=s.supervised([sys.executable,'-u',str(Path(__file__)),'child'],root/'arithmetic-discriminator-v1')
print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
