from pathlib import Path
import importlib.util,json,os,sys,time
root=Path(__file__).parent
installed=root.parent/"r8-q4-reference-installed-v1";site=installed/"site"
if len(sys.argv)>1:
    import numpy as np,anysolver,numba,threadpoolctl
    from dataclasses import asdict
    from scipy.sparse.linalg import spsolve
    from scipy.sparse import save_npz
    from anysolver import stiffened_shell as ss
    from anysolver._stiffened_shell_ge_finite_experimental import FinitePointDriver
    from anysolver._stiffened_shell_increment_control import FiniteIncrementFailure
    from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
    assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
    pools=threadpoolctl.threadpool_info();assert pools and all(p["num_threads"]==1 for p in pools)
    assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
    owner=ss.create_analysis(definition=make_definition(8,4))
    original=FinitePointDriver._assemble;observations=[];drivers=[]
    def observed(self,*args,**kwargs):
        drivers.append(self)
        output=original(self,*args,**kwargs)
        observations.append((args,kwargs.copy(),output[0].copy(),output[1].copy(),output[2],output[3]))
        return output
    FinitePointDriver._assemble=observed
    failure=None
    try:
        try:result=owner.solve(actions_for(owner._definition),(.01,),max_iterations=3,max_backtracks=2)
        except FiniteIncrementFailure as exc:failure=asdict(exc.attempt)
    finally:
        FinitePointDriver._assemble=original
    try:
        driver=drivers[-1]
        free=np.r_[owner._free,np.arange(owner._K.shape[0],owner._K.shape[0]+len(driver._state.multipliers))]
        seed_args,seed_kwargs,seed_r,seed_K,*_=observations[0]
        direction=np.zeros(seed_r.shape)
        direction[free]=spsolve(seed_K[free,:][:,free],-seed_r[free])
        args,kwargs,r,K,relative,gap=observations[-1]
        state,factor,shell_parent,beam_parent=args
        applied=factor*kwargs["pattern"]
        rows=[]
        for call,(_,kw,residual,_,ratio,cgap) in enumerate(observations):
            load=factor*kw["pattern"];active=load[owner._free]!=0.
            active_slots=owner._free[active]
            active_values=np.abs(residual[active_slots]/load[active_slots])
            highest=active_slots[np.argmax(active_values)]
            weights=owner._coordinate_scale[owner._free]
            global_ratio=float(np.linalg.norm(weights*residual[owner._free])/np.linalg.norm(weights*load[owner._free]))
            blocks={}
            beam_end=owner._shell_count+6*len(owner._beam_ids)
            for label,start,end in (("shell",0,owner._shell_count),("beam",owner._shell_count,beam_end),
                                    ("retained",beam_end,owner._K.shape[0])):
                slots=owner._free[(owner._free>=start)&(owner._free<end)]
                blocks[label]=float(np.linalg.norm(residual[slots]*owner._coordinate_scale[slots]))
            rows.append(dict(call=call,equilibrium=ratio,global_work_ratio=global_ratio,gap=cgap,
                largest_active_row=int(highest),largest_active_residual=float(residual[highest]),
                largest_active_applied=float(load[highest]),block_work_norms=blocks))
        expected=K@direction
        fd_rows=[]
        for h in (.3,.1,.03):
            plus=driver._advance(state,direction,h)
            minus=driver._advance(state,direction,-h)
            rp=original(driver,plus,factor,shell_parent,beam_parent,**kwargs)[0]
            rm=original(driver,minus,factor,shell_parent,beam_parent,**kwargs)[0]
            fd=(rp-rm)/(2*h)
            weights=owner._coordinate_scale[owner._free]
            error=float(np.linalg.norm((fd-expected)[owner._free]*weights)/np.linalg.norm(expected[owner._free]*weights))
            constraint_error=float(np.linalg.norm((fd-expected)[owner._K.shape[0]:]/owner._constraint_scale))
            fd_rows.append(dict(step=h,physical_work_relative_error=error,constraint_scaled_absolute_error=constraint_error))
        np.savez("last-trial.npz",q=state.q,frames=state.frames,cells=state.cells,
            resultants=state.resultants,multipliers=state.multipliers,residual=r,direction=direction,applied=applied)
        save_npz("last-tangent.npz",K)
        report=dict(diagnostic_status="COMPLETED",solver_status="FAILED_NUMERICAL" if failure else "completed",
            failure=failure,generation=owner._generation,observations=rows,actual_advance_derivatives=fd_rows,
            site=str(site),pools=pools,jit_disabled=True,numba_threads=1)
        Path("result.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
        print(json.dumps(dict(solver_status=report["solver_status"],failure=failure,derivatives=fd_rows)),flush=True)
    finally:owner.close()
    raise SystemExit()
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(site,installed/"fixtures-v2")))
r=s.supervised([sys.executable,"-u",str(Path(__file__)),"child"],root/"residual-direction-v2")
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
