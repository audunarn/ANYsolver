from pathlib import Path
import importlib.util,json,os,sys,time
root=Path(__file__).parent
installed=root.parent/"r8-q4-reference-installed-v1"
site=installed/"site"
if len(sys.argv)>1:
    import cProfile,pstats,numpy as np,anysolver,numba,threadpoolctl
    from anysolver import stiffened_shell as ss
    from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
    assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p["num_threads"]==1 for p in pools)
    assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
    before=time.perf_counter();definition=make_definition(8,4)
    owner=ss.create_analysis(definition=definition)
    setup=time.perf_counter()-before
    profile=cProfile.Profile()
    started=time.perf_counter()
    try:
        profile.enable()
        result=owner.solve(actions_for(definition),(.01,.02),max_iterations=20,max_backtracks=12)
        profile.disable()
        seconds=time.perf_counter()-started
        assert result.status=="completed" and result.accepted_factors==(.01,.02)
        assert result.free_equilibrium_ratio<=1e-8 and result.constraint_max<=1e-9
        checkpoint=owner.checkpoint()
        Path("accepted.bin").write_bytes(checkpoint)
        profile.dump_stats("finite.pstats")
        stats=pstats.Stats(profile)
        with Path("finite-profile.txt").open("w",encoding="utf-8") as out:
            stats.stream=out
            stats.sort_stats("cumulative").print_stats()
        selected=[]
        for (file,line,name),(cc,nc,tt,ct,_) in stats.stats.items():
            if "anysolver" in file and (name in ("_assemble","compute_nonlinear_response",
                 "_qualified_linear_correction","_consistent_corotational_tangent",
                 "_rotation_sensitivity","_shell_center_frame","_nonlinear_geometry",
                 "_constitutive_integrate_lobatto","_e4_pl_sparse_element_triplets") or "factor" in name):
                selected.append(dict(file=file,line=line,name=name,primitive_calls=cc,
                    calls=nc,self_seconds=tt,cumulative_seconds=ct))
        record=dict(status=result.status,accepted_factors=result.accepted_factors,
            setup_seconds=setup,profiled_solve_seconds=seconds,
            equilibrium=result.free_equilibrium_ratio,constraint=result.constraint_max,
            iterations=result.iterations,generation=result.generation,
            shell_elements=24,beam_elements=32,pools=pools,numba_threads=1,jit_disabled=True,
            checkpoint_bytes=len(checkpoint),operators=sorted(selected,key=lambda v:-v["cumulative_seconds"]),
            installed_site=str(site),anysolver_file=anysolver.__file__)
        Path("result.json").write_text(json.dumps(record,indent=2),encoding="utf-8")
        print(json.dumps(dict(status=result.status,setup=setup,profiled_solve=seconds,iterations=result.iterations)))
    finally:
        profile.disable();owner.close()
    raise SystemExit()
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(site,installed/"fixtures-v2")))
r=s.supervised([sys.executable,"-u",str(Path(__file__)),"child"],root/"profile-v2")
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
