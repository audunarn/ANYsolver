from pathlib import Path
import importlib.util,json,os,sys,time
root=Path(__file__).parent
installed=root.parent/"r8-q4-reference-installed-v1"
site=installed/"site"
if len(sys.argv)>1:
    import cProfile,pstats,numpy as np,anysolver,numba,threadpoolctl
    from dataclasses import asdict
    from anysolver import stiffened_shell as ss
    from anysolver._stiffened_shell_increment_control import FiniteIncrementFailure
    from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
    assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p["num_threads"]==1 for p in pools)
    assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
    before=time.perf_counter();definition=make_definition(8,4)
    owner=ss.create_analysis(definition=definition)
    setup=time.perf_counter()-before
    profile=cProfile.Profile();started=time.perf_counter()
    failure=None;result=None
    try:
        profile.enable()
        try:
            result=owner.solve(actions_for(definition),(.01,),max_iterations=3,max_backtracks=2)
        except FiniteIncrementFailure as exc:
            failure=asdict(exc.attempt)
            raise
        finally:
            profile.disable()
            seconds=time.perf_counter()-started
            profile.dump_stats("finite.pstats")
            stats=pstats.Stats(profile)
            with Path("finite-profile.txt").open("w",encoding="utf-8") as out:
                stats.stream=out;stats.sort_stats("cumulative").print_stats()
            rows=[]
            for (file,line,name),(cc,nc,tt,ct,_) in stats.stats.items():
                if "anysolver" in file:
                    rows.append(dict(file=file,line=line,name=name,primitive_calls=cc,
                        calls=nc,self_seconds=tt,cumulative_seconds=ct))
            record=dict(status="FAILED_NUMERICAL" if failure else ("completed" if result else "FAILED_UNEXPECTED"),
                setup_seconds=setup,profiled_solve_seconds=seconds,failure=failure,
                generation=owner._generation,
                accepted_factors=None if result is None else result.accepted_factors,
                shell_elements=24,beam_elements=32,pools=pools,numba_threads=1,jit_disabled=True,
                operators=sorted(rows,key=lambda v:-v["cumulative_seconds"]),
                installed_site=str(site),anysolver_file=anysolver.__file__)
            Path("result.json").write_text(json.dumps(record,indent=2),encoding="utf-8")
            if owner._generation:
                Path("accepted.bin").write_bytes(owner.checkpoint())
            print(json.dumps(dict(status=record["status"],setup=setup,
                profiled_solve=seconds,failure=failure)),flush=True)
    finally:
        profile.disable();owner.close()
    raise SystemExit()
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(site,installed/"fixtures-v2")))
r=s.supervised([sys.executable,"-u",str(Path(__file__)),"child"],root/"bounded-v1")
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
