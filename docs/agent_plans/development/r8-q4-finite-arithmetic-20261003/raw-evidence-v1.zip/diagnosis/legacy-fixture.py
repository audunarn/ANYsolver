from pathlib import Path
import importlib.util,json,os,sys,hashlib
root=Path(__file__).parent;installed=root.parent/'r8-q4-reference-installed-v1';site=installed/'site'
if len(sys.argv)>1:
 import numpy as np,anysolver,threadpoolctl,numba
 from anysolver import stiffened_shell as ss
 from test_stiffened_shell_ge_experimental import _panel
 identity=json.loads((installed/'identity-v3.json').read_text())
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 assert all(hashlib.sha256((site/p).read_bytes()).hexdigest()==h for p,h in identity['modules'].items())
 assert numba.config.DISABLE_JIT and all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
 owner=ss.create_analysis(definition=_panel())
 try:
  actions=(ss.NodalAction('beam',105,(0.,0.,1000.,0.,0.,0.)),)
  owner.solve(actions,(.5,1.));raw=owner.checkpoint();Path('checkpoint.bin').write_bytes(raw)
  result=owner.solve(actions,(2.,))
  np.savez('continued.npz',**{name:getattr(result,name) for name in ('shell_displacement','beam_positions','beam_frames','cell_frames','cell_resultants','multipliers','support_reactions')})
  meta=dict(library_commit='5136f026cb1844b57adb9c8e12404037cec9a728',wheel_sha256=identity['wheel_sha256'],site=str(site),verified_module_count=len(identity['modules']),checkpoint_sha256=hashlib.sha256(raw).hexdigest(),continued_sha256=hashlib.sha256(Path('continued.npz').read_bytes()).hexdigest(),accepted_factors=result.accepted_factors,eq=result.free_equilibrium_ratio,gap=result.constraint_max)
  Path('identity.json').write_text(json.dumps(meta,indent=2),encoding='utf-8');print(json.dumps(meta),flush=True)
 finally:owner.close()
 raise SystemExit()
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(site,installed/'fixtures-v2')))
r=s.supervised([sys.executable,'-u',str(Path(__file__)),'child'],root/'legacy-fixture-v1');print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
