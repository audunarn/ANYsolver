from pathlib import Path
import importlib.util,json,os,sys,time
root=Path(__file__).parent;installed=root.parent/'r8-q4-reference-installed-v1';site=installed/'site'
if len(sys.argv)>1:
 import numpy as np,numba,threadpoolctl,anysolver
 from dataclasses import asdict
 from anysolver import stiffened_shell as ss,corotational as c
 from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
 assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
 original=c._corotational_deformation_state
 def changed(ref,element,values):
  out,R,deformed=original(ref,element,values)
  if ref.category!='shell':return out,R,deformed
  u=np.asarray(values).reshape(int(element.num_nodes),6)
  A=.5*(R-R.T);cosine=.5*(np.trace(R)-1)
  difference=(A+(A@A)/(1+cosine)).T if cosine>.5 else R.T-np.eye(3)
  offset=u[:,:3]-u[:,:3].mean(axis=0);arm=ref.coordinates-ref.centroid
  out=out.reshape(-1,6)
  for i in range(len(u)):out[i,:3]=R.T@offset[i]+difference@arm[i]
  return out.ravel(),R,deformed
 c._corotational_deformation_state=changed
 owner=ss.create_analysis(definition=make_definition(8,4));resumed=None
 try:
  actions=actions_for(owner._definition);start=time.perf_counter()
  result=owner.solve(actions,(.01,.02),max_iterations=8,max_backtracks=4)
  saved=owner.checkpoint();Path('prototype-checkpoint.bin').write_bytes(saved)
  resumed=ss.create_analysis(definition=owner._definition);resumed.restore(saved)
  continued=owner.solve(actions,(.03,),max_iterations=8,max_backtracks=4)
  restarted=resumed.solve(actions,(.03,),max_iterations=8,max_backtracks=4)
  for name in ('shell_displacement','beam_positions','beam_frames','cell_frames','cell_resultants','multipliers','support_reactions'):
   np.testing.assert_array_equal(getattr(continued,name),getattr(restarted,name))
  assert owner.checkpoint()==resumed.checkpoint()
  report=dict(status='PROTOTYPE_COMPLETED',elapsed=time.perf_counter()-start,accepted_factors=result.accepted_factors,continued_factors=continued.accepted_factors,equilibrium=result.equilibrium_relative,gap=result.compatibility_scaled,exact_restart=True,pools=pools,jit_disabled=True)
  Path('result.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report),flush=True)
 finally:
  c._corotational_deformation_state=original;owner.close()
  if resumed is not None:resumed.close()
 raise SystemExit()
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(site,installed/'fixtures-v2')))
r=s.supervised([sys.executable,'-u',str(Path(__file__)),'child'],root/'public-prototype-v1')
print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
