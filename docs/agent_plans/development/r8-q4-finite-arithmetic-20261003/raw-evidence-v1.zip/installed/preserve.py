from pathlib import Path
import os,json,hashlib,zipfile,shutil,xml.etree.ElementTree as ET
repo=Path.cwd();temp=Path(os.environ['TEMP']);installed=temp/'r8-q4-rotation-installed-v2';diagnostic=temp/'r8-ge-finite-scale-profile-v1'
out=repo/'docs/agent_plans/development/r8-q4-finite-arithmetic-20261003';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((installed/'identity.json').read_text())
for name,value in identity['modules'].items():
 assert sha(installed/'site'/name)==value
 assert sha(repo/'src'/name)==value
with zipfile.ZipFile(identity['wheel']) as z:
 for name,value in identity['modules'].items():assert hashlib.sha256(z.read(name)).hexdigest()==value
junit=ET.parse(installed/'checks-v1/result.xml').getroot();counts={k:sum(int(s.get(k,'0')) for s in junit.findall('testsuite')) for k in ('tests','failures','errors','skipped')}
assert counts==dict(tests=24,failures=0,errors=0,skipped=0),counts
consumer=json.loads((installed/'consumer-algorithmic-v2/result.json').read_text());middle=json.loads((installed/'middle-algorithmic-v1/result.json').read_text());example=json.loads((installed/'example-v2/example-result.json').read_text());balance=json.loads((installed/'example-v2/middle-physical-adjudication.json').read_text())
summary=dict(library_commit='1a620808',wheel_sha256=identity['wheel_sha256'],verified_modules=len(identity['modules']),installed_checks=counts,consumer=consumer,middle=middle,middle_physical=balance,example=example,aggregate_qualification=False,F01='OPEN',G5='IN_PROGRESS',formal_F03='UNCONSUMED')
(out/'summary-v1.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
files=[]
def add_tree(path,label,extensions):
 for p in path.rglob('*'):
  if p.is_file() and p.suffix in extensions and '__pycache__' not in p.parts:
   files.append((p,label+'/'+p.relative_to(path).as_posix()))
add_tree(diagnostic,'diagnosis',{'.py','.json','.log','.npz','.bin','.pstats','.txt'})
# Explicit run/fixture/artifact inventory; never archive installed external packages or environments.
for name in ('checks-v1','consumer-v1','consumer-algorithmic-v1','consumer-algorithmic-v2','balance-discriminator-v1','middle-algorithmic-v1','example-v1','example-v2','fixtures'):
 add_tree(installed/name,'installed/'+name,{'.py','.json','.log','.npz','.bin','.pstats','.txt','.xml'})
for p in installed.iterdir():
 if p.is_file() and p.suffix in {'.py','.json','.log','.ini'}:files.append((p,'installed/'+p.name))
wheel=Path(identity['wheel']);files.append((wheel,'installed/wheels/'+wheel.name))
# Retain the earlier superseded build identity, without treating it as verified final execution.
for p in (temp/'r8-q4-rotation-installed-v1').iterdir():
 if p.is_file() and p.suffix in {'.py','.json','.log','.ini'}:files.append((p,'superseded-build/'+p.name))
for label in ('udjqdjgr','_slf5jzr','7t971r17','e5ne_mk5'):
 add_tree(temp/('anysolver-portable-ci-'+label),'source-checks/'+label,{'.json'})
for name in ('corotational.py','_stiffened_shell_ge_checkpoint_binary.py','_stiffened_shell_ge_experimental.py','_stiffened_shell_ge_finite_experimental.py'):
 p=repo/'src/anysolver'/name;files.append((p,'source/'+name))
for name in ('test_stiffened_shell_q4_rotation_arithmetic.py','test_stiffened_shell_ge_finite_experimental.py'):
 p=repo/'tests'/name;files.append((p,'source/tests/'+name))
files.append((repo/'scripts/experimental_stiffened_ge_finite_panel.py','source/experimental_stiffened_ge_finite_panel.py'))
files.append((temp/'r8-b2-panel-resolution-installed-v1/matched-run.py','supervisor.py'))
manifest=dict(files={name:sha(p) for p,name in files},source_module_binding=identity,consumer_binding=json.loads((temp/'r8-q4-reference-installed-v1/consumer-binding-v1.json').read_text()))
manifest_bytes=json.dumps(manifest,indent=2).encode('utf-8')
with zipfile.ZipFile(out/'raw-evidence-v1.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for p,name in files:z.write(p,name)
 z.writestr('manifest.json',manifest_bytes)
archive=out/'raw-evidence-v1.zip'
(out/'archive-v1.json').write_text(json.dumps(dict(sha256=sha(archive),bytes=archive.stat().st_size,files=len(files)+1,whitelisted=True),indent=2),encoding='utf-8')
print(json.dumps(dict(files=len(files)+1,bytes=archive.stat().st_size,sha256=sha(archive),installed=counts)))
