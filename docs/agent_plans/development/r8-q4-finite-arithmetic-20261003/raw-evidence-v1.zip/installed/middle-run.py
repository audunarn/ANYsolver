from pathlib import Path
import importlib.util,json,os,sys,time
root=Path(__file__).parent;site=root/'site';fixtures=root/'fixtures'
if len(sys.argv)>1:
 import cProfile,pstats,numpy as np,anysolver,numba,threadpoolctl
 from dataclasses import asdict
 from anysolver import stiffened_shell as ss
 from anysolver._stiffened_shell_increment_control import FiniteIncrementFailure
 from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 pools=threadpoolctl.threadpool_info();assert all(p['num_threads']==1 for p in pools) and numba.config.DISABLE_JIT
 start=time.perf_counter();definition=make_definition(20,6,shell_transverse_cells=20,tie_stride=2)
 owner=ss.create_analysis(definition=definition);setup=time.perf_counter()-start
 profile=cProfile.Profile();history=[];report=dict(status='IN_PROGRESS',setup_seconds=setup,preflight=owner.preflight(),pools=pools,jit_disabled=True,numba_threads=numba.get_num_threads())
 def accepted(result):history.append(dict(generation=result.generation,factor=result.load_factor,iterations=result.iterations,eq=result.free_equilibrium_ratio,gap=result.constraint_max))
 start=time.perf_counter()
 try:
  profile.enable()
  try:result=owner.solve(actions_for(definition),(.01,.02),max_iterations=8,max_backtracks=4,on_accepted=accepted)
  finally:profile.disable()
  raw=owner.checkpoint();Path('checkpoint.bin').write_bytes(raw)
  np.savez('physical.npz',shell_displacement=result.shell_displacement,beam_positions=result.beam_positions,beam_frames=result.beam_frames,cell_frames=result.cell_frames,cell_resultants=result.cell_resultants,multipliers=result.multipliers,support_reactions=result.support_reactions)
  report.update(status=result.status,accepted_factors=result.accepted_factors,eq=result.free_equilibrium_ratio,gap=result.constraint_max,iterations=result.iterations,qualified=result.production_qualified)
 except FiniteIncrementFailure as exc:
  report.update(status='FAILED_NUMERICAL',failure=asdict(exc.attempt));raise
 finally:
  report.update(solve_seconds=time.perf_counter()-start,generation=owner._generation,accepted_history=history)
  profile.dump_stats('solve.pstats')
  with Path('profile.txt').open('w') as stream:pstats.Stats(profile,stream=stream).sort_stats('cumulative').print_stats(45)
  Path('result.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report),flush=True);owner.close()
 raise SystemExit()
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(site,fixtures)))
r=s.supervised([sys.executable,'-u',str(Path(__file__)),'child'],root/'middle-v1');print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
