from pathlib import Path
import importlib.util,json,os,sys
root=Path(__file__).parent;site=root/'site';fixtures=root/'fixtures'
if len(sys.argv)>1:
 import numpy as np,anysolver,numba,threadpoolctl
 from anysolver import stiffened_shell as ss,corotational as cr
 from anysolver._stiffened_shell_q4_algorithmic_pullback import response as full_response
 from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 pools=threadpoolctl.threadpool_info();assert all(p['num_threads']==1 for p in pools) and numba.config.DISABLE_JIT
 definition=make_definition(4,3);owner=ss.create_analysis(definition=definition)
 try:
  owner.restore((root/'consumer-v1/checkpoint.bin').read_bytes());driver=owner._finite_driver;state=driver._state
  assert state.shell_anchors is None
  total_force=np.zeros(3);total_moment=np.zeros(3);result=owner.recover();factor=result.load_factor
  support=result.support_reactions[:owner._shell_count].reshape(-1,6)
  xyz=np.array(definition.shell.coordinates_m)+result.shell_displacement.reshape(-1,6)[:,:3]
  total_force+=support[:,:3].sum(axis=0);total_moment+=(support[:,3:]+np.cross(xyz,support[:,:3])).sum(axis=0)
  actions=actions_for(definition);scale=sum(np.linalg.norm(factor*np.array(a.wrench[:3])) for a in actions)
  for action in actions:
   load=factor*np.array(action.wrench[:3]);total_force+=load;total_moment+=np.cross(result.beam_positions[owner._beam_index[action.node]],load)
  rows=[]
  for mode in ('stable_rotated','historical_rotated','full_algorithmic'):
   force=np.zeros(3);moment=np.zeros(3)
   for (eid,element,slots,_),origin in zip(owner._shell_parts,driver._shell_origins):
    local=state.q[slots];reference=np.array([owner._shell_model.mesh.nodes[n].coords() for n in element.node_ids]);positions=reference+local.reshape(-1,6)[:,:3]
    if mode=='full_algorithmic':f=full_response(owner._shell_model,element,local,origin,3)[0]
    else:f=cr.corotational_element_response(owner._shell_model,eid,element,local,False,committed_state=origin,num_layers=3,tangent_mode='consistent',centered_shell_reference=True,stable_shell_rotation=mode=='stable_rotated')[0]
    blocks=f.reshape(-1,6);force+=blocks[:,:3].sum(axis=0);moment+=(blocks[:,3:]+np.cross(positions,blocks[:,:3])).sum(axis=0)
   rows.append(dict(mode=mode,internal_force=force.tolist(),internal_moment=moment.tolist(),scaled_force=float(np.linalg.norm(force)/scale),scaled_moment=float(np.linalg.norm(moment)/(2*scale))))
  report=dict(status='DIAGNOSTIC_COMPLETED',generation=owner._generation,factor=factor,no_commit=True,support_shell_rotations=state.q[:owner._shell_count].reshape(-1,6)[[owner._shell_index[n] for n in definition.shell.node_ids if owner._shell_model.mesh.nodes[n].x==0],3:].tolist(),force_balance=float(np.linalg.norm(total_force)/scale),moment_balance=float(np.linalg.norm(total_moment)/(2*scale)),external_support_moment=total_moment.tolist(),rows=rows,pools=pools,jit_disabled=True)
  Path('result.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report),flush=True)
 finally:owner.close()
 raise SystemExit()
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(site,fixtures)))
r=s.supervised([sys.executable,'-u',str(Path(__file__)),'child'],root/'balance-discriminator-v1');print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
