from pathlib import Path
import importlib.util,json,os,sys
root=Path(__file__).parent;site=root/'site';fixtures=root/'fixtures'
if len(sys.argv)>1:
 import numpy as np,anysolver,threadpoolctl,numba
 from types import SimpleNamespace
 from dataclasses import replace
 from scripts.experimental_stiffened_ge_finite_panel import run,physical_balance
 from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
 from anysolver import stiffened_shell as ss
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 assert numba.config.DISABLE_JIT and all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
 values=np.load(root/'middle-algorithmic-v1/physical.npz')
 definition=replace(make_definition(20,6,shell_transverse_cells=20,tie_stride=2),q4_pullback_policy=ss.Q4_ALGORITHMIC_PULLBACK_V1)
 result=SimpleNamespace(load_factor=.02,**{k:values[k] for k in values.files})
 force,moment=physical_balance(definition,result,actions_for(definition));assert force<=1e-8 and moment<=1e-8,(force,moment)
 middle=json.loads((root/'middle-algorithmic-v1/result.json').read_text());assert middle['eq']<=1e-8 and middle['gap']<=1e-9 and middle['accepted_factors']==[.01,.02]
 Path('middle-physical-adjudication.json').write_text(json.dumps(dict(status='PASSED_SCOPED_CHECKS',force_balance=force,moment_balance=moment,limits=dict(equilibrium=1e-8,constraint=1e-9,force=1e-8,moment=1e-8),no_G5_qualification=True),indent=2),encoding='utf-8')
 example=run();Path('example-result.json').write_text(json.dumps(example,indent=2),encoding='utf-8');print(json.dumps(dict(middle_force=force,middle_moment=moment,example=example)),flush=True)
 raise SystemExit()
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(site,fixtures)))
r=s.supervised([sys.executable,'-u',str(Path(__file__)),'child'],root/'example-v1');print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
