from pathlib import Path
import importlib.util,json,os,sys,time
root=Path(__file__).parent;site=root/'site';consumer=root.parent/'r8-ge-member-scale-installed-v1/consumer-site';fixtures=root/'fixtures'
if len(sys.argv)>1:
 import numpy as np,anysolver,anyfem,numba,threadpoolctl
 from anyfem.io.project_file import load_project,save_project
 from anyfem.model.project import Project
 from anyfem.model.records import AnalysisDefinition
 from anyfem.solve.stiffened_shell import ExperimentalGEPointPanel,load_case,save_case
 from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for
 assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
 assert Path(anyfem.__file__).resolve().is_relative_to(consumer.resolve())
 pools=threadpoolctl.threadpool_info();assert all(p['num_threads']==1 for p in pools) and numba.config.DISABLE_JIT
 from dataclasses import replace
 definition=replace(make_definition(4,3),q4_pullback_policy=ss.Q4_ALGORITHMIC_PULLBACK_V1);actions=actions_for(definition)
 case=ExperimentalGEPointPanel(definition.shell,definition.beams,definition.points,definition.fixed,actions=actions,q4_pullback_policy=definition.q4_pullback_policy)
 reopenedcase=load_case(save_case(case,Path('panel.anyfem-ge.json')))
 project=Project('finite flat panel',mesh_only=True)
 record=AnalysisDefinition.experimental_point_panel('three stiffeners',reopenedcase);project.add_analysis(record)
 reopened=load_project(save_project(project,Path('panel.anyfem')))
 owner=reopened.analyses[record.id].create_point_panel_analysis();resumed=None
 try:
  result=owner.solve(actions,(.01,.02),max_iterations=8,max_backtracks=4)
  saved=owner.checkpoint();Path('checkpoint.bin').write_bytes(saved)
  resumed=reopened.analyses[record.id].create_point_panel_analysis();resumed.restore(saved)
  first=owner.solve(actions,(.03,),max_iterations=8,max_backtracks=4)
  second=resumed.solve(actions,(.03,),max_iterations=8,max_backtracks=4)
  for name in ('shell_displacement','beam_positions','beam_frames','cell_frames','cell_resultants','multipliers','support_reactions'):
   np.testing.assert_array_equal(getattr(first,name),getattr(second,name))
  assert owner.checkpoint()==resumed.checkpoint()
  support=first.support_reactions[:owner._shell_count].reshape(-1,6)
  xyz=np.array(definition.shell.coordinates_m)+first.shell_displacement.reshape(-1,6)[:,:3]
  force=support[:,:3].sum(axis=0);moment=(support[:,3:]+np.cross(xyz,support[:,:3])).sum(axis=0)
  for action in actions:
   applied=first.load_factor*np.array(action.wrench[:3]);force+=applied
   moment+=np.cross(first.beam_positions[owner._beam_index[action.node]],applied)
  scale=sum(np.linalg.norm(first.load_factor*np.array(a.wrench[:3])) for a in actions)
  force_error=float(np.linalg.norm(force)/scale);moment_error=float(np.linalg.norm(moment)/(2*scale))
  assert force_error<=1e-8 and moment_error<=1e-8,(force_error,moment_error)
  report=dict(force_balance=force_error,moment_balance=moment_error,status=first.status,qualified=first.production_qualified,q4_policy=definition.q4_pullback_policy,accepted_factors=first.accepted_factors,eq=first.free_equilibrium_ratio,gap=first.constraint_max,exact_restart=True,shells=len(definition.shell.q4_elements),beams=len(definition.beams),solver_site=str(site),consumer_site=str(consumer),consumer_commit='4d6d4d0',pools=pools,jit_disabled=True,numba_threads=numba.get_num_threads())
  Path('result.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report),flush=True)
 finally:
  owner.close()
  if resumed is not None:resumed.close()
 raise SystemExit()
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(site,consumer,fixtures)))
r=s.supervised([sys.executable,'-u',str(Path(__file__)),'child'],root/'consumer-algorithmic-v1');print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
