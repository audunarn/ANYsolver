from pathlib import Path
import ast, hashlib, importlib.util, json, os, shutil, subprocess, sys, zipfile
root=Path(__file__).parent
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
site=root/"site"
baseline=root.parent/"r8-curved-material-staged-installed-v2/site"
consumer=root.parent/"r8-ge-member-scale-installed-v1/consumer-site"
fixtures=root/"fixtures"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mode=sys.argv[1]
if mode=="prepare":
    fixtures.mkdir()
    with (root/"build.log").open("w") as out:
        subprocess.run([sys.executable,"-m","pip","wheel","--no-deps","--no-build-isolation",
            "--no-index","--no-cache-dir","--wheel-dir",str(root/"wheels"),str(repo)],
            stdout=out,stderr=subprocess.STDOUT,check=True)
    wheel=next((root/"wheels").glob("*.whl"))
    with (root/"install.log").open("w") as out:
        subprocess.run([sys.executable,"-m","pip","install","--no-deps","--no-index",
            "--no-cache-dir","--target",str(site),str(wheel)],
            stdout=out,stderr=subprocess.STDOUT,check=True)
    modules={}
    with zipfile.ZipFile(wheel) as z:
        for p in (repo/"src/anysolver").rglob("*.py"):
            name=p.relative_to(repo/"src").as_posix()
            assert p.read_bytes()==z.read(name)==(site/name).read_bytes(),name
            modules[name]=sha(p)
    pending=["test_stiffened_shell_q4_rotation_arithmetic","test_stiffened_shell_q4_reference_reuse","test_stiffened_shell_ge_dense_assembly_oracle",
             "test_stiffened_shell_ge_finite_experimental","test_stiffened_shell_multi_member_panel"]
    seen=set()
    while pending:
        name=pending.pop()
        if name in seen:continue
        seen.add(name);p=repo/"tests"/(name+".py")
        shutil.copyfile(p,fixtures/p.name)
        for n in ast.walk(ast.parse(p.read_text(encoding="utf-8-sig"))):
            if isinstance(n,ast.ImportFrom) and n.module and n.module.startswith("test_"):
                pending.append(n.module)
    (fixtures/"scripts").mkdir()
    shutil.copyfile(repo/"scripts/experimental_stiffened_ge_multi_member_panel.py",
                    fixtures/"scripts/experimental_stiffened_ge_multi_member_panel.py")
    previous=root.parent/"r8-ge-member-scale-installed-v1/fixtures"
    # These immutable consumer fixtures exercised the installed 32-member Project route.
    for p in previous.glob("test*.py"):
        if not (fixtures/p.name).exists():shutil.copyfile(p,fixtures/p.name)
    shutil.copytree(repo/"tests/data/stiffened_shell_q4_legacy",fixtures/"data/stiffened_shell_q4_legacy")
    (root/"pytest.ini").write_text("[pytest]\n",encoding="utf-8")
    (root/"identity.json").write_text(json.dumps(dict(wheel=str(wheel),wheel_sha256=sha(wheel),
        site=str(site),modules=modules,fixtures={p.name:sha(p) for p in fixtures.rglob("*.py")}),indent=2),encoding="utf-8")
    print(json.dumps(dict(modules=len(modules),wheel_sha256=sha(wheel))))
    raise SystemExit()
if mode in ("checks-child","impacted-child"):
    import anysolver, anyfem, numba, threadpoolctl, pytest
    assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
    assert Path(anyfem.__file__).resolve().is_relative_to(consumer.resolve())
    targets=["test_stiffened_shell_q4_rotation_arithmetic.py",
        "test_stiffened_shell_ge_finite_experimental.py::test_elastic_unload_uses_new_checkpoint_without_changing_legacy_format",
        "test_stiffened_shell_ge_finite_experimental.py::test_binary_checkpoint_restores_finite_prefix_and_continues",
        "test_stiffened_shell_ge_finite_experimental.py::test_generalized_beam_unload_reload_preserves_history_across_restart",
        "test_stiffened_shell_ge_finite_experimental.py::test_q4_shell_and_beam_yield_atomically_and_restart",
        "test_stiffened_shell_ge_finite_experimental.py::test_rejected_and_cancelled_finite_trials_keep_accepted_prefix",
        "test_stiffened_shell_ge_finite_experimental.py::test_finite_mixed_and_s3_panels_restart_and_continue",
        "test_corotational.py::test_consistent_corotational_tangent_matches_force_jacobian",
        "test_corotational.py::test_legacy_corotational_shell_preserves_registered_900n_comparison"]
    if mode=="impacted-child":
        targets=["test_stiffened_shell_ge_reference_modal.py::test_modal_operation_owns_modes_reuses_mass_and_preserves_static_owner",
            "test_stiffened_shell_nodal_rigid_footprint.py::test_linear_physical_wrench_reference_restart_and_selection"]
    code=pytest.main(["-q","-p","no:cacheprovider","-c",str(root/"pytest.ini"),
        "--basetemp=temporary","--junitxml=result.xml",*[str(fixtures/t) for t in targets]])
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p["num_threads"]==1 for p in pools)
    assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items()
             if n.startswith(("anysolver","anyfem")) and getattr(m,"__file__",None)}
    for n,p in imports.items():
        assert Path(p).is_relative_to((consumer if n.startswith("anyfem") else site).resolve()),(n,p)
    Path("runtime.json").write_text(json.dumps(dict(imports=imports,pools=pools,
        jit_disabled=True,numba_threads=1,python=sys.version),indent=2),encoding="utf-8")
    raise SystemExit(code)
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(site,consumer,fixtures)))
r=s.supervised([sys.executable,"-u",str(Path(__file__)),mode+"-child"],root/(mode+"-v1"))
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
