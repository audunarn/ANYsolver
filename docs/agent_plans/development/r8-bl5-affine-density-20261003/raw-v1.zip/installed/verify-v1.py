from pathlib import Path
import os, ast, hashlib, json, zipfile, shutil, importlib.util, subprocess, sys
tmp=Path(os.environ['TEMP']);root=tmp/'r8-bl5-affine-installed-v1';site=root/'site'
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
wheel=next((root/'solver-dist').glob('*.whl'))
with zipfile.ZipFile(wheel) as z:
    modules=sorted(n for n in z.namelist() if n.startswith('anysolver/') and n.endswith('.py'))
    for n in modules:
        assert z.read(n)==(repo/'src'/n).read_bytes()==(site/n).read_bytes(),n
fixtures=root/'fixtures';fixtures.mkdir(exist_ok=False)
scripts=root/'scripts';scripts.mkdir(exist_ok=False)
targets=('test_stiffened_shell_bl5_affine_supports.py','test_r8_bl5_affine_carrier_reference_dev.py',
         'test_stiffened_shell_l1_assembly_experimental.py','test_stiffened_shell_bl5_aggregation.py',
         'test_stiffened_shell_bl5_finite.py')
todo=[repo/'tests'/n for n in targets];copied={}
for name in ('b3_e4_bl5_coherent_aggregation_dev.py','r8_bl5_affine_carrier_reference_dev.py',
             'r8_bl5_affine_support_screen_dev.py','r8_bl5_p0_carrier_reference_dev.py',
             'r8_bl5_rigid_carrier_dev.py'):
    todo.append(repo/'scripts'/name)
while todo:
    p=todo.pop();name=p.name;kind='fixtures' if p.parent.name=='tests' else 'scripts'
    key=kind+'/'+name
    if key in copied:
        assert copied[key]==p
        continue
    copied[key]=p;shutil.copy2(p,root/key)
    for node in ast.walk(ast.parse(p.read_text(encoding='utf-8-sig'))):
        module=node.module if isinstance(node,ast.ImportFrom) and node.level==0 else None
        if module and module.startswith('test_'):todo.append(repo/'tests'/(module+'.py'))
        if module and module.startswith('scripts.'):
            dependency=repo/(module.replace('.','/')+'.py')
            if dependency.exists():todo.append(dependency)
binding=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
             wheel=dict(path=str(wheel),sha256=sha(wheel),module_count=len(modules),modules=modules),
             files={name:dict(source=str(p),sha256=sha(p)) for name,p in sorted(copied.items())},
             scope='Installed solver; editable ANYmaterial dependency, not G6 graph/platform acceptance')
(root/'binding-v1.json').write_text(json.dumps(binding,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('sup',tmp/'r8-b2-panel-resolution-installed-v1/matched-run.py')
sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)
sup.ENV['PYTHONPATH']=os.pathsep.join(map(str,(site,fixtures,root,scripts)))
child=root/'check.py'
child.write_text('''import sys,json
from pathlib import Path
import anysolver,anymaterial,numpy,scipy,numba,pytest
from threadpoolctl import threadpool_info
site=Path(sys.argv[1]).resolve()
assert Path(anysolver.__file__).resolve().is_relative_to(site)
print(json.dumps(dict(imports={m.__name__:m.__file__ for m in (anysolver,anymaterial,numpy,scipy,numba,pytest)},versions={m.__name__:getattr(m,'__version__',None) for m in (numpy,scipy,numba,pytest)},numba_threads=numba.get_num_threads(),jit_disabled=numba.config.DISABLE_JIT)),flush=True)
code=pytest.main(['-q',*sys.argv[2:]])
print(json.dumps(dict(pools=threadpool_info())),flush=True)
assert all(p['num_threads']==1 for p in threadpool_info())
for name,m in tuple(sys.modules.items()):
    if name.startswith('anysolver.') and getattr(m,'__file__',None):assert Path(m.__file__).resolve().is_relative_to(site),name
raise SystemExit(code)
''')
checks=sup.supervised([sys.executable,str(child),str(site),*[str(fixtures/n) for n in targets]],root/'checks-v1')
print(json.dumps(dict(checks=checks,module_count=len(modules),wheel_sha256=sha(wheel))),flush=True)
screen=sup.supervised([sys.executable,str(scripts/'r8_bl5_affine_support_screen_dev.py'),'--output',str(root/'screen-output-v1')],root/'screen-v1')
print(json.dumps(dict(screen=screen)),flush=True)
