from pathlib import Path
import importlib.util,hashlib,json,os,shutil,sys,zipfile,subprocess
tmp=Path(os.environ['TEMP']);root=tmp/'r8-bl5-affine-installed-v1'
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
wheel=next((root/'solver-dist').glob('*.whl'))
with zipfile.ZipFile(wheel) as z:
    modules=sorted(n for n in z.namelist() if n.startswith('anysolver/') and n.endswith('.py'))
    for name in modules:assert z.read(name)==(repo/'src'/name).read_bytes()==(root/'site'/name).read_bytes(),name
source=repo/'scripts/b3_e4_bl5_mechanical_kernel_dev.py'
target=root/'scripts'/source.name
if target.exists():raise FileExistsError(target)
shutil.copy2(source,target)
binding=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    script_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),source=str(source),
    wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),module_count=len(modules),
    scope='One bounded actual mixed-system oracle, same flexible16x4/32 fixture, affine rows; not F03/all-ratio/locking acceptance')
(root/'kernel-binding-v1.json').write_text(json.dumps(binding,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('sup',tmp/'r8-b2-panel-resolution-installed-v1/matched-run.py')
sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)
sup.ENV['PYTHONPATH']=os.pathsep.join(map(str,(root/'site',root/'fixtures',root,root/'scripts')))
result=sup.supervised([sys.executable,str(target),'--basis','discontinuous_p1',
    '--output',str(root/'kernel-output-v1.json')],root/'kernel-v1')
print(json.dumps(result),flush=True)
