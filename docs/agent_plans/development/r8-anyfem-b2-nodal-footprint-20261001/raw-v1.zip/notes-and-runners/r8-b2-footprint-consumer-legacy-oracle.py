from pathlib import Path
from dataclasses import asdict
import hashlib,json,sys,zipfile
import numpy as np,numba,threadpoolctl
from anyfem.solve.stiffened_shell_b2 import ExperimentalB2PointPanel,save_case,load_case
from test_experimental_b2_stiffened_shell_consumer import _panel
r=Path.cwd();site=Path(sys.argv[1]).resolve();artifact=site.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((artifact/'prepared-manifest.json').read_text())
wheels={}
for package,files in manifest['modules'].items():
    wheel=next((artifact/'wheels').glob(package+'-*.whl'));wheels[wheel.name]=sha(wheel)
    with zipfile.ZipFile(wheel) as z:
        assert {p for p in z.namelist() if p.startswith(package+'/') and p.endswith('.py')}==set(files)
        for p,h in files.items():assert sha(site/p)==h and z.read(p)==(site/p).read_bytes(),p
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
definition=_panel();cases=[]
for index in range(10):
    load=np.zeros(54);load[49]=.08*(1+index/10);load[32]=-.16*(1+index/10)
    cases.append((f'load-{index:03d}',load))
consumer=ExperimentalB2PointPanel.from_definition(definition,cases,selected_dofs=(49,32),selected_points=('joint-right',),recover_members={'beam-right':(.25,.75)})
save_case(consumer,r/'legacy.anyfem-b2.json');reopened=load_case(r/'legacy.anyfem-b2.json')
assert reopened.payload==consumer.payload
result=reopened.solve_linear_many();assert result.status=='completed' and result.factorization_count==1
assert isinstance(consumer.payload,bytes)
(r/'observables.json').write_text(json.dumps({'payload_utf8':consumer.payload.decode('utf-8'),'result':asdict(result)},sort_keys=True,indent=2,allow_nan=False))
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0] in ('anysolver','anyfem') and getattr(m,'__file__',None)}
assert all(Path(p).is_relative_to(site) for p in imports.values())
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
(r/'identity.json').write_text(json.dumps({'wheels':wheels,'modules':{p:len(f) for p,f in manifest['modules'].items()},'imports':imports,'threads':pools,'numba_threads':1,'jit_disabled':True,'fixture_sha256':sha(Path(sys.argv[2])/'test_experimental_b2_stiffened_shell_consumer.py')},indent=2))
print(json.dumps({'status':'passed','onsite_imports':len(imports),'serialized_sha256':sha(r/'legacy.anyfem-b2.json'),'observables_sha256':sha(r/'observables.json')}))
