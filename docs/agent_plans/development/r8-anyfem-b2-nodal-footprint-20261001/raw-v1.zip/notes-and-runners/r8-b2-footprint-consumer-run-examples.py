from pathlib import Path
import contextlib,io,runpy,json,sys,hashlib
import numba,threadpoolctl
r=Path.cwd();site=Path(sys.argv[1]).resolve();example=Path(sys.argv[2])
manifest=json.loads((site.parent/'prepared-manifest.json').read_text())
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
reports=[];old_args=sys.argv
try:
    for count in (1,10,100):
        folder=r/f'cases-{count}';folder.mkdir(exist_ok=False)
        sys.argv=[str(example),str(folder/'panel.anyfem-b2.json'),'--cases',str(count),'--project',str(folder/'panel.anyfem')]
        output=io.StringIO()
        with contextlib.redirect_stdout(output):runpy.run_path(str(example),run_name='__main__')
        text=output.getvalue();value=json.loads(text)
        assert value['status']=='completed' and value['cases']==count and value['factorization_count']==1 and value['solve_count']==count
        assert value['production_qualified'] is False
        (folder/'result.json').write_text(text);reports.append(value)
finally:sys.argv=old_args
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0] in ('anysolver','anyfem') and getattr(m,'__file__',None)}
assert all(Path(p).is_relative_to(site) for p in imports.values())
for p in imports.values():
    key=Path(p).relative_to(site).as_posix()
    assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==manifest['modules'][key.split('/')[0]][key],key
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
(r/'identity.json').write_text(json.dumps({'example_sha256':hashlib.sha256(example.read_bytes()).hexdigest(),'imports':imports,'threads':pools,'numba_threads':1,'jit_disabled':True,'case_counts':[v['cases'] for v in reports]},indent=2))
print(json.dumps({'status':'passed','case_counts':[v['cases'] for v in reports],'onsite_imports':len(imports),'factor_count_per_owner':1}))
