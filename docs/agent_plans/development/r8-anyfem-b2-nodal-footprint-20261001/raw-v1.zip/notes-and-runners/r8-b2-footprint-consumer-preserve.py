from pathlib import Path
import hashlib,json,zipfile
r=Path(r'C:/Users/AUDUNA~1/AppData/Local/Temp')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=r/'r8-b2-footprint-consumer-legacy-old-v2'
new=r/'r8-b2-footprint-consumer-legacy-new-v1'
comparison={}
for name in ('legacy.anyfem-b2.json','observables.json'):
    assert (old/name).read_bytes()==(new/name).read_bytes(),name
    comparison[name]={'old':str(old/name),'new':str(new/name),'sha256':sha(new/name),'byte_equal':True}
comparison_path=r/'r8-b2-footprint-consumer-legacy-comparison-v1.json'
assert not comparison_path.exists()
comparison_path.write_text(json.dumps(comparison,indent=2))
out=r/'r8-b2-footprint-consumer-evidence-v1.zip';assert not out.exists()
files={}
def add(p,key):
    if p.is_file():
        assert key not in files,key
        files[key]=p
for name in ('r8-b2-footprint-consumer-installed-v1','r8-b2-footprint-consumer-legacy-old-v1',
             'r8-b2-footprint-consumer-legacy-old-v2','r8-b2-footprint-consumer-legacy-new-v1',
             'r8-b2-footprint-consumer-examples-installed-v1'):
    base=r/name;assert base.is_dir(),base
    for p in sorted(base.rglob('*')):
        rel=p.relative_to(base)
        if any(v in ('site','build-source','__pycache__','.pytest_cache') for v in rel.parts):continue
        if p.suffix in ('.pyc','.nbc','.nbi'):continue
        add(p,name+'/'+rel.as_posix())
    if (base/'build-source/src/anyfem/solve').exists():
        for n in ('stiffened_shell_b2.py','stiffened_shell_project.py'):
            add(base/'build-source/src/anyfem/solve'/n,name+'/runtime-source/anyfem/solve/'+n)
for pattern in ('r8-b2-footprint-consumer*.py','r8-b2-footprint-consumer*.json','r8-b2-footprint-consumer*.md','r8-prepare-b2-footprint-consumer*.py'):
    for p in sorted(r.glob(pattern)):add(p,'notes-and-runners/'+p.name)
for n in ('r8-nodal-footprint-command-bounded.py','r8-nodal-footprint-run-bounded.py','r8-nodal-footprint-consumer-run-installed.py'):
    add(r/n,'notes-and-runners/reused-'+n)
manifest={k:{'sha256':sha(p),'bytes':p.stat().st_size,'original_path':str(p.resolve())} for k,p in sorted(files.items())}
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for k,p in sorted(files.items()):z.write(p,k)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(out) as z:
    for k,v in manifest.items():assert hashlib.sha256(z.read(k)).hexdigest()==v['sha256'],k
identity={'files':len(manifest),'raw_bytes':sum(v['bytes'] for v in manifest.values()),'archive_bytes':out.stat().st_size,'archive_sha256':sha(out),'scope':'installed experimental B2 nodal-footprint consumer; full qualification open'}
(r/'r8-b2-footprint-consumer-evidence-v1-identity.json').write_text(json.dumps(identity,indent=2))
print(json.dumps(identity))
