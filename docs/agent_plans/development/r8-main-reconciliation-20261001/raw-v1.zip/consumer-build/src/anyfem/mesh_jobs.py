"""Background meshing over immutable document snapshots.

The mapped mesher is intentionally a synchronous, headless API.  This module
keeps that useful contract while providing the desktop application with a
single-worker adapter that never calls Tk from its worker thread.  Cancellation
is cooperative: checks surround the mesher and quality pass, so an
uninterruptible topology operation remains visibly ``cancelling`` until it
returns to a safe point.
"""

from __future__ import annotations

from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
import queue
import threading
import traceback
from typing import Any, Mapping

from .document import ProjectSnapshot, canonical_hash
from .mesh_controls import MeshControls, StructuredMeshControls

__all__ = [
    "clone_mesh_for_job",
    "MeshJobEvent",
    "MeshJobResult",
    "MeshProgress",
    "MeshSettings",
    "MeshTaskManager",
    "mesh_semantic_hash",
]


def clone_mesh_for_job(mesh: Any) -> Any:
    """Return a detached, solver-ready mesh through its public wire format.

    A current ANYmesher mesh may retain immutable ANYgeometry provenance such
    as ``mappingproxy`` objects.  Those values are intentionally not pickle or
    ``deepcopy`` compatible.  The versioned mesh codec is the supported
    boundary for background jobs and also guarantees that the worker receives
    no mutable objects shared with the live document.
    """

    from anymesher.serialize import mesh_from_dict, mesh_to_dict

    return mesh_from_dict(mesh_to_dict(mesh))


def _exception_diagnostic(error: BaseException) -> dict[str, Any]:
    """Preserve public structured evidence exposed by a meshing error."""

    payload: dict[str, Any] = {
        "type": type(error).__name__,
        "message": str(error),
        "traceback": traceback.format_exc(),
    }
    provider = getattr(error, "to_diagnostic", None)
    if callable(provider):
        try:
            details = provider()
        except BaseException as diagnostic_error:  # noqa: BLE001
            payload["diagnostic_error"] = (
                f"{type(diagnostic_error).__name__}: {diagnostic_error}"
            )
        else:
            if isinstance(details, Mapping):
                payload["details"] = dict(details)
    return payload


@dataclass(frozen=True)
class MeshSettings:
    """All explicit inputs needed to reproduce one mesh submission."""

    target_size: float
    element_order: str = "linear"
    overrides: tuple[tuple[int, int], ...] = ()
    # None preserves the established headless behaviour: inherit the strategy
    # from the snapshotted project, whose legacy default is Automatic.
    strategy: str | None = None
    structure_preference: str = "balanced"
    quality_policy: tuple[tuple[str, float], ...] = ()
    controls: MeshControls | None = None
    structured_controls: StructuredMeshControls | None = None
    quad_options: object | None = None
    layout_policy: str = "existing"
    automation: object | None = None

    def __post_init__(self) -> None:
        if self.automation is not None:
            try:
                from anymesher import MeshAutomationOptions
            except ImportError as error:
                raise RuntimeError(
                    "automatic mesh recovery requires a compatible ANYmesher installation"
                ) from error
            if not isinstance(self.automation, MeshAutomationOptions):
                raise TypeError("automation must be MeshAutomationOptions")
        if self.controls is not None and not isinstance(self.controls, MeshControls):
            raise TypeError("mesh controls must be MeshControls")
        if self.structured_controls is not None and not isinstance(
            self.structured_controls, StructuredMeshControls
        ):
            raise TypeError(
                "structured mesh controls must be StructuredMeshControls"
            )
        quad_selected = str(self.strategy).strip().lower() == "quad_first"
        if quad_selected:
            from .quad_first import effective_quad_options

            object.__setattr__(self, "quad_options", effective_quad_options(self.quad_options))
        elif self.quad_options is not None:
            raise ValueError("quad_options requires strategy='quad_first'")
        if self.layout_policy not in ("existing", "adaptive"):
            raise ValueError("layout_policy must be 'existing' or 'adaptive'")
        if self.layout_policy == "adaptive" and not quad_selected:
            raise ValueError("adaptive layout requires strategy='quad_first'")
        from anymesher.hybrid import MeshingStrategy
        from anymesher.structured import StructurePreference
        from anymesher.structured import MeshQualityPolicy

        if self.strategy is not None:
            try:
                strategy = (
                    "quad_first" if str(self.strategy).strip().lower() == "quad_first"
                    else MeshingStrategy(str(self.strategy).strip().lower()).value
                )
            except ValueError as error:
                choices = ", ".join(item.value for item in MeshingStrategy)
                raise ValueError(
                    f"unknown meshing strategy {self.strategy!r}; expected one of {choices}"
                ) from error
            object.__setattr__(self, "strategy", strategy)
        try:
            preference = StructurePreference(
                str(self.structure_preference).strip().lower()
            ).value
        except ValueError as error:
            choices = ", ".join(item.value for item in StructurePreference)
            raise ValueError(
                "unknown structure preference "
                f"{self.structure_preference!r}; expected one of {choices}"
            ) from error
        object.__setattr__(self, "structure_preference", preference)
        quality = MeshQualityPolicy.create(dict(self.quality_policy))
        object.__setattr__(
            self,
            "quality_policy",
            tuple(sorted((key, float(value)) for key, value in quality.to_dict().items())),
        )

    @classmethod
    def create(
        cls,
        target_size: float,
        *,
        element_order: str,
        overrides: Mapping[int, int] | None = None,
        strategy: str | None = None,
        structure_preference: str = "balanced",
        quality_policy: Mapping[str, float] | None = None,
        controls: MeshControls | None = None,
        structured_controls: StructuredMeshControls | None = None,
        quad_options: object | None = None,
        layout_policy: str = "existing",
        automation: object | None = None,
    ) -> "MeshSettings":
        size = float(target_size)
        if size <= 0.0:
            raise ValueError("element size must be positive")
        return cls(
            target_size=size,
            element_order=str(element_order),
            overrides=tuple(
                sorted((int(key), int(value)) for key, value in (overrides or {}).items())
            ),
            strategy=strategy,
            controls=controls,
            structured_controls=structured_controls,
            quad_options=quad_options,
            layout_policy=layout_policy,
            automation=automation,
            structure_preference=structure_preference,
            quality_policy=tuple(
                sorted((str(key), float(value)) for key, value in (quality_policy or {}).items())
            ),
        )

    @property
    def input_hash(self) -> str:
        payload = {
                "target_size": self.target_size,
                "element_order": self.element_order,
                "overrides": dict(self.overrides),
                "strategy": self.strategy,
                "quad_options": (
                    None if self.quad_options is None else self.quad_options.to_dict()
                ),
                "layout_policy": self.layout_policy if self.strategy == "quad_first" else None,
                "controls": (None if self.controls is None else
                             self.controls.effective_dict(self.strategy)),
                "structure_preference": (
                    self.structure_preference
                    if self.strategy in (None, "auto")
                    else None
                ),
                "quality_policy": (
                    dict(self.quality_policy)
                    if self.strategy in (None, "auto")
                    else None
                ),
                "structured_controls": (
                    None
                    if self.strategy not in (None, "auto")
                    or self.structured_controls is None
                    else self.structured_controls.effective_dict()
                ),
            }
        if self.automation is not None:
            payload["automation"] = self.automation.to_dict()
        return canonical_hash(payload)


@dataclass(frozen=True)
class MeshProgress:
    """Structured progress suitable for both a status bar and future logs."""

    stage: str
    message: str
    fraction: float


@dataclass(frozen=True)
class MeshJobResult:
    mesh: Any
    mesh_hash: str
    quality: Mapping[str, Any]
    structural_preparation: Mapping[str, Any]


def mesh_semantic_hash(
    mesh: Any,
    *,
    model_hash: str,
    mesh_input_hash: str,
    structural_preparation: Mapping[str, Any] | None = None,
) -> str:
    """Hash solver-affecting mesh semantics, excluding owner bookkeeping."""

    from anymesher.serialize import mesh_to_dict

    mesh_payload = dict(mesh_to_dict(mesh))
    mesh_payload.pop("geometry_model_id", None)
    mesh_payload.pop("geometry_revision", None)
    # ANYmesher 0.4 records its full preparation provenance in the neutral
    # mesh.  That block contains the detached working model UUID and hashes
    # derived from it, so it changes on every otherwise identical mesh job.
    # The canonicalized preparation report below already carries the
    # solver-affecting preparation semantics; keep the mesh portion limited to
    # materialized nodes, elements, associations, and coupling equations.
    mesh_payload.pop("structural_preparation", None)
    hybrid_diagnostics = mesh_payload.get("hybrid_diagnostics")
    if isinstance(hybrid_diagnostics, Mapping):
        hybrid_diagnostics = dict(hybrid_diagnostics)
        hybrid_diagnostics.pop("geometry_model_id", None)
        hybrid_diagnostics.pop("geometry_revision", None)
        hybrid_diagnostics.pop("structural_preparation_hash", None)

        def without_runtime_timings(value: Any) -> Any:
            if isinstance(value, Mapping):
                return {
                    key: without_runtime_timings(item)
                    for key, item in value.items()
                    if not str(key).endswith("_seconds")
                }
            if isinstance(value, list):
                return [without_runtime_timings(item) for item in value]
            if isinstance(value, tuple):
                return tuple(without_runtime_timings(item) for item in value)
            return value

        mesh_payload["hybrid_diagnostics"] = without_runtime_timings(
            hybrid_diagnostics
        )
    preparation = dict(structural_preparation or {})
    preparation.pop("working_model_id", None)
    preparation.pop("working_revision", None)
    preparation.pop("source_revision", None)
    preparation.pop("source_model_id", None)
    qualified_s3 = preparation.get("qualified_s3")
    if isinstance(qualified_s3, Mapping):
        qualified_s3 = dict(qualified_s3)
        authority_model = qualified_s3.get("authority_model")
        if isinstance(authority_model, Mapping):
            authority_model = dict(authority_model)
            # The authority remains the same physical model after exact undo;
            # its transaction revision is provenance rather than FE semantics.
            authority_model.pop("source_revision", None)
            qualified_s3["authority_model"] = authority_model
        preparation["qualified_s3"] = qualified_s3
    structural_closure = preparation.get("structural_closure")
    if isinstance(structural_closure, Mapping):
        structural_closure = dict(structural_closure)
        # Both values are derived from the detached job clone and therefore
        # change on an otherwise identical remesh.
        structural_closure.pop("model_id", None)
        structural_closure.pop("preparation_hash", None)
        preparation["structural_closure"] = structural_closure
    structured_layout = preparation.get("structured_layout")
    if isinstance(structured_layout, Mapping):
        structured_layout = dict(structured_layout)
        plan = structured_layout.get("plan")
        if isinstance(plan, Mapping):
            plan = dict(plan)
            # The detached clone receives a new UUID on every mesh job.  It is
            # provenance, not solver-affecting mesh semantics.  The plan hash
            # already captures its canonical topology/options without either
            # transaction identifier.
            plan.pop("model_id", None)
            plan.pop("revision", None)
            structured_layout["plan"] = plan
        structured_layout.pop("source_to_working_faces", None)
        structured_layout.pop("source_to_working_edges", None)
        preparation["structured_layout"] = structured_layout
    return canonical_hash(
        {
            "model_hash": str(model_hash),
            "mesh_input_hash": str(mesh_input_hash),
            "structural_preparation": preparation,
            "mesh": mesh_payload,
        }
    )


@dataclass(frozen=True)
class MeshJobEvent:
    job_id: str
    kind: str
    message: str = ""
    payload: Any = None


@dataclass
class _ActiveMeshJob:
    job_id: str
    cancellation: Any
    future: Future


class MeshTaskManager:
    """Run at most one local mesh operation without blocking the UI thread."""

    def __init__(self) -> None:
        self._executor = ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="anyfem-mesh"
        )
        self._events: "queue.Queue[MeshJobEvent]" = queue.Queue()
        self._lock = threading.RLock()
        self._active: _ActiveMeshJob | None = None
        self._closing = False

    @property
    def active_job_id(self) -> str | None:
        with self._lock:
            return None if self._active is None else self._active.job_id

    @property
    def running(self) -> bool:
        with self._lock:
            return self._active is not None and not self._active.future.done()

    @property
    def busy(self) -> bool:
        """Whether a submission still owns the manager, including final polling."""

        with self._lock:
            return self._active is not None

    def submit(
        self,
        job_id: str,
        snapshot: ProjectSnapshot,
        settings: MeshSettings,
    ) -> Future:
        with self._lock:
            if self._closing:
                raise RuntimeError("mesh task manager is closed")
            if self._active is not None:
                raise ValueError("a mesh is already being generated")
            cancellation = _cancellation_token()
            future = self._executor.submit(
                self._run, str(job_id), snapshot, settings, cancellation
            )
            self._active = _ActiveMeshJob(str(job_id), cancellation, future)
            return future

    def cancel(self, job_id: str | None = None) -> bool:
        with self._lock:
            active = self._active
            if active is None or (job_id is not None and job_id != active.job_id):
                return False
            if active.future.done():
                return False
            changed = active.cancellation.cancel("mesh cancellation requested")
            if changed:
                self._events.put(
                    MeshJobEvent(
                        active.job_id,
                        "cancelling",
                        "cancelling mesh; waiting for the current safe phase",
                    )
                )
            return bool(changed)

    def poll(self, limit: int | None = None) -> list[MeshJobEvent]:
        events: list[MeshJobEvent] = []
        while limit is None or len(events) < limit:
            try:
                event = self._events.get_nowait()
            except queue.Empty:
                break
            events.append(event)
            if event.kind in ("completed", "cancelled", "failed"):
                with self._lock:
                    if self._active is not None and self._active.job_id == event.job_id:
                        self._active = None
        return events

    def shutdown(self) -> None:
        with self._lock:
            self._closing = True
            active = self._active
            if active is not None:
                active.cancellation.cancel("application is closing")
        self._executor.shutdown(wait=False, cancel_futures=True)

    def _run(
        self,
        job_id: str,
        snapshot: ProjectSnapshot,
        settings: MeshSettings,
        cancellation: Any,
    ) -> None:
        def progress(stage: str, message: str, fraction: float) -> None:
            self._events.put(
                MeshJobEvent(
                    job_id,
                    "progress",
                    message,
                    MeshProgress(stage, message, float(fraction)),
                )
            )

        self._events.put(MeshJobEvent(job_id, "started", "preparing mesh snapshot"))
        try:
            cancellation.raise_if_cancelled("mesh snapshot")
            project = snapshot.thaw()
            from anymesher.hybrid import MeshingStrategy

            requested_strategy = settings.strategy
            if requested_strategy is None:
                project_settings = project.native_mesh_settings
                backend = (
                    "automatic"
                    if project_settings is None
                    else str(
                        getattr(
                            project_settings.backend,
                            "value",
                            project_settings.backend,
                        )
                    )
                )
                requested_strategy = {
                    "automatic": "auto",
                    "auto": "auto",
                    "mapped": "mapped",
                    "native": "native",
                }.get(backend, backend)
            resolved_strategy = (
                "quad_first" if requested_strategy == "quad_first"
                else MeshingStrategy(requested_strategy).value
            )
            resolved_controls = settings.controls or MeshControls.from_settings(project.native_mesh_settings)
            resolved_structured_controls = (
                settings.structured_controls
                or StructuredMeshControls.from_settings(
                    project.native_mesh_settings
                )
            )
            progress("snapshot", "prepared immutable model snapshot", 0.1)
            cancellation.raise_if_cancelled("mesh generation")
            progress("generation", "generating mesh elements", 0.2)
            mesh = project.generate_mesh(
                settings.target_size,
                overrides=dict(settings.overrides),
                order=settings.element_order,
                strategy=settings.strategy,
                structure_preference=settings.structure_preference,
                quality_policy=dict(settings.quality_policy),
                mesh_controls=resolved_controls,
                structured_controls=resolved_structured_controls,
                quad_options=settings.quad_options,
                layout_policy=settings.layout_policy,
                automation=settings.automation,
                cancellation_check=cancellation.raise_if_cancelled,
            )
            cancellation.raise_if_cancelled("mesh quality")
            progress("quality", "checking element quality", 0.85)
            from anymesher import verify_mesh_quality

            quality = verify_mesh_quality(mesh).as_dict()
            cancellation.raise_if_cancelled("mesh hashing")
            progress("hash", "hashing immutable mesh result", 0.94)
            structural_preparation = dict(project._last_mesh_preparation)
            resolved_settings_hash = settings.input_hash
            if (
                settings.strategy is None
                or settings.controls is None
                or settings.structured_controls is None
            ):
                # Older/headless callers inherit the snapshotted project
                # strategy. Canonicalize that resolved value so their hash is
                # identical to an explicit UI submission of the same method.
                resolved_settings_hash = MeshSettings.create(
                    settings.target_size,
                    element_order=settings.element_order,
                    overrides=dict(settings.overrides),
                    strategy=resolved_strategy,
                    structure_preference=settings.structure_preference,
                    quality_policy=dict(settings.quality_policy),
                    controls=resolved_controls,
                    structured_controls=resolved_structured_controls,
                    quad_options=settings.quad_options,
                    layout_policy=settings.layout_policy,
                    automation=settings.automation,
                ).input_hash
            semantic_input_hash = canonical_hash(
                {
                    "mesh_settings": resolved_settings_hash,
                    # The constrained triangulator is not consulted by an
                    # explicitly mapped job and therefore must not affect its
                    # reproducibility hash.
                    "native_backend": (
                        None
                        if resolved_strategy == "mapped"
                        else project.native_triangulation_backend
                    ),
                }
            )
            mesh_hash = mesh_semantic_hash(
                mesh,
                model_hash=snapshot.revision.model_hash,
                mesh_input_hash=semantic_input_hash,
                structural_preparation=structural_preparation,
            )
            cancellation.raise_if_cancelled("mesh completion")
            progress("complete", "mesh and quality checks complete", 1.0)
        except BaseException as error:  # noqa: BLE001 - retained as diagnostics
            if _is_cancelled(cancellation):
                self._events.put(
                    MeshJobEvent(job_id, "cancelled", "mesh generation cancelled")
                )
            else:
                self._events.put(
                    MeshJobEvent(
                        job_id,
                        "failed",
                        str(error),
                        _exception_diagnostic(error),
                    )
                )
            return
        self._events.put(
            MeshJobEvent(
                job_id,
                "completed",
                "mesh generation complete",
                MeshJobResult(
                    mesh=mesh,
                    mesh_hash=mesh_hash,
                    quality=quality,
                    structural_preparation=structural_preparation,
                ),
            )
        )


def _cancellation_token():
    try:
        from anysolver import CancellationToken

        return CancellationToken()
    except ImportError:  # pragma: no cover - ANYsolver is a normal dependency
        class Token:
            def __init__(self) -> None:
                self._cancelled = threading.Event()

            @property
            def is_cancelled(self) -> bool:
                return self._cancelled.is_set()

            def cancel(self, _reason: str = "") -> bool:
                changed = not self._cancelled.is_set()
                self._cancelled.set()
                return changed

            def raise_if_cancelled(self, _stage: str = "") -> None:
                if self.is_cancelled:
                    raise RuntimeError("mesh cancelled")

        return Token()


def _is_cancelled(token: Any) -> bool:
    value = getattr(token, "is_cancelled", None)
    if value is None:
        value = getattr(token, "cancelled", False)
    return bool(value() if callable(value) else value)
