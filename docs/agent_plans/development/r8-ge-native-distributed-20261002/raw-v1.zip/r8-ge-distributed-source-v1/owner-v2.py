import importlib.util, os, sys
from pathlib import Path
root=Path(os.environ['TEMP'])/'r8-ge-distributed-source-v1'
spec=importlib.util.spec_from_file_location('supervisor',Path(os.environ['TEMP'])/'r8-b2-panel-resolution-installed-v1/matched-run.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
s.ENV['PYTHONPATH']=str(repo/'src')
s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
r=s.supervised([sys.executable,'-m','pytest','-q',str(repo/'tests/test_stiffened_shell_ge_distributed_load.py')],root/'owner-v2')
print({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')})


