from pathlib import Path
import os,sys,json,hashlib,shutil,zipfile,importlib.util,runpy
ROOT=Path(__file__).parent
REPO=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
SITE=ROOT/'site'
TESTS=('test_stiffened_shell_ge_distributed_curved.py','test_stiffened_shell_native_distributed_load.py','test_stiffened_shell_ge_distributed_load.py','test_stiffened_shell_native_gravity.py','test_stiffened_shell_ge_body_load.py','test_stiffened_shell_ge_gravity_owner.py','test_stiffened_shell_staged_load_owner_experimental.py')
HELPERS=('test_ge_beam3_fibre_section.py','test_stiffened_shell_ge_physical_fibre_linear.py','test_stiffened_shell_ge_experimental.py','test_stiffened_shell_ge_reference_modal.py','test_stiffened_shell_ge_finite_experimental.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def prepare():
    manifest=json.loads((ROOT/'source-manifest.json').read_text());wheel,=(ROOT/'wheels').glob('*.whl')
    with zipfile.ZipFile(wheel) as z:
        names={n for n in z.namelist() if n.startswith('anysolver/') and n.endswith('.py')}
        assert names=={n.removeprefix('src/') for n in manifest}
        for name,digest in manifest.items():
            rel=name.removeprefix('src/')
            assert sha(REPO/name)==sha(SITE/rel)==hashlib.sha256(z.read(rel)).hexdigest()==digest
    fixtures=ROOT/'fixtures';fixtures.mkdir(exist_ok=True)
    records={}
    for name in (*TESTS,*HELPERS):
        path=REPO/'tests'/name;target=fixtures/name
        if target.exists():assert sha(target)==sha(path)
        else:shutil.copy2(path,target)
        records['tests/'+name]=sha(path)
    for name in ('examples/stiffened_shell_ge_gravity.py','examples/stiffened_shell_ge_distributed_load.py'):
        shutil.copy2(REPO/name,fixtures/Path(name).name);records[name]=sha(REPO/name)
    (fixtures/'pytest.ini').write_text('[pytest]\n')
    (ROOT/'curved-fixture-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
    (ROOT/'artifact-identity.json').write_text(json.dumps(dict(wheel=str(wheel),sha256=sha(wheel),modules=len(manifest),site=str(SITE)),indent=2)+'\n')
def child(mode):
    from importlib import metadata
    import anysolver,numba,threadpoolctl
    def runtime():
        pools=threadpoolctl.threadpool_info()
        assert pools and all(p['num_threads']==1 for p in pools)
        assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
        return pools
    runtime();assert Path(anysolver.__file__).resolve().is_relative_to(SITE.resolve())
    code=0
    if mode=='test':
        import pytest
        code=pytest.main(['-q','-c',str(ROOT/'fixtures/pytest.ini'),'-p','no:cacheprovider','--junitxml='+str(Path.cwd()/'junit.xml'),str(ROOT/'fixtures/test_stiffened_shell_ge_distributed_curved.py')])
    else:
        sys.path.insert(0,str(ROOT/'fixtures'))
        runpy.run_path(str(ROOT/'fixtures/stiffened_shell_ge_distributed_load.py'),run_name='__main__')
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith('anysolver') and getattr(m,'__file__',None)}
    assert all(Path(p).is_relative_to(SITE.resolve()) for p in imports.values())
    record=dict(exit_code=int(code),python=sys.version,imports=imports,pools=runtime(),numba_threads=numba.get_num_threads(),jit_disabled=bool(numba.config.DISABLE_JIT),dependencies={n:metadata.version(n) for n in ('numpy','scipy','numba','ANYmaterial','ANYsolver','pytest','threadpoolctl','psutil')})
    Path('runtime.json').write_text(json.dumps(record,indent=2)+'\n');sys.exit(code)
if sys.argv[1]=='child':child(sys.argv[2])
else:
    prepare()
    spec=importlib.util.spec_from_file_location('supervisor',ROOT.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    m.ENV['PYTHONPATH']=str(SITE)
    mode=sys.argv[1];r=m.supervised([sys.executable,str(ROOT/'run-curved.py'),'child',mode],ROOT/(mode+'-curved-v1'))
    print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))

