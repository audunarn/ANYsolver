"""Distributed native work with actual coupled material activity."""
import numpy as np
from anysolver import stiffened_shell as ss
from examples.stiffened_shell_coupled_plastic_history import definition, activity, OPTIONS, CONTROL
from test_stiffened_shell_ge_distributed_load import balance


def test_distributed_force_activates_shell_and_physical_fibres(request, record_property):
    owner = ss.create_analysis(definition=definition())
    request.addfinalizer(owner.close)
    loads = ss.GEBeamDistributedLoad(owner.preflight()['identity'], tuple(
        ss.GEBeamLineAction(e.element_id, (0., 0., 1500.)) for e, _, _ in owner._beam_parts))
    history, accepted = [], []
    def observe(result):
        row = activity(result, accepted[-1] if accepted else None)
        row['factor'] = result.accepted_factors[-1]
        history.append(row)
        accepted.append(result)
        balance(owner, result)
    result = owner.solve(loads, (.5, 1.), increment_control=CONTROL,
                         on_accepted=observe, **OPTIONS)
    record_property('material_activity', history)
    assert result.status == 'completed'
    assert any(row['simultaneous'] for row in history), history
    restored = ss.create_analysis(definition=definition())
    request.addfinalizer(restored.close)
    other = restored.restore(owner.checkpoint())
    np.testing.assert_array_equal(result.shell_layer_alpha, other.shell_layer_alpha)
    assert owner.checkpoint() == restored.checkpoint()
