from pathlib import Path
import hashlib,json,importlib.util,os,sys
root=Path(__file__).parent
old=root.parent/"r8-curved-consumer-installed-v1"
text=(old/"run.py").read_text()
body=text.split(" # Actual E04 geometry",1)[1].split("\nelse:",1)[0]
body="# Actual E04 geometry"+body
body="\n".join(line[1:] if line.startswith(" ") else line for line in body.splitlines())
body=body.replace("import build,definition","import build,definition,crown_reference_perturbations")
body=body.replace("case=build(4,4);d=definition(case,density_kg_m3=1.);node=case.loaded_shell_node+1",
"""case=build(4,4);original=definition(case,density_kg_m3=1.)
change=ss.create_stress_free_point_reference(original,crown_reference_perturbations(case,1e-4))
d=change.definition;node=case.loaded_shell_node+1
Path("reference.json").write_text(json.dumps(dict(policy=change.policy,source_identity=change.source_identity,target_identity=change.target_identity,stress_free_scaled_max=change.stress_free_scaled_max),indent=2))""")
prelude="""from pathlib import Path
import sys,os,json,hashlib,numpy as np
root=Path(__file__).parent
site=root.parent/'r8-curved-consumer-installed-v1/site'
solver_site=root/'site';fixtures=root/'fixtures'
sys.path.insert(0,str(fixtures))
import anyfem,anysolver,numba,threadpoolctl
assert Path(anyfem.__file__).resolve().is_relative_to(site.resolve())
assert Path(anysolver.__file__).resolve().is_relative_to(solver_site.resolve())
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
"""
(root/"consumer-child.py").write_text(prelude+body)
repo=Path("C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer")
artifact=json.loads((old/"artifact.json").read_text())
for rel,digest in artifact["consumer_modules"].items():
    b=(repo/"src"/rel).read_bytes();assert hashlib.sha256(b).hexdigest()==digest
    assert b==(old/"site"/rel).read_bytes()
(root/"consumer-artifact.json").write_text(json.dumps(dict(consumer_wheel_sha256=artifact["consumer_wheel_sha256"],consumer_modules_matched=len(artifact["consumer_modules"]),solver_wheel_sha256=json.loads((root/"artifact.json").read_text())["wheel_sha256"]),indent=2))
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=str(root/"site")+os.pathsep+str(old/"site")
result=s.supervised([sys.executable,str(root/"consumer-child.py")],root/"consumer")
print(json.dumps({k:result[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
