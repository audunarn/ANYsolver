from pathlib import Path
import sys,os,json,hashlib,numpy as np
root=Path(__file__).parent
site=root.parent/'r8-curved-consumer-installed-v1/site'
solver_site=root/'site';fixtures=root/'fixtures'
sys.path.insert(0,str(fixtures))
import anyfem,anysolver,numba,threadpoolctl
assert Path(anyfem.__file__).resolve().is_relative_to(site.resolve())
assert Path(anysolver.__file__).resolve().is_relative_to(solver_site.resolve())
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
# Actual E04 geometry is a captured reference-case fixture, not consumer-owned mechanics.
from dataclasses import replace
import numpy as np
from docs.reference_cases.stiffened_shell_e04_roof import build,definition,crown_reference_perturbations
from anysolver import stiffened_shell as ss
from anyfem.solve.stiffened_shell import ExperimentalGEPointPanel,save_case,load_case
from anyfem.io.project_file import save_project,load_project
from anyfem.model.project import Project
from anyfem.model.records import AnalysisDefinition
case=build(4,4);original=definition(case,density_kg_m3=1.)
change=ss.create_stress_free_point_reference(original,crown_reference_perturbations(case,1e-4))
d=change.definition;node=case.loaded_shell_node+1
Path("reference.json").write_text(json.dumps(dict(policy=change.policy,source_identity=change.source_identity,target_identity=change.target_identity,stress_free_scaled_max=change.stress_free_scaled_max),indent=2))
shell=replace(d.shell,coordinates_m=tuple(tuple(float(v) for v in row) for row in d.shell.coordinates_m))
actions=(ss.NodalAction('shell',node,(0.,0.,-10.,0.,0.,0.)),)
panel=ExperimentalGEPointPanel(shell,tuple(d.beams),tuple(d.points),tuple(d.fixed),actions,
 q4_pullback_policy=d.q4_pullback_policy,shell_reference_policy=d.shell_reference_policy)
reopened=load_case(save_case(panel,'roof.anyfem-ge.json'));assert reopened.to_dict()==panel.to_dict()
project=Project('E04 curved point roof',mesh_only=True);analysis=AnalysisDefinition.experimental_point_panel('roof',reopened);project.add_analysis(analysis)
path=save_project(project,'roof.anyfem');stored=load_project(path).analyses[analysis.id]
owner=stored.create_point_panel_analysis();restored=None
try:
 owner.solve(actions,(1.,));control=ss.ArcLengthControl('shell',node,2,ss.PhysicalChordMetric(case.metric_weights,case.length),1e-5,-1)
 owner.continue_arc_length(actions,control);prefix=owner.checkpoint();Path('roof-prefix.bin').write_bytes(prefix)
 restored=load_project(path).analyses[analysis.id].create_point_panel_analysis();restored.restore(prefix)
 assert restored.checkpoint()==prefix
 live=owner.continue_arc_length(actions,control);repeated=restored.continue_arc_length(actions,control)
 assert owner.checkpoint()==restored.checkpoint();np.testing.assert_array_equal(live.cell_resultants,repeated.cell_resultants)
 Path('roof-final.bin').write_bytes(restored.checkpoint())
 Path('roof-result.json').write_text(json.dumps(dict(status='COMPLETED_DEVELOPMENT_ONLY',schema=panel.to_dict()['schema'],shells=len(case.quads),beams=len(case.beam_cells),restart_bytes_equal=True,equilibrium=repeated.free_equilibrium_ratio,constraint=repeated.constraint_max,central_translation_m=repeated.shell_displacement.reshape(-1,6)[case.loaded_shell_node,:3].tolist(),downward_force_n=10*(1+repeated.amplitude)),indent=2))
finally:
 owner.close()
 if restored is not None:restored.close()
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith(('anysolver','anyfem')) and getattr(m,'__file__',None)}
assert all(Path(p).is_relative_to((site if n.startswith('anyfem') else solver_site).resolve()) for n,p in imports.items())
Path('runtime.json').write_text(json.dumps(dict(imports=imports,pools=threadpoolctl.threadpool_info(),python=sys.version,jit_disabled=bool(numba.config.DISABLE_JIT)),indent=2))