from pathlib import Path
import importlib.util,os,sys,json
root=Path(__file__).parent
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=str(root/"site")+os.pathsep+str(root/"fixtures")
r=s.supervised([sys.executable,str(root/"fixtures/roof.py"),"--output",str(root/"roof-negative/result"),"--size","4","--density","1","--imperfection-m","-0.0001","--seed-force","10","--radius","0.00001","--steps","2","--restart-after","1"],root/"roof-negative")
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
