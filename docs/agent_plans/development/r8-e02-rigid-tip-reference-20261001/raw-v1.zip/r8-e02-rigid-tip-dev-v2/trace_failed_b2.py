"""Observe an existing public failure without altering its result or equations."""
from pathlib import Path
import json, runpy, sys

out=Path(__file__).parent/'b2-resolution-diagnostic.json'
seen=[]
def trace(frame,event,arg):
    if event=='exception' and frame.f_code.co_filename.endswith('_stiffened_shell_b2_q4_panel_experimental.py'):
        typ,value,tb=arg
        if str(value)=='panel mixed-load resolution insufficient':
            local=frame.f_locals
            floor=local['resolution_floor']; rhs=local['explicit_rhs']; active=rhs>0.
            idx=(floor[active]/rhs[active]).argmax()
            seen.append(dict(error=str(value),active_indices=[int(i) for i in active.nonzero()[0]],
                floor_active=floor[active].tolist(),explicit_rhs_active=rhs[active].tolist(),
                max_floor_fraction=float((floor[active]/rhs[active])[idx]),
                roundoff_fraction=float(local['roundoff_fraction']),
                force_roundoff=float(local['force_roundoff']),moment_roundoff=float(local['moment_roundoff']),
                matrix_shape=frame.f_locals['self']._K.shape))
    return trace
sys.settrace(trace)
try:
    runpy.run_path(str(Path(__file__).parent/'native-runner.py'),run_name='__main__')
finally:
    sys.settrace(None)
    out.write_text(json.dumps(seen,indent=2)+'\n')
