"""Combined bounded development interpretation, never a qualification pass."""
from pathlib import Path
import hashlib,json,math

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
LEVELS=((10,4),(20,8),(40,16))
records=[]
def finite_tree(v):
    if isinstance(v,dict): return all(finite_tree(x) for x in v.values())
    if isinstance(v,list): return all(finite_tree(x) for x in v)
    if isinstance(v,float): return math.isfinite(v)
    return True

def native(nx,ny,sign):
    version='v2' if nx==10 and sign==1 else 'v3'
    p=BASE/f'r8-e02-rigid-tip-dev-{version}'/f'native-ge-{nx}x{ny}-s{sign}'/'outputs/result.json'
    value=json.loads(p.read_text())
    assert finite_tree(value)
    assert value['geometry']['rigid_patch_x']==[.8,1.]
    assert value['geometry']['thickness_m']==.02
    for case in value['results'].values():
        assert case['status']=='completed'
        c=case['controls']
        assert c['actual_shell_cross_block_ratio']<=1e-12
        assert c['shell_normal_spin_max']<=1e-12
        assert c['shell_membrane_drilling_coordinate_max']<=1e-12
        assert c['footprint_direct_Mz_max_Nm']<=1e-8
        assert abs(c['stub_quadratic_work_J'])<=1e-10*abs(case['external_final_pairing_J'])
        assert c['physical_patch_translation_gap_m']<=1e-9
        assert max(abs(x) for x in c['root_wrench_error'])<=1e-7
        assert max(abs(x) for x in c['footprint_wrench_error'])<=1e-8
        assert max(abs(x) for x in c['port_offset_identity_m'])<=1e-9
    records.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    return value

def external(nx,ny,sign,name):
    folder=ROOT/f'external-ccx-{nx}x{ny}-s{sign}'/name
    p=folder/'result.json'; identity=json.loads((folder/'identity.json').read_text())
    value=json.loads(p.read_text()); assert finite_tree(value)
    assert value['status']=='COMPLETED_DEVELOPMENT_ONLY'
    assert identity['deck_sha256']==identity['metadata']['deck_sha256']
    assert value['deck_sha256']==identity['deck_sha256']
    assert value['printed_rounding']['can_certify_relative_balance_1e_minus_8'] is False
    records.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    return value

rows=[]
for nx,ny in LEVELS:
    n=native(nx,ny,1)
    for name,a in n['results'].items():
        b=external(nx,ny,1,name)
        work_n=a['external_final_pairing_J']; work_b=b['conjugate_external_work_J']
        assert work_n>0 and work_b>0
        rows.append(dict(nx=nx,ny=ny,load=name,native_work_J=work_n,
            external_work_J=work_b,external_work_rounding_bound_J=b['conjugate_external_work_rounding_bound_J'],
            relative_native_external_difference=work_n/work_b-1,
            native_controls=a['controls'], external_rigid_mapping=b['rigid_mapping']))
trends={}
for name in ('Fz','Mx','My'):
    r=[x for x in rows if x['load']==name]
    trends[name]=dict(native_successive_changes=[r[i+1]['native_work_J']/r[i]['native_work_J']-1 for i in range(2)],
        external_successive_changes=[r[i+1]['external_work_J']/r[i]['external_work_J']-1 for i in range(2)])
parity=[]
nplus=native(10,4,1); nminus=native(10,4,-1)
for name in ('Fz','Mx','My'):
    for label,a,b in (('native',nplus['results'][name],nminus['results'][name]),
                       ('external',external(10,4,1,name),external(10,4,-1,name))):
        key='external_final_pairing_J' if label=='native' else 'conjugate_external_work_J'
        translation='port_translation_m' if label=='native' else 'patch_ref_displacement_m'
        rotation='port_rotation_rad' if label=='native' else 'patch_rot_theta_rad'
        delta=abs(a[key]/b[key]-1)
        assert delta<=1e-8
        parity.append(dict(profile=label,load=name,relative_work_difference=delta,
            odd_xy_translation_sum_m=[a[translation][i]+b[translation][i] for i in (0,1)],
            even_physical_difference=[a[translation][2]-b[translation][2],
                                     a[rotation][0]-b[rotation][0],a[rotation][1]-b[rotation][1]]))
decision=dict(status='COMPLETED_DEVELOPMENT_ONLY_NOT_QUALIFIED',source_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    compared_rows=rows,refinement=trends,coarse_offset_parity=parity,input_records=records,
    decision='Retain restricted reference-linear out-of-plane rigid-footprint candidate; no automatic fourth mesh.',
    scientific_acceptance='OPEN',
    boundaries=['Native final Mx refinement change remains greater than1%.',
        'Two solid thickness cells were fixed; through-thickness convergence is not established.',
        'Seven-digit external nodal output does not certify1e-8balance.',
        'Normal-spin/in-plane/finite-rotation/general connection equivalence not established.',
        'B2 public load-resolution guard failed at40Q4cells; retain failure and diagnose without relaxation.',
        'Coarse positive native GE energy in v2 was inferred half work, not independent internal energy; unused for acceptance.',
        'V2 external decks were CRLF-translated; exact LF deck identities verified for v3.'])
with (ROOT/'comparison.json').open('x') as f: json.dump(decision,f,indent=2); f.write('\n')
print(json.dumps(dict(status=decision['status'],finest={r['load']:r['relative_native_external_difference'] for r in rows if r['nx']==40},
    refinement=trends,coarse_parity_max=max(x['relative_work_difference'] for x in parity))))
