from pathlib import Path
import hashlib, json, os, runpy, shutil, subprocess, sys, time, zipfile
import psutil

ROOT = Path(__file__).resolve().parent
SOURCE = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
FIXTURES = ('test_stiffened_shell_b2_mixed_panel_experimental.py',
 'test_b2_f10_f11_s3_point_attachment.py',
 'test_stiffened_shell_b2_resolution_certificate.py',
 'test_stiffened_shell_b2_q4_panel_experimental.py',
 'test_stiffened_shell_b2_nodal_rigid_footprint.py',
 'test_b2_f13_affine_batch_dev.py',
 'test_stiffened_shell_b2_reference_modes.py',
 'test_stiffened_shell_b2_footprint_reference_modes.py',
 'test_b2_f09_physical_off_axis_elbow.py',
 'test_b2_physical_linear_oriented_graph.py')

def prepare():
    build = ROOT/'build-source'
    build.mkdir()
    shutil.copytree(SOURCE/'src', build/'src', ignore=shutil.ignore_patterns('__pycache__', '*.egg-info'))
    for name in ('pyproject.toml', 'MANIFEST.in', 'README.md', 'LICENSE', 'COPYRIGHT',
                 'LICENSING.md', 'THIRD_PARTY_NOTICES.md', 'dependency-licenses.json',
                 'CHANGELOG.md', 'MIGRATION.md'):
        shutil.copy2(SOURCE/name, build/name)
    # Copy the small package documentation selected by MANIFEST, not evidence.
    for line in (SOURCE/'MANIFEST.in').read_text().splitlines():
        if line.startswith('include docs/'):
            p = Path(line.removeprefix('include '))
            (build/p).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(SOURCE/p, build/p)
    manifest = {str(p.relative_to(SOURCE)).replace('\\', '/'): sha(p)
                for p in sorted((SOURCE/'src/anysolver').rglob('*.py'))}
    (ROOT/'source-manifest.json').write_text(json.dumps(manifest, indent=2))
    (ROOT/'fixtures').mkdir()
    for name in FIXTURES:
        shutil.copy2(SOURCE/'tests'/name, ROOT/'fixtures'/name)
    (ROOT/'scripts').mkdir()
    shutil.copy2(SOURCE/'scripts/probe_b3_ge_e4_pl_g0_f09_graph_reversal.py', ROOT/'scripts')
    shutil.copy2(SOURCE/'examples/stiffened_shell_b2_footprint_reference_modes.py', ROOT/'example.py')
    shutil.copy2(SOURCE/'examples/stiffened_shell_b2_mixed_panel.py', ROOT/'mixed-example.py')
    (ROOT/'pytest.ini').write_text('[pytest]\n')
    (ROOT/'wheels').mkdir()
    commands = ([sys.executable, '-m', 'pip', 'wheel', '--no-deps', '--no-build-isolation',
                 '--no-cache-dir', '--wheel-dir', str(ROOT/'wheels'), str(build)],)
    for command in commands:
        subprocess.run(command, check=True, timeout=120)
    wheel, = (ROOT/'wheels').glob('*.whl')
    subprocess.run([sys.executable, '-m', 'pip', 'install', '--no-deps', '--no-index',
                    '--no-cache-dir', '--target', str(ROOT/'site'), str(wheel)], check=True, timeout=60)
    old_consumer = ROOT.parent/'r8-anyfem-b2-modal-installed-v1'
    consumer_wheel, = (old_consumer/'wheels').glob('*.whl')
    assert sha(consumer_wheel) == '11728ab84a2c2b290d37651c455d9f6b7d63110e4804cb9263686c37511fa56e'
    subprocess.run([sys.executable, '-m', 'pip', 'install', '--no-deps', '--no-index',
                    '--no-cache-dir', '--target', str(ROOT/'site'), str(consumer_wheel)], check=True, timeout=60)
    shutil.copy2(ROOT.parent/'r8-b2-panel-resolution-installed-v1'/'consumer.py', ROOT/'consumer.py')
    print(json.dumps({'wheel_sha256': sha(wheel), 'source_modules': len(manifest)}))

def check(label):
    from importlib import metadata
    import anysolver, numpy, scipy, numba, threadpoolctl
    source = json.loads((ROOT/'source-manifest.json').read_text())
    wheel, = (ROOT/'wheels').glob('*.whl')
    site = ROOT/'site'
    assert all(sha(SOURCE/p) == h for p, h in source.items()), 'source changed since snapshot'
    with zipfile.ZipFile(wheel) as z:
        files = {p for p in z.namelist() if p.startswith('anysolver/') and p.endswith('.py')}
        assert files == {p.removeprefix('src/') for p in source}
        assert all(z.read(p) == (site/p).read_bytes() == (SOURCE/'src'/p).read_bytes() for p in files)
    assert numba.config.DISABLE_JIT and numba.get_num_threads() == 1
    pools = threadpoolctl.threadpool_info()
    assert pools and all(p['num_threads'] == 1 for p in pools)
    identity = {'wheel_sha256': sha(wheel), 'matching_modules': len(files),
      'source': str(SOURCE), 'site': str(site), 'python': sys.version,
      'pools': pools, 'jit_disabled': True, 'numba_threads': numba.get_num_threads(),
      'fixtures_sha256': {p.name: sha(p) for p in (ROOT/'fixtures').glob('*.py')},
      'example_sha256': sha(ROOT/'example.py'),
      'mixed_example_sha256': sha(ROOT/'mixed-example.py'),
      'dependencies': {n: metadata.version(n) for n in
                      ('numpy', 'scipy', 'numba', 'pytest', 'threadpoolctl', 'ANYmaterial', 'ANYmesher', 'ANYfileio')}}
    (ROOT/(label+'-identity.json')).write_text(json.dumps(identity, indent=2))
    try:
        if label == 'consumer':
            runpy.run_path(str(ROOT/'consumer.py'), run_name='__main__')
            code = 0
        elif label in ('example', 'example-mixed', 'example-s3'):
            example = ROOT/('example.py' if label == 'example' else 'mixed-example.py')
            sys.argv = [str(example)] if label == 'example' else [str(example), '--mesh', label.removeprefix('example-')]
            runpy.run_path(str(example), run_name='__main__')
            code = 0
        else:
            import pytest
            targets = [str(ROOT/'fixtures'/v.split('::')[0])+('::'+v.split('::', 1)[1] if '::' in v else '')
                       for v in sys.argv[3:]]
            code = int(pytest.main(['-q', '-c', str(ROOT/'pytest.ini'),
                '--basetemp='+str(ROOT/(label+'-states')), '--junitxml='+str(ROOT/(label+'-inventory.xml')), *targets]))
    finally:
        imports = {n: str(Path(m.__file__).resolve()) for n, m in sys.modules.copy().items()
                   if n.split('.')[0] == 'anysolver' and getattr(m, '__file__', None)}
        (ROOT/(label+'-imports.json')).write_text(json.dumps(imports, indent=2))
        assert imports and all(Path(p).is_relative_to(site.resolve()) for p in imports.values())
        assert numba.get_num_threads() == 1 and all(p['num_threads'] == 1 for p in threadpoolctl.threadpool_info())
    print(json.dumps({'exit': code, 'onsite_imports': len(imports), 'label': label}))
    sys.exit(code)

def supervise(label):
    env = os.environ.copy()
    env.update(PYTHONPATH=os.pathsep.join(map(str, (ROOT/'site', ROOT/'fixtures', ROOT))),
      PYTHONNOUSERSITE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', NUMBA_DISABLE_JIT='1',
      OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', OMP_NUM_THREADS='1', NUMBA_NUM_THREADS='1')
    command = [sys.executable, '-u', str(Path(__file__)), 'child', label, *sys.argv[2:]]
    started, peak, limit = time.monotonic(), 0, None
    with (ROOT/(label+'.log')).open('x') as log:
        p = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        owned = psutil.Process(p.pid)
        tree = [owned]
        while p.poll() is None:
            try:
                tree = [owned]+owned.children(recursive=True)
                peak = max(peak, sum(c.memory_info().rss for c in tree if c.is_running()))
            except psutil.NoSuchProcess:
                pass
            except psutil.AccessDenied:
                limit = 'memory observation denied'
            if time.monotonic()-started > 180: limit = 'time'
            if peak > 1024**3: limit = 'memory'
            if limit:
                for c in reversed(tree):
                    try: c.kill()
                    except psutil.NoSuchProcess: pass
                break
            time.sleep(.1)
        code = p.wait()
    record = dict(command=command, runner_sha256=sha(Path(__file__)),
      elapsed_seconds=time.monotonic()-started, peak_sampled_tree_bytes=peak,
      timeout_seconds=180, memory_limit_bytes=1024**3, resource_limit=limit, exit_code=code)
    (ROOT/(label+'-execution.json')).write_text(json.dumps(record, indent=2))
    print(json.dumps(record))
    print('\n'.join((ROOT/(label+'.log')).read_text().splitlines()[-10:]))
    sys.exit(code if limit is None else 124)

if sys.argv[1] == 'child':
    if sys.argv[2] == 'prepare': prepare()
    else: check(sys.argv[2])
else:
    supervise(sys.argv[1])
