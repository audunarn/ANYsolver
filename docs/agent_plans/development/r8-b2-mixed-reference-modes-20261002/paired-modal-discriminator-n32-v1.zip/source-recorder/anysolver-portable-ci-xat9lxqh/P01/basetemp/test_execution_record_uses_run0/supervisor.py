ENV={'OMP_NUM_THREADS':'1','NUMBA_DISABLE_JIT':'1','PYTHONPATH':'declared-site','FUTURE_CREDENTIAL':'do-not-record','MISTRAL_API_KEY':'synthetic-do-not-record'}
def supervised(command, folder):
    return {'exit_code':0,'resource_limit':None}
