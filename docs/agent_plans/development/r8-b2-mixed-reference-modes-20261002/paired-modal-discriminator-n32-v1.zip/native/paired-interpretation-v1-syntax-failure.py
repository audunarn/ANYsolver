"""Saved-field two-level interpretation; no new solve/convergence qualification."""
from pathlib import Path
import hashlib, importlib.util, json
import numpy as np
from scipy import sparse
from scipy.optimize import linear_sum_assignment
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
base=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp')
roots=[base/'r8-q4-us3-modal-compare-v1',base/'r8-q4-us3-modal-compare-n32-v1']
refs=[base/'r8-us3-modal-canary-v1',base/'r8-us3-modal-reference-n32-v1']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=repo/'scripts/r8_q4_us3_modal_compare_dev.py'
spec=importlib.util.spec_from_file_location('mode_metric',source)
metric=importlib.util.module_from_spec(spec); spec.loader.exec_module(metric)
layouts=[np.load(p/'layout.npz',allow_pickle=False) for p in roots]
coarse,fine=(p['xyz'] for p in layouts)
lookup={tuple(row):i for i,row in enumerate(fine)}
if len(lookup)!=len(fine): raise ValueError('nonunique fine coordinates')
selected=np.array([lookup[tuple(row)] for row in coarse])
if not np.array_equal(coarse,fine[selected]): raise ValueError('nested geometry differs')
rows=(6*selected[:,None]+np.arange(6)).ravel()
mass=sparse.load_npz(roots[0]/'mass.npz')
results=[json.loads((p/'result.json').read_text()) for p in roots]
native=[np.load(p/'native-modes.npz',allow_pickle=False) for p in roots]
external=[np.load(p/'reference-modes.npz',allow_pickle=False) for p in refs]
def track(a,b,fa,fb):
    mac,_,_=metric.common_mass_mac(a,b[rows],mass)
    ci,fi=linear_sum_assignment(-mac)
    pairs=[dict(coarse_mode=int(c+1),fine_mode=int(f+1),coarse_frequency_hz=float(fa[c]),fine_frequency_hz=float(fb[f]),signed_frequency_change_percent=float(100*(fb[f]/fa[c]-1)),restricted_fine_coarse_q4_mass_mac=float(mac[c,f])) for c,f in zip(ci,fi)]
    return dict(pairs=pairs,full_mac=mac.tolist())
tracking=dict(native=track(native[0]['modes'],native[1]['modes'],native[0]['frequencies_hz'],native[1]['frequencies_hz']),reference=track(external[0]['modes'].reshape(6,-1).T,external[1]['modes'].reshape(6,-1).T,external[0]['frequencies_hz'],external[1]['frequencies_hz']))
# Verify cross-family matches remain the same physical inventory across levels.
nt={p['coarse_mode']:p['fine_mode'] for p in tracking['native']['pairs']}
rt={p['coarse_mode']:p['fine_mode'] for p in tracking['reference']['pairs']}
finepairs={p['reference_mode']:p for p in results[1]['pairs']}
comparison=[]
for old in results[0]['pairs']:
    new=finepairs[rt[old['reference_mode']]]
    if new['native_mode']!=nt[old['native_mode']]: raise ValueError('cross-level family matching disagrees')
    comparison.append(dict(coarse_reference_mode=old['reference_mode'],fine_reference_mode=new['reference_mode'],coarse_gap_percent=old['signed_frequency_difference_percent'],fine_gap_percent=new['signed_frequency_difference_percent'],coarse_mac=old['common_q4_mass_mac'],fine_mac=new['common_q4_mass_mac']))
inputs={str(p):sha(p) for root in roots for p in (root/'result.json',root/'layout.npz',root/'mass.npz',root/'native-modes.npz')}
inputs.update({str(ref/'reference-modes.npz'):sha(ref/'reference-modes.npz') for ref in refs})
output=dict(classification='Level A two-level development discriminator only',qualification=False,numerical_solves=0,metric='fine nodal fields restricted to identical coarse physical nodes, common coarse Q4 mass; no L2 interpolation or clustered-subspace certificate',tracking=tracking,cross_family_comparison=comparison,convergence='NOT_ESTABLISHED: two levels only; reference eigen residual not verified',input_sha256=inputs,metric_source_sha256=sha(source),runner_sha256=sha(Path(__file__)))
(roots[1]/'paired-interpretation.json').write_text(json.dumps(output,indent=2)+'
')
print(json.dumps({'cross_family_comparison':comparison,'native_tracks':tracking['native']['pairs'],'reference_tracks':tracking['reference']['pairs']}))
