from pathlib import Path
import importlib.util, json, hashlib, sys
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owned_resource',root/'run.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
source=module.REPO/'scripts/r8_bl5_saved_trace_work_audit_dev.py'
(root/'trace-audit-binding-v1.json').write_text(json.dumps(dict(source=str(source),
    sha256=hashlib.sha256(source.read_bytes()).hexdigest(),scope='Saved-state postprocessing only; no numerical solve'),indent=2)+'\n')
module.supervise([sys.executable,'-u',str(source),'--root',str(root),'--output',str(root/'trace-audit-v1.json')],
    'trace-audit-run-v1',1024**3)
