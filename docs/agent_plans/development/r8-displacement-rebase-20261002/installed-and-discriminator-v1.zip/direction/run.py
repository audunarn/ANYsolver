from pathlib import Path
import sys,json,importlib.util,hashlib
root=Path(__file__).parent
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
if len(sys.argv)>1:
 from dataclasses import asdict
 import numpy as np
 from scipy import sparse
 sys.path.insert(0,str(repo/"tests"))
 from anysolver import stiffened_shell as ss
 import anysolver._stiffened_shell_displacement_corrector as module
 from anysolver._stiffened_shell_ge_finite_experimental import _material_arrays,_shell_material_arrays
 from test_stiffened_shell_bl5_coupled_material import coupled
 from test_stiffened_shell_bl5_finite import _action
 owner=ss.create_analysis(definition=coupled())
 saved=(root.parent/"r8-displacement-branch-v1/step-1.bin").read_bytes()
 owner.restore(saved);driver=owner._finite_driver
 shell=driver._shell_origins;beam=driver._beam_origins
 _,metadata,arrays=owner._displacement_snapshot
 base=arrays["base_load"];pattern=arrays["load_direction"]
 original=module.bordered_correction;advance=driver._advance;captured={}
 def bordered(matrix,residual,direction,control_dof,gap,free):
  step,delta=original(matrix,residual,direction,control_dof,gap,free)
  captured.update(K=matrix.copy(),r=residual.copy(),p=direction.copy(),d=step.copy(),da=delta,free=free.copy(),dof=control_dof,gap=gap)
  return step,delta
 def advancing(state,step,amount):
  captured['state']=state
  return advance(state,step,amount)
 module.bordered_correction=bordered;driver._advance=advancing
 try:
  owner.solve(_action(-15.625),(-68e-6,),displacement_control=ss.DisplacementControl("beam",105,2),max_iterations=20,max_backtracks=12)
 except ss.DisplacementCorrectorFailure as error:
  detail=asdict(error.detail)
 else:raise AssertionError("bounded failed state not reproduced; no derivative probes authorised")
 finally:
  module.bordered_correction=original;driver._advance=advance
 assert owner.checkpoint()==saved
 amplitude=detail['amplitude'];state=captured['state'];r=captured['r'];K=captured['K'];d=captured['d'];da=captured['da'];free=captured['free']
 evaluation=driver._assemble(state,0.,shell,beam,applied_load=base+amplitude*pattern)
 np.testing.assert_array_equal(evaluation[0],r)
 energy=float(np.max((abs(owner._K)@owner._coordinate_scale)*owner._coordinate_scale))
 weights=np.r_[owner._coordinate_scale,energy/owner._constraint_scale]/energy
 v=K@d-captured['p']*da;wr=r[free]*weights[free];wv=v[free]*weights[free]
 phi=.5*float(wr@wr);slope=float(wr@wv)
 raw=dict(residual=r,direction=d,load_direction=captured['p'],weights=weights,free=free,q=state.q,frames=state.frames,cells=state.cells,resultants=state.resultants,multipliers=state.multipliers,tangent_action=v)
 def materials(ev):
  bp,ba=_material_arrays(ev[5]);sp,sa=_shell_material_arrays(ev[4])
  return dict(beam_plastic=bp,beam_alpha=ba,shell_plastic=sp,shell_alpha=sa)
 material0=materials(evaluation)
 for key,value in material0.items():raw['base_'+key]=value
 parent_bp,parent_ba=_material_arrays(beam);parent_sp,parent_sa=_shell_material_arrays(shell)
 for key,value in dict(beam_plastic=parent_bp,beam_alpha=parent_ba,shell_plastic=parent_sp,shell_alpha=parent_sa).items():raw['parent_'+key]=value
 rows=[]
 for i,t in enumerate((2.**-14,-2.**-14,2.**-15,-2.**-15)):
  trial=advance(state,d,t)
  ev=driver._assemble(trial,0.,shell,beam,applied_load=base+(amplitude+t*da)*pattern)
  secant=(ev[0]-r)/t;scaled=secant[free]*weights[free]
  trialwr=ev[0][free]*weights[free];trialphi=.5*float(trialwr@trialwr)
  raw['residual_'+str(i)]=ev[0];raw['secant_'+str(i)]=secant
  mat=materials(ev)
  for key,value in mat.items():raw[str(i)+'_'+key]=value
  rows.append(dict(t=t,weighted_secant_error=float(np.linalg.norm(scaled-wv)/max(np.linalg.norm(wv),np.finfo(float).tiny)),phi_change=trialphi-phi,secant_slope=float(wr@scaled),shell_alpha_change=float(np.max(abs(mat['shell_alpha']-material0['shell_alpha']))),beam_alpha_change=float(np.max(abs(mat['beam_alpha']-material0['beam_alpha'])))))
 sparse.save_npz(root/'tangent.npz',K);np.savez_compressed(root/'arrays.npz',**raw)
 result=dict(seed_sha256=hashlib.sha256(saved).hexdigest(),failure=detail,phi=phi,predicted_slope=slope,newton_slope=-2*phi,weighted_linear_residual=float(np.linalg.norm(wv+wr)/np.linalg.norm(wr)),control_linear_error=float(d[captured['dof']]+captured['gap']),amplitude_direction=da,rows=rows,prefix_unchanged=owner.checkpoint()==saved)
 (root/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));owner.close()
else:
 spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV['PYTHONPATH']=str(repo/'src');s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
 result=s.supervised([sys.executable,str(Path(__file__)),'child'],root/'run-v1')
 print(json.dumps({k:result[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
