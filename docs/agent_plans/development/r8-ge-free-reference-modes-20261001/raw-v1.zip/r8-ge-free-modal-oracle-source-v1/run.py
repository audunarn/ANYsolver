import os, sys, json
from pathlib import Path
root=Path('C:/Github/ANYsolver/.perf2-worktrees/b3-ge-e4-pl-coupling')
out=Path(__file__).parent
sys.path.insert(0,str(root/'src')); os.chdir(root)
import numpy, scipy, numba, pytest
from threadpoolctl import threadpool_limits, threadpool_info
numba.set_num_threads(1)
with threadpool_limits(limits=1):
    pools=threadpool_info()
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    assert pools and all(p['num_threads']==1 for p in pools)
    (out/'runtime.json').write_text(json.dumps(dict(pools=pools,numba_threads=numba.get_num_threads(),jit_disabled=bool(numba.config.DISABLE_JIT),executable=sys.executable),indent=2))
    raise SystemExit(pytest.main(['-q','tests/test_stiffened_shell_ge_free_reference_modal_oracle.py','--junitxml='+str(out/'inventory.xml'),'--basetemp='+str(out/'pytest-tmp')]))
