import os, sys, time, subprocess, json
from pathlib import Path
import psutil
out = Path(__file__).parent
env = os.environ.copy()
for k in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMBA_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'): env[k]='1'
env['NUMBA_DISABLE_JIT']='1'; env['PYTHONDONTWRITEBYTECODE']='1'
start=time.monotonic(); peak=0; reason=None
with (out/'source.log').open('w') as log:
    p=subprocess.Popen([sys.executable,str(out/'run.py')],env=env,stdout=log,stderr=subprocess.STDOUT)
    while p.poll() is None:
        try:
            processes=[psutil.Process(p.pid),*psutil.Process(p.pid).children(recursive=True)]
            rss=sum(x.memory_info().rss for x in processes if x.is_running()); peak=max(peak,rss)
            if rss>8*1024**3 or time.monotonic()-start>600:
                reason='8GiB or 600s process-tree bound'
                for x in reversed(processes):
                    try: x.kill()
                    except psutil.Error: pass
        except psutil.Error: pass
        time.sleep(.1)
    code=p.wait()
data=dict(exit_code=code,wall_seconds=time.monotonic()-start,peak_tree_rss_bytes=peak,guard_failure=reason)
(out/'execution.json').write_text(json.dumps(data,indent=2)); print(json.dumps(data)); sys.exit(code)
