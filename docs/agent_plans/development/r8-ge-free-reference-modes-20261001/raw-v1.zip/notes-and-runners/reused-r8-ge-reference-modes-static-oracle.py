from pathlib import Path
from dataclasses import asdict
import hashlib,json,sys,zipfile
import numpy as np,numba,threadpoolctl
from anysolver.stiffened_shell import create_analysis,NodalAction
from test_stiffened_shell_ge_experimental import _panel
r=Path.cwd();site=Path(sys.argv[1]).resolve();artifact=site.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((artifact/'source-manifest.json').read_text())
wheel=next((artifact/'wheels').glob('*.whl'))
with zipfile.ZipFile(wheel) as z:
    names={p for p in z.namelist() if p.startswith('anysolver/') and p.endswith('.py')}
    assert names=={p.replace('src/','',1) for p in source}
    for p,h in source.items():
        n=p.replace('src/','',1);assert sha(site/n)==h and z.read(n)==(site/n).read_bytes(),p
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
owner=create_analysis(definition=_panel())
try:
    for n in ('_K','_C','_A'):
        m=getattr(owner,n).tocsr()
        for k,a in (('data',m.data),('indices',m.indices),('indptr',m.indptr)):
            np.save(r/(n+'-'+k+'.npy'),a,allow_pickle=False)
    result=owner.solve_linear((NodalAction('beam',105,(0.,0.,100.,0.,0.,0.)),))
    assert result.status=='completed'
    payload=owner.checkpoint();(r/'checkpoint.bin').write_bytes(payload)
    data=asdict(result)
    for k,v in list(data.items()):
        if isinstance(v,np.ndarray):np.save(r/(k+'.npy'),v,allow_pickle=False);data[k]=v.tolist()
    (r/'observables.json').write_text(json.dumps(data,sort_keys=True,indent=2,allow_nan=False))
finally:owner.close()
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0]=='anysolver' and getattr(m,'__file__',None)}
assert all(Path(p).is_relative_to(site) for p in imports.values())
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
(r/'identity.json').write_text(json.dumps({'wheel_sha256':sha(wheel),'modules':len(source),'imports':imports,'threads':pools,'numba_threads':1,'jit_disabled':True},indent=2))
print(json.dumps({'status':'passed','onsite_imports':len(imports),'checkpoint_sha256':sha(r/'checkpoint.bin'),'observables_sha256':sha(r/'observables.json')}))
