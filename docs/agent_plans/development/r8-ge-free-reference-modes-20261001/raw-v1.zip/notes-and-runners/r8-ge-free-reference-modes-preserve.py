from pathlib import Path
import hashlib,json,zipfile
r=Path('C:/Users/AUDUNA~1/AppData/Local/Temp')
out=r/'r8-ge-free-reference-modes-evidence-v1.zip';assert not out.exists()
files={}
def add(p,key):
 if p.is_file():
  assert key not in files,key
  files[key]=p
for name in ('r8-ge-free-reference-modal-source-v1','r8-ge-free-modal-oracle-source-v1','r8-ge-free-modal-oracle-source-v2','r8-ge-free-reference-modes-installed-v1','r8-ge-free-reference-modes-installed-v2','r8-ge-free-reference-modes-installed-v3','r8-ge-free-reference-modes-static-new-v1','r8-ge-free-reference-modes-example-installed-v1'):
 base=r/name;assert base.is_dir(),base
 for p in sorted(base.rglob('*')):
  rel=p.relative_to(base)
  if any(v in ('site','build-source','__pycache__','.pytest_cache') for v in rel.parts):continue
  if p.suffix in ('.pyc','.nbc','.nbi'):continue
  add(p,name+'/'+rel.as_posix())
 if (base/'build-source').exists():
  for n in ('_stiffened_shell_ge_reference_modal.py','_stiffened_shell_ge_experimental.py','stiffened_shell.py'):
   add(base/'build-source/src/anysolver'/n,name+'/runtime-source/anysolver/'+n)
for pattern in ('r8-ge-free-reference-modes*.py','r8-ge-free-reference-modes*.json','r8-ge-free-reference-modes*.md'):
 for p in sorted(r.glob(pattern)):add(p,'notes-and-runners/'+p.name)
for name in ('r8-ge-reference-modes-static-oracle.py','r8-nodal-footprint-command-bounded.py','r8-nodal-footprint-run-bounded.py','r8-nodal-footprint-run-installed.py','r8-prepare-ge-reference-modes-installed.py'):
 add(r/name,'notes-and-runners/reused-'+name)
base=r/'r8-ge-reference-modes-static-old-v1'
for p in base.iterdir():add(p,'reused-static-baseline/'+p.name)
review=r/'r8-ge-free-reference-modes-independent-review-v1.md';assert review.exists()
add(Path('C:/Github/ANYsolver/.perf2-worktrees/b3-ge-e4-pl-coupling/examples/stiffened_shell_ge_free_reference_modes.py'),'final-example/stiffened_shell_ge_free_reference_modes.py')
manifest={k:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'original_path':str(p.resolve())} for k,p in sorted(files.items())}
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for k,p in sorted(files.items()):z.write(p,k)
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(out) as z:
 for k,v in manifest.items():assert hashlib.sha256(z.read(k)).hexdigest()==v['sha256'],k
identity={'files':len(manifest),'raw_bytes':sum(v['bytes'] for v in manifest.values()),'archive_bytes':out.stat().st_size,'archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'scope':'explicit modal-only connected virgin Q4/generalized-GE six-pose points: six physical rigid fields and requested flexible pairs; no exactly-six-nullity/spectrum/physical or aggregate qualification'}
(r/'r8-ge-free-reference-modes-evidence-v1-identity.json').write_text(json.dumps(identity,indent=2));print(json.dumps(identity))
