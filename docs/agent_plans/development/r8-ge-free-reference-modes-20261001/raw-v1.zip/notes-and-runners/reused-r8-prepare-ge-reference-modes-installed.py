from pathlib import Path
import hashlib,json,shutil,sys,subprocess
w=Path(r'C:/Github/ANYsolver/.perf2-worktrees/b3-ge-e4-pl-coupling')
r=Path(sys.argv[1]);r.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={p.relative_to(w).as_posix():sha(p) for p in (w/'src/anysolver').rglob('*.py')}
(r/'source-manifest.json').write_text(json.dumps(source,indent=2))
b=r/'build-source';b.mkdir()
shutil.copytree(w/'src/anysolver',b/'src/anysolver',ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.nbc','*.nbi'))
for name in ('pyproject.toml','README.md','LICENSE','COPYRIGHT','THIRD_PARTY_NOTICES.md'):shutil.copy2(w/name,b/name)
f=r/'fixtures';f.mkdir()
for name in sys.argv[2:]:shutil.copy2(w/'tests'/name,f/name)
for name in ('r8-nodal-footprint-run-installed.py','r8-nodal-footprint-run-bounded.py'):
    shutil.copy2(r.parent/name,r/('run_installed.py' if 'run-installed' in name else 'run_bounded.py'))
(r/'pytest.ini').write_text('[pytest]\naddopts = -p no:cacheprovider\njunit_family = legacy\n')
assert source=={p.relative_to(w).as_posix():sha(p) for p in (w/'src/anysolver').rglob('*.py')}
(r/'prepared-identity.json').write_text(json.dumps({'source':source,'fixtures':{p.name:sha(p) for p in f.glob('*.py')},'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()},indent=2))
print(json.dumps({'root':str(r),'source_modules':len(source),'fixtures':len(tuple(f.glob('*.py')))}))
