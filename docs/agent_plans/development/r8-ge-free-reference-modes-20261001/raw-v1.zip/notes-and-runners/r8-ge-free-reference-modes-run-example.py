from pathlib import Path
import contextlib,hashlib,io,json,runpy,sys,zipfile
import numba,threadpoolctl
r=Path.cwd();site=Path(sys.argv[1]).resolve();example=Path(sys.argv[2]).resolve();artifact=site.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((artifact/'source-manifest.json').read_text());wheel=next((artifact/'wheels').glob('*.whl'))
with zipfile.ZipFile(wheel) as z:
    names={p for p in z.namelist() if p.startswith('anysolver/') and p.endswith('.py')}
    assert names=={p.replace('src/','',1) for p in source}
    for p,h in source.items():
        name=p.replace('src/','',1);assert sha(site/name)==h and z.read(name)==(site/name).read_bytes()
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
output=io.StringIO()
with contextlib.redirect_stdout(output):runpy.run_path(str(example),run_name='__main__')
result=json.loads(output.getvalue())
assert result['status']=='completed' and result['factorization_count']==1
assert result['production_qualified'] is False and len(result['frequencies_hz'])==3
assert result['rigid_mode_count']==6 and result['spectral_shift_rad2_s2']<0.
assert max(result['rigid_equation_residuals'])<=1e-8 and max(result['rigid_constraint_residuals'])<=1e-9
assert result['rigid_flexible_mass_overlap']<=1e-7
assert max(result['equation_residuals'])<=1e-8 and max(result['constraint_residuals'])<=1e-9
(r/'result.json').write_text(json.dumps(result,indent=2))
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0]=='anysolver' and getattr(m,'__file__',None)}
assert all(Path(p).is_relative_to(site) for p in imports.values())
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
(r/'identity.json').write_text(json.dumps({'wheel_sha256':sha(wheel),'example_sha256':sha(example),'modules':len(source),'imports':imports,'threads':pools,'numba_threads':1,'jit_disabled':True},indent=2))
print(json.dumps({'status':'passed','onsite_imports':len(imports),'frequencies_hz':result['frequencies_hz'],'factorization_count':1}))
