from pathlib import Path
import hashlib, json, shutil, zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
OUT = SOURCE/'docs/agent_plans/development/r8-b2-mixed-panel-20261002'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
OUT.mkdir(parents=True, exist_ok=True)
shutil.copytree(ROOT.parent/'anysolver-portable-ci-ih8x1ms4'/'P01', ROOT/'source-final-record')
for name in ('affected', 'example-mixed', 'example-s3', 'example', 'consumer'):
    record = json.loads((ROOT/(name+'-execution.json')).read_text())
    assert record['exit_code'] == 0 and record['resource_limit'] is None
    identity = json.loads((ROOT/(name+'-identity.json')).read_text())
    assert identity['matching_modules'] == 391 and identity['jit_disabled']
    assert identity['numba_threads'] == 1
    assert all(pool['num_threads'] == 1 for pool in identity['pools'])
manifest = json.loads((ROOT/'source-manifest.json').read_text())
assert all(sha(SOURCE/path) == digest for path, digest in manifest.items())
selected = list(ROOT.glob('*.py'))+list(ROOT.glob('*.json'))+list(ROOT.glob('*.log'))+list(ROOT.glob('*.xml'))
for folder in ('fixtures', 'scripts', 'wheels', 'source-initial-failed', 'source-repair-failed', 'source-final-record'):
    selected.extend((ROOT/folder).rglob('*'))
selected = sorted({p for p in selected if p.is_file()})
archive = OUT/'raw-v1.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
    for path in selected:
        z.writestr(path.relative_to(ROOT).as_posix(), path.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(selected)
    assert all(z.read(p.relative_to(ROOT).as_posix()) == p.read_bytes() for p in selected)
record = dict(archive_sha256=sha(archive), archive_members=len(selected), archive_bytes=archive.stat().st_size,
    wheel_sha256=sha(next((ROOT/'wheels').glob('*.whl'))), matching_source_modules=len(manifest),
    frozen_files={p.relative_to(ROOT).as_posix():sha(p) for p in selected})
(OUT/'raw-v1.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k != 'frozen_files'}))
