"""Owned serial supervisor for one restricted matched-reference development batch."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys, time
import psutil

ROOT = Path(__file__).resolve().parent
REPO = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
SITE = ROOT/'site'
EXE = Path('C:/Github/ANYsolver/.qualification/b3-ge-e4-pl/calculix-223/CalculiX-2.23.0-win-x64/bin/ccx.exe')
SHA = '27a9426a1ee2f72c38fbe892e0ffaf38e14867628ffd0235770261b6f3ec9c5f'
ENV = os.environ.copy()
ENV.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
    NUMBA_NUM_THREADS='1', NUMBA_DISABLE_JIT='1', CCX_NPROC_RESULTS='1',
    CCX_NPROC_EQUATION_SOLVER='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def supervised(command, folder):
    folder.mkdir(parents=True, exist_ok=False)
    started, peak, threads, limit = time.monotonic(), 0, 0, None
    observed = False
    with (folder/'stdout.log').open('x') as out, (folder/'stderr.log').open('x') as err:
        p = subprocess.Popen(command, cwd=folder, env=ENV, stdout=out, stderr=err)
        proc = psutil.Process(p.pid); tree = [proc]
        try:
            while p.poll() is None:
                try:
                    tree = [proc]+proc.children(recursive=True)
                    rss = sum(x.memory_info().rss for x in tree if x.is_running())
                    peak = max(peak, rss)
                    threads = max(threads, sum(x.num_threads() for x in tree if x.is_running()))
                    observed = True
                except psutil.NoSuchProcess:
                    pass
                except psutil.AccessDenied:
                    limit = 'resource observation denied'
                if time.monotonic()-started > 600: limit = 'time'
                if peak > 8*1024**3: limit = 'memory'
                if limit:
                    for x in reversed(tree):
                        try: x.kill()
                        except psutil.NoSuchProcess: pass
                    break
                time.sleep(.02)
            code = p.wait(timeout=20)
        finally:
            if p.poll() is None:
                for x in reversed(tree):
                    try: x.kill()
                    except psutil.NoSuchProcess: pass
    record = dict(command=command, exit_code=code, elapsed_seconds=time.monotonic()-started,
        sampled_peak_tree_bytes=peak if observed else None,
        sampled_max_process_tree_threads=threads if observed else None,
        resource_observed=observed, resource_limit=limit, timeout_seconds=600,
        memory_limit_bytes=8*1024**3, supervisor_sha256=sha(Path(__file__)),
        environment={k:ENV[k] for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS',
        'NUMBA_NUM_THREADS','NUMBA_DISABLE_JIT','CCX_NPROC_RESULTS','CCX_NPROC_EQUATION_SOLVER')})
    (folder/'execution.json').write_text(json.dumps(record, indent=2)+'\n')
    if code or limit: raise RuntimeError(f'failed child: {folder}; exit={code}; limit={limit}')
    return record


