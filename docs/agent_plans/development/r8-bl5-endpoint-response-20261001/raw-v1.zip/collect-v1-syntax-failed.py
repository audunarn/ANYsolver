"""Saved actual endpoint response interpretation; no numerical solves."""
from pathlib import Path
import hashlib,json,math
import numpy as np
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'r8-bl5-native-p0-family-v1'
REPO=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
end=REPO/'docs/agent_plans/development/r8-bl5-matched-comparison-20261001/endport-support-work.json'
assert sha(end)=='48f2132a483b19b803f6ad6623de8fab6cec83c56e9eb15432b39fd0e6ffc777'
endport=json.loads(end.read_text())
inputs={str(end):sha(end)}; records=[]; previous={}
for nx in (16,32,64):
    folder=ROOT/f'n{nx}'
    execution=json.loads((folder/'execution.json').read_text())
    summary=json.loads((folder/'outputs/summary.json').read_text())
    assert execution['exit_code']==0 and execution['resource_limit'] is None
    assert summary['status']=='COMPLETED_DEVELOPMENT_ONLY'
    assert summary['policy']['span_halfcells']==32 and summary['counts']['members']==8*nx
    assert summary['preflight_after']['reference_linear_factorizations']==1
    for path in folder.rglob('*'):
        if path.is_file():inputs[str(path)]=sha(path)
    for case,result in summary['cases'].items():
        old=OLD/f'n{nx}'/case/'physical-actions.json'
        inputs[str(old)]=sha(old)
        baseline=json.loads(old.read_text())
        prior=next(v for v in endport['cases'] if v['nx']==nx and v['case']==case)
        work=result['final_pairing_J']
        ground=result['ground']['beam']
        delta=[a-b for a,b in zip(ground,prior['domains']['beam']['common_origin_native']['R'])]
        discrepancy=prior['domains']['beam']['delta_common_origin']['R']
        norms={d:math.hypot(*result['ground'][d]) for d in ('shell','beam')}
        field_paths=(folder/'outputs'/case/'raw-state.npz', OLD/f'n{nx}'/case/'raw-state.npz')
        a,b=(np.load(path,allow_pickle=False) for path in field_paths)
        # Older raw inventory uses its documented nodal array roles.
        assert a['q'].ndim==b['q'].ndim==1
        old_layout=json.loads((OLD/f'n{nx}'/'layout.json').read_text())
        ns=summary['counts']['shell_nodes']; old_nb=old_layout['counts']['beam_nodes']
        shell_old=b['q'][:6*ns].reshape(ns,6)
        beam_old=b['q'][6*ns:6*(ns+old_nb)].reshape(old_nb,6)
        assert np.array_equal(a['xyz_m'][:ns],b['xyz_m'][:ns])
        assert np.array_equal(a['xyz_m'][ns::8],b['xyz_m'][ns:])
        fields={}
        for name,left,right in [('shell',a['shell_poses'],shell_old),('beam_common_nodes',a['beam_nodal_poses'][::8],beam_old)]:
            fields[name]={}
            for components,label in [(slice(0,3),'translations'),(slice(3,5),'physical_director_xy'),(slice(5,6),'released_normal_rotation')]:
                v,w=left[:,components],right[:,components]
                fields[name][label]={'difference_norm':float(np.linalg.norm(v-w)),
                    'reference_norm':float(np.linalg.norm(w)),
                    'relative_difference':float(np.linalg.norm(v-w)/max(np.linalg.norm(w),1e-24))}
        for path in (*field_paths,OLD/f'n{nx}'/'layout.json'):inputs[str(path)]=sha(path)
        record={'nx':nx,'case':case,'work_J':work,
            'successive_work_change_percent':None if case not in previous else100*(work/previous[case]-1),
            'saved_1to1_work_difference_percent':100*(work/baseline['work_J']['applied']-1),
            'checks':result['checks'],'sampled_gaps':result['pointwise_gap_diagnostics'],
            'beam_ground_delta_from_1to1':delta,
            'root_delta_norm_relative_to_previous_external_discrepancy':math.hypot(*delta)/math.hypot(*discrepancy),
            'ground_norms_N_equivalent':norms,'common_nodal_fields':fields,
            'elapsed_seconds':execution['elapsed_seconds'],'peak_bytes':execution['sampled_peak_tree_bytes']}
        records.append(record);previous[case]=work
record={'classification':'development-only endpoint response; no formal F03 or physical accuracy acceptance',
    'source_sha256':sha(Path(__file__)),'bound_inputs':inputs,'cases':records,
    'field_measure':'Unweighted common-node norms, translations/director xy/ released normal rotation separate; not mesh-converged continuum errors',
    'decision':'Stop this three-level batch. No observed endpoint solve/work collapse. Torque convergence and completion-sensitive root transfer remain open; no fourth grid or coefficient tuning.'}
(ROOT/'collected.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'cases':len(records),'bound_inputs':len(inputs),'max_check':max(v for r in records for v in r['checks'].values())}))
