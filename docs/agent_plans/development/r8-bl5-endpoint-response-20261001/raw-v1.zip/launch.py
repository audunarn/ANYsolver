"""One supervised installed native endpoint level; preserve every result."""
from pathlib import Path
import argparse, hashlib, json, sys
from supervise import supervised

ROOT = Path(__file__).resolve().parent
INSTALLED = ROOT.parent/'r8-b2-panel-resolution-installed-v1'
parser = argparse.ArgumentParser()
parser.add_argument('--nx', type=int, choices=(16,32,64), required=True)
args = parser.parse_args()
paths = [ROOT/'runner.py', *sorted((ROOT/'scripts').glob('*.py')),
         *sorted((ROOT/'tests').glob('*.py')), ROOT/'supervise.py', Path(__file__)]
identity = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
target = ROOT/f'n{args.nx}'
record = supervised([sys.executable,'-u',str(ROOT/'runner.py'),'--site',str(INSTALLED/'site'),
    '--manifest',str(INSTALLED/'source-manifest.json'),'--fixtures',str(ROOT),
    '--nx',str(args.nx),'--output',str(target/'outputs')],target)
(target/'runner-bindings.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps({'nx':args.nx,'elapsed_seconds':record['elapsed_seconds'],
    'peak_bytes':record['sampled_peak_tree_bytes'],'exit':record['exit_code']}))
