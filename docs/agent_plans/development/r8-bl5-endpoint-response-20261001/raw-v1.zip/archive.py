"""Preserve this completed development batch; verify every archive member."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
DEST=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/docs/agent_plans/development/r8-bl5-endpoint-response-20261001')
archive,manifest=DEST/'raw-v1.zip',DEST/'raw-v1.json'
assert not archive.exists() and not manifest.exists()
hashes={}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':
            data=path.read_bytes();name=path.relative_to(ROOT).as_posix()
            hashes[name]=hashlib.sha256(data).hexdigest();z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(hashes)
    for name,digest in hashes.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
record={'classification':'immutable development raw evidence; no qualification pass',
    'original_root':str(ROOT),'source_product_commit':'d96471c62c5838ba5c47732eced6069158f8c27a',
    'started_day':'2026-10-01','completed_day':'2026-10-02',
    'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_bytes':archive.stat().st_size,'members':len(hashes),'member_sha256':hashes,
    'reproduction':'runner.py plus frozen scripts/tests, launch.py/supervise.py and unchanged installed wheel/site; historical bound inputs remain in prior protected evidence',
    'numerical_runs':'three owners/three loads each; all terminal; no rerun',
    'harness_findings':'harness-findings.json; no numerical data modified'}
manifest.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('members','archive_bytes','archive_sha256')}))
