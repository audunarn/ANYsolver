from pathlib import Path
import sys,os,json,hashlib,importlib.util,subprocess,zipfile
root=Path(__file__).parent;repo=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
solver_repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
site=root/'site';solver_site=root.parent/'r8-native-retained-scale-installed-v1/site';fixtures=root/'fixtures'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if len(sys.argv)>1 and sys.argv[1]=='prepare':
 for name,args in [('build',['wheel','--no-deps','--no-build-isolation','--no-cache-dir','--no-index','--wheel-dir',str(root/'wheels'),str(repo)]),('install',None)]:
  if args is None:args=['install','--no-deps','--no-cache-dir','--no-index','--target',str(site),str(next((root/'wheels').glob('*.whl')))]
  with (root/(name+'.log')).open('w') as log:subprocess.run([sys.executable,'-m','pip',*args],stdout=log,stderr=subprocess.STDOUT,check=True)
 wheel=next((root/'wheels').glob('*.whl'));modules={}
 with zipfile.ZipFile(wheel) as archive:
  for p in (repo/'src/anyfem').rglob('*.py'):
   n=p.relative_to(repo/'src').as_posix();assert p.read_bytes()==archive.read(n)==(site/n).read_bytes(),n;modules[n]=sha(p)
 for p in (solver_repo/'src/anysolver').rglob('*.py'):
  assert p.read_bytes()==(solver_site/p.relative_to(solver_repo/'src')).read_bytes(),p.name
 solver_artifact=json.loads((root.parent/'r8-native-retained-scale-installed-v1/artifact.json').read_text())
 (root/'artifact.json').write_text(json.dumps(dict(consumer_wheel_sha256=sha(wheel),consumer_modules=modules,solver_wheel_sha256=solver_artifact['wheel_sha256'],solver_modules_matched=len(solver_artifact['modules']),fixtures={p.relative_to(fixtures).as_posix():sha(p) for p in fixtures.rglob('*.py')}),indent=2))
 print(json.dumps(dict(consumer_modules=len(modules),consumer_wheel_sha256=sha(wheel))))
elif len(sys.argv)>1:
 sys.path.insert(0,str(fixtures))
 import anyfem,anysolver,numba,threadpoolctl,pytest
 assert Path(anyfem.__file__).resolve().is_relative_to(site.resolve())
 assert Path(anysolver.__file__).resolve().is_relative_to(solver_site.resolve())
 pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
 assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
 code=pytest.main(['-q','-p','no:cacheprovider','--basetemp=temporary','--junitxml=result.xml',str(fixtures/'test_installed_material_project.py'),str(fixtures/'test_curved_material_consumer.py'),str(fixtures/'test_native_retained_scale_consumer.py')])
 if code:raise SystemExit(code)
 imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith(('anysolver','anyfem')) and getattr(m,'__file__',None)}
 assert all(Path(p).is_relative_to((site if n.startswith('anyfem') else solver_site).resolve()) for n,p in imports.items())
 Path('runtime.json').write_text(json.dumps(dict(imports=imports,pools=threadpoolctl.threadpool_info(),python=sys.version,jit_disabled=bool(numba.config.DISABLE_JIT)),indent=2))
else:
 spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV['PYTHONPATH']=str(site)+os.pathsep+str(solver_site);s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
 result=s.supervised([sys.executable,'-u',str(Path(__file__)),'child'],root/'installed')
 print(json.dumps({k:result[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
