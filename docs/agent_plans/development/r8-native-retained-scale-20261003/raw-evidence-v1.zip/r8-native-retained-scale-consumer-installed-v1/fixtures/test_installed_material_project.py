from dataclasses import replace
import json
from pathlib import Path
import numpy as np
from anysolver import stiffened_shell as ss
from anyfem.solve.stiffened_shell import ExperimentalGEPointPanel,save_case,load_case
from anyfem.io.project_file import save_project,load_project
from anyfem.model.project import Project
from anyfem.model.records import AnalysisDefinition
from test_stiffened_shell_curved_material import curved_material_panel,_actions,assert_generalized_records_equal


def test_native_material_project_actual_history_and_restart(tmp_path,request):
 d=replace(curved_material_panel(),retained_scale_policy="native_force_moment_roles_v1")
 changes=tuple(ss.ReferencePosePerturbation('shell',n,(0.,0.,1e-4*(p[1]+.5)))
               for n,p in zip(d.shell.node_ids,d.shell.coordinates_m))
 reference=ss.create_stress_free_point_reference(d,changes);d=reference.definition
 assert reference.source_identity!=reference.target_identity and reference.stress_free_scaled_max<=1e-9
 shell=replace(d.shell,coordinates_m=tuple(tuple(float(v) for v in row) for row in d.shell.coordinates_m))
 panel=ExperimentalGEPointPanel(shell,d.beams,d.points,d.fixed,_actions(),
     q4_pullback_policy=d.q4_pullback_policy,shell_reference_policy=d.shell_reference_policy,retained_scale_policy=d.retained_scale_policy)
 reopened=load_case(save_case(panel,tmp_path/'material.anyfem-ge.json'))
 assert reopened.to_dict()==panel.to_dict()
 assert "native-scale-v3" in reopened.to_dict()["schema"]
 project=Project('curved material continuation',mesh_only=True)
 record=AnalysisDefinition.experimental_point_panel('material panel',reopened);project.add_analysis(record)
 path=save_project(project,tmp_path/'material.anyfem')
 def make():
  owner=load_project(path).analyses[record.id].create_point_panel_analysis()
  request.addfinalizer(owner.close);return owner
 owner=make();seed=owner.solve(panel.actions,(.5,1.),max_iterations=20,max_backtracks=12)
 assert np.max(seed.shell_layer_alpha)>0 and np.max(seed.beam_station_accumulated)>0
 info=owner.preflight();count=len(info['arc_metric_node_order'])
 control=ss.ArcLengthControl('beam',105,2,ss.PhysicalChordMetric(
     np.full(count,1/count),info['reference_length_m']),1e-5,-1)
 actual=owner.continue_arc_length(panel.actions,control)
 prefix=owner.checkpoint();fresh=make();restored=fresh.restore(prefix)
 assert fresh.checkpoint()==prefix
 assert_generalized_records_equal(actual.beam_generalized_material,restored.beam_generalized_material)
 second=owner.continue_arc_length(panel.actions,control)
 repeated=fresh.continue_arc_length(panel.actions,control)
 assert owner.checkpoint()==fresh.checkpoint()
 assert second.free_equilibrium_ratio<=1e-8 and second.constraint_max<=1e-9
 assert_generalized_records_equal(second.beam_generalized_material,repeated.beam_generalized_material)
 for name in ('cell_resultants','shell_layer_alpha','beam_station_accumulated','applied_dead_load'):
  np.testing.assert_array_equal(getattr(second,name),getattr(repeated,name))
 for left,right in zip(second.shell_q4_material,repeated.shell_q4_material):
  for name in ('layer_strain','layer_stress','plastic_strain','alpha'):
   np.testing.assert_array_equal(getattr(left,name),getattr(right,name))
 Path('material-history.json').write_text(json.dumps(dict(status=panel.status,
     identity=owner.preflight()['identity'],history=second.history,
     equilibrium=second.free_equilibrium_ratio,constraint=second.constraint_max,
     exact_restart=True),indent=2))
