from pathlib import Path
import importlib.util,os,sys,json
root=Path(__file__).parent
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(repo/'src',repo/'tests',repo)));s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
r=s.supervised([sys.executable,'-u',str(root/'probe.py')],root/'source')
print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
