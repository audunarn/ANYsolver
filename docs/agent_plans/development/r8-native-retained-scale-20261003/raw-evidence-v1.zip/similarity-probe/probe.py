from dataclasses import replace,asdict
from pathlib import Path
import json,time,hashlib
import numpy as np
import numba,threadpoolctl
from anysolver import stiffened_shell as ss,b3_ge
from anysolver import _stiffened_shell_ge_experimental as ge
from test_stiffened_shell_curved_material import curved_material_panel,_actions


def similar(d,g):
    curve=d.shell.j2_curve
    curve=replace(curve,**{n:getattr(curve,n)/g**2 for n in
                         ('sigma_prop','sigma_yield','sigma_yield_2','K')})
    shell=replace(d.shell,coordinates_m=np.asarray(d.shell.coordinates_m)*g,
        thickness_m=d.shell.thickness_m*g,young_pa=d.shell.young_pa/g**2,
        density_kg_m3=d.shell.density_kg_m3/g**3,j2_curve=curve)
    D=np.diag([1.,1.,1.,g,g,g]);inv=np.diag([1.,1.,1.,1/g,1/g,1/g]);beams=[]
    for definition in d.beams:
        e,inertia=definition.instantiate();section=e.section
        law=b3_ge.EllipsoidalGeneralizedSection(D@section.elastic@D,
            inv@section.metric@inv,section.yield_force,section.hardening)
        beams.append(b3_ge.define_beam('b3-ge',e.element_id,e.node_ids,
            e.operator.reference.coordinates*g,e.operator.reference.nodal_triads,
            law,D@inertia@D/g,quadrature=e.operator.order,
            arithmetic_policy=e.operator.arithmetic_policy))
    return replace(d,shell=shell,beams=tuple(beams))


def observations(result,g):
    shell=result.shell_displacement.reshape(-1,6).copy();shell[:,:3]/=g
    forces=result.cell_resultants.copy()
    forces[:,:6]=forces[:,:6];forces[:,6:]/=g
    return dict(shell=shell.tolist(),forces=forces.tolist(),
        shell_alpha=result.shell_layer_alpha,beam_alpha=result.beam_station_accumulated,
        equilibrium=result.free_equilibrium_ratio,gap=result.constraint_max,
        amplitude=getattr(result,'amplitude',None),
        shell_stress=[(v.layer_stress*g**2).tolist() for v in result.shell_q4_material])


original=ge._reference_scales
def native(*args,**kwargs):
    return original(*args,**dict(kwargs,footprint_retained_roles=True))

base=curved_material_panel();rows=[];scales={}
for g in (1.,.1,10.):
    for policy in ('legacy','native_roles_private_diagnostic'):
        started=time.monotonic();row=dict(length_factor=g,policy=policy,status='running')
        rows.append(row);owner=None
        try:
            ge._reference_scales=native if policy!='legacy' else original
            owner=ss.create_analysis(definition=similar(base,g))
            scales[g,policy]=owner._coordinate_scale.copy()
            row['model']=owner._identity
            # No external/restart qualification is claimed for this private override.
            row['seed']=observations(owner.solve(_actions(),(.5,1.),
                max_iterations=20,max_backtracks=12),g)
            info=owner.preflight();count=len(info['arc_metric_node_order'])
            control=ss.ArcLengthControl('beam',105,2,ss.PhysicalChordMetric(
                np.full(count,1/count),info['reference_length_m']),1e-5,-1)
            result=owner.continue_arc_length(_actions(),control)
            row['arc']=observations(result,g)
            row['attempts']=[asdict(a) for a in result.attempts]
            row['status']='completed'
        except Exception as error:
            row.update(status='failed',failure_type=type(error).__name__,failure=str(error))
            if hasattr(error,'attempts'):row['attempts']=[asdict(a) for a in error.attempts]
        finally:
            ge._reference_scales=original
            if owner is not None:owner.close()
            row['elapsed_seconds']=time.monotonic()-started
            Path('outcomes.json').write_text(json.dumps(rows,indent=2))
            print(json.dumps({k:row[k] for k in ('length_factor','policy','status','elapsed_seconds')},default=float),flush=True)

homogeneity=[]
for g in (.1,10.):
    n=len(scales[1.,'legacy']);physical=6*(len(base.shell.node_ids)+5)
    expected=np.r_[np.tile([g,g,g,1.,1.,1.],physical//6),
                   np.tile(np.r_[np.ones(6),np.ones(6),np.full(12,g)],len(base.beams))]
    assert expected.shape==(n,)
    for policy in ('legacy','native_roles_private_diagnostic'):
        ratio=scales[g,policy]/scales[1.,policy]
        homogeneity.append(dict(length_factor=g,policy=policy,
            maximum_relative_error=float(np.max(abs(ratio/expected-1))),
            mismatched_slots=np.flatnonzero(abs(ratio/expected-1)>1e-12).tolist()))
Path('coordinate-homogeneity.json').write_text(json.dumps(homogeneity,indent=2))
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
Path('runtime.json').write_text(json.dumps(dict(pools=pools,jit_disabled=True,numerical_threads=1),indent=2))
print(json.dumps(homogeneity),flush=True)
