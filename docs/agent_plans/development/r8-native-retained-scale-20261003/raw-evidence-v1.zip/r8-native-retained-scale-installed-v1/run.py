from pathlib import Path
import ast,hashlib,importlib.util,json,os,subprocess,sys,zipfile
root=Path(__file__).parent
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
site=root/"site";fixtures=root/"fixtures"
sha=lambda b:hashlib.sha256(b).hexdigest()
selected=("test_stiffened_shell_curved_material_scaling.py","test_stiffened_shell_curved_material_arc.py","test_stiffened_shell_curved_material.py","test_stiffened_shell_ge_experimental.py")
if len(sys.argv)>1 and sys.argv[1]=="prepare":
    fixtures.mkdir();pending=[repo/"tests"/n for n in selected];seen=set()
    while pending:
        p=pending.pop()
        if p in seen:continue
        seen.add(p)
        for node in ast.walk(ast.parse(p.read_text(encoding="utf-8-sig"))):
            if not isinstance(node,ast.ImportFrom) or not node.module:continue
            module=node.module
            q=(repo/"tests"/(module+".py") if module.startswith("test_") else
               repo/Path(*module.split(".")).with_suffix(".py") if module.startswith("docs.") else None)
            if q and q.exists():pending.append(q)
    for p in seen:
        rel=Path(p.name) if p.parent==repo/"tests" else p.relative_to(repo)
        q=fixtures/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
    (fixtures/"docs/__init__.py").write_text("")
    (fixtures/"docs/reference_cases/__init__.py").write_text("")
    (fixtures/"roof.py").write_bytes((repo/"scripts/r8_e04_native_roof.py").read_bytes())
    for name,args in (("build",["wheel","--no-deps","--no-build-isolation","--no-cache-dir","--no-index","--wheel-dir",str(root/"wheels"),str(repo)]),("install",None)):
        if args is None:args=["install","--no-deps","--no-cache-dir","--no-index","--target",str(site),str(next((root/"wheels").glob("*.whl")))]
        with (root/(name+".log")).open("w") as log:subprocess.run([sys.executable,"-m","pip",*args],stdout=log,stderr=subprocess.STDOUT,check=True)
    wheel=next((root/"wheels").glob("*.whl"));modules={}
    with zipfile.ZipFile(wheel) as archive:
        for p in (repo/"src/anysolver").rglob("*.py"):
            rel=p.relative_to(repo/"src").as_posix();b=p.read_bytes()
            assert b==archive.read(rel)==(site/rel).read_bytes(),rel
            modules[rel]=sha(b)
    (root/"artifact.json").write_text(json.dumps(dict(wheel=wheel.name,wheel_sha256=sha(wheel.read_bytes()),modules=modules,fixtures={p.relative_to(fixtures).as_posix():sha(p.read_bytes()) for p in fixtures.rglob("*.py")}),indent=2))
    print(json.dumps(dict(modules=len(modules),wheel_sha256=sha(wheel.read_bytes()))))
elif len(sys.argv)>1:
    sys.path.insert(0,str(fixtures))
    import anysolver,numba,threadpoolctl,pytest
    assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
    tests=[selected[0],selected[1]+"::test_material_arc_without_shell_j2",selected[2]+"::test_old_curved_material_guards_and_new_policy_limits",selected[3]+"::test_sparse_mixed_panel_solve_recovery_and_restart"]
    code=pytest.main(["-q","-p","no:cacheprovider","--basetemp=temporary","--junitxml=result.xml",*[str(fixtures/n) for n in tests]])
    pools=threadpoolctl.threadpool_info();assert pools and all(p["num_threads"]==1 for p in pools)
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith("anysolver") and getattr(m,"__file__",None)}
    assert all(Path(p).is_relative_to(site.resolve()) for p in imports.values())
    Path("runtime.json").write_text(json.dumps(dict(imports=imports,pools=pools,python=sys.version,jit_disabled=bool(numba.config.DISABLE_JIT)),indent=2))
    raise SystemExit(code)
else:
    spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
    s.ENV["PYTHONPATH"]=str(site)
    result=s.supervised([sys.executable,str(Path(__file__)),"tests"],root/"installed")
    print(json.dumps({k:result[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
