from dataclasses import replace
from pathlib import Path
import json
import numpy as np
import pytest
from anysolver import stiffened_shell as ss
from anyfem.solve.stiffened_shell import ExperimentalGEPointPanel,save_case,load_case
from anyfem.io.project_file import save_project,load_project
from anyfem.model.project import Project
from anyfem.model.records import AnalysisDefinition
from test_stiffened_shell_curved_material import curved_material_panel,_actions
from test_stiffened_shell_curved_material_displacement import material_equal
from test_stiffened_shell_curved_material_staged import programme,OPTIONS


@pytest.mark.parametrize('shell_j2',[False,True])
def test_native_curved_staged_material_project(tmp_path,request,shell_j2):
    d=replace(curved_material_panel(),retained_scale_policy='native_force_moment_roles_v1')
    if not shell_j2:d=replace(d,shell=replace(d.shell,j2_curve=None))
    shell=replace(d.shell,coordinates_m=tuple(tuple(float(v) for v in row) for row in d.shell.coordinates_m))
    base=ExperimentalGEPointPanel(shell,d.beams,d.points,d.fixed,(),
        q4_pullback_policy=d.q4_pullback_policy,shell_reference_policy=d.shell_reference_policy,
        retained_scale_policy=d.retained_scale_policy)
    temporary=base.create_analysis()
    try:plan=programme(temporary)
    finally:temporary.close()
    case=replace(base,load_programme=plan)
    reopened=load_case(save_case(case,tmp_path/'curved-staged.anyfem-ge.json'))
    assert reopened.to_dict()==case.to_dict()
    assert reopened.to_dict()['schema']=='anyfem.experimental-ge-curved-q4-point-panel-material-staged-v1'
    project=Project('curved material staged history',mesh_only=True)
    record=AnalysisDefinition.experimental_point_panel('curved staged',reopened);project.add_analysis(record)
    path=save_project(project,tmp_path/'curved-staged.anyfem')
    def make():
        owner=load_project(path).analyses[record.id].create_point_panel_analysis()
        request.addfinalizer(owner.close);return owner
    owner=make();prefix=owner.solve(plan,(.5,1.,1.5),**OPTIONS)
    assert np.max(prefix.beam_station_accumulated)>0
    if shell_j2:assert np.max(prefix.shell_layer_alpha)>0
    raw=owner.checkpoint();fresh=make();again=fresh.restore(raw)
    assert fresh.checkpoint()==raw;material_equal(prefix,again)
    left=owner.solve(plan,(2.,3.),**OPTIONS);right=fresh.solve(plan,(2.,3.),**OPTIONS)
    assert owner.checkpoint()==fresh.checkpoint();material_equal(left,right)
    assert left.load_programme_complete and left.load_position==3.
    assert left.free_equilibrium_ratio<=1e-8 and left.constraint_max<=1e-9
    for field in ('shell_displacement','cell_resultants','support_reactions','applied_dead_load'):
        np.testing.assert_array_equal(getattr(left,field),getattr(right,field))
    (Path(__file__).parent.parent/('consumer-shell-j2-'+str(shell_j2)+'.json')).write_text(json.dumps(dict(
        schema=case.to_dict()['schema'],model_identity=owner.preflight()['identity'],
        programme_identity=plan.identity,load_position=left.load_position,
        history=left.accepted_factors,equilibrium=left.free_equilibrium_ratio,
        constraint=left.constraint_max,exact_restart=True),indent=2),encoding='utf-8')
