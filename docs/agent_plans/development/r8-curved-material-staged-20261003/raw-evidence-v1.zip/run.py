from pathlib import Path
import sys,os,json,hashlib,subprocess,zipfile,ast,shutil,importlib.util
root=Path(__file__).parent
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
consumer_repo=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
site=root/'site';consumer_site=root.parent/'r8-curved-material-staged-installed-v1/consumer-site';fixtures=root/'fixtures'
checks=['test_stiffened_shell_curved_material_staged.py',
    'test_stiffened_shell_staged_load_owner_experimental.py::test_single_stage_matches_legacy_and_keeps_legacy_checkpoint_contract',
    'test_stiffened_shell_curved_material.py::test_old_curved_material_guards_and_new_policy_limits']
consumer_checks=['test_curved_material_staged_consumer.py',
    'test_stiffened_shell_staged_load_consumer.py::test_staged_save_reopen_native_project_and_standalone_without_assembly',
    'test_installed_curved_staged_project.py']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mode=sys.argv[1] if len(sys.argv)>1 else 'installed'
if mode=='prepare':
    fixtures.mkdir(exist_ok=True)
    seen=set()
    for source,selected in ((repo,checks),(consumer_repo,consumer_checks)):
        pending=[v.split('::')[0][:-3] for v in selected if not v.startswith('test_installed')]
        while pending:
            name=pending.pop()
            if name in seen:continue
            seen.add(name);p=source/'tests'/(name+'.py')
            shutil.copyfile(p,fixtures/p.name)
            for node in ast.walk(ast.parse(p.read_text(encoding='utf-8-sig'))):
                if isinstance(node,ast.ImportFrom) and node.module and node.module.startswith('test_'):
                    pending.append(node.module)
    target=fixtures/'docs/reference_cases/stiffened_shell_e04_roof.py'
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(repo/'docs/reference_cases/stiffened_shell_e04_roof.py',target)
    artifacts={}
    for source,installed,package,wheel_dir in ((repo,site,'anysolver',root/'wheels'),
            (consumer_repo,consumer_site,'anyfem',root.parent/'r8-curved-material-staged-installed-v1/consumer-wheels')):
        if package=='anysolver':
            with (root/(package+'-build.log')).open('w') as log:
                subprocess.run([sys.executable,'-m','pip','wheel','--no-deps','--no-build-isolation',
                    '--no-cache-dir','--no-index','--wheel-dir',str(wheel_dir),str(source)],
                    stdout=log,stderr=subprocess.STDOUT,check=True)
            wheel=next(wheel_dir.glob('*.whl'))
            with (root/(package+'-install.log')).open('w') as log:
                subprocess.run([sys.executable,'-m','pip','install','--no-deps','--no-cache-dir',
                    '--no-index','--target',str(installed),str(wheel)],stdout=log,stderr=subprocess.STDOUT,check=True)
        else:
            wheel=next(wheel_dir.glob('*.whl'))
            (root/'consumer-reuse.txt').write_text('Unchanged source/wheel/site module identities verified below; consumer v1 wheel/site reused. No numerical v1 job executed.',encoding='utf-8')
        modules={}
        with zipfile.ZipFile(wheel) as z:
            for p in (source/'src'/package).rglob('*.py'):
                rel=p.relative_to(source/'src').as_posix()
                assert p.read_bytes()==z.read(rel)==(installed/rel).read_bytes(),rel
                modules[rel]=sha(p)
        artifacts[package]=dict(wheel_sha256=sha(wheel),modules=modules)
    artifacts['fixtures']={p.relative_to(fixtures).as_posix():sha(p) for p in fixtures.rglob('*.py')}
    (root/'artifact.json').write_text(json.dumps(artifacts,indent=2),encoding='utf-8')
    print(json.dumps({n:dict(wheel_sha256=v['wheel_sha256'],modules=len(v['modules']))
        for n,v in artifacts.items() if n!='fixtures'}));raise SystemExit()
if mode in ('installed-child','consumer-child','reversal-child'):
    import anysolver,numba,threadpoolctl,pytest
    assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
    selected=consumer_checks if mode=='consumer-child' else ['test_stiffened_shell_curved_material_staged_reversal.py'] if mode=='reversal-child' else checks
    code=pytest.main(['-q','-p','no:cacheprovider','--basetemp=temporary',
        '--junitxml=result.xml',*[str(fixtures/v) for v in selected]])
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p['num_threads']==1 for p in pools)
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items()
        if n.startswith(('anysolver','anyfem')) and getattr(m,'__file__',None)}
    for n,p in imports.items():
        assert Path(p).is_relative_to((consumer_site if n.startswith('anyfem') else site).resolve()),(n,p)
    Path('runtime.json').write_text(json.dumps(dict(imports=imports,pools=pools,
        jit_disabled=True,python=sys.version),indent=2),encoding='utf-8');raise SystemExit(code)
spec=importlib.util.spec_from_file_location('supervisor',
    root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(site,consumer_site,fixtures)))
s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
destination=root/('installed-repair' if mode=='installed-repair' else mode)
r=s.supervised([sys.executable,'-u',str(Path(__file__)),
    'consumer-child' if mode=='consumer' else 'reversal-child' if mode=='reversal' else 'installed-child'],destination)
print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
