"""Preserve the fresh grouped evidence with an explicit metadata whitelist."""
from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET,importlib.metadata as md
root=Path(__file__).parent
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
out=repo/'docs/agent_plans/development/r8-curved-material-staged-20261003'
out.mkdir(exist_ok=True)
safe_keys=('command','exit_code','elapsed_seconds','sampled_peak_tree_bytes',
    'sampled_max_process_tree_threads','resource_observed','resource_limit',
    'timeout_seconds','memory_limit_bytes','supervisor_sha256')
thread_keys=('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS',
    'NUMBA_NUM_THREADS','NUMBA_DISABLE_JIT','CCX_NPROC_RESULTS','CCX_NPROC_EQUATION_SOLVER')
executions={}
with zipfile.ZipFile(out/'raw-evidence-v1.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,path in (
        ('source-v1',root.parent/'r8-ge-pressure-source-v1/curved-staged-v1'),
        ('source-v2',root.parent/'r8-ge-pressure-source-v1/curved-staged-v2'),
        ('installed-collection',root/'installed'),('installed',root/'installed-repair'),
        ('consumer',root/'consumer'),('reversal',root/'reversal')):
        data=json.loads((path/'execution.json').read_text(encoding='utf-8'))
        record={k:data[k] for k in safe_keys if k in data}
        record['environment']={k:data.get('environment',{})[k] for k in thread_keys
            if k in data.get('environment',{})}
        executions[name]=record
        z.writestr(name+'/execution.json',json.dumps(record,indent=2))
        for filename in ('stdout.log','stderr.log','runtime.json','result.xml'):
            p=path/filename
            if p.exists():z.write(p,name+'/'+filename)
        if name in ('installed','consumer','reversal'):
            tests=ET.parse(path/'result.xml').getroot()
            suites=list(tests) if tests.tag=='testsuites' else [tests]
            record['tests']={k:sum(int(s.attrib.get(k,'0')) for s in suites)
                for k in ('tests','failures','errors','skipped')}
    for filename in ('run.py','run-before-reversal.py','retain.py','artifact.json',
        'artifact-before-reversal.json','anysolver-build.log','anysolver-install.log',
        'consumer-reuse.txt','independent-development-review.txt','physical-summary.json',
        'consumer-shell-j2-False.json','consumer-shell-j2-True.json'):
        p=root/filename
        if p.exists():z.write(p,filename)
    v1=root.parent/'r8-curved-material-staged-installed-v1'
    for filename in ('run.py','artifact.json','anysolver-build.log','anysolver-install.log',
        'anyfem-build.log','anyfem-install.log'):
        z.write(v1/filename,'pre-review-build/'+filename)
    for p in (root/'fixtures').rglob('*.py'):
        z.write(p,'fixtures/'+p.relative_to(root/'fixtures').as_posix())
    for filename in ('positive-prefix.bin','reversal.json'):
        p=next((root/'reversal/temporary').rglob(filename));z.write(p,'signed-cycle/'+filename)
    for filename,p in (
        ('supervisor.py',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py'),
        ('source-runner.py',root.parent/'r8-ge-pressure-source-v1/run-root.py')):
        z.write(p,filename)
artifact=json.loads((root/'artifact.json').read_text(encoding='utf-8'))
dependencies={}
for n in ('numpy','scipy','numba','llvmlite','threadpoolctl','pytest','ANYmaterial','ANYmesh','ANYgeometry'):
    try:dependencies[n]=md.version(n)
    except md.PackageNotFoundError:dependencies[n]=None
summary=dict(source_parent='2653b6d5',consumer_source_parent='295f667',
    status='IMPLEMENTED_NOT_QUALIFIED',executions=executions,dependencies=dependencies,
    artifacts={n:dict(wheel_sha256=artifact[n]['wheel_sha256'],modules=len(artifact[n]['modules']))
        for n in ('anysolver','anyfem')},physical=json.loads((root/'physical-summary.json').read_text()),
    raw_sha256=hashlib.sha256((out/'raw-evidence-v1.zip').read_bytes()).hexdigest())
(out/'summary-v1.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(dict(artifacts=summary['artifacts'],
    checks={n:summary['executions'][n]['tests'] for n in ('installed','consumer','reversal')},
    raw_sha256=summary['raw_sha256']),indent=2))
