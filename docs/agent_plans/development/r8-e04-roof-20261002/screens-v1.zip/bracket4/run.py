from pathlib import Path
import os,json,hashlib,importlib.util,sys
r=Path(os.environ['TEMP'])/'r8-e04-roof-bracket-v1';site=r.parent/'r8-curved-arc-installed-v1/site'
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
for p in (repo/'src/anysolver').rglob('*.py'):
 assert p.read_bytes()==(site/p.relative_to(repo/'src')).read_bytes(),p.name
artifact=json.loads((r.parent/'r8-curved-arc-installed-v1/artifact.json').read_text())
(r/'source.json').write_text(json.dumps(dict(wheel_sha256=artifact['wheel_sha256'],modules=len(artifact['modules']),runner_sha256=hashlib.sha256((r/'native-roof.py').read_bytes()).hexdigest(),case_sha256=hashlib.sha256((r/'fixtures/docs/reference_cases/stiffened_shell_e04_roof.py').read_bytes()).hexdigest()),indent=2))
spec=importlib.util.spec_from_file_location('supervisor',r.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=str(site)+os.pathsep+str(r/'fixtures')
result=s.supervised([sys.executable,'-u',str(r/'native-roof.py'),'--output',str(r/'bracket-4/outputs'),'--size','4','--density','1','--seed-force','100','--radius','.003','--steps','24'],r/'bracket-4')
print(json.dumps({k:result[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
