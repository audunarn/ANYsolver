from pathlib import Path
import hashlib,json,statistics,zipfile,xml.etree.ElementTree as ET
import numpy as np
root=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((root/"artifact-binding-v1.json").read_text(encoding="utf-8"))
for record,site in ((identity,root/"site"),(identity["baseline"],root.parent/"r8-q4-rotation-installed-v2/site")):
 assert sha(Path(record["wheel"]))==record["wheel_sha256"]
 with zipfile.ZipFile(record["wheel"]) as z:
  for n,h in record["modules"].items():assert h==hashlib.sha256(z.read(n)).hexdigest()==sha(site/n),n
for p,h in identity["dependency_modules"].items():assert sha(Path(p))==h,p
consumer=root.parent/"r8-ge-member-scale-installed-v1/consumer-site"
for n,h in identity["consumer_modules"].items():assert sha(consumer/n)==h,n
cases={}
for case,pairs in (("screen",7),("easy",7),("middle",1)):
 samples={};peaks={};histories={}
 for label in ("baseline","candidate"):
  records=[];resources=[]
  for i in range(1,pairs+1):
   p=root/f"timing-{case}-{i}-{label}";r=json.loads((p/"result.json").read_text());e=json.loads((p/"execution.json").read_text())
   assert r["status"]=="completed" and not r["qualified"] and e["exit_code"]==0 and e["resource_limit"] is None
   assert r["pools"] and all(t["num_threads"]==1 for t in r["pools"])
   assert r["jit_disabled"] and r["numba_threads"]==1
   records.append(r);resources.append(e)
  values=[r["complete_route_seconds"] for r in records]
  samples[label]=dict(seconds=values,median=statistics.median(values),min=min(values),max=max(values),spread=max(values)-min(values))
  peaks[label]=dict(sampled_bytes=[e["sampled_peak_tree_bytes"] for e in resources],median=statistics.median(e["sampled_peak_tree_bytes"] for e in resources))
  histories[label]=records[0]["history"]
 for i in range(1,pairs+1):
  a=root/f"timing-{case}-{i}-baseline";b=root/f"timing-{case}-{i}-candidate"
  ar,br=[json.loads((p/"result.json").read_text()) for p in (a,b)]
  assert ar["history"]==br["history"] and ar["preflight"]==br["preflight"]
  with np.load(a/"physical.npz") as aa,np.load(b/"physical.npz") as bb:
   assert aa.files==bb.files
   for n in aa.files:np.testing.assert_array_equal(aa[n],bb[n])
  assert (a/"checkpoint.bin").read_bytes()==(b/"checkpoint.bin").read_bytes()
 reductions=[100*(1-b/a) for a,b in zip(samples["baseline"]["seconds"],samples["candidate"]["seconds"])]
 cases[case]=dict(pairs=pairs,timing=samples,memory=peaks,history=histories["baseline"],median_time_reduction_percent=100*(1-samples["candidate"]["median"]/samples["baseline"]["median"]),paired_reduction_percent=reductions,exact_physical_history_checkpoint=True,qualification=False)
assert cases["screen"]["median_time_reduction_percent"]>0
assert cases["easy"]["median_time_reduction_percent"]>=-5
suites=ET.parse(root/"checks-v1/result.xml").getroot()
tests=list(suites.iter("testcase"));assert len(tests)==57
assert not list(suites.iter("failure")) and not list(suites.iter("error")) and not list(suites.iter("skipped"))
probe={}
for label in ("baseline","candidate"):
 p=root/f"probe-easy-1-{label}"
 r=json.loads((p/"result.json").read_text());assert r["status"]=="completed"
 probe[label]=json.loads((p/"work.json").read_text())
for name in ("_assemble","_advance","evaluate","spatial_response"):
 a={};b={}
 for target,label in ((a,"baseline"),(b,"candidate")):
  for row in probe[label]:
   if row["name"]==name:
    key=(Path(row["file"]).name,name);target[key]=target.get(key,0)+row["total"]
 assert a==b,(name,a,b)
report=dict(status="RETAIN_SCOPED_DEVELOPMENT_CHANGE",source_commit="0d494d1a",wheel_sha256=identity["wheel_sha256"],baseline_wheel_sha256=identity["baseline"]["wheel_sha256"],installed_checks=dict(passed=57,failed=0,errors=0,skipped=0),consumer=json.loads((root/"consumer-v1/result.json").read_text()),cases=cases,work_probe=probe,source_wheel_site_exact=True,artifact_modules=414,consumer_modules=98,dependency_files=len(identity["dependency_modules"]),all_relevant_trees_reverified=True,formal_F03="UNCONSUMED",G5="IN_PROGRESS",release=False)
(root/"adjudication-v1.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
print(json.dumps(dict(status=report["status"],cases={n:dict(pairs=r["pairs"],reduction_percent=r["median_time_reduction_percent"]) for n,r in cases.items()},work={label:[(r["name"],r["total"]) for r in rows if r["name"]=="_qualified_linear_correction"] for label,rows in probe.items()})))
