import sys,json
from pathlib import Path
import anysolver,numpy,scipy,numba,pytest
from threadpoolctl import threadpool_info
site=Path(sys.argv[1]).resolve()
assert Path(anysolver.__file__).resolve().is_relative_to(site)
print(json.dumps(dict(imports={m.__name__:m.__file__ for m in (anysolver,numpy,scipy,numba,pytest)},versions={m.__name__:getattr(m,"__version__",None) for m in (numpy,scipy,numba,pytest)},pools=threadpool_info(),numba_threads=numba.get_num_threads(),jit_disabled=numba.config.DISABLE_JIT)),flush=True)
assert all(p["num_threads"]==1 for p in threadpool_info())
raise SystemExit(pytest.main(["-q",sys.argv[2],"--basetemp",sys.argv[3]]))
