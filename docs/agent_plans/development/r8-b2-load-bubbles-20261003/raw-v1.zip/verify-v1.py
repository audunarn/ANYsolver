from pathlib import Path
import hashlib,importlib.util,json,shutil,sys,zipfile,os
root=Path(os.environ["TEMP"])/"r8-b2-load-bubbles-installed-v1"
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
wheel=next((root/"dist").glob("*.whl")); site=root/"site"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with zipfile.ZipFile(wheel) as z:
    names=sorted(n for n in z.namelist() if n.startswith("anysolver/") and n.endswith(".py"))
    for n in names:
        if z.read(n)!=(repo/"src"/n).read_bytes() or z.read(n)!=(site/n).read_bytes(): raise RuntimeError("module mismatch "+n)
fixture=root/"fixtures";fixture.mkdir(exist_ok=False)
src=repo/"tests/test_b2_physical_load_bubbles.py";shutil.copy2(src,fixture/src.name)
binding=dict(source_head="c83c5d4e13fdb44d8ac1055ab7f3a01883f9f5a8",wheel=str(wheel),wheel_sha256=sha(wheel),site=str(site),module_count=len(names),test_sha256=sha(src),modules=names)
(root/"binding-v1.json").write_text(json.dumps(binding,indent=2)+"\n")
child=root/"installed-check.py"
child.write_text('''import sys,json\nfrom pathlib import Path\nimport anysolver,numpy,scipy,numba,pytest\nfrom threadpoolctl import threadpool_info\nsite=Path(sys.argv[1]).resolve()\nassert Path(anysolver.__file__).resolve().is_relative_to(site)\nprint(json.dumps(dict(imports={m.__name__:m.__file__ for m in (anysolver,numpy,scipy,numba,pytest)},versions={m.__name__:getattr(m,"__version__",None) for m in (numpy,scipy,numba,pytest)},pools=threadpool_info(),numba_threads=numba.get_num_threads(),jit_disabled=numba.config.DISABLE_JIT)),flush=True)\nassert all(p["num_threads"]==1 for p in threadpool_info())\nraise SystemExit(pytest.main(["-q",sys.argv[2],"--basetemp",sys.argv[3]]))\n''')
spec=importlib.util.spec_from_file_location("sup",Path(os.environ["TEMP"])/"r8-b2-panel-resolution-installed-v1/matched-run.py")
sup=importlib.util.module_from_spec(spec);spec.loader.exec_module(sup)
sup.ENV["PYTHONPATH"]=str(site)+os.pathsep+str(fixture)
r=sup.supervised([sys.executable,str(child),str(site),str(fixture/src.name),str(root/"pytest-temp")],root/"run-v1")
print(json.dumps(dict(modules=len(names),wheel_sha256=sha(wheel),execution=r)))

