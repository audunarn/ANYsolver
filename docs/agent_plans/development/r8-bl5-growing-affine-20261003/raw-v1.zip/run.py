"""One same-fine-mesh complete growing-space comparison; serial children."""
from pathlib import Path
import hashlib, importlib.util, json, shutil, sys
ROOT=Path(__file__).resolve().parent
REPO=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
OLD=ROOT.parent/'r8-bl5-affine-flexible-v1'
PREVIOUS=ROOT.parent/'r8-bl5-affine-installed-v1'
spec=importlib.util.spec_from_file_location('owned_supervisor',OLD/'run.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.ROOT=ROOT
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
FILES=('r8_bl5_external_affine_reference_dev.py','r8_bl5_affine_flexible_native_dev.py',
 'r8_bl5_saved_trace_work_audit_dev.py','b3_e4_bl5_external_p0_refinement_dev.py',
 'b3_e4_bl5_external_p0_enforcement_dev.py','b3_e4_bl5_matched_mz_reference_dev.py',
 'b3_e4_bl5_matched_reference_actions.py','b3_e4_f03_bl5_opensees_line_reference.py',
 'b3_e4_bl5_matched_mz_native_dev.py','b3_e4_bl5_matched_p0_native_refinement_dev.py',
 'b3_e4_bl5_coherent_aggregation_dev.py')
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='stage':
  entries={}
  (ROOT/'fixtures').mkdir(exist_ok=False)
  for name in FILES:
   shutil.copyfile(REPO/'scripts'/name,ROOT/'fixtures'/name);entries['scripts/'+name]=sha(ROOT/'fixtures'/name)
  name='test_stiffened_shell_l1_assembly_experimental.py'
  shutil.copyfile(REPO/'tests'/name,ROOT/'fixtures'/name);entries['tests/'+name]=sha(ROOT/'fixtures'/name)
  assert sha(module.EXTERNAL_SITE/'openseespywin/opensees.pyd')=='25ba42e1672526137d765d9c3631d1403e091f54f5afcdb9242f9243c63c3a96'
  (ROOT/'binding.json').write_text(json.dumps(dict(sources=entries,supervisor_source=str(OLD/'run.py'),
   supervisor_sha256=sha(OLD/'run.py'),physical_supports=[i/16 for i in range(17)],nx=32,ny=8,
   native_members=32,beam_halfcells=64,multiplier_span=4,rows=160,loads=dict(fy=[0,100,0,0,0,0],mx=[0,0,0,10,0,0],mz=[0,0,0,0,0,10]),
   source_parent='ef07ddad',scope='One bounded existingfine-grid complete growing-space comparison; no F03/convergence/locking/selection'),indent=2)+'\n')
 elif mode=='external':
  for case in ('fy','mx','mz'):
   module.supervise([str(module.RUNTIME),'-u',str(ROOT/'fixtures/r8_bl5_external_affine_reference_dev.py'),
    '--site',str(module.EXTERNAL_SITE),'--output-dir',str(ROOT/'external'/case),'--case',case,'--nx','32',
    '--support-count','16'],'external-'+case+'-run',8*1024**3)
 elif mode=='native':
  module.supervise([sys.executable,'-u',str(ROOT/'fixtures/r8_bl5_affine_flexible_native_dev.py'),
   '--site',str(PREVIOUS/'site'),'--wheel',str(PREVIOUS/'solver-dist/anysolver-0.4.7-py3-none-any.whl'),
   '--source',str(REPO),'--fixtures',str(ROOT/'fixtures'),'--external',str(ROOT/'external'),
   '--output',str(ROOT/'native'),'--nx','32','--support-count','16'],'native-three-run',1024**3)
 elif mode=='audit':
  module.supervise([sys.executable,'-u',str(ROOT/'fixtures/r8_bl5_saved_trace_work_audit_dev.py'),
   '--root',str(ROOT),'--output',str(ROOT/'trace-audit-v1.json')],'audit-run',1024**3)
 else:raise ValueError('stage/external/native/audit only')
