from pathlib import Path
import importlib.util,sys,os,json
root=Path(__file__).parent
repo=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=str(repo/'src')+os.pathsep+str(root.parent/'r8-bl5-material-installed-v1/site')
s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
r=s.supervised([sys.executable,'-m','pytest','-q','-p','no:cacheprovider',*[str(repo/'tests'/n) for n in sys.argv[2:]]],root/sys.argv[1])
print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))


