"""Stored-KKT discriminator only; not public acceptance or element certification."""
from fractions import Fraction
from pathlib import Path
import json,os,sys
ROOT=Path(__file__).resolve().parent
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMBA_NUM_THREADS='1',NUMBA_DISABLE_JIT='1')
sys.path.insert(0,'C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-footprint-modes-installed-v1/site')
import numpy as np
from scipy import sparse
from anysolver._b2_physical_linear_batch_dev import _accurate_sparse_residual
K=sparse.load_npz(ROOT/'K.npz');C=sparse.load_npz(ROOT/'C.npz');T=sparse.load_npz(ROOT/'T.npz').tocsc()
a=np.load(ROOT/'candidate.npz')
assert np.all(np.diff(T.indptr)==1) and np.all(T.data==1.)
assert len(set(T.indices))==T.shape[1] and not np.any(a['u0'])
rk=(T.T@K@T).tocsc();rc=(C@T).tocsc()
A=sparse.bmat(((rk,rc.T),(rc,None)),format='csr')
res=_accurate_sparse_residual(A,a['answer'][:,None],a['rhs'][:,None])[:,0]
active=a['explicit_rhs']>0.; rows=np.flatnonzero(active)
exact=[]
for row in rows:
    start,stop=A.indptr[row:row+2]
    r=sum((Fraction(float(v))*Fraction(float(a['answer'][i])) for v,i in zip(A.data[start:stop],A.indices[start:stop])),
        -Fraction(float(a['rhs'][row])))
    assert float(r)==res[row]
    exact.append(dict(row=int(row),residual=float(r),absolute_cap=1e-9*float(a['explicit_rhs'][row]),
                      exact_fraction=str(r),fraction_of_applied_load=abs(float(r))/float(a['explicit_rhs'][row])))
data=dict(scope='stored binary64 equations only; original public status remainsfailed',
    active_rows=exact,component_cap_met=all(abs(x['residual'])<=x['absolute_cap'] for x in exact),
    max_constraint_residual=float(np.max(np.abs(res[len(a['explicit_rhs']):]))),
    old_global_floor_fraction=float(np.max(a['resolution_floor'][active]/a['explicit_rhs'][active])))
with (ROOT/'discriminator.json').open('x') as f:json.dump(data,f,indent=2);f.write('\n')
print(json.dumps(data))
