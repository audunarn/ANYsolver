from pathlib import Path
import importlib.util,json,runpy,sys
ROOT=Path(__file__).resolve().parent
def observe(frame,event,arg):
    if event=='exception' and frame.f_code.co_filename.endswith('_stiffened_shell_b2_q4_panel_experimental.py'):
        typ,value,tb=arg
        if str(value)=='panel point gap or equilibrium failed':
            import numpy as np
            f=frame.f_locals
            bad_gap=np.flatnonzero(np.abs(f['gap'])>1e-9*f['gap_scale'])
            bad_eq=np.flatnonzero(np.abs(f['projected'])>f['equilibrium_tolerance'])
            data=dict(error=str(value),bad_gap_rows=bad_gap.tolist(),bad_equilibrium_rows=bad_eq.tolist(),
                gap=f['gap'][bad_gap].tolist(),gap_scale=f['gap_scale'][bad_gap].tolist(),
                projected=f['projected'][bad_eq].tolist(),tolerance=f['equilibrium_tolerance'][bad_eq].tolist(),
                applied_indices=np.flatnonzero(f['applied']).tolist())
            (ROOT/'source-failure.json').write_text(json.dumps(data,indent=2)+'\n')
    return observe
if len(sys.argv)>1 and sys.argv[1]=='child':
    sys.argv=sys.argv[1:]
    sys.settrace(observe)
    try:runpy.run_path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-e02-rigid-tip-dev-v2/native-runner.py',run_name='__main__')
    finally:sys.settrace(None)
else:
    path=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-e02-rigid-tip-dev-v3/run.py')
    spec=importlib.util.spec_from_file_location('supervision',path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    command=[sys.executable,'-u',str(Path(__file__)),'child','--site',
        'C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/src',
        '--output',str(ROOT/'source-output'),'--nx','10','--ny','4','--sign','1','--profile','b2']
    try:mod.supervised(command,ROOT/'source-execution')
    except RuntimeError:
        assert (ROOT/'source-failure.json').exists()
        print((ROOT/'source-failure.json').read_text())
