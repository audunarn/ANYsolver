"""Capture the current failed public candidate; no equations or statuses changed."""
from pathlib import Path
import json,runpy,sys

ROOT=Path(__file__).resolve().parent
def observe(frame,event,arg):
    if event=='exception' and frame.f_code.co_filename.endswith('_stiffened_shell_b2_q4_panel_experimental.py'):
        typ,value,tb=arg
        if str(value)=='panel mixed-load resolution insufficient':
            import numpy as np
            from scipy import sparse
            f=frame.f_locals; owner=f['self']
            if not (ROOT/'candidate.npz').exists():
                for name in ('K','C','T'):
                    sparse.save_npz(ROOT/(name+'.npz'),getattr(owner,'_'+name))
                np.savez(ROOT/'candidate.npz',answer=f['answer'],rhs=f['rhs'],
                    factor_scale=owner._factor_scale,u0=owner._u0,
                    explicit_rhs=f['explicit_rhs'],resolution_floor=f['resolution_floor'],
                    force_scale=f['physical_force_scale'],projected=f['projected'],gap=f['gap'])
                (ROOT/'failure.json').write_text(json.dumps(dict(error=str(value),
                    source_file=frame.f_code.co_filename,source_line=frame.f_lineno,
                    unchanged_public_status='failed',matrix_shape=owner._K.shape,
                    max_floor_fraction=float(np.max(f['resolution_floor'][f['active']]/f['explicit_rhs'][f['active']]))),indent=2)+'\n')
    return observe
sys.settrace(observe)
try:
    runpy.run_path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-e02-rigid-tip-dev-v2/native-runner.py',run_name='__main__')
finally:
    sys.settrace(None)
