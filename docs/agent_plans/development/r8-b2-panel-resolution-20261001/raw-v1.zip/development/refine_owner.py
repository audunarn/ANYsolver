from pathlib import Path
p=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/src/anysolver/_stiffened_shell_b2_q4_panel_experimental.py')
text=p.read_text()
start=text.index('        try:\n            if answer.shape != rhs.shape',text.index('    def solve_linear('))
stop=text.index('        recovered = []',start)
old=text[start:stop]
split=old.index('        except _NumericalFailure as exc:')
body=old[:split]
failure=old[split:]
assert failure.count('return self._panel_result(')==1
new='        for refinement in range(2):\n'+''.join('    '+line if line.strip() else line for line in body.splitlines(keepends=True))
new+='''            except _NumericalFailure as exc:
                if (refinement == 0 and
                        str(exc) == "panel point gap or equilibrium failed" and
                        self._explicit_load_resolved(answer, rhs, explicit_rhs)):
                    try:
                        defect = _accurate_sparse_residual(
                            self._resolution_kkt, answer[:, None], rhs[:, None])[:, 0]
                        with np.errstate(over="ignore", under="ignore", invalid="ignore"):
                            correction_rhs = -self._factor_scale*defect
                        if (not np.isfinite(correction_rhs).all() or
                                np.any((defect != 0.) & (correction_rhs == 0.))):
                            raise _NumericalFailure("panel correction scaling is not representable")
                        correction = self._factor_scale*np.asarray(
                            self._handle.solve(correction_rhs), dtype=float)
                        if correction.shape != answer.shape or not np.isfinite(correction).all():
                            raise _NumericalFailure("finite panel correction required")
                        answer = answer+correction
                    except (B2NumericalSolveFailure, RuntimeError) as correction_failure:
                        return self._panel_result(
                            "failed", factorization_count=self._handle.factorization_count,
                            solve_count=self._handle.solve_count, failure_reason=str(correction_failure))
                    continue
                return self._panel_result(
                    "failed", factorization_count=self._handle.factorization_count,
                    solve_count=self._handle.solve_count, failure_reason=str(exc))
            break
'''
p.write_text(text[:start]+new+text[stop:])
print('added one bounded same-factor correction and full revalidation')
