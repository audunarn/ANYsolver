"""Reuse existing owned-process supervision, observing expected non-success."""
from pathlib import Path
import importlib.util,json,sys
ROOT=Path(__file__).resolve().parent
path=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-e02-rigid-tip-dev-v3/run.py')
spec=importlib.util.spec_from_file_location('supervision',path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
command=[sys.executable,'-u',str(ROOT/'capture.py'),'--site',str(module.SITE),
    '--output',str(ROOT/'native-output'),'--nx','10','--ny','4','--sign','1','--profile','b2']
try:
    module.supervised(command,ROOT/'execution')
except RuntimeError:
    execution=json.loads((ROOT/'execution/execution.json').read_text())
    assert execution['exit_code']==1 and execution['resource_limit'] is None
    assert (ROOT/'candidate.npz').is_file()
    print(json.dumps(dict(status='EXPECTED_PUBLIC_FAILURE_CAPTURED',
        elapsed_seconds=execution['elapsed_seconds'],peak_bytes=execution['sampled_peak_tree_bytes'])))
else:
    raise RuntimeError('expected original public failure was not observed')
