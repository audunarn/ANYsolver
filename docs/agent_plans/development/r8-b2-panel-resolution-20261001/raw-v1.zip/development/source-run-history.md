# Source checks and retained limitations
Final source-final.log records136 passed, with exact current source copies and
portable runtime/resource/selection records. The initial125-pass console-only
run preceded final review fixes/test additions. Earlier source failures after
certificate-only and one correction are retained by source-v1/source-v2,
public failure captures/arrays and available portable records. Those portable
runs did not save full pytest stdout/XML. Prior121/1 and0/1 counts were reported
in the prior tool conversation and are not reconstructed as new raw logs here.
Initial quiet component predicates remained failing; no tolerated scientific
criterion was weakened to label those failures passes.
