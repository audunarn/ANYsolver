from pathlib import Path
import importlib.util,sys
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('supervision',ROOT/'matched-run.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.supervised([sys.executable,'-u',str(ROOT/'consumer.py')],ROOT/'consumer-execution-v2')
print('Consumer Project save/reopen completed')
