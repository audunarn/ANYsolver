from pathlib import Path
import hashlib,json,math
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
EXTERNAL=BASE/'r8-e02-rigid-tip-dev-v3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=[]
def read(p):
    inputs.append(dict(path=str(p),sha256=sha(p)))
    return json.loads(p.read_text())
rows=[]
for nx,ny in ((10,4),(20,8),(40,16)):
    b=read(ROOT/f'native-b2-{nx}x{ny}-s1/outputs/result.json')
    gv='v2' if nx==10 else 'v3'
    g=read(BASE/f'r8-e02-rigid-tip-dev-{gv}'/f'native-ge-{nx}x{ny}-s1/outputs/result.json')
    assert b['geometry']==g['geometry'] and b['loads']==g['loads']
    assert b['nodes']==g['nodes'] and b['cells']==g['cells'] and b['patch_nodes']==g['patch_nodes']
    for name in ('Fz','Mx','My'):
        extdir=EXTERNAL/f'external-ccx-{nx}x{ny}-s1'/name
        e=read(extdir/'result.json');i=read(extdir/'identity.json')
        assert e['status']=='PARSED_DEVELOPMENT_ONLY' and not e['qualification_claim']
        assert e['deck_sha256']==i['deck_sha256']==i['metadata']['deck_sha256']
        a=b['results'][name];v=g['results'][name]
        assert a['status']==v['status']=='completed' and a['factors']==1
        w=a['external_final_pairing_J'];wg=v['external_final_pairing_J'];we=e['conjugate_external_work_J']
        assert w>0 and wg>0 and we>0 and all(map(math.isfinite,(w,wg,we)))
        rows.append(dict(nx=nx,ny=ny,load=name,b2_work_J=w,ge_work_J=wg,external_work_J=we,
            b2_ge_difference=w/wg-1,b2_external_difference=w/we-1,controls=a['controls']))
trends={name:[v[i+1]['b2_work_J']/v[i]['b2_work_J']-1 for i in range(2)]
    for name in ('Fz','Mx','My') for v in ([r for r in rows if r['load']==name],)}
record=dict(status='COMPLETED_DEVELOPMENT_ONLY_NOT_QUALIFIED',rows=rows,refinement=trends,
    input_identities=inputs,wheel_sha256=sha(next((ROOT/'wheels').glob('*.whl'))),
    boundaries=['Native torque last refinement exceeds1%; solid thickness convergence unproven.',
      'External seven-digit DAT cannot certify1e-8balance.',
      'No signed eccentric moment, normal-spin, in-plane, finite GE or complete footprint acceptance.',
      'Stored-equation resolution certificate does not certify element/forward accuracy.'])
(ROOT/'comparison-b2.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],max_b2_ge_difference=max(abs(r['b2_ge_difference']) for r in rows),
    finest={r['load']:r['b2_external_difference'] for r in rows if r['nx']==40},refinement=trends)))
