from pathlib import Path
import sys,json,hashlib,zipfile,runpy
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'site'))
import anysolver,anyfem,numpy,scipy,numba,threadpoolctl
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=ROOT.parent/'r8-anyfem-b2-modal-installed-v1'
source=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
wheel=next((old/'wheels').glob('*.whl'))
manifest=json.loads((old/'source-manifest.json').read_text())
assert all(sha(source/p)==h for p,h in manifest.items())
with zipfile.ZipFile(wheel) as z:
    files={p for p in z.namelist() if p.startswith('anyfem/') and p.endswith('.py')}
    assert files=={p.removeprefix('src/') for p in manifest}
    assert all(z.read(p)==(ROOT/'site'/p).read_bytes()==(source/'src'/p).read_bytes() for p in files)
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
sys.argv=['example.py',str(ROOT/'consumer.json'),'--project',str(ROOT/'consumer.anyfem')]
runpy.run_path(str(old/'example.py'),run_name='__main__')
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items()
    if n.split('.')[0] in ('anysolver','anyfem') and getattr(m,'__file__',None)}
assert imports and all(Path(p).is_relative_to((ROOT/'site').resolve()) for p in imports.values())
record=dict(consumer_sha256=sha(wheel),matching_consumer_modules=len(files),imports=imports,
    example_sha256=sha(old/'example.py'),numerical_pools=threadpoolctl.threadpool_info(),jit_disabled=True)
(ROOT/'consumer-identity.json').write_text(json.dumps(record,indent=2))
print(json.dumps(dict(status='COMPLETED_CONSUMER_EXAMPLE',matching_consumer_modules=len(files))))
