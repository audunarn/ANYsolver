from pathlib import Path
import hashlib,importlib.util,json,os,sys
ROOT=Path(__file__).resolve().parent
SUP=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-panel-resolution-installed-v1/matched-run.py')
assert hashlib.sha256(SUP.read_bytes()).hexdigest()=='5837645ddf40e591451cbd58f8975ce8f026cb908e750044b848c8c04dcae5d4'
spec=importlib.util.spec_from_file_location('supervisor',SUP)
service=importlib.util.module_from_spec(spec);spec.loader.exec_module(service)
site=json.loads((ROOT/'wheel-identity.json').read_text())['site']
service.ENV.update(PYTHONPATH=os.pathsep.join((site,str(ROOT/'fixtures'),str(ROOT/'fixtures/tests'))),PYTHONNOUSERSITE='1')
print(json.dumps(service.supervised([sys.executable,str(ROOT/'example-check.py')],ROOT/'example')))
