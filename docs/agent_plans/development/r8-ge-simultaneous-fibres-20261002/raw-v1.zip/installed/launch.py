from pathlib import Path
import ast,hashlib,importlib.util,json,os,shutil,sys,zipfile
ROOT=Path(__file__).resolve().parent
REPO=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
ART=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-loaded-sections-installed-v2')
SUP=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-panel-resolution-installed-v1/matched-run.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(SUP)=='5837645ddf40e591451cbd58f8975ce8f026cb908e750044b848c8c04dcae5d4'
manifest=json.loads((ART/'solver-source-manifest.json').read_text());site=ART/'solver-artifact/site'
wheel,=(ART/'solver-artifact/wheels').glob('*.whl')
assert sha(wheel)=='4c14d0942410f97b6e2ab397eb0d4e567cbff4169c05b391c5685c4df40d3b7c'
with zipfile.ZipFile(wheel) as z:
    for name,digest in manifest.items():
        rel=name.removeprefix('src/')
        assert sha(REPO/name)==sha(site/rel)==hashlib.sha256(z.read(rel)).hexdigest()==digest
fixtures=ROOT/'fixtures';(fixtures/'tests').mkdir(parents=True,exist_ok=True);(fixtures/'examples').mkdir(exist_ok=True)
pending=[REPO/'tests/test_stiffened_shell_physical_fibre_j2_history.py'];copied=set()
while pending:
    p=pending.pop()
    if p in copied:continue
    dest=fixtures/p.relative_to(REPO)
    if dest.exists():assert sha(dest)==sha(p)
    else:shutil.copy2(p,dest)
    copied.add(p)
    for item in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
        names=[]
        if isinstance(item,ast.ImportFrom) and item.module:names=[item.module]
        if isinstance(item,ast.Import):names=[n.name for n in item.names]
        for n in names:
            if n.startswith('test_'):pending.append(REPO/'tests'/(n+'.py'))
            if n.startswith('examples.'):pending.append(REPO/(n.replace('.','/')+'.py'))
(ROOT/'fixture-manifest.json').write_text(json.dumps({p.relative_to(ROOT).as_posix():sha(p) for p in fixtures.rglob('*.py')},indent=2)+'\n',encoding='utf-8')
(fixtures/'pytest.ini').write_text('[pytest]\n',encoding='utf-8')
shutil.copy2(ART/'solver-source-manifest.json',ROOT/'solver-source-manifest.json')
(ROOT/'wheel-identity.json').write_text(json.dumps(dict(wheel_sha256=sha(wheel),modules=len(manifest),site=str(site),supervisor_sha256=sha(SUP),launcher_sha256=sha(Path(__file__))),indent=2)+'\n',encoding='utf-8')
spec=importlib.util.spec_from_file_location('supervisor',SUP);service=importlib.util.module_from_spec(spec);spec.loader.exec_module(service)
service.ENV.update(PYTHONPATH=os.pathsep.join((str(site),str(fixtures),str(fixtures/'tests'))),PYTHONNOUSERSITE='1')
if len(sys.argv)>1:
    if sys.argv[1]=='test':command=[sys.executable,str(ROOT/'installed-check.py')];folder=ROOT/'test'
    elif sys.argv[1]=='example':command=[sys.executable,str(ROOT/'fixtures/examples/stiffened_shell_coupled_plastic_history.py')];folder=ROOT/'example'
    else:raise ValueError('exact test or example mode required')
    print(json.dumps(service.supervised(command,folder)))
else:print('Installed module identity and fixture preparation verified')
