from pathlib import Path
import hashlib,importlib.metadata,json,sys
import numba,pytest
from threadpoolctl import threadpool_info
import anysolver
ROOT=Path(__file__).resolve().parent
SITE=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-loaded-sections-installed-v2/solver-artifact/site').resolve()
assert Path(anysolver.__file__).resolve().is_relative_to(SITE)
assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
assert all(p['num_threads']==1 for p in threadpool_info())
args=['-q','-c',str(ROOT/'fixtures/pytest.ini'),'--basetemp='+str(Path.cwd()/'basetemp'),'--junitxml='+str(Path.cwd()/'junit.xml'),str(ROOT/'fixtures/tests/test_stiffened_shell_physical_fibre_j2_history.py')]
code=pytest.main(args)
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith('anysolver') and getattr(m,'__file__',None)}
assert all(Path(p).is_relative_to(SITE) for p in imports.values())
assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
assert all(p['num_threads']==1 for p in threadpool_info())
identity=dict(exit_code=int(code),python=sys.version,imports=imports,pools=threadpool_info(),jit_disabled=bool(numba.config.DISABLE_JIT),numba_threads=numba.get_num_threads(),dependencies={n:importlib.metadata.version(n) for n in ('numpy','scipy','numba','ANYmaterial','pytest','threadpoolctl','psutil')})
Path('import-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
sys.exit(code)
