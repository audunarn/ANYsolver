"""Actual simultaneous histories in two parallel native stiffeners, not G3 acceptance."""
import json
import numpy as np
from anysolver import stiffened_shell as ss
from examples.stiffened_shell_coupled_plastic_history import definition, programme, activity, OPTIONS, CONTROL
from test_stiffened_shell_staged_material_history import _capture


def test_two_stiffener_simultaneous_prefix(request, tmp_path, record_property):
    model = definition()
    owner = ss.create_analysis(definition=model)
    request.addfinalizer(owner.close)
    loads = programme(owner)
    history = []
    states = []
    def accepted(result):
        row = activity(result,states[-1]['result'] if states else None)
        state = _capture(owner,result,tmp_path/('accepted-'+str(len(states))))
        row['shell_stress_abs_max_Pa'] = max(float(np.max(np.abs(r.layer_stress))) for r in result.shell_q4_material)
        row['fibre_accumulated_max'] = float(np.max(state['beam']['accepted_fibres'][:,2:]))
        row['generalized_accumulated_max'] = float(np.max(state['beam']['accepted_accumulated']))
        history.append(row);states.append(state)
        (tmp_path/'activity.json').write_text(json.dumps(history,indent=2)+'\n',encoding='utf-8')
    (tmp_path/'programme.json').write_bytes(loads.serialize())
    record_property('raw_state_directory',str(tmp_path))
    result = owner.solve(loads,(.5,1.),increment_control=CONTROL,on_accepted=accepted,**OPTIONS)
    assert result.status == 'completed'
    assert max(r['equilibrium'] for r in history) <= 1e-8
    assert max(r['gap'] for r in history) <= 1e-9
    assert any(r['simultaneous'] for r in history), 'no actual accepted increment advanced both shell and fibres'
