"""Experimental two-stiffener J2/fibre panel; no engineering qualification.

One member uses physical axial/biaxial fibres, the other an elastic generalized
section. Six objective eccentric point bonds retain their six-channel identity.
The deliberately low strengths exercise history; they are not a steel design.
"""
from contextlib import ExitStack
import json
import math

import numpy as np
from anymaterial import DNVC208MaterialCurve
from anysolver import b3_ge, stiffened_shell as ss


OPTIONS = dict(max_iterations=20, max_backtracks=12)
CONTROL = ss.AdaptiveIncrementControl(4, 64)
ENDPOINT_FORCES_N = (500., 125., -250., 500.)  # each stiffener


def definition():
    e, nu = 210e9, .3
    g = e/(2.*(1.+nu))
    section = b3_ge.EllipsoidalGeneralizedSection(
        np.diag((e*.01, g*.008, g*.008, g*1.6666666666666667e-5,
                 e*8.333333333333333e-6, e*8.333333333333333e-6)),
        np.eye(6), 1e20, 1e9)
    arm = math.sqrt(8.333333333333333e-6/.01)
    fibres = tuple(b3_ge.Fibre(str(i), y*arm, z*arm, .0025, e,
        b3_ge.FlowCurve((0.,), (1e5 if i == 0 else 1e20,), 1e9))
        for i, (y, z) in enumerate(((-1,-1),(-1,1),(1,-1),(1,1))))
    physical = b3_ge.PhysicalFibreSection(fibres,
        np.diag(np.sqrt((0.,g*.008,g*.008,g*1.6666666666666667e-5,0.,0.))))
    beams = []
    points = []
    for family, y, first_node, first_element, shell_nodes in (
        (physical,-.5,101,1,(1,2,3)), (section,.5,201,3,(4,5,6))):
        xyz = np.array([(x,y,.1) for x in (0.,.5,1.,1.5,2.)])
        for i in range(2):
            beams.append(b3_ge.define_beam('b3-ge',first_element+i,
                tuple(first_node+2*i+j for j in range(3)),xyz[2*i:2*i+3],
                np.tile(np.eye(3),(3,1,1)),family,np.eye(6)))
        points.extend(ss.PointConnection(node,first_node+2*i)
                      for i,node in enumerate(shell_nodes))
    strength = 1e6
    curve = DNVC208MaterialCurve(strength,1.05*strength,1.1*strength,
                                .005,.01,4.*strength,.2)
    shell = ss.ShellPanel((1,2,3,4,5,6),
        ((0.,-.5,0.),(1.,-.5,0.),(2.,-.5,0.),
         (0.,.5,0.),(1.,.5,0.),(2.,.5,0.)),
        ((1,2,5,4),(2,3,6,5)),.07,e,nu,7850.,j2_curve=curve)
    return ss.LinearDefinition(ss.B3_GE_E4_PL_STIFFENED_SHELL_V1,
        shell,tuple(beams),tuple(points),
        tuple(ss.FixedCoordinate('shell',node,axis)
              for node in (1,4) for axis in range(6)),
        q4_pullback_policy=ss.Q4_ALGORITHMIC_PULLBACK_V1)


def programme(owner):
    return ss.StagedDeadLoadProgramme(owner.preflight()['identity'],tuple(
        tuple(ss.NodalAction('beam',node,(0.,0.,force,0.,0.,0.))
              for node in (105,205)) for force in ENDPOINT_FORCES_N))


def activity(result, previous=None):
    """Actual last accepted update, rather than cumulative yielding alone."""
    alpha = np.asarray(result.shell_layer_alpha)
    before = np.zeros_like(alpha) if previous is None else np.asarray(previous.shell_layer_alpha)
    delta = alpha-before
    budget = 64.*np.finfo(float).eps*np.maximum(np.abs(alpha),np.abs(before))
    assert np.all(delta >= -budget)
    fibre_increments = [math.fsum(f.plastic_increment)
        for station in result.beam_fibre_material for f in station.fibres]
    dissipation = [math.fsum(e.incremental_dissipation_j)
                   for e in result.beam_fibre_energy]
    assert all(math.isfinite(d) and d >= 0. for d in dissipation)
    shell_active = bool(np.any(delta > budget))
    fibre_active = any(value != 0. for value in fibre_increments)
    return dict(position=result.load_position,generation=result.generation,
        shell_alpha_max=float(np.max(alpha)),shell_active=shell_active,
        fibre_active=fibre_active,simultaneous=shell_active and fibre_active,
        fibre_plastic_increment_min=min(fibre_increments),
        fibre_plastic_increment_max=max(fibre_increments),
        last_increment_fibre_dissipation_J=math.fsum(dissipation),
        equilibrium=result.free_equilibrium_ratio,gap=result.constraint_max)


def main():
    with ExitStack() as resources:
        owner = ss.create_analysis(definition=definition())
        resources.callback(owner.close)
        loads = programme(owner)
        history, results = [], []
        def accepted(result):
            history.append(activity(result,results[-1] if results else None))
            results.append(result)
        owner.solve(loads,(.5,1.),increment_control=CONTROL,
                    on_accepted=accepted,**OPTIONS)
        assert any(row['simultaneous'] for row in history)
        saved = owner.checkpoint()
        resumed = ss.create_analysis(definition=definition())
        resources.callback(resumed.close)
        resumed.restore(saved)
        assert resumed.checkpoint() == saved
        result = owner.solve(loads,(2.,3.,4.),increment_control=CONTROL,
                             on_accepted=accepted,**OPTIONS)
        repeated = resumed.solve(loads,(2.,3.,4.),increment_control=CONTROL,**OPTIONS)
        assert result.status == repeated.status == 'completed'
        assert result.accepted_factors == repeated.accepted_factors
        assert owner.checkpoint() == resumed.checkpoint()
        assert max(row['equilibrium'] for row in history) <= 1e-8
        assert max(row['gap'] for row in history) <= 1e-9
        print(json.dumps(dict(status=result.status,qualified=False,
            member_families=owner.capabilities['beam_section_families'],
            stiffeners=2,beam_elements=4,shell_elements=2,history=history,
            restart_identical=True),allow_nan=False))


if __name__ == '__main__':
    main()
