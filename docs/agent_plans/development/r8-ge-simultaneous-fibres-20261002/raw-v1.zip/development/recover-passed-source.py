from pathlib import Path
import hashlib,json
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
p=repo/'tests/test_stiffened_shell_physical_fibre_j2_history.py'
s=p.read_text(encoding='utf-8')
s=s.replace('from anysolver import b3_ge, stiffened_shell as ss','from anysolver import stiffened_shell as ss')
s=s.replace('    generalized_rows=[i for i,(e,_,_) in enumerate(owner._beam_parts)\n                      if type(e.section) is not b3_ge.PhysicalFibreSection]\n    assert generalized_rows and np.any(result.cell_resultants[generalized_rows] != 0.)\n','')
a=s.index('    expected_keys=');b=s.index('    increments =',a);s=s[:a]+s[b:]
a=s.index('    energy_ids=');b=s.index('    for energy in result.beam_fibre_energy:',a);s=s[:a]+s[b:]
a=s.index("        for field in ('stored_energy_j'");b=s.index('        actual=',a);s=s[:a]+s[b:]
a=s.index('    with pytest.raises(ss.AdaptiveIncrementExhausted)');b=s.index('    token=CancellationToken()',a);s=s[:a]+s[b:]
a=s.index('    recovered=finite._fibre_recovery');b=s.index('    def cancel(value,stage):',a);s=s[:a]+s[b:]
s=s.replace("        patch.setattr(finite,'_fibre_recovery',capture_recovery)\n",'')
s=s.replace('    assert len(cancelled_candidates)==1\n','')
a=s.index("    assert np.any(before['q'][:chart._shell_count]");b=s.index("    assert before['exact_material']",a);s=s[:a]+s[b:]
selection=json.loads(Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/anysolver-portable-ci-1k8_62lh/P01/selection.json').read_text())
want=next(iter(selection['selected_file_sha256'].values()))
variants=(s.encode(),s.replace('\n','\r\n').encode())
data=next((d for d in variants if hashlib.sha256(d).hexdigest()==want),None)
assert data is not None,'passed source reconstruction mismatch; no snapshot accepted'
Path(__file__).with_name('source-passed-v2.py').write_bytes(data)
print('Prior passed test source recovered by exact registered SHA')
