from pathlib import Path
import sys,os,json,hashlib,importlib.util,shutil,zipfile
root=Path(__file__).parent;repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001');consumer=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer');fixtures=root/'fixtures'
solver_root=root.parent/'r8-native-retained-scale-installed-v1';consumer_root=root.parent/'r8-native-retained-scale-consumer-installed-v1';site=solver_root/'site';consumer_site=consumer_root/'site'
for name in ('scripts/r8_e04_native_roof.py','scripts/r8_e04_material_consumer.py','docs/reference_cases/stiffened_shell_e04_roof.py'):
 rel='/'.join(name.split('/')[1:]) if name.startswith('scripts/') else name;target=fixtures/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,target)
artifacts={}
for source,artifact_root,installed,package in ((repo,solver_root,site,'anysolver'),(consumer,consumer_root,consumer_site,'anyfem')):
 wheel=next((artifact_root/'wheels').glob('*.whl'));modules={}
 with zipfile.ZipFile(wheel) as z:
  for p in (source/'src'/package).rglob('*.py'):
   rel=p.relative_to(source/'src').as_posix();assert p.read_bytes()==z.read(rel)==(installed/rel).read_bytes(),rel;modules[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
 artifacts[package]=dict(wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),modules=modules)
artifacts['fixtures']={p.relative_to(fixtures).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in fixtures.rglob('*.py')};(root/'artifact.json').write_text(json.dumps(artifacts,indent=2))
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,(consumer_site,site,fixtures)))
common=['--size','4','--density','1','--seed-force','100','--radius','.003','--imperfection-m','.0001','--shell-proportional-limit-pa','3102750','--beam-resultant-limits','500,300,300,1,2,.5','--beam-hardening-n','25000']
if len(sys.argv)>1 and sys.argv[1]=='consumer':
 command=[sys.executable,'-u',str(fixtures/'r8_e04_material_consumer.py'),'--output',str(root/'project-path'),'--checkpoint',str(root/'material-path/accepted.bin'),'--steps','2',*common];label='consumer'
else:
 command=[sys.executable,'-u',str(fixtures/'r8_e04_native_roof.py'),'--output',str(root/'material-path'),'--steps','20','--restart-after','5',*common];label='roof'
r=s.supervised(command,root/label);print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
