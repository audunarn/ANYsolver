from pathlib import Path
import sys,json,importlib.util,hashlib
root=Path(__file__).parent;repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
if len(sys.argv)>1:
 from dataclasses import asdict,is_dataclass
 import numpy as np
 sys.path.insert(0,str(repo/'tests'))
 from anysolver import stiffened_shell as ss
 from anysolver._stiffened_shell_displacement_corrector import correct,DisplacementCorrectorFailure
 from anysolver._stiffened_shell_branch_event_trial import POLICY
 from anysolver._stiffened_shell_ge_finite_experimental import _material_arrays,_shell_material_arrays
 from test_stiffened_shell_bl5_coupled_material import coupled
 owner=ss.create_analysis(definition=coupled())
 saved=(root.parent/'r8-displacement-branch-v1/step-1.bin').read_bytes();owner.restore(saved)
 _,m,a=owner._displacement_snapshot;records=[]
 try:
  trial=correct(owner._finite_driver,base_load=a['base_load'],load_direction=a['load_direction'],amplitude=float(a['history'][-1,1]),control_dof=m['control_dof'],target=-68e-6,max_iterations=20,max_backtracks=12,trial_policy=POLICY,event_records=records)
 except DisplacementCorrectorFailure as error:
  result=dict(status='failed',message=str(error),detail=asdict(error.detail))
 else:
  state=trial.state
  bp,ba=_material_arrays(trial.evaluation[5]);sp,sa=_shell_material_arrays(trial.evaluation[4])
  np.savez_compressed(root/'trial.npz',q=state.q,frames=state.frames,cells=state.cells,resultants=state.resultants,multipliers=state.multipliers,shell_anchors=state.shell_anchors,beam_plastic=bp,beam_alpha=ba,shell_plastic=sp,shell_alpha=sa)
  result=dict(status='uncommitted_equilibrium',amplitude=trial.amplitude,load=float(a['base_load'][m['control_dof']]+trial.amplitude*a['load_direction'][m['control_dof']]),equilibrium=float(trial.evaluation[2]),gap=float(trial.evaluation[3]),iterations=trial.iterations,evaluations=trial.evaluations,linear_solves=trial.linear_solves,rejections=trial.rejected_trials)
 assert owner.checkpoint()==saved
 result.update(seed_sha256=hashlib.sha256(saved).hexdigest(),policy=POLICY,prefix_unchanged=True,event_cell_evaluations=sum(row['cell_evaluations'] for row in records),events=records)
 def encode(value):
  if is_dataclass(value):return asdict(value)
  raise TypeError(type(value).__name__)
 (root/'result.json').write_text(json.dumps(result,default=encode,indent=2))
 print(json.dumps({k:v for k,v in result.items() if k!='events'}));owner.close()
else:
 spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV['PYTHONPATH']=str(repo/'src');s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
 result=s.supervised([sys.executable,str(Path(__file__)),'child'],root/'run-v1')
 print(json.dumps({k:result[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
