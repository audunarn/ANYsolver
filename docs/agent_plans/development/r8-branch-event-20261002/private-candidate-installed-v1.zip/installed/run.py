from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,zipfile
root=Path(__file__).parent;repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001');site=root/'site';fixtures=root/'fixtures'
def digest(b):return hashlib.sha256(b).hexdigest()
if len(sys.argv)>1 and sys.argv[1]=='prepare':
    fixtures.mkdir();(fixtures/'examples').mkdir();(fixtures/'examples/__init__.py').write_text('')
    copies={n:repo/'tests'/n for n in ('test_ge_beam3_branch_direction.py','test_stiffened_shell_displacement_adaptive.py','test_stiffened_shell_displacement_increment.py','test_stiffened_shell_displacement_public.py','test_stiffened_shell_displacement_checkpoint.py','test_stiffened_shell_displacement_corrector.py','test_stiffened_shell_bl5_coupled_material.py','test_stiffened_shell_bl5_material.py','test_stiffened_shell_bl5_staged_loads.py','test_stiffened_shell_bl5_finite.py','test_stiffened_shell_l1_assembly_experimental.py','test_stiffened_shell_ge_finite_experimental.py','test_stiffened_shell_ge_experimental.py')}
    import ast
    pending=list(copies.values());seen=set()
    while pending:
        source=pending.pop()
        if source in seen:continue
        seen.add(source)
        for node in ast.walk(ast.parse(source.read_text(encoding="utf-8-sig"))):
            if not isinstance(node,ast.ImportFrom) or not node.module:continue
            module=node.module
            dependency=(repo/'tests'/(module+'.py') if module.startswith('test_') else
                        repo/Path(*module.split('.')).with_suffix('.py') if module.startswith('docs.') else None)
            if dependency is not None and dependency.exists():pending.append(dependency)
    for source in seen:
        target=source.name if source.parent==repo/'tests' else source.relative_to(repo).as_posix()
        copies[target]=source
    for target,source in copies.items():
        destination=fixtures/target;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(source.read_bytes())
    (fixtures/'docs/__init__.py').write_text('')
    (fixtures/'docs/reference_cases/__init__.py').write_text('')

    for name,args in [('build',['wheel','--no-cache-dir','--no-deps','--no-build-isolation','--no-index','--wheel-dir',str(root/'wheels'),str(repo)]),('install',None)]:
        if args is None:args=['install','--no-cache-dir','--no-deps','--no-index','--target',str(site),str(next((root/'wheels').glob('*.whl')))]
        with (root/(name+'.log')).open('w') as log:subprocess.run([sys.executable,'-m','pip',*args],stdout=log,stderr=subprocess.STDOUT,check=True)
    wheel=next((root/'wheels').glob('*.whl'));modules={}
    with zipfile.ZipFile(wheel) as archive:
        for source in (repo/'src/anysolver').rglob('*.py'):
            relative=source.relative_to(repo/'src').as_posix();b=source.read_bytes()
            assert b==archive.read(relative)==(site/relative).read_bytes(),relative
            modules[relative]=digest(b)
    (root/'artifact.json').write_text(json.dumps(dict(wheel=wheel.name,wheel_sha256=digest(wheel.read_bytes()),modules=modules,fixtures={n:digest((fixtures/n).read_bytes()) for n in copies}),indent=2))
    print(json.dumps(dict(modules=len(modules),wheel_sha256=digest(wheel.read_bytes()))))
elif len(sys.argv)>1:
    sys.path.insert(0,str(fixtures))
    import anysolver,numba,threadpoolctl,pytest
    assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
    code=pytest.main(['-q','-s','-p','no:cacheprovider','--junitxml=result.xml',*[str(fixtures/n) for n in ('test_ge_beam3_branch_direction.py','test_stiffened_shell_displacement_corrector.py','test_event_candidate.py')]])
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith('anysolver') and getattr(m,'__file__',None)}
    assert all(Path(p).is_relative_to(site.resolve()) for p in imports.values())
    pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    (Path.cwd()/'runtime.json').write_text(json.dumps(dict(imports=imports,pools=pools,python=sys.version,jit_disabled=bool(numba.config.DISABLE_JIT)),indent=2))
    raise SystemExit(code)
else:
    spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
    s.ENV['PYTHONPATH']=str(site);s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
    result=s.supervised([sys.executable,str(Path(__file__)),'child'],root/'test-v2')
    print(json.dumps({k:result[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
