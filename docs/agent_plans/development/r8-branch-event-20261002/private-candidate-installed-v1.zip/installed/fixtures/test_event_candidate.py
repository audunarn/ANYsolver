from pathlib import Path
import numpy as np
from anysolver import stiffened_shell as ss
from anysolver._stiffened_shell_displacement_corrector import correct
from anysolver._stiffened_shell_branch_event_trial import POLICY
from test_stiffened_shell_bl5_coupled_material import coupled

def test_installed_private_candidate(request):
    owner=ss.create_analysis(definition=coupled());request.addfinalizer(owner.close)
    seed=Path(__file__).with_name("branch-seed.bin").read_bytes();owner.restore(seed)
    _,metadata,a=owner._displacement_snapshot;records=[]
    trial=correct(owner._finite_driver,base_load=a["base_load"],load_direction=a["load_direction"],
        amplitude=float(a["history"][-1,1]),control_dof=metadata["control_dof"],target=-68e-6,
        max_iterations=20,max_backtracks=12,trial_policy=POLICY,event_records=records)
    assert trial.evaluation[2]<=1e-8 and trial.evaluation[3]<=1e-9
    assert abs(trial.state.q[metadata["control_dof"]]+68e-6)<1e-12
    np.testing.assert_allclose(trial.amplitude,.173832744974511,rtol=1e-10,atol=1e-12)
    assert sum(row["cell_evaluations"] for row in records)>0
    assert owner.checkpoint()==seed
