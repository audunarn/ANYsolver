# B3-GE / E4-PL / B2 — active state, 2 October 2026

## Authority and current checkout

Full Revision8 goal/plan in ../b3-ge-e4-pl-coupling/docs/agent_plans remains active.
No aggregate G0–G6/M1–M5 acceptance. Use the [acceptance matrix](B3_GE_E4_PL_REVISION_8_ACCEPTANCE_MATRIX.md).
Risk-proportionate/tiered checks, scientific tolerances and protected evidence remain.
Prior active note preserved byte-for-byte [here](development/r8-bl5-staged-loads-20261002/active-before-staged-lines.md).

Solver C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001,
branch codex/stiffened-main-reconcile-20261001; solver source58286d90; consumer evidence update follows. ANYfem C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer,
branch codex/experimental-ge-panel-consumer, HEAD330cb22; distributed consumer slice committed.
Local commits permitted; no push/main merge/publication or contact-worker messaging.
Historical archive contains credentials: no dissemination before authorized remediation.
No numerical job live. At most3workers/one heavy numerical job;100krows/600s/8GiB/
8numerical threads ceiling. Current checks600s/1GiB/1thread/JITdisabled.
Local/Mistral unavailable earlier; no repeated probes. OpenAI review is not
cross-family qualification. Formal F03 UNCONSUMED; protected original script SHA
c908b1f3e4d9467deb3a96876126d5488cd040503cc6c6ec485b8aeaecef9481.

## Delivered behavior

GE/B2 installed owner/consumer, materials, gravity and signed distributed-load
histories remain as linked in the matrix. Local0888da71 adds signed couple/material
history evidence;14c5d0eb records the rejected U1 shear-comparator route.

Current slice admits explicit objective-Q4 elastic BL5 with staged nodal translation
forces. Both P0/coarseP1 pass signed stages/cancellation/restart/balance; P0 adds
adaptive/chart restart. Installed wheel d506e3f3...14be90 has398matching modules,
219onsite imports and3passing new checks. Five focused compatibility checks pass;
independent source/evidence review found no consequential issue. Historical line
moment failures and test-helper failures preserved. No acceptance or release claim.
[Complete slice evidence](development/r8-bl5-staged-loads-20261002/results.md).
Public examples/stiffened_shell_bl5_staged.py now constructs and runs this path
without test imports. Source/installed lifecycle passes on the same verified wheel;
four historical/objective P0/P1 reference-parity cases pass. No new solver equation.

## Decision, uncertainty and next action

Retain BL5 experimentally. Common-action/root/completion checks do not identify a
law defect; remaining clamp-transfer reference error is not bounded sufficiently
for1% physical acceptance. U1 canary is11.1423% too stiff in isolated tip-force
compliance at its actual discretization. Do not build a corrected U1 coupled
reference or automatically repeat refinement/completion tests. Missing controlled
coupled reference remains an M2/F03 obligation, not grounds for acceptance/failure.

ANYfem BL5 objective/staged inputs and distinct native Project route are delivered:
49 source and70 installed checks pass, including cancellation/chart/restart.
[Consumer evidence](development/r8-anyfem-bl5-project-20261002/results.md).
Distributed BL5 consumer persistence is now delivered:17 source and53 installed
checks pass; independent review clear.
[Consumer load evidence](development/r8-anyfem-bl5-distributed-20261002/results.md).
Next: assess the missing line material-history integration against the existing
algorithmic Q4 and native material owner. Preserve elastic admission until actual
yielded-trial, rejection and restart checks justify a distinct extension. Line materials/S3 remain excluded. Native distributed BL5 loading now passes
source and 11 installed checks, including signed stages, work, chart restart and
a mixed point/line layout. Review clear within bounded experimental scope.
[Distributed integration evidence](development/r8-bl5-distributed-20261002/results.md).
All final topology/material/stability/capacity/scale/external/platform obligations
remain mandatory. Do not repeat closed B2 or spectral campaigns without a discriminator.

Pressure vector-assessment amendment remains awaiting user decision. Mixed follower
and mixed/all-S3 director finite histories fail current component checks; private
overrides are counterfactual only. No criteria change authorized. Zero-total-load
relative assessment remains unresolved; no silent floor or tiny-load relaxation.
[Pressure boundary](development/r8-ge-pressure-work-20261002/s3-director-integration.md).


Current material slice: distinct opt-in generalized yielding with elastic Q4 BL5;
new binary/chart schema retains accepted and predecessor history. Review repaired
pre-yield restoration and added rebase history checks. Fixed/adaptive low-yield
cases failed backtracking/cutback (preserved). Bounded diagnostic shows first trial
free residual50 N ->0.062 N but component merit1 ->8364; actual-update tangent
errors reach2.0e-13. Next discriminator reuses existing work-scaled trial comparison
for this new opt-in only, preserving final component/compatibility acceptance.
A failure of final acceptance remains a failure; no pressure amendment or tolerance
change. Retain product only after yielded lifecycle/tangent/installed checks pass.

Work-scaled trial comparison and12-backtrack control did not resolve the low-
hardening case; trial-comparison product change removed. Linear systems solve
accurately; Newton-direction derivative plateau is branch-sensitive near first
yield. Next single control uses the existing generalized-history fixture's1e8
hardening rather than1e6, holding geometry/loads/yield threshold fixed. This
separates a severe-softening/mixed-merit obstruction from all material line
integration. Original cases stay failed; no domain-wide acceptance follows.
