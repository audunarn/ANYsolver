from pathlib import Path
import sys,importlib.util,json,os
root=Path(__file__).parent
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
if len(sys.argv)>1:
 sys.path[:0]=[str(repo/'src'),str(repo/'tests')]
 import numpy as np
 from dataclasses import asdict
 from test_stiffened_shell_bl5_material import model
 from test_stiffened_shell_bl5_finite import _action
 from anysolver import stiffened_shell as ss
 from anysolver._stiffened_shell_ge_finite_experimental import FinitePointDriver
 a=ss.create_analysis(definition=model(hardening=1e8));driver=FinitePointDriver(a)
 pattern,_=driver._prepare_load(_action(),(.5,))
 original=driver._assemble;records=[];last=[]
 def tracked(state,factor,shell,beam,**kwargs):
  out=original(state,factor,shell,beam,**kwargs)
  records.append(dict(factor=factor,relative=out[2],gap=out[3],residual=float(np.linalg.norm(out[0][a._free])),yielded=max(v for h in out[5] for t in h.stations for v in t.accumulated)))
  last[:]=[state,factor,shell,beam,kwargs,out]
  return out
 driver._assemble=tracked
 try:driver.solve(_action(),(.5,),max_iterations=20,max_backtracks=12)
 except Exception as e:failure=dict(type=type(e).__name__,message=str(e))
 else:failure=None
 state,factor,shell,beam,kw,out=last
 from scipy.sparse.linalg import spsolve
 free=np.r_[a._free,np.arange(a._K.shape[0],len(out[0]))]
 direction=np.zeros(len(out[0]));direction[free]=spsolve(out[1][free,:][:,free],-out[0][free])
 weights=np.r_[a._coordinate_scale,np.ones(a._C.shape[0])]
 expected=out[1]@direction
 errors=[]
 for h in (1e-3,1e-4,1e-5,1e-6):
  minus=original(driver._advance(state,direction,-h),factor,shell,beam,**kw)[0]
  plus=original(driver._advance(state,direction,h),factor,shell,beam,**kw)[0]
  errors.append(dict(h=h,relative=float(np.linalg.norm(((plus-minus)/(2*h)-expected)[free]*weights[free])/max(np.linalg.norm(expected[free]*weights[free]),1.))))
 indices=np.argsort(np.abs(out[0][:a._K.shape[0]]*a._coordinate_scale))[-8:]
 details=[dict(row=int(i),residual=float(out[0][i]),scale=float(a._coordinate_scale[i])) for i in indices]
 print(json.dumps(dict(newton_linear_residual=float(np.linalg.norm((expected+out[0])[free])),worst_rows=details)))
 Path('diagnostic.json').write_text(json.dumps(dict(failure=failure,evaluations=records,directional_errors=errors),indent=2))
 print(json.dumps(dict(failure=failure,last=records[-1],directional_errors=errors)))
 a.close()
else:
 spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV['PYTHONPATH']=str(repo/'src');s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
 result=s.supervised([sys.executable,str(Path(__file__)),'child'],root/'run-v1')
 print(json.dumps({k:result[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
