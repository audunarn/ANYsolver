from pathlib import Path
import sys,importlib.util,json
r=Path(__file__).parent
spec=importlib.util.spec_from_file_location('supervisor',r.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=str(r/'site')+';'+str(r/'fixtures');s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
v=s.supervised([sys.executable,'-m','pytest','-q','-p','no:cacheprovider',str(r/'supplement/test_stiffened_shell_displacement_checkpoint.py')+'::test_event_snapshot_zero_work_identity_and_strict_fields'],r/'supplement-result')
print(json.dumps({k:v[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
