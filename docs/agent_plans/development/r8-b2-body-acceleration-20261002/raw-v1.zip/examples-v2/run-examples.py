from pathlib import Path
import importlib.util, json, os, sys
root = Path(__file__).resolve().parent
supervisor = Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-panel-resolution-installed-v1/matched-run.py')
spec=importlib.util.spec_from_file_location('bounded',supervisor)
service=importlib.util.module_from_spec(spec);spec.loader.exec_module(service)
site=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-body-load-installed-v1/solver-artifact/site')
service.ENV.update(PYTHONPATH=str(site),PYTHONNOUSERSITE='1')
for mesh in ('q4','mixed','s3'):
    service.supervised([sys.executable,str(root/'body-example.py'),'--mesh',mesh],root/mesh)
    result=json.loads((root/mesh/'stdout.log').read_text())
    assert all(x['cases']==n and x['status']=='completed' and x['factorization_count']==1
               for x,n in zip(result['batches'],(1,10,100)))
print(json.dumps(dict(completed=['q4','mixed','s3'],example_sha256=service.sha(root/'body-example.py'),
    wheel=json.loads((site.parents[1]/'solver-wheel-identity.json').read_text()))))
