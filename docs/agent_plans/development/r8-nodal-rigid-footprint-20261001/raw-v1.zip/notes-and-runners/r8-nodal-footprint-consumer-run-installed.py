from pathlib import Path
import hashlib,json,sys,zipfile,xml.etree.ElementTree as ET
from importlib import metadata
import numpy as np,numba,pytest,threadpoolctl

r=Path.cwd();site=(r/'site').resolve();label=sys.argv[1]
manifest=json.loads((r/'prepared-manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={'anysolver':Path(r'C:/Github/ANYsolver/.perf2-worktrees/b3-ge-e4-pl-coupling/src/anysolver'),
        'anyfem':Path(r'C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer/src/anyfem')}
wheels={}
for name,files in manifest['modules'].items():
    wheel=next((r/'wheels').glob(name+'-*.whl'));wheels[wheel.name]=sha(wheel)
    with zipfile.ZipFile(wheel) as z:
        assert {p for p in z.namelist() if p.startswith(name+'/') and p.endswith('.py')}==set(files)
        for key,h in files.items():
            src=source[name]/key.split('/',1)[1]
            assert src.read_bytes()==z.read(key)==(site/key).read_bytes() and sha(src)==h
for name,h in manifest['fixtures'].items():assert sha(r/'fixtures'/name)==h
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
(r/(label+'-identity.json')).write_text(json.dumps({'modules':{k:len(v) for k,v in manifest['modules'].items()},'wheels':wheels,
    'python':sys.version,'threads':pools,'jit_disabled':True,'numba_threads':1,'dependencies':{n:metadata.version(n) for n in
    ('ANYsolver','ANYfem','numpy','scipy','numba','pytest','ANYmaterial','ANYmesher','ANYfileio')}},indent=2))
targets=[str(r/'fixtures'/v.split('::')[0])+('::'+v.split('::',1)[1] if '::' in v else '') for v in sys.argv[2:]]
code=pytest.main(['-q','-c',str(r/'pytest.ini'),'--basetemp='+str(r/(label+'-states')),'--junitxml='+str(r/(label+'-inventory.xml')),*targets])
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0] in ('anysolver','anyfem') and getattr(m,'__file__',None)}
(r/(label+'-imports.json')).write_text(json.dumps(imports,indent=2));assert all(Path(p).is_relative_to(site) for p in imports.values())
assert numba.get_num_threads()==1 and all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
cases=ET.parse(r/(label+'-inventory.xml')).findall('.//testcase');counts={k:sum(c.find(k) is not None for c in cases) for k in ('failure','error','skipped')}
(r/(label+'-verification.json')).write_text(json.dumps({'cases':len(cases),'counts':counts,'exit_code':code,'onsite_imports':len(imports)},indent=2))
print(json.dumps({'cases':len(cases),'counts':counts,'onsite_imports':len(imports),'label':label}),flush=True)
sys.exit(code if code else (1 if any(counts.values()) else 0))
