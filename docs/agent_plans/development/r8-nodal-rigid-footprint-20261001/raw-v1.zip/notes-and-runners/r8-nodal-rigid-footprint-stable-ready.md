# Nodal-footprint stable-S3 handoff (source only)

Ready for independent source review and root-coordinated installed execution. No numerical jobs/imports/build/Git mutation were performed by this worker. Prior fixture failures/diagnosis and initial hashes remain preserved.

The original selected-node six-row pose law is unchanged. New elastic generalized-beam footprints containing S3 opt into the existing cancellation-resistant S3 translation calculation under explicit model/preflight/capability policy `GE_NODAL_RIGID_FOOTPRINT_ELASTIC_S3_STABLE_NATIVE_HISTORY_V1`. Complete origin and accepted compensated generalized histories use the existing V9 native-history framing, including explicit empty fibre arrays. No checkpoint codec, mechanics, load scope, Newton/line-search budgets or tolerance changed. Pure Q4 footprint identity remains as before this extension; ALL empty-footprint identities/default arithmetic/checkpoint eligibility remain unchanged, and existing fibre S3 eligibility stays intact.

New footprint+weak-line combinations reject before execution as point-owner-only scope. Footprint shell J2/fibre declarations remain unsupported. Candidate and restored origin/accepted histories reject every nonzero plastic high/low or accumulated pair before publication. Correct byte digests are not mechanical admission.

Prepared tests include loaded mixed/all-S3 full assembled derivatives through `_advance/_assemble` in accepted ordinary and rebased charts, nonzero multipliers, fixed same predecessors and all physical/retained/constraint row roles; existing 1e-6 derivative budget is retained. New V9 tests cover exact generalized histories/empty-fibre layout, fresh restore byte parity, valid-digest corrupt origin/accepted paired histories, missing layout, wrong numerical policy and provisional pre-policy group identity with accepted-prefix atomicity. Early and controller-publish cancellation plus both plastic-only/accumulated-only candidate rejection now include Q4, mixed and all-S3 fixtures. Explicit footprint/weak-line admission negative added. Finite footprint load remains Fz10N only, factors .25/.5/1, max_iterations20/backtracks12. Reference-linear direct-couple and local nonzero-lambda work/derivative checks remain unchanged.

Retained resultants are six force coordinates plus twelve moment coordinates, NOT three recovered station wrenches: `_ge_beam3_generalized_cell.py` p[:6]/p[6:] is authoritative. Existing successor 10NÃ—6/20NmÃ—12 comparison (1e-9) and new complementary-row scales retain this packing. A provisional misinterpretation of `_reference_scales` was reversed before execution.

Root execution route: new footprint test (44 collected cases by static decorator inventory), impacted point-recovery test, unchanged stable-S3 subspacing/complete-finite-chart tests, relevant finite/generalized/fibre/checkpoint/rebase tests, headless reference and finite Q4 example, and identical isolated old/new empty-footprint oracle using already preserved old-wheel outputs. Source ASTs parsed successfully only; runtime success is unmeasured. New wheel is required: current installed footprint V1 wheel does not contain this stable-policy extension. Root independently decides installed scopes/resources and obtains mechanics review.

Limitations: explicit experimental selected-node/complete-selected-patch policy only; elastic-response-only generalized beams; no arbitrary continuous footprint/distributing/weld/offnode/plastic/combined weak-line admission or F04/M4 qualification claim. No broad numerical-stability claim from this new eligibility.

Files/hashes:

- src/anysolver/_stiffened_shell_ge_experimental.py: `f89031afe5c44e793d40a20573713e3415962aef15faccf9f37413234932ec84`
- src/anysolver/_stiffened_shell_ge_finite_experimental.py: `55e7e2b0587918bc6b4523d284acd56a2649448440dbc5b55a3d029600b7a320`
- src/anysolver/_stiffened_shell_nodal_footprint.py: `bb585f03245718e6a03b62a4ce9e6c812badfad3a465ffbf38f23e00e2c16767`
- src/anysolver/_stiffened_shell_point_recovery.py: `beb3a5309dbd2099560ca343f2fece7b41b80e3da09d91ebf35d1188a8636f6b`
- src/anysolver/stiffened_shell.py: `5704d6196b27127e23284cd0f23c7098e3ebdf55543b9219649b068e54eef40d`
- tests/test_stiffened_shell_nodal_rigid_footprint.py: `c6dc823c87269845399c2181f4817c9da0447c84f86c023f5753221501163cac`
- tests/test_stiffened_shell_point_recovery.py: `2eb554e904f0408702cbe182bf0d4d3303a6a0264e1a1b99a5c45b5eaf24be03`
- examples/stiffened_shell_nodal_rigid_footprint.py: `1026dcbe85d899ae0cfbb1a8d1e08f04ba15787ef252ce25bd28bc9b34799b02`

Pre-execution review correction: every valid-digest corrupt schema/layout/model/history payload is restored into its own fresh compatible owner. Rejection must preserve generation0/no accepted result/no published finite driver; original source accepted checkpoint/result remains exact. Thus the negative predicates reach the intended mechanics/schema validation instead of the existing accepted-owner lifecycle guard. No runtime code, criteria or input changed.
