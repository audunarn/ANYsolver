from pathlib import Path
from importlib import metadata
import hashlib,json,runpy,sys

target=Path(sys.argv[1]).resolve();site=Path(sys.argv[2]).resolve()
sys.argv=[str(target),'outputs'];runpy.run_path(str(target),run_name='__main__')
import anysolver,anyfem,numba,threadpoolctl
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0] in ('anysolver','anyfem') and getattr(m,'__file__',None)}
assert imports and all(Path(p).is_relative_to(site) for p in imports.values())
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
Path('imports.json').write_text(json.dumps(imports,indent=2))
Path('runtime-identity.json').write_text(json.dumps({'example_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
    'example_path':str(target),'site':str(site),'python':sys.version,'threads':pools,'jit_disabled':True,'numba_threads':1,
    'versions':{n:metadata.version(n) for n in ('ANYsolver','ANYfem','numpy','scipy','numba','ANYmaterial','ANYmesher','ANYfileio')}},indent=2))
print(json.dumps({'onsite_imports':len(imports),'verified_numerical_threads':1,'jit_disabled':True}))
