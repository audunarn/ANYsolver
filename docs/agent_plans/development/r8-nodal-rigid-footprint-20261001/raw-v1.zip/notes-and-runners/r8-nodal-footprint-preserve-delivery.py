from pathlib import Path
import hashlib,json,zipfile,sys

root=Path(r'C:/Users/AUDUNA~1/AppData/Local/Temp')
out=root/'r8-nodal-footprint-delivery-evidence-v1.zip'
assert not out.exists()
sources={}
def add(p,key):
    if p.is_file():
        assert key not in sources, key
        sources[key]=p
def tree(name):
    base=root/name
    assert base.is_dir(),base
    for p in sorted(base.rglob('*')):
        relative=p.relative_to(base)
        if any(v in ('site','build-source','__pycache__','.pytest_cache') for v in relative.parts):continue
        if p.suffix in ('.pyc','.nbc','.nbi'):continue
        add(p,name+'/'+relative.as_posix())
    if (base/'build-source').exists():
        for n in ('_stiffened_shell_ge_experimental.py','_stiffened_shell_ge_finite_experimental.py',
                  '_stiffened_shell_nodal_footprint.py','_stiffened_shell_point_recovery.py','stiffened_shell.py'):
            add(base/'build-source'/'src'/'anysolver'/n,name+'/runtime-source/anysolver/'+n)
        for n in ('stiffened_shell.py','stiffened_shell_project.py'):
            add(base/'build-source'/'src'/'anyfem'/'solve'/n,name+'/runtime-source/anyfem/solve/'+n)

for name in ('r8-nodal-footprint-installed-stable-v1','r8-nodal-footprint-installed-unrebased-v1',
             'r8-nodal-footprint-successor-diagnostic-v1','r8-nodal-footprint-unrebased-legacy-v1',
             'r8-nodal-footprint-unrebased-example-linear-v1','r8-nodal-footprint-unrebased-example-finite-v1',
             'r8-nodal-footprint-pre-scale-prepared-v1','r8-nodal-footprint-pre-rebase-park-prepared-v1',
             'r8-nodal-footprint-consumer-installed-v1','r8-nodal-footprint-consumer-example-installed-v1'):
    tree(name)
for pattern in ('r8-nodal*.md','r8-nodal*.json','r8-nodal*.py','r8-prepare-nodal*.py'):
    for p in sorted(root.glob(pattern)):add(p,'notes-and-runners/'+p.name)
for name in ('r8-nodal-footprint-preparation-v1.zip',):add(root/name,'prior-phase/'+name)
manifest={k:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,
             'original_path':str(p.resolve())} for k,p in sorted(sources.items())}
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for key,p in sorted(sources.items()):z.write(p,key)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(out) as z:
    for key,value in manifest.items():assert hashlib.sha256(z.read(key)).hexdigest()==value['sha256'],key
identity={'files':len(manifest),'raw_bytes':sum(v['bytes'] for v in manifest.values()),
          'archive_bytes':out.stat().st_size,'archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
          'scope':'development artifact/source/runner/fixture/raw outputs/reviews; mandatory qualification remains open'}
(root/'r8-nodal-footprint-delivery-evidence-v1-identity.json').write_text(json.dumps(identity,indent=2))
print(json.dumps(identity))
