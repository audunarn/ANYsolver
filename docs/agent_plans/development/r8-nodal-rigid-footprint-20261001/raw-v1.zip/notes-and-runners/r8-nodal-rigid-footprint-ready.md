# Nodal rigid-footprint bounded source handoff

Ready for independent review and root-coordinated installed checks. No product/fixture imports, tests, solves or wheel builds were run by this worker. Standard-library AST parsing passed for all owned files. Finite solver AST differs only in `_assemble`, adding the precommit generalized elastic-response guard. The new footprint module depends on point recovery (which does not import it), so the layer has no new import cycle.

Immutable `NodalRigidFootprint(id,nodes,beam_node,patch_cells=())` compiles original point incidence first, then ordered group nodes. It directly inherits the existing six-channel objective point pose work; normal spin is locked. Whole-cell patch declaration is an explicit connected/canonical-edge coverage policy, not a mathematical iff. Three selected nodes alone do not constrain an omitted Q4 corner. Full-map Q4 must be explicitly selected; all-S3 uses its existing objective route. New footprints reject J2/fibre declarations; generalized yielding candidates fail before commit. This does not inherit point material qualification or qualify a weld, distributing area law or BL5.

`recover()` retains the existing accepted result and original no-accepted error. Optional typed `NodalRigidFootprintSelection` returns immutable `NodalRigidFootprintWrench` records. Common origin is explicitly the accepted beam port (reference/current configuration, with low part). Group sums use the actual published exerted actions, retain every direct couple and per-node full action/gap, and keep low lever-arm products separate through final `fsum`. Nonfinite grouped resultants reject. No mechanics replay, raw-lambda moment substitution or generic result fields were added.

Empty-footprint model identity/preflight/capabilities/checkpoint meanings remain unchanged. New law/group/membership/station metadata binds nonempty identities. Private `_point_incidence` is authoritative for reference and finite recovery. The two isolated point-recovery test namespaces now provide that compiled incidence explicitly; no fallback or mechanics assertion was weakened.

## Source freeze hashes

- `src/anysolver/_stiffened_shell_ge_experimental.py` `d8ec364c99e53ffa2e82f43d19fe1ac27b9798c6b60022df1ae7c463650ba353`.
- `src/anysolver/_stiffened_shell_nodal_footprint.py` `3dfc289734a497ca8583107dd4e2ee3dab3ce5b29dd23a45337c6f57b3b7a73f`.
- `src/anysolver/_stiffened_shell_point_recovery.py` `beb3a5309dbd2099560ca343f2fece7b41b80e3da09d91ebf35d1188a8636f6b`.
- `src/anysolver/_stiffened_shell_ge_finite_experimental.py` `feb26232041529d37602032e01cd8f13710174d32045ba7af8a52c3fa2f9dc01`.
- `src/anysolver/stiffened_shell.py` `5704d6196b27127e23284cd0f23c7098e3ebdf55543b9219649b068e54eef40d`.
- `tests/test_stiffened_shell_nodal_rigid_footprint.py` `0e7fece83514a26e85b43bba8b894ab3d623bfbfd6f28dba8ea64c37263caf9f`.
- `tests/test_stiffened_shell_point_recovery.py` `2eb554e904f0408702cbe182bf0d4d3303a6a0264e1a1b99a5c45b5eaf24be03`.

Prepared headless example `TEMP/r8-nodal-rigid-footprint-example.py` SHA `bfd5acebd04796167dca8410a10bf37ac7104bb1858f7fa2239732496834af23` must be copied exactly to new `examples/stiffened_shell_nodal_rigid_footprint.py`. `apply_patch` could not create the missing examples parent directory under the current worktree permission layout; no ACL/escalation was attempted. The example has public construction, reference/finite (--finite) solve, selected physical recovery and fresh-owner checkpoint restore. Root owns the normal integration copy.

## Coordinated installed checks needed

New test file has 14 test functions /36 statically enumerated cases, unexecuted: complete Q4/mixed/pure-S3 rigid fields and zero objective deformation; independent reference rows and explicit-pair small assembly oracle; nonzero-multiplier actual-left-update derivative/work plateau; physical eccentric group balance and restore/rebase/continuation; both early and late checkpoint-prepared cancellation plus injected yielded-candidate atomicity; ownership, grouping/station/legacy-checkpoint mismatch; duplicate/unknown/collinear/unsupported material/supported-rank errors; complete-patch connectivity, diagonal-sharing negative, low-arm1Nm and overflow controls. Test force/moment/length scales are explicitly10N/20Nm/2m and existing criteria are retained; failures must be preserved rather than retuning loads or tolerances.

Companion fixture modules: `test_stiffened_shell_ge_experimental.py`, `test_stiffened_shell_ge_finite_experimental.py`, `test_stiffened_shell_ge_physical_fibre_finite.py` and that file's existing physical-fibre linear fixture dependency. Run new footprint tests, changed point-recovery tests and directly impacted existing GE reference/finite/Q4-map/staged/observer/checkpoint tests against the newly built wheel. Verify canonical on-site imports, all installed/source bytes and1effective BLAS/Numba/JIT disabled in the actual target process. The new private module makes the solver module inventory389 rather than the old388; no old-site import count is claimed for new code. Run the headless example in reference and finite modes.

Exact independent old/new empty-footprint baseline is required in addition to the in-tree old-schema test: root has already saved old-wheel historical reference-linear+finite(.5,1) default/restored trees, capabilities/model identity and checkpoint bytes in `TEMP/r8-nodal-footprint-legacy-old-v1/outputs` using old wheel0c456666... . Execute the identical isolated helper against the new wheel and compare those arrays/trees/checkpoint bytes exactly. Do not call new-vs-new default/empty parity an old-wheel oracle. Root owns this execution and independent evidence review.

No scientific acceptance, aggregate F04/M4 closure, production qualification, consumer footprint persistence, release or Git mutation is claimed.
