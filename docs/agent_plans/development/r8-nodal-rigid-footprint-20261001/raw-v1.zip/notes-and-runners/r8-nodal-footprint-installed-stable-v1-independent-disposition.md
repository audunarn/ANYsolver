# Installed stable-footprint V1: independent failure disposition

2026-10-01. Bounded read-only inspection of the frozen test/source, installed identity, execution record, pytest log and XML. No numerical jobs or source edits. The separate final integrated source review remains unchanged.

The installed 46-case suite reports 43 passed and 3 failed. Wheel SHA256 is `d9b409dc603361eefa757b4822da217f6e828fd492256572669d1d799194b350`; the recorded matching module count is 389 and footprint fixture SHA256 is `c1cf0d00f7d57c030bbb2c8fc63560d5c8b38a6ef1230a40360dd571e2d03ca0`, matching the independently reviewed source. NumPy/SciPy OpenBLAS pools each report one thread; Numba reports one and JIT disabled. Supervisor exit 1 preserves the failure, elapsed 42.22376590000931s and observed process-tree peak RSS 186671104B under the stated 600s/8GiB limits. Pytest elapsed is 39.695s. This is not an all-green installed result.

All three failures are `test_finite_eccentric_group_balance_restart_and_actual_rebase`, for Q4, mixed and all-S3 layouts, at the retained-resultant successor comparison. The test uses correct native p18 scales: force10N in its first six slots, moment20Nm in the final twelve. Four entries out of 36 violate the unchanged dimensionless 1e-9 tolerance, specifically p[0] and p[3] in each of two members. These are axial-force coordinates, not recovered station moments or incorrectly packed moment slots.

| Layout | Maximum F10-normalized violation | Corresponding force difference |
| --- | ---: | ---: |
| Q4 | 9.13027343e-9 | 9.13027343e-8N |
| Mixed | 9.12930176e-9 | 9.12930176e-8N |
| All S3 | 3.55114071e-9 | 3.55114071e-8N |

The allowed absolute force difference under this fixed scale is 1e-8N. The assertion is therefore a genuine failure of the adopted metric, even though each relative difference to the large individual axial force is small. No threshold adjustment follows from these observations.

The accepted prefix, exact checkpoint roundtrips, immediate chart event checks and all four subsequent finite solve calls precede this comparison. Thus numerical completion is distinct from continuation parity. Each visited successor also passes its preceding equilibrium/gap, accepted-factor, beam-position and frame checks. The loop fails at its first discrepant branch: the XML does not identify which branch, does not allocate the difference to restore versus rebase, and does not establish that all remaining successor reaction/shell-pose/global-balance assertions passed. Separate loaded derivative, canonical norm and checkpoint-negative cases passing cannot replace this failed lifecycle predicate.

The root's fixed-load, fixed-path four-branch raw diagnosis is a suitable bounded next discriminator: compare original, restore-only, rebase and rebase-then-restore states before and after continuation; bind predecessor histories and applied loads, capture exact accepted source state and attempted residuals/iterations, and report all adopted role-scaled observables without stopping at the first discrepancy. Until those data exist, this result supports neither a packing defect nor a specific chart/restore implementation defect. It also cannot qualify the footprint or justify changing its law, numerical thresholds or physical scope.
