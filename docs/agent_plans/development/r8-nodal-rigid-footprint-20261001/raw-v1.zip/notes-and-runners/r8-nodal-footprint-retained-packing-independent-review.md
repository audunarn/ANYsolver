# R8 footprint loaded-check retained packing

2026-10-01. Independent source-only verification. No numerical jobs, product/test edits or replay of protected F06/material campaigns.

`FinitePointResult.cell_resultants` is **retained p18**, not three sampled six-wrenches. `_ge_beam3_generalized_cell.py::_evaluate` reconstructs station force variables x and station moments via `n @ p[6:]`; its six force constraints compare integrated station-force maps with `p[:6]`. Native p therefore has **six force coefficients, then twelve end-moment coefficients**. `_ge_beam3_retained_generalized.py::recover` separately derives each station's six-resultant wrench through the constitutive cell and its interpolation; that output does not define p's packing.

Each globally assembled member has nodal18 followed by retained24. The latter is **cell rotations6, force coefficients6, moment coefficients12**. This is independently explicit in owner `_beam_reference` slots and finite `_advance`: the first six retained increments left-update the two cell frames, and the final18 add to state.resultants. The temporary finite `state.q` retained slots remain zero; actual retained state is stored in cells/resultants, but Newton columns still follow that24-slot order.

The visible new loaded global derivative test assigns the correct SI roles:

| Member retained role | Input scale | Residual row scale |
|---|---|---|
| cell rotations6 | rad | Nm |
| force coefficients6 | N | m |
| end moments12 | Nm | rad |

Its concrete scales `[1]*6+[100]*6+[200]*12` and residual `[200]*6+[2]*6+[1]*12` respect those roles. Nodal blocks are `(m3,rad3)` against `(N3,Nm3)`; point multipliers `(N3,Nm3)` are paired with constraint rows `(m3,rad3)`. `_advance` implements the actual additive shell and left beam/cell updates used for central differences. Loaded accepted material predecessors are held fixed, both ordinary/rebased charts are checked, fixed columns are zero, and immutable accepted checkpoint/recovery are checked after diagnostic trial evaluation. This is meaningful derivative verification; it does not establish all possible nonlinear states.

The continuation test's p18 scale `[10]*6+[20]*12` is correct for its prospective F10N/L2m/M20Nm reference. It must not be replaced by `tile([F3,M3],3)`. The original material-history test and its already executed F06 role-correction supplement are not modified or rerun here.

**Separate consequential product-normalization finding:** existing owner `_reference_scales` still sets `beam_scale[base+6:base+24]=tile(resultant_scale,3)`, with `resultant_scale` a six-channel section wrench scale. That repeats `(F3,M3)` rather than assigning p's `(F6,M12)` roles and feeds the global retained coordinate/work weights. A role-correct assignment would duplicate its first three force scales twice, then its last three moment scales four times. This finding is not permission to change an adopted metric or legacy default silently. Root must decide an explicit prospective numerical-policy/eligibility boundary and evidence for a correction, or keep the inaccurate role claim open; a correctly scaled independent test does not make this product scale physically consistent.

**Separate draft-test blocker:** the newly visible corruption loop initially called `owner.restore(raw)` on its already accepted source owner. That triggers the fresh-owner lifecycle guard before the intended schema/history validation. Each corrupt checkpoint needs a fresh compatible target and must assert generation0/no accepted driver/result after rejection; the accepted source prefix/checkpoint should remain unchanged. Root was notified before execution. Final tests are still evolving, so this note does not claim a corruption-test pass or freeze their hash.
