# Nodal-footprint retained-role scale amendment ready

Pre-amendment eight files, ready note and static hashes are preserved uniquely at TEMP/r8-nodal-footprint-pre-scale-prepared-v1. Current eight ASTs parse; 46 cases statically inventoried (not executed). No numerical imports/runs/build/Git mutation.

ONLY nonempty new footprint owners now use (sF,sF,sM,sM,sM,sM), s=abs(virgin elastic section tangent)@(1,1,1,1/L,1/L,1/L), in native retained p18. Every empty-footprint owner keeps exact historical np.tile(s,3), all old numerics/model identities/checkpoints unchanged. New explicit `GE_NODAL_RIGID_FOOTPRINT_RETAINED_FORCE6_MOMENT12_WORK_SCALE_V1` descriptor binds model identity, preflight and capabilities for Q4/mixed/S3. Q4 footprint provisional identity intentionally changes; stable-S3 remains a distinct additional policy only for nonempty footprints containing S3. No element equation, raw operator, physical load, criterion, Newton/backtracking budget or checkpoint format changes. Acceptance/merit work weighting does change for new footprints, requiring fresh installed execution. Source docstrings now condition work-unit invariance on correctly packed supplied scales, rather than claiming historical empty-owner packing was corrected.

Tests independently check unequal anisotropic force/moment weights, canonical quiet retained force and moment row controls (L2m,F*100N,M*2Nm,load10N: legacy1e-9/correct5e-8 and legacy5e-8/correct1e-9), work-conjugate m->mm reexpression with covectors/work floor both converted to Nmm and unchanged appliedN force, and internal work equality. Sparse reference tests compare K/C/A exactly against expanded point incidence for all three shell layouts. Correctly reencoded stable-S3 snapshots separately reject missing-only-stable policy and missing-only-retained-scale policy identities; Q4 JSON snapshot rejects its provisional old scale identity. Every negative restoration uses a fresh compatible owner and checks generation0/no accepted/no driver, plus original source exact checkpoint/recovery.

All prior loaded assembled actual-update derivative, complete generalized origin/accepted history/empty fibre inventories, strict elastic guard, fresh restore/rebase/continuation, late cancellation and point-only admission tests remain prepared at their unchanged10N fixture and1e-8/1e-9/1e-6 criteria. Existing successor resultants use retained six force/twelve moment scales. Required installed seams: all46 footprint cases, point-recovery fixtures, stable-S3/fibre/rebase/finite/checkpoint regressions, reference+finite headless example, and exact old/new empty-footprint default oracle. Root schedules and independently reviews. No measured success/qualification claim; plastic/combined-line/continuous-area/weld/offnode scopes remain excluded.

Current exact hashes:

- src/anysolver/_stiffened_shell_ge_experimental.py: `92548dffda576c035f15c0d8a977713f8be2d915292f7653a18aa5a35c00571d`
- src/anysolver/_stiffened_shell_ge_finite_experimental.py: `55e7e2b0587918bc6b4523d284acd56a2649448440dbc5b55a3d029600b7a320`
- src/anysolver/_stiffened_shell_nodal_footprint.py: `2bba84680b813da617018a0a944138828826c8e091118754f93f1359af4a7000`
- src/anysolver/_stiffened_shell_point_recovery.py: `beb3a5309dbd2099560ca343f2fece7b41b80e3da09d91ebf35d1188a8636f6b`
- src/anysolver/stiffened_shell.py: `5704d6196b27127e23284cd0f23c7098e3ebdf55543b9219649b068e54eef40d`
- tests/test_stiffened_shell_nodal_rigid_footprint.py: `c1cf0d00f7d57c030bbb2c8fc63560d5c8b38a6ef1230a40360dd571e2d03ca0`
- tests/test_stiffened_shell_point_recovery.py: `2eb554e904f0408702cbe182bf0d4d3303a6a0264e1a1b99a5c45b5eaf24be03`
- examples/stiffened_shell_nodal_rigid_footprint.py: `1026dcbe85d899ae0cfbb1a8d1e08f04ba15787ef252ce25bd28bc9b34799b02`
