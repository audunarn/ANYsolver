from pathlib import Path
import dataclasses, hashlib, json, sys
import numpy as np
import anysolver, numba, threadpoolctl
from test_stiffened_shell_ge_experimental import _panel
from anysolver import stiffened_shell as s
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
def tree(x):
    if isinstance(x,np.ndarray):return {"dtype":x.dtype.str,"shape":x.shape,"bytes":x.tobytes().hex()}
    if dataclasses.is_dataclass(x):return {f.name:tree(getattr(x,f.name)) for f in dataclasses.fields(x)}
    if isinstance(x,dict):return {str(k):tree(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [tree(v) for v in x]
    if isinstance(x,(float,np.floating)):return {"float_hex":float(x).hex()}
    if isinstance(x,np.integer):return int(x)
    return x
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
records={}
for route in ('linear','finite'):
    definition=_panel()
    owner=s.create_analysis(definition=definition)
    actions=(s.NodalAction('beam',105,(0.,0.,100.,0.,0.,0.)),)
    result=owner.solve_linear(actions) if route=='linear' else owner.solve(actions,(.5,1.))
    checkpoint=owner.checkpoint();(out/(route+'.checkpoint')).write_bytes(checkpoint)
    recovered=owner.recover()
    fresh=s.create_analysis(definition=definition);restored=fresh.restore(checkpoint)
    records[route]={'identity':owner._identity,'capabilities':tree(owner.capabilities),
                    'result':tree(result),'recovered':tree(recovered),'restored':tree(restored),
                    'checkpoint_sha256':hashlib.sha256(checkpoint).hexdigest()}
    assert fresh.checkpoint()==checkpoint
    owner.close();fresh.close()
(out/'observables.json').write_text(json.dumps(records,sort_keys=True,separators=(',',':')))
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0]=='anysolver' and getattr(m,'__file__',None)}
(out/'imports.json').write_text(json.dumps(imports,indent=2))
assert numba.get_num_threads()==1 and all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
print(json.dumps({'routes':list(records),'solver':str(Path(anysolver.__file__).resolve()),'imports':len(imports)}))
