# Nodal-footprint unrebased admission handoff

Current49 cases statically inventoried (20 functions); all eight ASTs valid. No worker numerical jobs/imports/build/Git mutation. Failed46-case source/hashes/notes preserved uniquely in TEMP/r8-nodal-footprint-pre-rebase-park-prepared-v1; root retains actual43pass/3fail evidence and four-branch diagnosis. Prior snapshots remain untouched.

Decision-bound scope: exact retained-force/multiplier successor parity after shell chart rebase is NOT established. Restore-only is exact in the bounded Q4 diagnostic; rebase changes binary64 chart factorization and amplifies endpoint force differences. No generic Jet2 rewrite, tolerance waiver, physical load change or Newton-budget change is made.

New semantic descriptor `GE_NODAL_RIGID_FOOTPRINT_UNREBASED_ADMISSION_V1` binds every nonempty footprint model identity/preflight/capability, separately from retained-force6/moment12 work scaling and stable-S3 arithmetic. Nonempty footprint public rebase rejects before driver/state publication. Chart-wrapped restore rejects before chart decoding/publication after adaptive unwrapping; staged nested restore invokes the same guard. Correctly rewrapped CURRENT-model chart bytes cannot reintroduce the unsupported capability. Every empty-footprint owner retains its existing chart/rebase/default identity/scales/bytes behavior. Generic law/mechanics/checkpoint codec is unchanged.

Tests keep ALL prior normalized1e-9 force/state/multiplier/support successor assertions for original versus fresh restored unrebased owners with fixedFz10N/.25,.5,1 and20Newton/12backtrack. New Q4/mixed/all-S3 atomic rejection checks preserve checkpoint/generation/result/state arrays/history references and independently encode/decode proper CURRENT-model chart envelopes before rejected fresh-owner restoration. Numerical loaded assembled derivative retains nonzero multipliers and1e-6 criterion; its ordinary accepted chart and independently scalar-Rodrigues detached anchor chart exercise `_assemble/_advance` WITHOUT issuing/publishing a public rebase or claiming accepted anchored continuation. All other sparse reference/rigid/update/work/recovery/strict elastic history/late cancellation/unit/quiet-row tests remain.

Stable versus scale versus chart semantic identity rejection are separate. Mandatory future footprint chart/rebase+continuation remains OPEN in M4/F06; this is a present experimental admission bound, not permanent programme removal or F04/F06/M4 qualification. Plastic/combined-lines/continuous-area/distributing/weld/off-node scopes remain unsupported.

Root-coordinated installed checks required: current49 footprint cases, unchanged stable-S3/fibre/rebase/finite/checkpoint regression seams and affected point-recovery fixtures, headless example reference/finite, exact preserved old/new empty-owner oracle. Runtime success is not yet measured. Full final hashes:

- src/anysolver/_stiffened_shell_ge_experimental.py: `9ee64bd3eb5f5a3f86ae617bdabc192a4c1d9c246fbd5ce543102052b5129451`
- src/anysolver/_stiffened_shell_ge_finite_experimental.py: `55e7e2b0587918bc6b4523d284acd56a2649448440dbc5b55a3d029600b7a320`
- src/anysolver/_stiffened_shell_nodal_footprint.py: `d0556dd7df6d4cd04a8c6652c6a275e8c140fa97fa3226507f0ba8a02943b136`
- src/anysolver/_stiffened_shell_point_recovery.py: `beb3a5309dbd2099560ca343f2fece7b41b80e3da09d91ebf35d1188a8636f6b`
- src/anysolver/stiffened_shell.py: `5704d6196b27127e23284cd0f23c7098e3ebdf55543b9219649b068e54eef40d`
- tests/test_stiffened_shell_nodal_rigid_footprint.py: `c599ca46ac4c3d23a13d6352a5204b560b8e338cc6b5ca6a1ebfb248ae23f777`
- tests/test_stiffened_shell_point_recovery.py: `2eb554e904f0408702cbe182bf0d4d3303a6a0264e1a1b99a5c45b5eaf24be03`
- examples/stiffened_shell_nodal_rigid_footprint.py: `1026dcbe85d899ae0cfbb1a8d1e08f04ba15787ef252ce25bd28bc9b34799b02`
