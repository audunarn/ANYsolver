# R8 nodal rigid footprint: frozen independent source review

2026-10-01. Complete source/test/example review after author readiness. Read-only inspection; no product/model imports, numerical jobs, tests, factors, source edits or Git mutations. The design review and provisional product review v1 remain unchanged. This is a source-clear disposition for root's bounded installed checks, **not** a test-pass, F04/G2/M4 acceptance or qualification claim.

## Disposition

No remaining consequential source defect was found in this explicitly elastic, existing-node, six-pose footprint slice. Both earlier concrete findings are corrected and have meaningful direct regressions: high/low lever contributions stay separate through multiplication and the final compensated sum, including the exact 1Nm cancellation control and finite-output rejection; patch connectivity uses canonical actual shell edges, so two shared Q4 diagonal vertices and a reordered caller declaration cannot manufacture a connected patch.

The compilation and identity decisions are coherent. Declared points remain declared points, while ordered private incidences add one existing `RigidPoseJoint` per selected footprint node. The same ordering drives sparse reference rows, finite assembly, multiplier slices and immutable point-action capture. Supported-row dependence is still rejected with source labels; subsequent sparse mixed numerical admission remains required. Normal-spin locking is part of this full-six law. Grouping adds no quadrature, distributing weights, material model, global inverse, elimination rule or independent state store.

Recovery has the correct exerted sign and work map: `F*=sum(Fi)`, `M*=sum(Mi+(ri-r*) cross Fi)`, with separate high/low position differences and a common beam-port origin for both domains. It sums **all** repeated beam-port actions. Reference recovery uses reference positions and the actual frozen `C.T`; finite recovery uses the already captured same-trial spatial pose residual and current ports. Published point tuples and the enclosing generation supply state provenance, without replaying mechanics. These are physical domain actions, not ground reactions or raw multipliers.

Only nonempty group declarations augment owner identity; law, group ID, ordered membership, beam station and optional patch declaration are bound. Expanded legacy pair chains deliberately cannot accept the group's checkpoints even where their numerical operators match. Empty defaults retain the old identity payload, capability/result behavior and checkpoint framing. Existing single-owner writer/read guards, controller/state transaction, chart rebase and prepared fresh-owner restore continue to apply. The two isolated old point-recovery fixtures now construct the new private incidence field; their numerical assertions were not weakened.

Full-map Q4 is explicitly selected rather than silently replacing the historical default. Shell J2 and physical-fibre definitions remain excluded. Generalized beam plastic candidates are rejected before publication; the injection regression proves this scope guard, not a new physical plastic oracle. A complete declared cell patch contains every vertex and shares canonical edges; selected-node-only declarations promise only selected nodes. Geometric noncollinearity does not prove supported row independence or physical torque adequacy.

## Tests and example reviewed, awaiting execution

The frozen new file defines **36 parametrized predicates** by static inventory: Q4, mixed Q4/S3 and all-S3 complete rigid fields/objective deformation; omitted Q4 corner; analytical sparse point rows and expanded-chain equality; nonzero-multiplier actual left-update residual/potential derivatives; linear and finite exerted group balance; restore/continue and actual chart rebase; ownership/descriptor roundtrip; negative geometry/support/material/scope admission; canonical connectivity; low-arm/overflow recovery; stale group/order/station/chain identity; and legacy empty-footprint JSON identity/bytes.

The adaptive cancellation predicate covers both `finite.publish` and the applicable late `controller-publish` seam. The latter asserts that a complete prospective checkpoint was prepared, that no accepted observer notification occurred, and that accepted recovery identity, generation and checkpoint bytes remain unchanged. It does not misuse the fibre-only publication hook. Finite successor comparisons use fixed 2m/10N/20Nm scales: retained18 is six force coordinates followed by twelve moments, while point/support6 is three forces followed by three moments. Physical shell frames are compared across chart rebasing; chart coordinates are not incorrectly required to match.

The public example constructs a complete right Q4 cell at beam105, with the left cell connected to a fully clamped shell root, an explicit root point, an eccentric beam axis, and explicit full-map Q4. Its reference-linear/default and optional finite paths exercise Fz10N/My1Nm, typed selected recovery and fresh-owner checkpoint restore, with unchanged equilibrium/gap criteria. It labels output experimental/unqualified and describes locked normal spin. No unsupported off-node station, area weld or distributing meaning is introduced. Its numerical completion remains to be measured by root.

Root should bind the installed artifact and execute these checks plus the separate exact unchanged-default oracle. Source review alone cannot establish numerical completion, resource performance, physical weld equivalence, drilling-independent torque, plastic footprint histories, external E02 accuracy, distributing/continuous-area transfer or whole F04/G2/M4 closure. The actual independent moment-versus-force-arm split and drilling sensitivity remain mechanical obligations beyond this discrete capability.

## Exact frozen bindings

These match `TEMP/r8-nodal-rigid-footprint-static.json` and were independently hash-read in the worktree:

| File | SHA256 |
|---|---|
| `src/anysolver/_stiffened_shell_nodal_footprint.py` | `3dfc289734a497ca8583107dd4e2ee3dab3ce5b29dd23a45337c6f57b3b7a73f` |
| `src/anysolver/_stiffened_shell_ge_experimental.py` | `d8ec364c99e53ffa2e82f43d19fe1ac27b9798c6b60022df1ae7c463650ba353` |
| `src/anysolver/_stiffened_shell_ge_finite_experimental.py` | `feb26232041529d37602032e01cd8f13710174d32045ba7af8a52c3fa2f9dc01` |
| `src/anysolver/_stiffened_shell_point_recovery.py` | `beb3a5309dbd2099560ca343f2fece7b41b80e3da09d91ebf35d1188a8636f6b` |
| `src/anysolver/stiffened_shell.py` | `5704d6196b27127e23284cd0f23c7098e3ebdf55543b9219649b068e54eef40d` |
| `tests/test_stiffened_shell_nodal_rigid_footprint.py` | `0e7fece83514a26e85b43bba8b894ab3d623bfbfd6f28dba8ea64c37263caf9f` |
| `tests/test_stiffened_shell_point_recovery.py` | `2eb554e904f0408702cbe182bf0d4d3303a6a0264e1a1b99a5c45b5eaf24be03` |
| `examples/stiffened_shell_nodal_rigid_footprint.py` | `bfd5acebd04796167dca8410a10bf37ac7104bb1858f7fa2239732496834af23` |
