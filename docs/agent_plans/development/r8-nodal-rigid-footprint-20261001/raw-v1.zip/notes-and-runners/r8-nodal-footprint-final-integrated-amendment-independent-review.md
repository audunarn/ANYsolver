# Independent final integrated nodal-footprint amendment review

2026-10-01. Source-only independent review; no product/model imports, tests, assembly, factorization, solves, numerical jobs, source edits or Git mutation. Earlier design, diagnostic, product, packing and norm reviews remain unchanged. This note freezes the final source assessment, not installed acceptance.

## Disposition and bindings

No blocking correctness finding in the integrated prospective amendment. Nonempty new footprint owners use the actual retained force6/moment12 coordinate roles, with a declared scale policy in owner identity, capabilities and preflight. Empty-footprint owners retain the historical scale arrangement and identities. Elastic S3 footprint arithmetic/history eligibility remains a separate policy. The fresh installed checks are still required; the root-owned 46-predicate campaign was active when this review was saved.

I independently hashed all eight files and verified equality to `r8-nodal-rigid-footprint-role-scale-static.json`, SHA256 `96d9e77c74c3c1b519d7d8ed2d6b297f3c552306a407fcfb2d982271387c6bee`. Current ready-note SHA256 is `5438a7e84eaa7fe37d6f1807225c290d3554ebdc78781c3e0439e45fdae5191b`; the parent previously supplied `05791c2f...`, so that earlier note identity must not be used for these current bytes. This discrepancy does not affect the eight verified source bindings.

| File in the coupling worktree | SHA256 |
| --- | --- |
| `src/anysolver/_stiffened_shell_ge_experimental.py` | `92548dffda576c035f15c0d8a977713f8be2d915292f7653a18aa5a35c00571d` |
| `src/anysolver/_stiffened_shell_ge_finite_experimental.py` | `55e7e2b0587918bc6b4523d284acd56a2649448440dbc5b55a3d029600b7a320` |
| `src/anysolver/_stiffened_shell_nodal_footprint.py` | `2bba84680b813da617018a0a944138828826c8e091118754f93f1359af4a7000` |
| `src/anysolver/_stiffened_shell_point_recovery.py` | `beb3a5309dbd2099560ca343f2fece7b41b80e3da09d91ebf35d1188a8636f6b` |
| `src/anysolver/stiffened_shell.py` | `5704d6196b27127e23284cd0f23c7098e3ebdf55543b9219649b068e54eef40d` |
| `tests/test_stiffened_shell_nodal_rigid_footprint.py` | `c1cf0d00f7d57c030bbb2c8fc63560d5c8b38a6ef1230a40360dd571e2d03ca0` |
| `tests/test_stiffened_shell_point_recovery.py` | `2eb554e904f0408702cbe182bf0d4d3303a6a0264e1a1b99a5c45b5eaf24be03` |
| `examples/stiffened_shell_nodal_rigid_footprint.py` | `1026dcbe85d899ae0cfbb1a8d1e08f04ba15787ef252ce25bd28bc9b34799b02` |

## Mechanical and numerical contract

`_reference_scales` now assigns native p18 the sequence `(sF,sF,sM,sM,sM,sM)`, where `s=abs(C_virgin)@(1,1,1,1/L,1/L,1/L)`. The two force triplets have N units; the four moment triplets have Nm units. This follows the actual generalized-cell construction, not the separate recovered station-wrench representation. Global member retained24 is cell rotations6 followed by those force6/moment12 coordinates. The loaded actual-update derivative test uses the corresponding reciprocal residual roles: moment6, translation-compatibility6, rotation-compatibility12. Its physical scaling and the successor-resultant scaling are consistent.

The amendment corrects work weights prospectively; it does not weaken the fixed 1e-8 equilibrium, 1e-9 gap/continuation or 1e-6 derivative criteria. In the independent quiet-row controls, L=2m, F*=100N, M*=2Nm and a 10N nodal force give 20J applied work. A quiet second-force residual of 1e-8m produces legacy/correct ratios 1e-9/5e-8; a quiet first-moment residual of 1e-8rad produces 5e-8/1e-9. Thus the correction can change admission in either direction. Both `_relative_equilibrium` and the actual finite-used `_linear_equilibrium` assert these analytic values. The m-to-mm reexpression also checks both norms and internal work, with unchanged force units and consistently converted moment coordinates, covectors and work floor.

The coordinate scale does not multiply the raw K, C, A, finite tangent, RHS or direct backsolve. At the same state the physical operator is unchanged. The prepared grouped-versus-expanded tests assert exact K/C/A equality for Q4, mixed and all-S3 layouts. However scales affect stress-free validation, equilibrium/restore checks, nonlinear merit and stopping, and possibly subsequent trial/cutback or residual-correction selection. A fresh campaign is therefore necessary; old successful trajectories cannot substitute for it. Point-only C has no retained-resultant columns, so this particular packing correction also does not alter its constraint-row scale. That statement is not a general line-owner claim.

## Identity, restart and atomicity

Every nonempty footprint, including pure Q4, binds `GE_NODAL_RIGID_FOOTPRINT_RETAINED_FORCE6_MOMENT12_WORK_SCALE_V1`. The earlier provisional pure-Q4 footprint identity intentionally changes. Empty legacy owners do not acquire this key or the corrected weights. S3-containing elastic footprints additionally bind the cancellation-resistant S3/native-history policy; pure Q4 does not acquire that policy.

The S3 finite path requires stable native V9 before decode/publication, also inside chart framing. It carries complete origin and accepted generalized paired histories and explicit empty fibre inventories. Origin and accepted plastic/accumulated fields must each be zero before publication; it cannot downgrade silently to historical arithmetic. Legacy physical-fibre handling remains a distinct existing route. Private prepared restore keeps the public owner unmodified until validation succeeds.

The final tests reencode valid checksums while separately removing only the stable-arithmetic identity key or only the retained-scale key; they reject V7 downgrade, missing accepted-fibre layout, and nonzero origin/accepted plastic or accumulated pairs. Each negative now targets a fresh compatible owner and checks generation zero, no accepted result and no driver. The original accepted owner's checkpoint/recovery remain exact. Pure Q4 independently rejects its reconstructed provisional old-scale JSON identity. These predicates test policy/layout/history semantics rather than merely a broken checksum or the already-accepted-owner guard.

## Limits and next action

Finalize only after root's bound installed results, regressions, example and empty-default oracle are available. This source review does not make the old failed fixtures or the pre-amendment 44-predicate freeze pass. The old stable-only diagnostic isolates an arithmetic difference on its frozen elastic S3 fixture; it is not itself the new product's checkpoint/lifecycle evidence. The selected-node six-channel law still does not qualify a weld, distributing or continuous-area attachment, physical torque/drilling independence, plastic footprint, combined weak-line owner, off-node station, or aggregate F04/G2 acceptance. The historical empty-owner retained work-weight limitation remains explicitly open rather than silently repaired.
