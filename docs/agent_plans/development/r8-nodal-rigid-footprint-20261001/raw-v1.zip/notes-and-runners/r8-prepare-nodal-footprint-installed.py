from pathlib import Path
import hashlib,json,shutil,sys,subprocess
w=Path(r"C:/Github/ANYsolver/.perf2-worktrees/b3-ge-e4-pl-coupling")
r=Path(sys.argv[1]);r.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={str(p.relative_to(w)).replace(chr(92),'/'):sha(p) for p in (w/'src'/'anysolver').rglob('*.py')}
(r/'source-manifest.json').write_text(json.dumps(source,indent=2))
b=r/'build-source';b.mkdir();shutil.copytree(w/'src'/'anysolver',b/'src'/'anysolver',ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.nbc','*.nbi'))
for name in ('pyproject.toml','README.md','LICENSE','COPYRIGHT','THIRD_PARTY_NOTICES.md'):shutil.copy2(w/name,b/name)
f=r/'fixtures';f.mkdir()
old=r.parent/'r8-staged-load-installed-v1'
names={p.name for p in (old/'fixtures').glob('*.py')}
names.update(('test_stiffened_shell_nodal_rigid_footprint.py','test_stiffened_shell_staged_material_history.py'))
for name in sorted(names):shutil.copy2(w/'tests'/name,f/name)
shutil.copy2(w/'examples'/'stiffened_shell_nodal_rigid_footprint.py',r/'example.py')
shutil.copy2(r.parent/'r8-nodal-footprint-legacy-oracle.py',r/'legacy_oracle.py')
(r/'pytest.ini').write_text('[pytest]\naddopts = -p no:cacheprovider\njunit_family = legacy\n')
assert source=={str(p.relative_to(w)).replace(chr(92),'/'):sha(p) for p in (w/'src'/'anysolver').rglob('*.py')}
(r/'prepared-identity.json').write_text(json.dumps({'source':source,'fixtures':{p.name:sha(p) for p in f.glob('*.py')},'example_sha256':sha(r/'example.py'),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()},indent=2))
print(json.dumps({'root':str(r),'source_modules':len(source),'fixtures':len(names)}))
