from pathlib import Path
from dataclasses import asdict,replace
import hashlib,json,sys
import numpy as np,numba,threadpoolctl
from anysolver import stiffened_shell as s
from anysolver import _stiffened_shell_ge_finite_experimental as finite
from anysolver._stiffened_shell_increment_control import FiniteIncrementFailure
from test_stiffened_shell_ge_experimental import _panel
out=Path(sys.argv[1]);out.mkdir(exist_ok=False);old=sys.argv[2]=='old'
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1 and all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
sha=lambda a:hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()
original_init=finite.FinitePointDriver.__init__; original_assemble=finite.FinitePointDriver._assemble
summaries={}
for mesh in ('mixed','all-s3'):
 for mode in (('expanded',) if old else ('grouped','expanded','grouped-stable-diagnostic')):
    label=mesh+'-'+mode;d=out/label;d.mkdir();base=_panel();right=((2,3,6),(2,6,5))
    shell=replace(base.shell,q4_elements=((1,2,5,4),) if mesh=='mixed' else (),s3_elements=right if mesh=='mixed' else ((1,2,5),(1,5,4))+right)
    definition=replace(base,shell=shell,q4_pullback_policy=s.Q4_ALGORITHMIC_PULLBACK_V1 if shell.q4_elements else base.q4_pullback_policy)
    if mode=='expanded':definition=replace(definition,points=(base.points[0],)+tuple(s.PointConnection(n,105) for n in (2,3,6,5)))
    else:definition=replace(definition,points=(base.points[0],),footprints=(s.NodalRigidFootprint('tip-pad',(2,3,6,5),105,right),))
    owner=s.create_analysis(definition=definition);traces=[];states={};events=[]
    def init(self,owner):
        original_init(self,owner)
        if mode=='grouped-stable-diagnostic':self._stable_s3=True
    def assemble(self,state,factor,*args,**kwargs):
        answer=original_assemble(self,state,factor,*args,**kwargs)
        traces.append({'factor':float(factor),'relative':float(answer[2]),'gap':float(answer[3]),'q_sha256':sha(state.q),'residual_sha256':sha(answer[0]),'residual':answer[0].tolist(),'stable_s3':self._stable_s3})
        for name in ('q','q_low','frames','cells','resultants'):
            value=getattr(state,name,None)
            if value is not None:states['last_'+name]=np.asarray(value).copy()
        return answer
    finite.FinitePointDriver.__init__=init;finite.FinitePointDriver._assemble=assemble
    status='completed';attempt=None
    try:
        owner.solve((s.NodalAction('beam',105,(0.,0.,10.,0.,0.,0.)),),(.25,.5),max_iterations=20,max_backtracks=12,on_accepted=lambda r:events.append({'generation':r.generation,'accepted_factors':r.accepted_factors,'equilibrium_ratio':r.free_equilibrium_ratio,'constraint_max':r.constraint_max}))
    except FiniteIncrementFailure as exc:status='typed_increment_failure';attempt=asdict(exc.attempt)
    finally:finite.FinitePointDriver.__init__=original_init;finite.FinitePointDriver._assemble=original_assemble
    if owner._finite_driver is not None:
        state=owner._finite_driver._state
        for name in ('q','q_low','frames','cells','resultants'):
            value=getattr(state,name,None)
            if value is not None:states['accepted_'+name]=np.asarray(value).copy()
    np.savez(d/'states.npz',**states)
    data={'mesh':mesh,'mode':mode,'status':status,'attempt':attempt,'events':events,'model_identity':owner._identity,'matrices':{name:sha(getattr(owner,name).toarray()) for name in ('_K','_C','_A')},'trace':traces}
    (d/'result.json').write_text(json.dumps(data,indent=2));summaries[label]={k:data[k] for k in ('status','attempt','events','matrices')};owner.close()
(out/'summary.json').write_text(json.dumps(summaries,indent=2))
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0]=='anysolver' and getattr(m,'__file__',None)};(out/'imports.json').write_text(json.dumps(imports,indent=2))
assert numba.get_num_threads()==1 and all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
print(json.dumps({k:{'status':v['status'],'attempt':v['attempt'],'accepted_events':len(v['events'])} for k,v in summaries.items()}))
