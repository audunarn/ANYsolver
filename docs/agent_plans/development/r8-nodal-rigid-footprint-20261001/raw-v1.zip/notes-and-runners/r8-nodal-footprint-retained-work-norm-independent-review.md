# R8 native retained work norm: independent bounded contract

2026-10-01. Source-only tracing and pure scalar arithmetic; no product imports, assembly, factors, solves, numerical campaign or source edits. Current44-case stable-policy freeze remains a preserved prior artifact. The root-authorized next scope is an explicit prospective scale policy for **nonempty new nodal-footprint owners**, including Q4/mixed/S3; empty legacy owners keep exact norms/identities. This note does not change that freeze or any scientific threshold/load/budget.

## Defect and dimensional correction

Native retained p18 is `(F6,M12)`, not three sampled `(F3,M3)` wrenches. `_ge_beam3_generalized_cell.py::_evaluate` constrains integrated station forces with p[:6] and derives station moments through n@p[6:]. Station6 wrench recovery is a separate derived representation. Each global retained24 member block is `(Theta6,F6,M12)` as independently shown by owner `_beam_reference` slots and finite `_advance`.

Existing `_reference_scales` computes six section-row scales `s=abs(C_el) @ (1,1,1,1/L,1/L,1/L)` and tiles s three times into native p18. Since s[:3] has N units and s[3:] has Nm units, this assigns moment scales to the second force block and force scales to the first/third moment blocks. Positive finite numbers alone do not correct this role/unit mismatch. The owner-level claim that every retained residual-times-coordinate product has work units is consequently too broad for the legacy construction.

Keep the independent frozen length L and the same virgin elastic C_el. Define `sF=s[:3]`, `sM=s[3:]`. The correct p18 scale is **(sF,sF,sM,sM,sM,sM)**. A cell-rotation input scale remains1rad. Nodal input scales remain(Lm,Lm,Lm,1rad,1rad,1rad). The resulting covector products have common Nm work units: force-times-translation, moment-times-rotation, retained force scale-times-compatibility displacement, and retained moment scale-times-compatibility angle. Coupled section rows still have the correct output units because curvature scales carry1/L. Absolute values provide independent positive characteristic sizes, not a candidate-fitted correction.

With correct scale vector d, use the existing ratio `max(norm(r*d)/norm(a*d), max_active(abs(r_i/a_i)))`. Keep zero-load, representability and active-row behavior unchanged. Under a work-conjugate coordinate change z'=D z, covectors become D^-T r and characteristic coordinates D d, so each weighted product is unchanged. The defect is in native role assignment, not in the abstract ratio formula. No new residual floor or absolute acceptance threshold follows.

## Independently calculated unequal-weight counterexamples

A canonical positive diagonal section with L2m, translational stiffness100N and bending/torsional stiffness4Nm² gives sF100N and sM2Nm. Apply a10N nodal force; weighted applied norm is20Nm. Set every physical/active residual and point gap zero, and use one quiet retained compatibility residual1e-8 in the indicated row:

| Quiet retained row | Legacy numeric ratio | Correct ratio | At unchanged1e-8 criterion |
|---|---:|---:|---|
| second force block:1e-8m | 1e-9 | 5e-8 | legacy passes, correct fails |
| first moment block:1e-8rad | 5e-8 | 1e-9 | legacy fails, correct passes |

This is a direct metric control, not an assertion that a particular accepted model state has this isolated defect. The active-load check is zero and cannot detect a quiet retained mismatch. Correction is not uniformly stricter or looser: it restores actual roles.

Pure arithmetic on the existing `_panel` fixture's declared coordinates/section, without constructing a model, independently gives L0.8897952220539749m, first force scale2.1e9N and first moment scale1512880.5064230708Nm. The old p[3] weight is the latter although p[3] is a force coordinate; the correct weight ratio is1388.0805464042007. With the same Fz10N denominator8.897952220539748Nm and one quiet p[3] compatibility1e-15m, the existing numeric ratio is1.7002569455596602e-10 while the correct ratio is2.3600935900199906e-7. No candidate spectrum, measured solution error or observed acceptance ratio was used to choose these weights.

## What changes and what does not

The raw physical K/C/A and RHS are not multiplied by `_coordinate_scale`. Reference linear solving factorizes A directly with `splu(A)`; finite solving uses `spsolve(matrix_free,-residual_free)` directly. Thus this correction does **not** alter the matrix or backsolve for the same iterate. The reference-section tangent is read only to construct characteristic scales.

The scale affects compilation stress-free residual normalization; global equilibrium admission and checkpoint replay; finite stopping and the `max(relative,gap)` line-search merit; and whether an optional extra reference residual correction is attempted. Changed merit may change nonlinear trial selection, adaptive history, iteration counts or accepted output roundoff, so it is not merely a cosmetic reported ratio. Re-execution of affected checks is required. For these point-only footprints, retained p columns of C are zero; consequently their C row scales and supported-row rank scaling do not change. Do not generalize this statement to unreviewed attachment operators.

## Prospective policy boundary

Root's selected boundary—only nonempty new nodal-footprint owners—is defensible and bounded. Bind a distinct versioned retained-scale/work-norm descriptor in **every** such owner identity/preflight, including pure-Q4 footprints. The S3 stable-arithmetic/V9 condition remains separately scoped to S3; a scale correction alone does not require stable S3 framing for pure-Q4. All prior provisional footprint checkpoint/programme identities must reject under the new scale policy, even when raw operators match. Empty legacy point/line/fibre owners retain exact identities, array layout, arithmetic and norm selection; the legacy unit mismatch remains explicitly documented rather than silently corrected globally.

This intentional new-Q4-footprint identity change supersedes the earlier provisional pure-Q4-footprint parity promise. It does not change empty-Q4 legacy defaults. Preserve the44-case freeze and failed evidence before amending source/tests. Required fresh evidence includes exact raw operator equality, correctly packed scales for unequal force/moment section entries, the two independent quiet-row controls, actual loaded derivative/restore/rebase/late-cancellation guards, stale-policy rejection and exact empty-owner baseline parity. Keep the1e-8 equilibrium and1e-9 gap criteria, physical load/path and iteration/backtrack budgets unchanged. A metric correction is not a physical weld/torque/drilling qualification or F04/G2/M4 acceptance.

Source read bindings at diagnosis: GE owner `f89031afe5c44e793d40a20573713e3415962aef15faccf9f37413234932ec84`; finite driver `55e7e2b0587918bc6b4523d284acd56a2649448440dbc5b55a3d029600b7a320`. No norm amendment was made by this reviewer.
