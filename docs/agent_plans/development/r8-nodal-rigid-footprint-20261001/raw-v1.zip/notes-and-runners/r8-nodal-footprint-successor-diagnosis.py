from pathlib import Path
from dataclasses import fields, asdict
from types import SimpleNamespace
import json, sys, hashlib
import numpy as np
import numba, threadpoolctl, anysolver
from anysolver import stiffened_shell as ss
from test_stiffened_shell_nodal_rigid_footprint import _definition, _owner, _group_checks

root=Path.cwd(); callbacks=[]; request=SimpleNamespace(addfinalizer=callbacks.append)
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def snapshot(owner, name):
    driver=owner._finite_driver; state=driver._state; result=owner.recover()
    arrays={f.name:getattr(state,f.name) for f in fields(state) if isinstance(getattr(state,f.name),np.ndarray)}
    arrays.update({'result_'+f.name:getattr(result,f.name) for f in fields(result) if isinstance(getattr(result,f.name),np.ndarray)})
    np.savez(root/(name+'.npz'), **arrays)
    raw=owner.checkpoint(); (root/(name+'.checkpoint')).write_bytes(raw)
    return dict(checkpoint_sha256=sha(raw), generation=result.generation,
        equilibrium=result.free_equilibrium_ratio, gap=result.constraint_max,
        factors=result.accepted_factors, iterations=result.iterations,
        state_sha256={k:sha(v.tobytes()) for k,v in arrays.items()},
        beam_origins=[asdict(v) for v in driver._beam_origins])

try:
    definition=_definition(False); owner=_owner(request,definition)
    actions=(ss.NodalAction('beam',105,(0.,0.,10.,0.,0.,0.)),)
    prefix=owner.solve(actions,(.25,.5),max_iterations=20,max_backtracks=12)
    saved=owner.checkpoint(); control=_owner(request,definition); control.restore(saved)
    rebased=_owner(request,definition); rebased.restore(saved)
    report={'before':{},'after':{},'difference':{}}
    for name, branch in [('original',owner),('restored',control),('pre_rebase',rebased)]:
        report['before'][name]=snapshot(branch,name+'-prefix')
    rebased.rebase_rotations(expected_generation=prefix.generation)
    restored=_owner(request,definition); restored.restore(rebased.checkpoint())
    for name,branch in [('rebased',rebased),('rebased_restored',restored)]:
        report['before'][name]=snapshot(branch,name+'-prefix')
    reference=None
    for name,branch in [('original',owner),('restored',control),('rebased',rebased),('rebased_restored',restored)]:
        result=branch.solve(actions,(1.,),max_iterations=20,max_backtracks=12)
        _group_checks(branch,result)
        report['after'][name]=snapshot(branch,name+'-successor')
        if reference is None:reference=result
        report['difference'][name]={f:float(np.max(np.abs(getattr(result,f)-getattr(reference,f)))) for f in
            ('beam_positions','beam_frames','cell_frames','cell_resultants','multipliers','support_reactions')}
    report['imports']={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0]=='anysolver' and getattr(m,'__file__',None)}
    site=Path(anysolver.__file__).resolve().parent.parent
    assert all(Path(p).is_relative_to(site) for p in report['imports'].values())
    report['threads']=threadpoolctl.threadpool_info()
    (root/'result.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({'difference':report['difference'],'after':{k:{f:v[f] for f in ('equilibrium','gap','iterations')} for k,v in report['after'].items()}}))
finally:
    for close in reversed(callbacks):close()
