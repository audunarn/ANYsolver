from pathlib import Path
import hashlib,json,shutil,sys,subprocess

temp=Path(r'C:/Users/AUDUNA~1/AppData/Local/Temp')
r=temp/'r8-nodal-footprint-consumer-installed-v1';r.mkdir(exist_ok=False)
solver=Path(r'C:/Github/ANYsolver/.perf2-worktrees/b3-ge-e4-pl-coupling')
consumer=Path(r'C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={'anysolver':solver/'src'/'anysolver','anyfem':consumer/'src'/'anyfem'}
modules={n:{n+'/'+p.relative_to(base).as_posix():sha(p) for p in base.rglob('*.py')} for n,base in sources.items()}
b=r/'build-source';b.mkdir()
shutil.copytree(sources['anyfem'],b/'src'/'anyfem',ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.nbc','*.nbi'))
for name in ('pyproject.toml','README.md','LICENSE','NOTICE','THIRD_PARTY_NOTICES.md','dependency-licenses.json','docs/LICENSE.md','MANIFEST.in'):
    p=consumer/name
    if p.is_file():
        target=b/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
(r/'wheels').mkdir()
shutil.copy2(temp/'r8-nodal-footprint-installed-unrebased-v1'/'wheels'/'anysolver-0.4.7-py3-none-any.whl',r/'wheels')
f=r/'fixtures';f.mkdir()
names=('test_stiffened_shell_nodal_footprint_consumer.py','test_experimental_stiffened_shell_consumer.py',
       'test_stiffened_shell_project.py','test_stiffened_shell_staged_load_consumer.py',
       'test_experimental_b2_stiffened_shell_consumer.py')
for name in names:shutil.copy2(consumer/'tests'/name,f/name)
shutil.copy2(consumer/'examples'/'experimental_ge_nodal_rigid_footprint.py',r/'example.py')
shutil.copy2(temp/'r8-nodal-footprint-run-bounded.py',r/'run_bounded.py')
(r/'pytest.ini').write_text('[pytest]\naddopts = -p no:cacheprovider\njunit_family = legacy\n')
assert modules=={n:{n+'/'+p.relative_to(base).as_posix():sha(p) for p in base.rglob('*.py')} for n,base in sources.items()}
manifest={'modules':modules,'fixtures':{p.name:sha(p) for p in f.glob('*.py')},'example_sha256':sha(r/'example.py'),
          'heads':{n:subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip() for n,w in [('anysolver',solver),('anyfem',consumer)]}}
(r/'prepared-manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({'root':str(r),'modules':{n:len(v) for n,v in modules.items()},'fixtures':len(names)}))
