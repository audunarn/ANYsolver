# Independent nodal rigid-footprint mechanics review

2026-10-01. Read-only independent review of seam SHA256 `a87963a6ec7434991a292e44545fe572de936d8582c7664e8a6d29ff3347a67f` and existing joint/full-map operators at reported HEADf2528206. No product/test edits, model imports or numerical jobs; only this note written. **No mathematical obstruction to an explicitly declared nodal rigid footprint at one existing beam nodal station.** It is a stack of existing exact six-pose constraints, not distributing coupling, continuous-area integration, an off-node beam station or qualified weld. Product/tests are not yet reviewed or accepted here; F04 remains open.

## What zero point gaps prove

For selected shell node i, let reference pose be `(X_i,Qs0_i)` and beam reference `(rb0,Qb0)`. Existing `RigidPoseJoint` declares

`e_i=Qs0_i.T (rb0-X_i)`, `A_i=Qs0_i.T Qb0`,
`ct_i=Qs_i.T (rb-rs_i)-e_i`, `cr_i=Log(A_i.T Qs_i.T Qb)`.

On the admitted smooth SO(3) branch, ct=cr=0 gives

`R=Qb Qb0.T`, `Qs_i=R Qs0_i`, `rs_i=rb+R(X_i-rb0)`.

Consequently `rs_i-rs_j=R(X_i-X_j)`: all selected nodes follow one rigid pose. The seam's `Qs_i=R` is correct for its flat owner convention `Qs0_i=I`; use the transported-reference formula above if initial shell frames ever vary. No least-squares fit, centroid approximation or area weight is needed. At reference the rigid tangent is `du_i=du_b+omega×(X_i-rb0)`, `dtheta_i=omega`. Relative nodal spin is locked in all three directions; this is distinct from BL5's five-channel director release and from finite-vertex B2 fitting.

Complete vertex coverage gives exact Q1-Q4/P1-S3 geometric field rigidity: partition of unity and reference isoparametric coordinate reproduction imply `sum N_i rs_i=rb+R(sum N_i X_i-rb0)`. Constant reference-relative rotation R is exactly representable by the admitted physical nodal-frame field. This applies to every completely covered element, with nondegenerate reference mapping and the existing frame/map eligibility. It does not supply surface traction integration or distributing weights.

**Do not express complete-patch admission as a universal mathematical “iff all vertices and connected.”** All vertices satisfying the rigid field is sufficient, and interpolation at a node requires its value, but other explicit constraints could also enforce an omitted node. Disconnected completely covered cells tied to the same body are each rigid too. Connectedness is needed for a declared contiguous patch interpretation, not this algebraic conclusion. For an area patch, declare whether connectivity means sharing an edge; two cells touching only at a point do not establish a connected area of positive width. A record of nodes alone may safely identify the induced completely covered elements; a larger claimed cell union must bind its complete membership and connectivity.

Concrete coverage counterexample: in a unit Q4 tie three noncollinear corners to the identity beam pose, leave the fourth untied and move it by `epsilon ez`. All three selected ct/cr gaps remain zero, while the interior acquires `N_4 epsilon ez`; it is not a rigid Q4 field. Three noncollinear nodes also can lie in a mesh without containing any completely covered cell. Neither fact is repaired by a geometric area test.

## Rank, supports and material objectivity

Away from the Log branch cut, each joint's derivative with respect to its six shell pose coordinates has invertible translation and rotation diagonal blocks. For distinct free shell nodes, these blocks give stacked row rank6m even though every joint shares the same beam columns. Noncollinearity is therefore an area-policy admission, **not** why this six-pose law has rank. Even one full-pose pair has six independent rows before supports. A collinear set still follows a rigid pose under this law, although it need not be admitted as an area footprint.

Conversely, three noncollinear fully fixed shell nodes tied to one free beam pose give18 rows supported by at most six free beam pose columns: rank cannot exceed6. Noncollinearity does not cure this redundancy. Retain supported row/scaling checks and numerical KKT admission, with row provenance identifying footprint ID/node/component. The existing small-row numerical rank check and large-row structural matching have distinct meanings; structural matching is not a numerical independence certificate. Factorization cannot be replaced by an assumption that shell/mixed beam stiffness is SPD. Exact duplicate incidence must fail without row deletion. Shared nodes tied to different beam masters need explicit admission semantics and supported-rank checks; do not silently deduplicate or relabel a multi-master rigid chain as one body.

For a completely covered virgin unstressed patch, the existing Procrustes deformation map removes a common rigid motion and produces zero local deformation/material stress within its established numerical budgets. Initial strain, prestress or irreversible history can produce nonzero local stress, so “rigid motion means zero stress” must be limited to that virgin control. A fixed yielded-predecessor objectivity control instead compares unchanged local deformation/history and correctly rotated physical response. It does not fabricate a plastic energy potential.

Q4 physical-work tests must explicitly choose `Q4_ALGORITHMIC_PULLBACK_V1`; historical rotate-forward force mapping is a separate policy and does not become the full work-conjugate map by adding footprint constraints. S3 J2 uses its existing complete pullback. Preserve the product default/policy identity rather than switching it automatically on footprint admission.

## Spatial/chart work and grouped resultants

The joint evaluates spatial left variations and material-basis lambda; lambda is not a spatial applied wrench. Additive shell chart columns require the actual Exp Jacobian and its curvature. `evaluate_ports` provides a coordinate-pulled covector/operator, whereas the mixed owner currently sums **spatial residual rows** and pulls increment columns only. Reusing its `pose.residual` and `pose.spatial_jacobian @ coordinate_map` is coherent. Summing coordinate-pulled joint rows with spatial shell/beam/load rows would be wrong. Complete Q4/S3 shell mapping uses `J^-T D.T f` and its full fixed-predecessor derivative; neither the Hessian alone nor a symmetrized tangent substitutes for the spatial operator.

Existing per-node records correctly store **minus** the resisting connection residual as exerted actions `(F_i,M_i)` about that port position, with high/low positions and reference/current configuration. Retain those records and build immutable group mapping from compiled incidence, not `_definition.points[index]`; appended footprint joints otherwise cause wrong IDs/out-of-range recovery. Grouping cannot lose repeated beam-node contributions or combine accepted states from different generations/configurations.

For a declared common origin `o=o_hi+o_lo`, the exact rigid-body dual is

`F_group=sum F_i`,
`M_group=sum [M_i+(r_i-o)×F_i]`,
`sum [F_i·du_i+M_i·omega]=F_group·du_o+M_group·omega`.

Evaluate lever differences with both position halves: `(r_hi-o_hi)×F+(r_lo-o_lo)×F`, with stable summation. Do not first discard the lows or subtract rounded large absolute positions. Beam group action is the sum of every repeated beam-port record, shifted to the **same** origin; shell and beam resultants then cancel by joint objectivity. This cancellation is a force/work balance control, not proof of solved physical response accuracy. A local-frame group representation would also need the explicit rotation dual; global spatial components at the common origin avoid that extra convention.

Report direct-couple and force-arm moment contributions separately. A noncollinear force pattern can transfer normal-axis torque through force arms, but full-pose locking also admits direct normal-spin couples. A small or zero direct drilling couple on one load does not establish independence from numerical drilling stiffness. Conversely a nonzero direct-couple component alone does not identify a defective rigid law. Keep all six engineering outputs visible and the required drilling/physical torque/attachment qualification open; do not borrow BL5 release interpretation for this law.

## Required bounded verification and identity checks

1. Independently impose six infinitesimal rigid modes and a nonaxis finite common pose on a complete flat Q4 and a complete mixed Q4/S3 patch, at eccentric existing beam station. Check the formulas, full per-node gaps and virgin zero deformation/material response; separately demonstrate the omitted-Q4-corner counterexample. Use standalone kinematic/element oracles when the supported analysis cannot admit that global rigid motion. Count every declared vertex and define patch connectivity explicitly.
2. Check reference stacked C against independent analytical rows and finite nonzero-lambda work/derivative plateaux, including chart curvature and an owned nonzero anchor. Check per-node and grouped virtual work at the same origin, all six force/moment cancellations and a low-part lever control; frame/sign/origin conventions must be explicit. Retain force-arm/direct-couple decomposition under physical transverse force and torque actions, without a drilling-independence inference.
3. Check one bounded supported sparse solve against an independently assembled dense system of the declared pair laws. Include dependent fixed-overlap and duplicate-incidence failures with source attribution. A grouping-equivalent explicit point chain is a useful numerical implementation oracle, but its law/checkpoint identity must remain semantically different.
4. Deep-owned descriptor/group/output membership and stable ordering; reconstruct definition without dropping footprints. Empty-footprint legacy C/identity/checkpoint parity remains exact. Nonempty identity includes group IDs, ordered membership, beam station and law: regrouping cannot alias an expanded legacy point checkpoint merely because C matches. Changed membership/group/station must reject stale checkpoint/programme before publication. Footprint-only admission and every point-count/recovery/row-offset use must reference compiled incidence.
5. One accepted loaded selected-full-map state through actual rebase/checkpoint/restore/continue, callback/cancellation and failed-candidate prefix preservation using the existing safe point appropriate to the chosen material branch. Generalized-only owners do not emit fibre material-publish; controller-publish applies after complete prospective checkpoint before commit. Keep exact accepted histories and the existing typed derived-response/physical criteria, not new byte promises or relaxed low-component denominators.

These are bounded tests of the explicit **discrete nodal** attachment. They do not qualify a distributing footprint, continuum area weld, E02 reference, torque/drilling independence, F04 or broader M4/G2. Experimental capability should state that station/selected-node scope, full normal-spin lock and unchanged Q4 policy explicitly.

Read operator bindings: joint `f3fce05e6d65dfac9a9783e6fb466b8a0067ab4831ba00a74df9c579461abf71`; Q4 adapter `5cfc91a3fc113b23f6077571c3241c44477e8004f36211651d7f47109ae934b2`; S3 adapter `b0a4b684082d2ae3352aad117b539ac7691f8a9975b182ca37f56f6edc8bc9cb`; spatial pullback `af30497d5b2a7bbfefa48ceafe0590edb847ed41d6db006b745dcde9e4c43119`; deformation map `8745f4c544ab8cde1151eb53a0fd6d129a8e8e26595e0c6decd37674db054015`. Relevant seams: joint94–122,176–248; deformation80–124; supported rank94–126; point recovery29–48. No current implementation/qualification acceptance follows from this design review.
