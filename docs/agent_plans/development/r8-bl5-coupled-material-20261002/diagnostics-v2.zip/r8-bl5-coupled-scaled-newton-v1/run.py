from pathlib import Path
import sys,json,importlib.util
root=Path(__file__).parent;repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
if len(sys.argv)>1:
 import numpy as np
 from scipy.sparse import linalg as spla
 from dataclasses import asdict
 sys.path.insert(0,str(repo/"tests"))
 from test_stiffened_shell_bl5_coupled_material import coupled
 from test_stiffened_shell_bl5_finite import _action
 from anysolver import stiffened_shell as ss
 owner=ss.create_analysis(definition=coupled())
 owner.restore((root.parent/"r8-bl5-coupled-reversal-diagnostic-v1/p0-failure-prefix.bin").read_bytes())
 driver=owner._finite_driver;n=owner._K.shape[0];free=np.r_[owner._free,np.arange(n,n+owner._C.shape[0])]
 energy=float(np.max((abs(owner._K)@owner._coordinate_scale)*owner._coordinate_scale))
 scales=np.r_[owner._coordinate_scale,energy/owner._constraint_scale][free]
 def solve(matrix,rhs):
  fact=spla.splu(matrix.multiply(scales[:,None]).multiply(scales[None,:]).tocsc()/energy)
  return scales*fact.solve(rhs*scales/energy)
 spla.spsolve=solve
 programme=ss.StagedDeadLoadProgramme(owner.preflight()["identity"],(_action(500.),_action(-500.)))
 try:
  result=driver._solve_fixed(programme,(2.,),max_iterations=20,max_backtracks=12)
  record=dict(status="completed",position=result.load_position,ratio=result.free_equilibrium_ratio,gap=result.constraint_max)
 except ss.FiniteIncrementFailure as error:record=dict(status="failed",attempt=asdict(error.attempt))
 (root/"result.json").write_text(json.dumps(record,indent=2));print(json.dumps(record));owner.close()
else:
 spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV["PYTHONPATH"]=str(repo/"src");s.ENV["PYTEST_DISABLE_PLUGIN_AUTOLOAD"]="1"
 result=s.supervised([sys.executable,str(Path(__file__)),"child"],root/"run-v1")
 print(json.dumps({k:result[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
