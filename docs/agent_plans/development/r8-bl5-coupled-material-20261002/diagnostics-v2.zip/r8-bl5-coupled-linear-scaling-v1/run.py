from pathlib import Path
import sys,json,importlib.util
root=Path(__file__).parent;repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
if len(sys.argv)>1:
 import numpy as np
 from math import fsum
 from dataclasses import replace
 from scipy.sparse.linalg import splu
 sys.path.insert(0,str(repo/"tests"))
 from test_stiffened_shell_bl5_coupled_material import coupled
 from anysolver import stiffened_shell as ss
 owner=ss.create_analysis(definition=coupled())
 owner.restore((root.parent/"r8-bl5-coupled-reversal-diagnostic-v1/p0-failure-prefix.bin").read_bytes())
 driver=owner._finite_driver;blob=np.load(root.parent/"r8-bl5-coupled-direction-v1/native-scale-failure-parent.npz")
 state=replace(driver._state,**{k:blob[k] for k in ("q","frames","cells","resultants","multipliers","shell_anchors")})
 def evaluate(q):return driver._assemble(q,2.,driver._shell_origins,driver._beam_origins,applied_load=driver._programme.load_at(2.))
 residual,tangent,ratio,gap,*_=evaluate(state);n=owner._K.shape[0];free=np.r_[owner._free,np.arange(n,len(residual))]
 matrix=tangent[free,:][:,free].tocsr();rhs=-residual[free]
 energy=float(np.max((abs(owner._K)@owner._coordinate_scale)*owner._coordinate_scale))
 scales=np.r_[owner._coordinate_scale,energy/owner._constraint_scale][free]
 scaled=matrix.multiply(scales[:,None]).multiply(scales[None,:]).tocsc()/energy
 factor=splu(scaled)
 direction=scales*factor.solve(rhs*scales/energy)
 weights=np.r_[owner._coordinate_scale,np.ones(owner._C.shape[0])][free]
 def defect(delta):
  return np.array([fsum([float(-rhs[i]),*(float(v)*float(delta[j]) for j,v in zip(matrix.indices[matrix.indptr[i]:matrix.indptr[i+1]],matrix.data[matrix.indptr[i]:matrix.indptr[i+1]]))]) for i in range(len(rhs))])
 def metric(delta):return float(np.linalg.norm(defect(delta)*weights)/np.linalg.norm(rhs*weights))
 results=dict(original=metric(blob["direction"][free]),scaled=[metric(direction)],energy=energy)
 for _ in range(3):
  direction+=scales*factor.solve(-defect(direction)*scales/energy);results["scaled"].append(metric(direction))
 full=np.zeros(len(residual));full[free]=direction
 results["candidate_ratios"]=[dict(halvings=k,ratio=evaluate(driver._advance(state,full,2.**-k))[2]) for k in (0,4,8,12,16,20)]
 (root/"result.json").write_text(json.dumps(results,indent=2));print(json.dumps(results));owner.close()
else:
 spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV["PYTHONPATH"]=str(repo/"src");s.ENV["PYTEST_DISABLE_PLUGIN_AUTOLOAD"]="1"
 result=s.supervised([sys.executable,str(Path(__file__)),"child"],root/"run-v1")
 print(json.dumps({k:result[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
