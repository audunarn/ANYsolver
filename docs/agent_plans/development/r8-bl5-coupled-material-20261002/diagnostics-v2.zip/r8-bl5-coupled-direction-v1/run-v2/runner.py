from pathlib import Path
import sys,os,json,importlib.util
root=Path(__file__).parent
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
if len(sys.argv)>1:
 import numpy as np
 sys.path.insert(0,str(repo/"tests"))
 from test_stiffened_shell_bl5_coupled_material import coupled
 from test_stiffened_shell_bl5_finite import _action
 from anysolver import stiffened_shell as ss
 owner=ss.create_analysis(definition=coupled())
 owner.restore((root.parent/"r8-bl5-coupled-reversal-diagnostic-v1/p0-failure-prefix.bin").read_bytes())
 driver=owner._finite_driver;last={};advance=driver._advance
 def track(state,direction,step):
  last.update(state=state,direction=np.array(direction,copy=True),step=step)
  return advance(state,direction,step)
 driver._advance=track
 programme=ss.StagedDeadLoadProgramme(owner.preflight()["identity"],(_action(500.),_action(-500.)))
 try:driver._solve_fixed(programme,(2.,),max_iterations=20,max_backtracks=12)
 except ss.FiniteIncrementFailure as error:failure=str(error)
 else:failure=None
 state=last["state"];direction=last["direction"]
 def evaluate(q):return driver._assemble(q,2.,driver._shell_origins,driver._beam_origins,applied_load=driver._programme.load_at(2.))
 residual,tangent,ratio,gap,*_=evaluate(state);expected=tangent@direction
 weights=np.r_[owner._coordinate_scale,np.ones(owner._C.shape[0])]
 groups=(("shell",0,owner._shell_count),("beam",owner._shell_count,owner._K.shape[0]),("constraint",owner._K.shape[0],len(residual)))
 errors=[]
 for h in (1e-2,1e-3,1e-4,1e-5):
  difference=(evaluate(advance(state,direction,h))[0]-evaluate(advance(state,direction,-h))[0])/(2*h)-expected
  errors.append(dict(h=h,**{name:float(np.linalg.norm(difference[a:b]*weights[a:b])/max(np.linalg.norm(expected[a:b]*weights[a:b]),1e-20)) for name,a,b in groups}))
 result=dict(failure=failure,parent_ratio=ratio,parent_gap=gap,last_fraction=last["step"],direction_errors=errors)
 (root/"result.json").write_text(json.dumps(result,indent=2))
 print(json.dumps(result));owner.close()
else:
 spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV["PYTHONPATH"]=str(repo/"src");s.ENV["PYTEST_DISABLE_PLUGIN_AUTOLOAD"]="1"
 result=s.supervised([sys.executable,str(Path(__file__)),"child"],root/"run-v2")
 print(json.dumps({k:result[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
