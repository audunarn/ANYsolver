from pathlib import Path
import sys,json,importlib.util
root=Path(__file__).parent;repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
if len(sys.argv)>1:
 import numpy as np
 from dataclasses import replace
 sys.path.insert(0,str(repo/"tests"))
 from test_stiffened_shell_bl5_coupled_material import coupled
 from anysolver import stiffened_shell as ss
 from anysolver._stiffened_shell_ge_finite_experimental import FinitePointDriver
 from anysolver._ge_beam3_pose_joint import _exp_terms
 from anysolver._ge_beam3_p5.algebra import skew
 owner=ss.create_analysis(definition=coupled());reference=FinitePointDriver(owner)
 owner.restore((root.parent/"r8-bl5-coupled-reversal-diagnostic-v1/p0-failure-prefix.bin").read_bytes())
 driver=owner._finite_driver;n=owner._K.shape[0];size=n+owner._C.shape[0];assert size<=512
 free=np.r_[owner._free,np.arange(n,size)]
 energy=float(np.max((abs(owner._K)@owner._coordinate_scale)*owner._coordinate_scale))
 scales=np.r_[owner._coordinate_scale,energy/owner._constraint_scale]
 blob=np.load(root.parent/"r8-bl5-coupled-direction-v1/native-scale-failure-parent.npz")
 failed=replace(driver._state,**{k:blob[k] for k in ("q","frames","cells","resultants","multipliers","shell_anchors")})
 from anysolver._stiffened_shell_displacement_corrector import correct
 before=owner.checkpoint();base=driver._programme.load_at(driver._load_factor)
 direction=driver._programme.load_at(2.)-base;index=int(np.flatnonzero(direction)[0])
 target=float(failed.q[index]);initial=float(driver._state.q[index])
 result=correct(driver,base_load=base,load_direction=direction,amplitude=0.,
                control_dof=index,target=target,max_iterations=20,max_backtracks=12)
 assert owner.checkpoint()==before
 data=dict(control_dof=index,initial_displacement=initial,target_displacement=target,
    amplitude=result.amplitude,load=float((base+result.amplitude*direction)[index]),
    equilibrium_ratio=result.evaluation[2],constraint_gap=result.evaluation[3],
    displacement_error=float(result.state.q[index]-target),iterations=result.iterations,
    evaluations=result.evaluations,rejected_trials=result.rejected_trials,
    accepted_prefix_unchanged=True)
 (root/"result.json").write_text(json.dumps(data,indent=2));print(json.dumps(data));owner.close()

else:
 spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV["PYTHONPATH"]=str(repo/"src");s.ENV["PYTEST_DISABLE_PLUGIN_AUTOLOAD"]="1"
 result=s.supervised([sys.executable,str(Path(__file__)),"child"],root/"run-v2")
 print(json.dumps({k:result[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
