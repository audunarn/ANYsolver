"""Private bordered correction: singular and nonsymmetric equilibrium operators."""
import numpy as np
import pytest
from scipy import sparse
from anysolver._stiffened_shell_displacement_corrector import bordered_correction


@pytest.mark.parametrize("coupling",(0.,3.))
def test_displacement_control_resolves_loaded_mechanism(coupling):
    # First coordinate has zero tangent stiffness; second has stiffness two.
    # A load-amplitude unknown and first-coordinate control resolve equilibrium.
    matrix=sparse.csc_matrix([[0.,coupling],[0.,2.]])
    step,amplitude=bordered_correction(matrix,np.array([-1.,4.]),
        np.array([1.,0.]),0,-.3,np.array([0,1]))
    np.testing.assert_allclose(step,[.3,-2.],rtol=0.,atol=1e-15)
    assert amplitude==pytest.approx(-1.-2.*coupling)
    np.testing.assert_allclose(matrix@step-amplitude*np.array([1.,0.]),[1.,-4.])


def test_fixed_control_rejected():
    with pytest.raises(ValueError,match="free coordinate"):
        bordered_correction(sparse.eye(2,format="csc"),np.zeros(2),
                            np.ones(2),0,0.,np.array([1]))


def test_coupled_displacement_trial_preserves_owner_and_predecessor(request,monkeypatch):
    from anysolver import stiffened_shell as ss
    from anysolver.control import CancellationToken,SolveCancelled
    from anysolver._stiffened_shell_displacement_corrector import correct
    from anysolver._stiffened_shell_ge_finite_experimental import FinitePointDriver
    from test_stiffened_shell_bl5_coupled_material import coupled
    from test_stiffened_shell_bl5_material import make
    from test_stiffened_shell_bl5_finite import _action
    owner=make(request,coupled())
    programme=ss.StagedDeadLoadProgramme(owner.preflight()["identity"],(_action(500.),))
    owner.solve(programme,(.5,1.),max_iterations=20,max_backtracks=12)
    driver=owner._finite_driver;saved=owner.checkpoint()
    base=driver._programme.load_at(1.).copy();direction=base*.1
    dof=int(np.flatnonzero(direction)[0]);target=driver._state.q[dof]*1.01
    args=dict(base_load=base,load_direction=direction,amplitude=0.,
              control_dof=dof,target=target)
    with pytest.raises(ValueError,match="accepted endpoint"):
        correct(driver,**{**args,"base_load":base*1.001})
    trial=correct(driver,**args)
    assert trial.evaluation[2]<=1e-8 and trial.evaluation[3]<=1e-9
    assert abs(trial.state.q[dof]-target)/owner._reference_length<=1e-9
    assert trial.predecessor_state is driver._state
    assert trial.shell_predecessor is driver._shell_origins
    assert trial.beam_predecessor is driver._beam_origins
    assert np.max([np.max(s["alpha"]) for s in trial.evaluation[4]])>0.
    assert owner.checkpoint()==saved
    base[:]=0.;direction[:]=0.
    assert np.any(trial.base_load) and np.any(trial.load_direction)
    assert not trial.base_load.flags.writeable and not trial.load_direction.flags.writeable
    token=CancellationToken();token.cancel("private trial")
    args.update(base_load=trial.base_load,load_direction=trial.load_direction)
    with pytest.raises(SolveCancelled):correct(driver,**args,cancellation_token=token)
    assert owner.checkpoint()==saved
    original=FinitePointDriver._assemble;origin=driver._shell_origins
    def invalidate(self,*a,**kw):
        value=original(self,*a,**kw)
        self._shell_origins=tuple(list(origin))
        return value
    try:
        with monkeypatch.context() as patch:
            patch.setattr(FinitePointDriver,"_assemble",invalidate)
            with pytest.raises(ValueError,match="stale displacement"):
                correct(driver,**args)
    finally:
        driver._shell_origins=origin
    assert owner.checkpoint()==saved
