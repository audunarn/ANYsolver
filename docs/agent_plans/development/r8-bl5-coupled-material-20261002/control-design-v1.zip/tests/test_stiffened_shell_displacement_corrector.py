"""Private bordered correction: singular and nonsymmetric equilibrium operators."""
import numpy as np
import pytest
from scipy import sparse
from anysolver._stiffened_shell_displacement_corrector import bordered_correction


@pytest.mark.parametrize("coupling",(0.,3.))
def test_displacement_control_resolves_loaded_mechanism(coupling):
    # First coordinate has zero tangent stiffness; second has stiffness two.
    # A load-amplitude unknown and first-coordinate control resolve equilibrium.
    matrix=sparse.csc_matrix([[0.,coupling],[0.,2.]])
    step,amplitude=bordered_correction(matrix,np.array([-1.,4.]),
        np.array([1.,0.]),0,-.3,np.array([0,1]))
    np.testing.assert_allclose(step,[.3,-2.],rtol=0.,atol=1e-15)
    assert amplitude==pytest.approx(-1.-2.*coupling)
    np.testing.assert_allclose(matrix@step-amplitude*np.array([1.,0.]),[1.,-4.])


def test_fixed_control_rejected():
    with pytest.raises(ValueError,match="free coordinate"):
        bordered_correction(sparse.eye(2,format="csc"),np.zeros(2),
                            np.ones(2),0,0.,np.array([1]))
