from pathlib import Path
import sys,json,importlib.util
root=Path(__file__).parent;repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
if len(sys.argv)>1:
 import numpy as np
 from dataclasses import replace
 sys.path.insert(0,str(repo/"tests"))
 from test_stiffened_shell_bl5_coupled_material import coupled
 from anysolver import stiffened_shell as ss
 from anysolver._stiffened_shell_ge_finite_experimental import FinitePointDriver
 from anysolver._ge_beam3_pose_joint import _exp_terms
 from anysolver._ge_beam3_p5.algebra import skew
 owner=ss.create_analysis(definition=coupled());reference=FinitePointDriver(owner)
 owner.restore((root.parent/"r8-bl5-coupled-reversal-diagnostic-v1/p0-failure-prefix.bin").read_bytes())
 driver=owner._finite_driver;n=owner._K.shape[0];size=n+owner._C.shape[0];assert size<=512
 free=np.r_[owner._free,np.arange(n,size)]
 energy=float(np.max((abs(owner._K)@owner._coordinate_scale)*owner._coordinate_scale))
 scales=np.r_[owner._coordinate_scale,energy/owner._constraint_scale]
 blob=np.load(root.parent/"r8-bl5-coupled-direction-v1/native-scale-failure-parent.npz")
 failed=replace(driver._state,**{k:blob[k] for k in ("q","frames","cells","resultants","multipliers","shell_anchors")})
 nodal=owner._shell_count+6*len(owner._beam_ids)
 rotations=list(range(3,nodal,6))+[nodal+24*i+j for i in range(len(owner._beam_parts)) for j in (0,3)]
 results={}
 for name,state,shell,beam,factor in (("reference",reference._state,reference._shell_origins,reference._beam_origins,0.),("accepted",driver._state,driver._shell_predecessors,driver._beam_predecessors,driver._load_factor),("failed_trial",failed,driver._shell_origins,driver._beam_origins,2.)):
  load=np.zeros(n) if name=="reference" else driver._programme.load_at(factor)
  residual,tangent,*_=driver._assemble(state,factor,shell,beam,applied_load=load)
  matrix=tangent.toarray()
  for start in range(3,owner._shell_count,6):matrix[:,start:start+3]=matrix[:,start:start+3]@np.linalg.inv(_exp_terms(state.q[start:start+3])[1])
  actual=matrix[np.ix_(free,free)]*scales[free,None]*scales[None,free]/energy
  for start in rotations:matrix[start:start+3,start:start+3]+=.5*skew(residual[start:start+3])
  h=matrix[np.ix_(free,free)]*scales[free,None]*scales[None,free]/energy
  skew_ratio=float(np.linalg.norm(h-h.T)/np.linalg.norm(h))
  eigen,vectors=np.linalg.eig(h)
  symmetric=skew_ratio<=1e-9 and np.max(abs(eigen.imag))<=1e-10
  modes=[]
  for j in np.argsort(abs(eigen))[:3]:
   v=vectors[:,j];modes.append(dict(eigenvalue=float(eigen[j].real),nodal=float(np.linalg.norm(v[free<nodal])),retained=float(np.linalg.norm(v[(free>=nodal)&(free<n)])),multiplier=float(np.linalg.norm(v[free>=n]))))
  results[name]=dict(size=len(free),skew_ratio=skew_ratio,max_imaginary=float(np.max(abs(eigen.imag))),near_zero=sorted(eigen.real,key=abs)[:12],scaled_mode_content=modes,inertia=([dict(floor=f,negative=int(sum(eigen.real < -f)),zero=int(sum(abs(eigen.real)<=f)),positive=int(sum(eigen.real>f))) for f in (1e-12,1e-10,1e-8)] if symmetric else None))
  derivative=driver._programme.load_at(2.)-driver._programme.load_at(1.)
  loaded=np.flatnonzero(derivative);assert len(loaded)==1
  index=int(loaded[0]);assert index in free and index<nodal and index%6==2
  column=np.r_[-derivative,np.zeros(size-n)][free]*scales[free]/energy
  control=np.zeros(len(free));control[np.flatnonzero(free==index)[0]]=scales[index]
  column/=np.linalg.norm(column);control/=np.linalg.norm(control)
  u,singular,vt=np.linalg.svd(actual)
  bordered=np.block([[actual,column[:,None]],[control[None,:],np.zeros((1,1))]])
  bs=np.linalg.svd(bordered,compute_uv=False)
  j=np.argmin(abs(eigen));v=vectors[:,j].real
  results[name]["control_design"]=dict(control_global_dof=index,
    control_description="loaded beam105 global-z displacement",
    programme_derivative=float(derivative[index]),
    soft_eigen_load_projection=float(abs(v@column)),
    soft_eigen_control_projection=float(abs(control@v)),
    actual_left_singular_load_projection=float(abs(u[:,-1]@column)),
    actual_right_singular_control_projection=float(abs(control@vt[-1])),
    actual_min_singular=float(singular[-1]),bordered_min_singular=float(bs[-1]),
    actual_condition=float(singular[0]/singular[-1]),
    bordered_condition=float(bs[0]/bs[-1]))
 (root/"result.json").write_text(json.dumps(results,indent=2));print(json.dumps(results));owner.close()
else:
 spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV["PYTHONPATH"]=str(repo/"src");s.ENV["PYTEST_DISABLE_PLUGIN_AUTOLOAD"]="1"
 result=s.supervised([sys.executable,str(Path(__file__)),"child"],root/"run-v1")
 print(json.dumps({k:result[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
