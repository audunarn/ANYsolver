from pathlib import Path
import sys,json,importlib.util
root=Path(__file__).parent;repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
if len(sys.argv)>1:
 from dataclasses import asdict
 sys.path.insert(0,str(repo/"tests"))
 from anysolver import stiffened_shell as ss
 from test_stiffened_shell_bl5_coupled_material import coupled
 from test_stiffened_shell_bl5_finite import _action
 owner=ss.create_analysis(definition=coupled())
 saved=(root.parent/"r8-displacement-branch-v1/step-1.bin").read_bytes();owner.restore(saved)
 try:
  owner.solve(_action(-15.625),(-68e-6,),displacement_control=ss.DisplacementControl("beam",105,2),max_iterations=20,max_backtracks=12)
 except ss.DisplacementCorrectorFailure as error:
  assert owner.checkpoint()==saved
  data=dict(status="numerical_failure",message=str(error),detail=asdict(error.detail),prefix_unchanged=True)
 else:raise AssertionError("failure no longer reproduced")
 finally:owner.close()
 (root/"result.json").write_text(json.dumps(data,indent=2));print(json.dumps(data))
else:
 spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV["PYTHONPATH"]=str(repo/"src");s.ENV["PYTEST_DISABLE_PLUGIN_AUTOLOAD"]="1"
 result=s.supervised([sys.executable,str(Path(__file__)),"child"],root/"run-v1")
 print(json.dumps({k:result[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
