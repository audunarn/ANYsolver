from pathlib import Path
import sys,json,importlib.util,hashlib
root=Path(__file__).parent;installed=root.parent/"r8-displacement-installed-v1"
if len(sys.argv)>1:
 import numpy as np
 sys.path.insert(0,str(installed/"fixtures"))
 import anysolver
 from anysolver import stiffened_shell as ss
 from test_stiffened_shell_bl5_coupled_material import coupled
 from test_stiffened_shell_bl5_finite import _action
 assert Path(anysolver.__file__).resolve().is_relative_to((installed/"site").resolve())
 seed=root.parent/"r8-bl5-coupled-reversal-diagnostic-v1/p0-failure-prefix.bin"
 owner=ss.create_analysis(definition=coupled());owner.restore(seed.read_bytes())
 control=ss.DisplacementControl("beam",105,2);targets=(-66e-6,-68e-6,-70e-6,-72e-6)
 rows=[];restored=None
 data=dict(seed_sha256=hashlib.sha256(seed.read_bytes()).hexdigest(),targets=targets,
           wheel_sha256=json.loads((installed/"artifact.json").read_text())["wheel_sha256"],rows=rows)
 try:
  for i,target in enumerate(targets):
   result=owner.solve(_action(-15.625),(target,),displacement_control=control,max_iterations=20,max_backtracks=12)
   dof=owner._shell_count+6*owner._beam_index[105]+2
   raw=owner.checkpoint();(root/f"step-{i+1}.bin").write_bytes(raw)
   row=dict(target=target,amplitude=result.amplitude,load=float(result.applied_dead_load[dof]),
       equilibrium=result.free_equilibrium_ratio,gap=result.constraint_max,generation=result.generation,
       shell_alpha_max=float(np.max(result.shell_layer_alpha)),beam_alpha_max=float(np.max(result.beam_station_accumulated)))
   if restored is not None:
    resumed=restored.solve(_action(-15.625),(target,),displacement_control=control,max_iterations=20,max_backtracks=12)
    assert restored.checkpoint()==raw
    row["restart_exact"]=True
   rows.append(row);(root/"result.json").write_text(json.dumps(data,indent=2))
   if i==1:
    restored=ss.create_analysis(definition=coupled());restored.restore(raw)
    assert restored.checkpoint()==raw
  data["status"]="completed"
 except Exception as error:
  data["status"]="failed";data["failure"]=dict(type=type(error).__name__,message=str(error))
  (root/"accepted-prefix.bin").write_bytes(owner.checkpoint())
  raise
 finally:
  (root/"result.json").write_text(json.dumps(data,indent=2));owner.close()
  if restored is not None:restored.close()
else:
 spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV["PYTHONPATH"]=str(installed/"site");s.ENV["PYTEST_DISABLE_PLUGIN_AUTOLOAD"]="1"
 result=s.supervised([sys.executable,str(Path(__file__)),"child"],root/"run-v1")
 print(json.dumps({k:result[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
