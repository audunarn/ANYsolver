# B3-GE / E4-PL / B2 â€” active state, 2 October 2026

## Authority and checkout

Full Revision 8 goal/plan in ../b3-ge-e4-pl-coupling remains active. All mandatory
G0â€“G6, F01â€“F13, V01â€“V28, B01â€“B18 and final-release obligations remain open where
not accepted in the matrix. Experimental development does not confer qualification.
Solver: stiffened-main-reconcile-20261001, codex/stiffened-main-reconcile-20261001,
HEAD c32782ed. ANYfem: .worktrees/experimental-ge-panel-consumer, HEAD eaed5ec.
Local scoped commits permitted; no push/main merge/publication or contact-worker
communication. Do not disseminate the historical credential-containing
us3-modal-canary-v1.zip; no history-rewrite authority.

One heavy job at a time; ceiling 100k rows/600 s/8 GiB/8 threads. Current disposable
checks use 600 s/1 GiB/1 thread/JIT off. Local/Mistral unavailable earlier; no
reprobes. OpenAI review does not confer cross-family acceptance. Formal F03 remains
UNCONSUMED; protected original script SHA256:
c908b1f3e4d9467deb3a96876126d5488cd040503cc6c6ec485b8aeaecef9481.

## Delivered behavior and current candidate

Existing GE/B2 owner/consumer, elastic/staged/distributed BL5 and generalized-beam
material work remain as linked in the acceptance matrix. Do not repeat unchanged
campaigns. Latest committed material consumer is recorded at c32782ed.

Uncommitted coupled policy admits objective pure-Q4 J2 with generalized-beam
plasticity and BL5, with distinct binary/chart checkpoint histories. Native virtual
work identified incorrect legacy retained-role tiling: ONLY this new unaccepted
policy uses two force then four moment triples and a new identity field. Legacy
policies and scientific tolerances are unchanged. Earlier candidate pass evidence
is superseded for this policy; historical failures remain preserved.

Corrected-source P0 monotonic lifecycle passes simultaneous yielding, cancellation,
tangent checks, rejected-trial isolation, chart rebase and exact restored
continuation. Five selected installed checks pass (129.60 s), including compatible
legacy material routes. Wheel SHA256:
87146a8c0946ade59a2abba3f4c71478250d337f672ad4a8d04aed126bec6410.
All 398 source/wheel/site modules match; 219 imports onsite, JIT off and numerical
pools at one thread. This is bounded verification, not material-envelope acceptance.
[Evidence and failures](development/r8-bl5-coupled-material-20261002/results.md).

Dirty solver ownership: four material source files, coupled test, docs/evidence.
Dirty ANYfem: solve/stiffened_shell.py and coupled consumer test, strict coupled-v4.
Three affected ANYfem source checks pass against corrected solver (33.41 s); no
installed coupled-consumer claim. All owned jobs finished; none remain active.
No product changes to linear factorization or globalization. Full signed-history
tests remain unchanged in intent and failing, without skip/xfail. Candidate remains
uncommitted. Test evidence paths now use unique pytest temporary directories.

## Decision and next action

Signed P0 reversal accepts -484.375 N but fails toward -500 N. Coarse P1 is still
shell-elastic at 500 N. Correct scales did not remove the failure. A diagnostic
scaled solve greatly improves linear residual but follows the same failed path.
The 134-row transformed tangent has a soft direction at the failed state:
smallest positive scaled eigenvalue 1.27e-8 versus 1.14e-5 accepted. Inertia stays
56 negative/78 positive; skew is approximately 1e-16. The state is off equilibrium,
with different material predecessors: no physical limit point has been established.
Independent review agrees. Stop this diagnostic batch; do not increase budgets or
repeat the full reversal history automatically.

The bounded control-design check found loaded-tip translation/load coupling~0.307
and a bordered minimum singular value3.63e-5 versus1.27e-8. The private corrector
reached the saved displacement at-487.841N without altering its accepted seed.

The public experimental solve now accepts typed DisplacementControl for seeded
coupled-Q4 J2/generalized BL5. Actions define the fixed affine load direction;
targets are absolute translations. Typed results expose signed amplitude, actual
step history, physical rotations and separate chart coordinates, loads/reactions,
material states and connection work. All endpoint mechanics and checkpoint bytes
are prepared before atomic publication. Cancellation preserves complete prefixes.
Distinct snapshot mechanics/controller identities preserve authentic seed digest,
materials, poses and amplitudes without invented force-cursor history. Isolated
restore replays saved predecessors and checks equilibrium/compatibility/materials.

Nine latest public/framing source checks pass including a rebased force seed,
exact restored continuation, cancellation and prepublication failure. Independent
review corrected generation/history consistency and physical/chart output; changed
lines and earlier extraction then reviewed without further findings. Full scientific
acceptance is still open. Installed candidate:15checks pass on wheel f8d64a0b...311acb9;401modules match,
verified one-thread/JIT-off runtime. All owned runs completed. See results.

Current restrictions: force mode cannot resume a displacement history; fixed control
and load direction, no external loads, no adaptive displacement, selected recovery
or post-seed rebase. These are pending programme requirements, not final exclusions.
Dirty scope now includes the displacement controller/corrector/codec and tests,
owner dispatch/export plus earlier coupled material changes. No commits/push yet.

The bounded installed branch run has FAILED: target-66um accepted at-487.859N;
-68um exhausts backtracking. -70/-72um and planned midpoint restart were NOT reached.
Saved prefix: TEMP/r8-displacement-branch-v1/step-1.bin. A single final-increment
replay with new structured diagnostics reports equilibrium1.625, gap3.49e-13,
zero control error,61evaluations/7solves/54rejections. No tiny-tolerance issue or
physical instability conclusion. Stop this branch batch; no automatic smaller
step/longer interval/budget campaign. Evidence in displacement-branch-v1.zip.

Structured failure detail is now public with source integration verification;
installed wheel predates this diagnostic addition. Earlier patch-script failure
and unchanged test run are recorded distinctly. All owned jobs terminal.
Private signed displacement cutback state is implemented; six source checks pass
for negative targets/reversal, halving, restart and spent-budget preservation.
It reuses existing limit settings; no mechanical history replay or public adaptive
admission yet. New dirty module/test: _stiffened_shell_displacement_increment.py
and test_stiffened_shell_displacement_increment.py.
Next development: wire this state into atomic displacement publication and a
bounded adaptive checkpoint envelope, verify accepted-prefix cancellation/restart,
then consumer integration
on bounded known-working fixtures; this must not be presented as resolving the
failed branch. Before another branch experiment identify a specific material/
tangent or continuation-path discriminator from this failure, with focused review.

M2/F03 still lacks a controlled coupled clamp-transfer reference within 1%; U1
shear canary is 11.1423% too stiff. No automatic corrected-U1/refinement campaign.
Pressure assessment amendment awaits explicit user decision. Mixed/all-S3 director
histories, zero-load assessment, low-hardening convergence and full material,
topology, spectral, capacity, scale, external and platform obligations remain open.
[Pressure boundary](development/r8-ge-pressure-work-20261002/s3-director-integration.md).
