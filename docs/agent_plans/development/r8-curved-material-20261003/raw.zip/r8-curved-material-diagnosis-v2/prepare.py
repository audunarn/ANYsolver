from pathlib import Path
root=Path(__file__).parent
text=(root.parent/"r8-curved-material-diagnosis-v1/run.py").read_text()
start=text.index("        for factor in (.5,1.,.9,1.):")
end=text.index("        driver=owner._finite_driver",start)
text=text[:start]+"""        owner.restore((root.parent/"r8-curved-material-diagnosis-v1/direction/accepted-1.0.bin").read_bytes())
"""+text[end:]
text=text.replace("free=driver._free;","free=np.r_[owner._free,np.arange(owner._K.shape[0],k.shape[0])];")
(root/"run.py").write_text(text)
