from pathlib import Path
import sys,os,importlib.util,json
root=Path(__file__).parent;repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
if len(sys.argv)>1:
    import numpy as np
    from scipy.sparse.linalg import spsolve
    from test_stiffened_shell_curved_material import curved_material_panel,_actions
    from anysolver import stiffened_shell as ss
    from anysolver._stiffened_shell_ge_finite_experimental import _trial_work_ratio
    owner=ss.create_analysis(definition=curved_material_panel())
    try:
        owner.restore((root.parent/"r8-curved-material-diagnosis-v1/direction/accepted-1.0.bin").read_bytes())
        driver=owner._finite_driver;state=driver._state
        factor=1.003125;parent_shell=driver._shell_origins;parent_beam=driver._beam_origins
        residual,k,relative,gap,*_=driver._assemble(state,factor,parent_shell,parent_beam)
        free=np.r_[owner._free,np.arange(owner._K.shape[0],k.shape[0])];step=spsolve(k[free,:][:,free],-residual[free])
        full=np.zeros(k.shape[0]);full[free]=step;predicted=k@full
        groups={"shell":slice(0,owner._shell_count),"beam":slice(owner._shell_count,owner._shell_count+driver._beam_nodal),"retained":slice(owner._shell_count+driver._beam_nodal,owner._K.shape[0]),"constraints":slice(owner._K.shape[0],k.shape[0])}
        rows=[]
        for alpha in (1.,.5,.0625,1/4096,1e-4,1e-5):
            advanced=driver._advance(state,full,alpha)
            changed=driver._assemble(advanced,factor,parent_shell,parent_beam)
            derivative=(changed[0]-residual)/alpha
            rows.append(dict(alpha=alpha,equilibrium=changed[2],gap=changed[3],
                global_merit=_trial_work_ratio(changed[0][owner._free],factor*driver._pattern[owner._free],owner._coordinate_scale[owner._free]),
                groups={name:dict(predicted_norm=float(np.linalg.norm(predicted[s])),actual_norm=float(np.linalg.norm(derivative[s])),
                relative_error=float(np.linalg.norm(derivative[s]-predicted[s])/max(np.linalg.norm(predicted[s]),np.finfo(float).tiny))) for name,s in groups.items()}))
        smooth=driver._advance(state,full,.0625)
        current=driver._assemble(smooth,factor,parent_shell,parent_beam)
        expected=current[1]@full
        plateau=[]
        for h in (1e-4,1e-5):
            plus=driver._assemble(driver._advance(state,full,.0625+h),factor,parent_shell,parent_beam)[0]
            minus=driver._assemble(driver._advance(state,full,.0625-h),factor,parent_shell,parent_beam)[0]
            actual=(plus-minus)/(2*h)
            plateau.append(dict(h=h,error=float(np.linalg.norm((actual-expected)[free])/np.linalg.norm(expected[free]))))
        Path("direction.json").write_text(json.dumps(dict(equilibrium=relative,gap=gap,
            initial_global_merit=_trial_work_ratio(residual[owner._free],factor*driver._pattern[owner._free],owner._coordinate_scale[owner._free]),
            smooth_plateau=plateau,linear_residual=float(np.linalg.norm((k@full+residual)[free])),rows=rows),indent=2))
    finally:owner.close()
else:
    spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py");s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
    s.ENV["PYTHONPATH"]=str(repo/"src")+os.pathsep+str(repo/"tests")+os.pathsep+str(repo)
    r=s.supervised([sys.executable,str(Path(__file__)),"child"],root/"direction")
    print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
