from pathlib import Path
root=Path(__file__).parent
text=(root.parent/"r8-curved-material-diagnosis-v2/run.py").read_text()
text=text.replace('from anysolver import stiffened_shell as ss','from anysolver import stiffened_shell as ss\n    from anysolver._stiffened_shell_ge_finite_experimental import _trial_work_ratio')
text=text.replace('rows.append(dict(alpha=alpha,equilibrium=changed[2],gap=changed[3],',
'''rows.append(dict(alpha=alpha,equilibrium=changed[2],gap=changed[3],
                global_merit=_trial_work_ratio(changed[0][owner._free],factor*driver._pattern[owner._free],owner._coordinate_scale[owner._free]),''')
text=text.replace('Path("direction.json").write_text(json.dumps(dict(equilibrium=relative,gap=gap,linear_residual=',
'''smooth=driver._advance(state,full,.0625)
        current=driver._assemble(smooth,factor,parent_shell,parent_beam)
        expected=current[1]@full
        plateau=[]
        for h in (1e-4,1e-5):
            plus=driver._assemble(driver._advance(state,full,.0625+h),factor,parent_shell,parent_beam)[0]
            minus=driver._assemble(driver._advance(state,full,.0625-h),factor,parent_shell,parent_beam)[0]
            actual=(plus-minus)/(2*h)
            plateau.append(dict(h=h,error=float(np.linalg.norm((actual-expected)[free])/np.linalg.norm(expected[free]))))
        Path("direction.json").write_text(json.dumps(dict(equilibrium=relative,gap=gap,
            initial_global_merit=_trial_work_ratio(residual[owner._free],factor*driver._pattern[owner._free],owner._coordinate_scale[owner._free]),
            smooth_plateau=plateau,linear_residual=''')
(root/"run.py").write_text(text)
