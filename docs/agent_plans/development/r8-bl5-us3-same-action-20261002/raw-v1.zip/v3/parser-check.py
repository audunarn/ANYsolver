from pathlib import Path
import importlib.util, json, math, re

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('reference', ROOT/'runner.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
old = ROOT.parent/'r8-bl5-u1-us3-canary-v1/canary.dat'
text = old.read_text()
blocks = []
for i in range(1, 4):
    block = text.replace('S T E P       1', f'S T E P       {i}')
    block = block.replace('0.1000000E+01', f'0.{i}000000E+01')
    blocks.append(block)
combined = '\n'.join(blocks)
ids = [1,2,3,10,11,12]
u,e = module.parse(combined, ids)
assert u.shape == e.shape == (3,6,6) and all(math.isfinite(v) for v in e.flat)
assert module.printed('0.000000E+00')[1] == math.ulp(0.)
checks = {'three_complete_blocks_with_STEP_headings':True, 'zero_uncertainty_floor':True}
first = next(line for line in text.splitlines() if line.split() and line.split()[0]=='1')
for label, broken in (
    ('duplicate_node',combined.replace(first, first+'\n'+first, 1)),
    ('missing_component',combined.replace(first, '         1  0.0', 1)),
    ('nonfinite_token',combined.replace('2.153601E-10','NaN',1)),
    ('incomplete_step', '\n'.join(blocks[:2])),
    ('wrong_time',combined.replace('0.2000000E+01','0.4000000E+01'))):
    try: module.parse(broken, ids)
    except ValueError: checks[label] = True
    else: raise AssertionError(label+' accepted')
for value in (1.5264059574844862e-5,-1.5264059574844862e-5,0.,1e-300,1e300):
    token,decoded=module.cload_number(value)
    assert len(token)<=20 and math.isfinite(decoded)
    assert value==0. or abs(decoded-value)/abs(value)<=1e-12
checks['cload_width_and_signed_extremes'] = True
(ROOT/'parser-check.json').write_text(json.dumps(checks, indent=2)+'\n')
print(json.dumps(checks))
