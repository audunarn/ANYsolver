from pathlib import Path
import hashlib, json, zipfile

ROOT = Path(__file__).resolve().parent
REPO = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
EVIDENCE = REPO/'docs/agent_plans/development/r8-bl5-us3-same-action-20261002'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
EVIDENCE.mkdir(parents=True, exist_ok=False)
selected = {}
for version in ('v1','v2','v3'):
    directory = ROOT.parent/('r8-bl5-us3-same-action-'+version)
    for p in sorted(directory.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:
            selected[version+'/'+p.relative_to(directory).as_posix()] = p
archive = EVIDENCE/'raw-v1.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in selected.items(): z.write(p,name)
manifest = {'classification':'fixed-mesh same-action shell discriminator, not coupled qualification',
    'source_parent':'1e4e6d7adb55e450f6797458ce1ce338ef8ae3f9',
    'archive_sha256':sha(archive), 'archive_bytes':archive.stat().st_size, 'members':len(selected),
    'versions':{'v1':'prepared only, pre-review', 'v2':'exit201 CLOAD field-width error; partial2steps not scored',
                'v3':'corrected field serialization, completed3steps, same physical model'},
    'member_sha256':{name:sha(p) for name,p in selected.items()},
    'protected_native_inventory':'development/r8-bl5-endpoint-response-20261001/raw-v1.json',
    'protected_native_archive_sha256':'138017d65c6204e8e653a2f4694f85b287604ccabafd71b29d02f4bcf37a83b2'}
(EVIDENCE/'raw-v1.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('archive_sha256','archive_bytes','members','versions')}))
