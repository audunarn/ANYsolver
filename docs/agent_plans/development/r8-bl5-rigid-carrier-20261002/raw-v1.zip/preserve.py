from pathlib import Path
import hashlib,json,os,shutil,zipfile,importlib.metadata
ROOT=Path(__file__).resolve().parent
REPO=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
DEST=REPO/'docs/agent_plans/development/r8-bl5-rigid-carrier-20261002'
DEST.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={p.relative_to(ROOT).as_posix():p.read_bytes() for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
for label,folder in (('source-failed','anysolver-portable-ci-od9x38xb'),('source-repaired','anysolver-portable-ci-idpi__v9')):
    base=ROOT.parent/folder
    for p in base.rglob('*.json'):files[label+'/'+p.relative_to(base).as_posix()]=p.read_bytes()
    selection=json.loads((base/'P01/selection.json').read_text())
    for target,digest in selection['selected_file_sha256'].items():
        p=REPO/target;data=p.read_bytes()
        if label=='source-failed':data=data.replace(b'from scripts.r8_bl5_rigid_carrier_dev',b'from r8_bl5_rigid_carrier_dev')
        variants=(data,data.replace(b'\r\n',b'\n'),data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n'))
        data=next((d for d in variants if hashlib.sha256(d).hexdigest()==digest),None)
        assert data is not None,target
        files[label+'/'+target]=data
SUP=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-panel-resolution-installed-v1/matched-run.py')
files['supervisor.py']=SUP.read_bytes()
ART=ROOT.parent/'r8-b2-loaded-sections-installed-v2'
for name in ('solver-source-manifest.json','solver-wheel-identity.json'):files[name]=(ART/name).read_bytes()
files['dependencies.json']=(json.dumps({n:importlib.metadata.version(n) for n in ('numpy','scipy','numba','ANYmaterial','pytest','threadpoolctl','psutil')},indent=2)+'\n').encode()
known=[v.encode() for k,v in os.environ.items() if k in ('MISTRAL_API_KEY','OPENTOPO_API_KEY','PELYR_API_KEY') and v]
failures=[name for name,data in files.items() if any(secret in data for secret in known)]
assert not failures,failures
archive=DEST/'raw-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(files.items()):z.writestr(name,data)
record=dict(archive_sha256=sha(archive),members=len(files),known_credential_scan='clear',files={name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())})
(DEST/'raw-v1.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(path=str(DEST),members=len(files),archive_bytes=archive.stat().st_size,sha256=sha(archive))))
