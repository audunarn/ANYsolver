from pathlib import Path
import ast, hashlib, importlib.util, json, os, shutil, sys, zipfile
ROOT=Path(__file__).resolve().parent
REPO=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
ART=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-loaded-sections-installed-v2')
SUP=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-panel-resolution-installed-v1/matched-run.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(SUP)=='5837645ddf40e591451cbd58f8975ce8f026cb908e750044b848c8c04dcae5d4'
manifest=json.loads((ART/'solver-source-manifest.json').read_text())
wheel,=(ART/'solver-artifact/wheels').glob('*.whl')
assert sha(wheel)=='4c14d0942410f97b6e2ab397eb0d4e567cbff4169c05b391c5685c4df40d3b7c'
site=ART/'solver-artifact/site'
with zipfile.ZipFile(wheel) as z:
    for name,digest in manifest.items():
        rel=name.removeprefix('src/')
        assert sha(REPO/name)==digest and sha(site/rel)==digest
        assert hashlib.sha256(z.read(rel)).hexdigest()==digest
fixtures=ROOT/'fixtures'
if not fixtures.exists():
    (fixtures/'tests').mkdir(parents=True);(fixtures/'scripts').mkdir()
    pending=[REPO/'scripts/r8_bl5_rigid_carrier_dev.py',REPO/'scripts/b3_e4_bl5_coherent_aggregation_dev.py',REPO/'tests/test_bl5_rigid_carrier_reference_dev.py']
    copied=set()
    while pending:
        p=pending.pop()
        if p in copied:continue
        dest=fixtures/p.relative_to(REPO)
        shutil.copy2(p,dest);copied.add(p)
        for item in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            names=[]
            if isinstance(item,ast.ImportFrom) and item.module:names=[item.module]
            if isinstance(item,ast.Import):names=[n.name for n in item.names]
            for name in names:
                if name.startswith('test_'):pending.append(REPO/'tests'/(name+'.py'))
    (ROOT/'fixture-manifest.json').write_text(json.dumps({str(p.relative_to(ROOT)):sha(p) for p in fixtures.rglob('*.py')},indent=2),encoding='utf-8')
for relative,digest in json.loads((ROOT/'fixture-manifest.json').read_text()).items():
    p=ROOT/relative
    assert sha(p)==digest and sha(REPO/p.relative_to(fixtures))==digest
spec=importlib.util.spec_from_file_location('supervisor',SUP)
service=importlib.util.module_from_spec(spec);spec.loader.exec_module(service)
service.ENV.update(PYTHONPATH=os.pathsep.join((str(site),str(fixtures/'scripts'),str(fixtures/'tests'))),PYTHONNOUSERSITE='1')
(ROOT/'identity.json').write_text(json.dumps(dict(wheel_sha256=sha(wheel),modules=len(manifest),site=str(site),supervisor_sha256=sha(SUP),launcher_sha256=sha(Path(__file__))),indent=2),encoding='utf-8')
if len(sys.argv)>1:
    nx,ny,hc=map(int,sys.argv[1:])
    record=service.supervised([sys.executable,str(ROOT/'pilot.py'),str(nx),str(ny),str(hc)],ROOT/f'run-{nx}x{ny}-{hc}')
    print(json.dumps(record))
else:print('Preparation and installed identity verified')
