from pathlib import Path
import hashlib,json,sys
import numpy as np
from scipy.integrate import quad
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'fixtures/scripts'))
from r8_bl5_rigid_carrier_dev import carrier_reference
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for nx,ny,hc in ((16,4,32),(32,8,64),(64,16,128)):
    folder=ROOT/f'run-{nx}x{ny}-{hc}'/'outputs'
    summary=json.loads((folder/'summary.json').read_text())
    assert summary['status']=='COMPLETED_DEVELOPMENT_ONLY'
    physical=summary['physical']; L=physical['length_m']; EI=physical['EI_z_Nm2']; GA=physical['kGA_y_N']; M=physical['tip_moment_Nm']
    ref=lambda x:carrier_reference(L,EI,GA,M,x)
    transfer=json.loads((folder/'transfer.json').read_text())
    actual=np.array(transfer['polynomial_transfer_moments'])
    expected=np.zeros((3,6))
    for k in range(3):
        expected[k,1]=quad(lambda x:x**k*GA*ref(x)[1],0,L,epsabs=1e-10,epsrel=1e-12)[0]
        expected[k,5]=quad(lambda x:x**(k+1)*GA*ref(x)[1],0,L,epsabs=1e-10,epsrel=1e-12)[0]
    with np.load(folder/'state.npz') as z:
        reaction=z['reactions'][:6*len(z['xyz'])].reshape(-1,6)
        nshell=(nx+1)*(ny+1)
        root_y=float(reaction[nshell,1]);tip_y=float(reaction[nshell+hc,1])
    ref_root=-float(ref(0)[2]);ref_tip=float(ref(L)[2])
    record=dict(grid=[nx,ny,hc],input_sha256={p.name:sha(p) for p in (folder/'summary.json',folder/'transfer.json',folder/'state.npz')},
      tip_relative=summary['comparison']['tip_spin_relative'],
      force_and_moment_transfer_relative=((actual[:,[1,5]]-expected[:,[1,5]])/expected[:,[1,5]]).tolist(),
      beam_root_reaction_y_N=root_y,analytic_root_reaction_y_N=ref_root,
      beam_tip_reaction_y_N=tip_y,analytic_tip_reaction_y_N=ref_tip,
      root_force_error_on_applied_force_scale=(root_y-ref_root)/(abs(M)/L),
      tip_force_relative=(tip_y-ref_tip)/ref_tip,
      actual_transfer_moments=actual.tolist(),analytic_transfer_moments=expected.tolist(),
      boundary_layer_m=float(np.sqrt(EI/GA)),support_length_m=summary['policy']['span_halfcells']*summary['policy']['beam_spacing_m'],
      pointwise_position_gap_m=transfer['pointwise_translation_gap_max_m'],pullback_absolute=transfer['local_pullback_max_abs'],
      sampled_peak_tree_bytes=json.loads((folder.parent/'execution.json').read_text())['sampled_peak_tree_bytes'],
      interpretation='Rigid carrier only; finite weak constraints. Tip work and spin are one observable. Transfer moments/reaction partition add physical checks; no full coupled qualification.')
    rows.append(record)
record=dict(postprocessor_sha256=sha(Path(__file__)),cases=rows)
(ROOT/'assessment.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps([dict(grid=r['grid'],tip_relative=r['tip_relative'],transfer_relative=r['force_and_moment_transfer_relative'],tip_force_relative=r['tip_force_relative'],root_y=r['beam_root_reaction_y_N']) for r in rows]))
