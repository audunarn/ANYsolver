from pathlib import Path
import json,sys
import anysolver,numba
from threadpoolctl import threadpool_info
from r8_bl5_rigid_carrier_dev import run
site=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-loaded-sections-installed-v2/solver-artifact/site').resolve()
try:
    nx,ny,hc=map(int,sys.argv[1:])
    result=run(Path.cwd()/'outputs',nx,ny,hc)
    print(json.dumps({n:result[n] for n in ('status','native','comparison','checks')}))
    code=0 if result['status']=='COMPLETED_DEVELOPMENT_ONLY' else 1
finally:
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith('anysolver') and getattr(m,'__file__',None)}
    errors=[p for p in imports.values() if not Path(p).is_relative_to(site)]
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    assert all(p['num_threads']==1 for p in threadpool_info())
    Path('import-identity.json').write_text(json.dumps(dict(imports=imports,errors=errors,pools=threadpool_info(),jit_disabled=bool(numba.config.DISABLE_JIT),numba_threads=numba.get_num_threads()),indent=2),encoding='utf-8')
    assert not errors
sys.exit(code)
