from pathlib import Path
import numpy as np,json
from anysolver._ge_beam3_variational_shell import _quaternion_jets
ns={'__package__':'anysolver','__name__':'anysolver._fit_baseline_diagnostic'}
exec(compile((Path(__file__).parent/'fit-baseline.py').read_text(encoding='utf-8-sig'),'baseline','exec'),ns)
ref=np.array([[-1.,-.5,0.],[1.,-.5,0.],[1.,.5,0.],[-1.,.5,0.]])
rows=[]
for angle in (1e-12,-1e-12,1e-7,-1e-7):
    inc=np.array([[-2*np.sin(angle/2)**2,0.,np.sin(angle)],[0.,0.,0.],[-np.sin(angle),0.,-2*np.sin(angle/2)**2]])
    expected=np.array([np.cos(angle/2),0.,np.sin(angle/2),0.]);row={'angle':angle}
    for label,fn in [('baseline',ns['_quaternion_jets']),('candidate',_quaternion_jets)]:
        q=np.array([j.value for j in fn(ref,None,displacement=ref@inc.T)])
        if q@expected<0:q=-q
        row[label+'_rotation_component_error']=float(np.linalg.norm(q[1:]-expected[1:]))
    rows.append(row)
Path('comparison.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print(json.dumps(rows,indent=2))
