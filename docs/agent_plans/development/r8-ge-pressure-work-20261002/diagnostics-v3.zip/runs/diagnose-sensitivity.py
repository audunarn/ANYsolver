from pathlib import Path
import sys,json,numpy as np
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
sys.path.insert(0,str(repo/'tests'))
from test_stiffened_shell_ge_pressure_owner import definition
from anysolver import stiffened_shell as ss
from anysolver._stiffened_shell_ge_finite_experimental import FinitePointDriver,_State
import anysolver._ge_beam3_variational_shell as sm
p=Path(__file__).parent/'newton-v1/newton-state-2.npz'
z=np.load(p)
a=ss.create_analysis(definition=definition());driver=FinitePointDriver(a)
state=_State(**{k:(z[k] if k in z else None) for k in ('q','frames','cells','resultants','multipliers','shell_anchors')})
candidate=driver._advance(state,z['increment'],1.)
eid,e,slots,_=a._shell_parts[1];ref=a._shell_xyz[slots[::6]//6];mat=a._shell_model.get_material('shell')
rows=[]
for policy in ('current','component_reconstructed'):
    if policy!='current':
        text=(Path(__file__).parent/'diagnose-eigen.py').read_text(encoding='utf-8-sig').split('rows=[]')[0]
        exec(compile(text,'diagnostic','exec'))
    q0=state.q[slots];q1=candidate.q[slots]
    l0,D0,H0=sm.deformation(ref,q0,stable_translation=True)
    l1,D1,H1=sm.deformation(ref,q1,stable_translation=True)
    f0,K0,_=e.compute_nonlinear_response(a._shell_model.mesh,mat,l0,driver._shell_origins[1],3,True)
    f1,K1,_=e.compute_nonlinear_response(a._shell_model.mesh,mat,l1,driver._shell_origins[1],3,True)
    dl=l1-l0;linear_dl=D0@(q1-q0);df=f1-f0
    # Decompose actual spatial change into changing force and changing pullback.
    actual_change=(D1.T@f1-D0.T@f0)[13]
    predicted=(D0.T@K0@D0+np.einsum('i,ijk->jk',f0,H0))@(q1-q0)
    row=dict(policy=policy,actual_change=float(actual_change),predicted_change=float(predicted[13]),local_deformation_error=float((D0.T@K0@(dl-linear_dl))[13]),local_force_error=float((D0.T@(df-K0@dl))[13]),pullback_error=float(((D1-D0).T@f0-np.einsum('i,ijk,k->j',f0,H0,q1-q0))[13]),max_local_deformation_error=float(max(abs(dl-linear_dl))),max_local_force_error=float(max(abs(df-K0@dl))))
    rows.append(row)
    np.savez(policy+'.npz',l0=l0,l1=l1,linear_dl=linear_dl,f0=f0,f1=f1,K0=K0,D0=D0,D1=D1)
a.close()
Path('sensitivity.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print(json.dumps(rows,indent=2))

