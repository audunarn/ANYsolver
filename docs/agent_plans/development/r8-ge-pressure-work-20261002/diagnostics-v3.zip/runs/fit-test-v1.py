"""Physical small-rotation precision and differentiated normalization."""
import numpy as np
import pytest
from anysolver._ge_beam3_variational_shell import _quaternion_jets,deformation

@pytest.mark.parametrize('angle',[0.,1e-12,-1e-12,1e-7,-1e-7,.5,np.pi/2,2.])
def test_stable_fit_analytic_rotation_and_normalization(angle):
    ref=np.array([[-1.,-.5,0.],[1.,-.5,0.],[1.,.5,0.],[-1.,.5,0.]])
    s=np.sin(angle);cminus=-2*np.sin(angle/2)**2
    increment=np.array([[cminus,0.,s],[0.,0.,0.],[-s,0.,cminus]])
    u=ref@increment.T
    jets=_quaternion_jets(ref,None,displacement=u)
    q=np.array([v.value for v in jets]);dq=np.array([v.gradient for v in jets]);ddq=np.array([v.hessian for v in jets])
    expected=np.array([np.cos(angle/2),0.,np.sin(angle/2),0.])
    if q@expected<0:expected=-expected
    np.testing.assert_allclose(q,expected,rtol=2e-14,atol=1e-28 if abs(angle)<1e-6 else 1e-15)
    np.testing.assert_allclose(q@dq,0.,atol=3e-16)
    np.testing.assert_allclose(np.einsum('i,ijk->jk',q,ddq)+dq.T@dq,0.,atol=2e-15)

@pytest.mark.parametrize('count',[3,4])
def test_stable_fit_derivatives_at_finite_rotation_and_deformation(count):
    ref=np.array([[0.,0.,0.],[1.2,.1,0.],[.9,1.1,0.],[-.1,.9,0.]])[:count]
    u=.035*np.sin(np.arange(6*count)+.4)
    direction=np.cos(np.arange(len(u))+.6);h=2e-6
    value,d,second=deformation(ref,u,stable_translation=True)
    plus=deformation(ref,u+h*direction,stable_translation=True)
    minus=deformation(ref,u-h*direction,stable_translation=True)
    np.testing.assert_allclose((plus[0]-minus[0])/(2*h),d@direction,rtol=1e-7,atol=1e-9)
    np.testing.assert_allclose((plus[1]-minus[1])/(2*h),np.einsum('ijk,k->ij',second,direction),rtol=1e-6,atol=1e-9)
