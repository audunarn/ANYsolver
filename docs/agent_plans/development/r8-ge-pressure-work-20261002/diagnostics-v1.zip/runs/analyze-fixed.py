from pathlib import Path
import sys,json,numpy as np
from fractions import Fraction as F
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001');sys.path.insert(0,str(repo/'tests'))
from test_stiffened_shell_ge_pressure_owner import definition
from anysolver import stiffened_shell as ss
from anysolver.e4_pl_element import _QUALIFIED_Q4_BASE_NONLINEAR_KERNEL
root=Path(__file__).parent;data=np.load(root/'split-v1/fixed-state.npz',allow_pickle=False)
a=ss.create_analysis(definition=definition())
try:
    _,e,_,origin=a._shell_parts[1];mesh=a._shell_model.mesh;material=a._shell_model.get_material('shell')
    local=data['local'];D=data['D'];old=data['force']
    base,*_=_QUALIFIED_Q4_BASE_NONLINEAR_KERNEL(e,mesh,material,local,origin,3,True)
    correction=e._qualified_linear_correction(mesh,material,3)
    exact_local=[F(float(base[i]))+sum((F(float(correction[i,j]))*F(float(local[j])) for j in range(24)),F(0)) for i in range(24)]
    rounded=np.array(list(map(float,exact_local)))
    exact_contraction=float(sum((F(float(D[i,13]))*exact_local[i] for i in range(24)),F(0)))
    pressure=json.loads((root/'split-v1/split.json').read_text())['pressure']
    record=dict(max_local_error=float(np.max(abs(old-rounded))),exact_two_stage_contraction=exact_contraction,pressure=pressure,residual_exact_two_stage=exact_contraction-pressure,old_residual=float((D.T@old)[13]-pressure))
    Path('correction.json').write_text(json.dumps(record,indent=2));np.savez('local-force-parts.npz',base=base,correction=correction,rounded_exact=rounded)
    print(json.dumps(record,indent=2))
finally:a.close()
