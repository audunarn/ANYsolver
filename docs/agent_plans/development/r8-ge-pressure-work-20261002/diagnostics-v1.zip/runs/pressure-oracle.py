from pathlib import Path
import os,json,numpy as np,sys
from fractions import Fraction as F
r=Path(os.environ['TEMP'])/'r8-ge-pressure-source-v1';repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001');sys.path.insert(0,str(repo/'tests'))
from test_stiffened_shell_ge_pressure_owner import definition
from anysolver import stiffened_shell as ss
q=np.load(r/'split-v1/fixed-state.npz',allow_pickle=False)['q'];a=ss.create_analysis(definition=definition())
try:
    _,e,slots,_=a._shell_parts[1];xyz=a._shell_xyz[slots[::6]//6];u=q[slots].reshape(-1,6)[:,:3]
    x=[[F(float(xyz[i,j]))+F(float(u[i,j])) for j in range(3)] for i in range(4)]
    total=F(0);sign=e.sheet_area_orientation_sign(a._shell_model.mesh) if hasattr(e,'sheet_area_orientation_sign') else 1.
    for (xi,eta),weight in zip(e.gauss_points,e.gauss_weights):
        N,dx,dy=e.compute_shape_functions(float(xi),float(eta))
        tx=[sum((x[i][j]*F(float(dx[i])) for i in range(4)),F(0)) for j in range(3)]
        ty=[sum((x[i][j]*F(float(dy[i])) for i in range(4)),F(0)) for j in range(3)]
        total+=F(10)*F(float(sign))*F(float(weight))*F(float(N[2]))*(tx[2]*ty[0]-tx[0]*ty[2])
    current=json.loads((r/'split-v1/split.json').read_text())['pressure']
    record=dict(pressure=float(current),exact_binary64_geometry_and_products=float(total),difference=current-float(total))
    Path('pressure-oracle.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
finally:a.close()
