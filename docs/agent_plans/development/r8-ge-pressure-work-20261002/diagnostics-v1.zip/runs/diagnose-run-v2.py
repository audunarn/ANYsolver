from pathlib import Path
import importlib.util,sys
r=Path(__file__).parent
s=importlib.util.spec_from_file_location('s',r.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.ENV['PYTHONPATH']='C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/src'
m.supervised([sys.executable,str(r/'diagnose.py')],r/'diagnosis-v2')

