from pathlib import Path
import sys,json,numpy as np
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
sys.path.insert(0,str(repo/'tests'))
from test_stiffened_shell_ge_pressure_owner import definition,load
from anysolver import stiffened_shell as ss
from anysolver._stiffened_shell_ge_finite_experimental import FinitePointDriver
original=FinitePointDriver._assemble
rows=[]
def watch(self,state,factor,*args,**kwargs):
    result=original(self,state,factor,*args,**kwargs)
    applied=factor*self._external.evaluate(state)[0]
    free=self.owner._free;r=result[0][free];f=applied[free]
    ratios=np.divide(abs(r),abs(f),out=np.zeros_like(r),where=f!=0)
    at=int(np.argmax(ratios));scale=self.owner._coordinate_scale[free]
    global_ratio=float(np.linalg.norm(r*scale)/np.linalg.norm(f*scale))
    rows.append(dict(factor=factor,reported=result[2],global_ratio=global_ratio,gap=result[3],row=int(free[at]),residual=float(r[at]),applied=float(f[at]),active_ratio=float(ratios[at])))
    return result
FinitePointDriver._assemble=watch
a=ss.create_analysis(definition=definition())
try:
    try:a.solve(load(a),(.1,))
    except Exception as e:print(type(e).__name__,str(e))
finally:a.close()
Path('diagnosis.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows[:4]+rows[-2:],indent=2))
