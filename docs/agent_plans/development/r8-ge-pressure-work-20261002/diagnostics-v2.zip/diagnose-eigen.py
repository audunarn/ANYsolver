from pathlib import Path
import sys,numpy as np,json
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
sys.path.insert(0,str(repo/'tests'))
from test_stiffened_shell_ge_pressure_owner import definition,load
from anysolver import stiffened_shell as ss
original=np.linalg.eigh
counts=[0]
def refined(matrix,*args,**kwargs):
    values,vectors=original(matrix,*args,**kwargs)
    if np.shape(matrix)==(4,4):
        q=vectors[:,-1];pivot=int(np.argmax(abs(q)));rest=np.array([i for i in range(4) if i!=pivot])
        refined_q=np.zeros(4);refined_q[pivot]=1.
        refined_q[rest]=np.linalg.solve(values[-1]*np.eye(3)-matrix[np.ix_(rest,rest)],matrix[rest,pivot])
        refined_q/=np.linalg.norm(refined_q)
        if q[pivot]<0:refined_q=-refined_q
        vectors[:,-1]=refined_q;counts[0]+=1
    return values,vectors
# Keep the protected NumPy runtime untouched; vary only the private development map.
import types
import anysolver._ge_beam3_variational_shell as shellmap
class Proxy:
    def __init__(self,target,**overrides):self.target=target;self.overrides=overrides
    def __getattr__(self,name):return self.overrides[name] if name in self.overrides else getattr(self.target,name)
fn=shellmap._quaternion_jets
globals_copy=dict(fn.__globals__)
globals_copy['np']=Proxy(np,linalg=Proxy(np.linalg,eigh=refined))
replacement=types.FunctionType(fn.__code__,globals_copy,fn.__name__,fn.__defaults__,fn.__closure__)
replacement.__kwdefaults__=fn.__kwdefaults__
shellmap._quaternion_jets=replacement
rows=[]
for kind in ('q4','mixed','s3'):
    a=ss.create_analysis(definition=definition(kind))
    try:
        r=a.solve(load(a),(.1,));rows.append(dict(kind=kind,status=r.status))
    except Exception as e:rows.append(dict(kind=kind,error=type(e).__name__,detail=str(e)))
    finally:a.close()
Path('result.json').write_text(json.dumps(dict(rows=rows,eigensolves=counts[0]),indent=2),encoding='utf-8')
print(json.dumps(rows,indent=2))

