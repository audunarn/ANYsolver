from pathlib import Path
import sys,json,numpy as np
from math import fsum
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
sys.path.insert(0,str(repo/'tests'))
from test_stiffened_shell_ge_pressure_owner import definition,load
from anysolver import stiffened_shell as ss
from anysolver._stiffened_shell_ge_finite_experimental import FinitePointDriver
assemble=FinitePointDriver._assemble
advance=FinitePointDriver._advance
cache={}; rows=[]; pending={}
def watch_assembly(self,state,factor,*args,**kwargs):
    result=assemble(self,state,factor,*args,**kwargs)
    cache[id(state)]=(state,result)
    if id(state) in pending:
        record=pending.pop(id(state));record.update(actual_row31=float(result[0][31]),actual_relative=float(result[2]))
        rows.append(record)
    return result
def watch_advance(self,state,increment,amount):
    candidate=advance(self,state,increment,amount)
    parent=cache[id(state)][1]
    if amount==1 and parent[2]<1e-5:
        residual,matrix=parent[:2]; csr=matrix.tocsr()
        predicted=np.array([fsum([float(residual[i])]+[float(v)*float(increment[j]) for j,v in zip(csr.indices[csr.indptr[i]:csr.indptr[i+1]],csr.data[csr.indptr[i]:csr.indptr[i+1]])]) for i in range(len(residual))])
        free=self.owner._free
        record=dict(parent_relative=float(parent[2]),parent_row31=float(residual[31]),predicted_row31=float(predicted[31]),predicted_free_max=float(max(abs(predicted[free]))),step_max=float(max(abs(increment))),shell_step_max=float(max(abs(increment[:self.owner._shell_count]))),unchanged_shell_entries=int(np.count_nonzero((candidate.q[:self.owner._shell_count]==state.q[:self.owner._shell_count])&(increment[:self.owner._shell_count]!=0))))
        pending[id(candidate)]=record
        payload={k:getattr(state,k) for k in ('q','frames','cells','resultants','multipliers','shell_anchors') if getattr(state,k) is not None}
        np.savez('newton-state-'+str(len(rows))+'.npz',**payload,increment=increment,residual=residual,predicted=predicted,candidate_q=candidate.q)
    return candidate
FinitePointDriver._assemble=watch_assembly
FinitePointDriver._advance=watch_advance
a=ss.create_analysis(definition=definition())
try:
    try:a.solve(load(a),(.1,))
    except Exception as e:print(type(e).__name__,str(e))
finally:a.close()
Path('newton.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print(json.dumps(rows,indent=2))
