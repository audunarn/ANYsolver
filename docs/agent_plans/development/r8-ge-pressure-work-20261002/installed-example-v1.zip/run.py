from pathlib import Path
import sys,json,importlib.util
root=Path(__file__).parent;site=root/'site'
if len(sys.argv)>1:
    sys.path.insert(0,str(root/'fixtures'))
    import anysolver,numba,threadpoolctl
    from importlib import metadata
    from stiffened_shell_ge_pressure import workflow
    assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
    def pools():
        p=threadpoolctl.threadpool_info();assert p and all(x['num_threads']==1 for x in p)
        assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
        return p
    pools();result=workflow()
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith('anysolver') and getattr(m,'__file__',None)}
    assert all(Path(p).is_relative_to(site.resolve()) for p in imports.values())
    Path('result.json').write_text(json.dumps(result,indent=2)+'\n')
    Path('runtime.json').write_text(json.dumps(dict(imports=imports,pools=pools(),numba_threads=numba.get_num_threads(),jit_disabled=bool(numba.config.DISABLE_JIT),python=sys.version,dependencies={n:metadata.version(n) for n in ('numpy','scipy','numba','ANYmaterial','ANYsolver')}),indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],equilibrium=result['equilibrium'],imports=len(imports))))
else:
    spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
    s.ENV['PYTHONPATH']=str(site)
    s.supervised([sys.executable,str(Path(__file__)),'child'],root/'example-v1')
