from pathlib import Path
import sys,json,numpy as np
from fractions import Fraction as F
from dataclasses import replace
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
sys.path.insert(0,str(repo/'tests'))
from test_stiffened_shell_ge_pressure_owner import definition,load
from anysolver import stiffened_shell as ss
import anysolver._stiffened_shell_ge_finite_experimental as fd
from anysolver._ge_beam3_variational_shell import deformation
from anysolver._ge_beam3_pose_joint import RigidPoseJoint,_exp_terms
orig_shell=fd.variational_shell_response;orig_joint=RigidPoseJoint.evaluate_ports

def exactdot(a,b):return float(sum((F(float(x))*F(float(y)) for x,y in zip(a,b)),F(0)))
def shell(model,element,displacement,origin,layers,**kw):
    force,tangent,state=orig_shell(model,element,displacement,origin,layers,**kw)
    ref=np.array([model.mesh.nodes[i].coords() for i in element.node_ids])
    local,D,_=deformation(ref,displacement,rotation_anchors=kw.get('rotation_anchors'),stable_translation=kw.get('stable_translation',False))
    f,_,_=element.compute_nonlinear_response(model.mesh,model.get_material(element.material_name),local,origin,layers,True)
    force=force.copy()
    for i in range(len(force)):
        if i%6<3:force[i]=exactdot(D[:,i],f)
    return force,tangent,state

def joint(self,positions,anchors,multipliers,**kw):
    trial=orig_joint(self,positions,anchors,multipliers,**kw)
    rs=_exp_terms(kw['rotation_coordinates'][0])[0]@anchors[0]
    f=trial.pose.residual.copy()
    for i in range(3):f[i]=-exactdot(rs[i],multipliers[:3]);f[6+i]=-f[i]
    return replace(trial,pose=replace(trial.pose,residual=f))
fd.variational_shell_response=shell
RigidPoseJoint.evaluate_ports=joint
owner=ss.create_analysis(definition=definition('mixed'))
try:
    try:
        result=owner.solve(load(owner),(.1,.2,.3));report=dict(status=result.status,steps=result.accepted_factors)
    except Exception as e:report=dict(error=type(e).__name__,detail=str(e),generation=owner._generation)
finally:owner.close()
Path('result.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
