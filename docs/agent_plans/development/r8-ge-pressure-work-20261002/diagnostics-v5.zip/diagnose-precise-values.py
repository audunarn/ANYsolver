from pathlib import Path
import sys,json,numpy as np
from decimal import Decimal as D,localcontext
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
sys.path.insert(0,str(repo/'tests'))
from test_stiffened_shell_ge_pressure_owner import definition,load
from anysolver import stiffened_shell as ss
import anysolver._ge_beam3_variational_shell as sm
old=sm.deformation

def solve(A,b):
    a=[list(row)+[rhs] for row,rhs in zip(A,b)];n=len(b)
    for j in range(n):
        k=max(range(j,n),key=lambda k:abs(a[k][j]));a[j],a[k]=a[k],a[j]
        divisor=a[j][j];a[j]=[v/divisor for v in a[j]]
        for i in range(n):
            if i!=j:
                factor=a[i][j];a[i]=[v-factor*w for v,w in zip(a[i],a[j])]
    return [row[-1] for row in a]

def precise(ref,u,**kw):
    values,gradient,hessian=old(ref,u,**kw)
    if not kw.get('stable_translation',False):return values,gradient,hessian
    n=len(ref);z=D(0);one=D(1)
    with localcontext() as ctx:
        ctx.prec=60
        rc=[[D(float(v)) for v in row] for row in ref]
        du=[[D(float(v)) for v in row[:3]] for row in np.asarray(u).reshape(-1,6)]
        for arr in (rc,du):
            centre=[sum((row[j] for row in arr),z)/n for j in range(3)]
            for row in arr:
                for j in range(3):row[j]-=centre[j]
        c=[[sum(((rc[k][i]+du[k][i])*rc[k][j] for k in range(n)),z) for j in range(3)] for i in range(3)]
        tr=sum((c[i][i] for i in range(3)),z);v=[c[2][1]-c[1][2],c[0][2]-c[2][0],c[1][0]-c[0][1]]
        m=[[tr]+v]+[[v[i]]+[c[i][j]+c[j][i]-(tr if i==j else z) for j in range(3)] for i in range(3)]
        q=[D(x.value) for x in sm._quaternion_jets(ref,None,displacement=np.asarray(u).reshape(-1,6)[:,:3])]
        lam=sum((q[i]*m[i][j]*q[j] for i in range(4) for j in range(4)),z)
        for _ in range(4):
            residual=[sum((m[i][j]*q[j] for j in range(4)),z)-lam*q[i] for i in range(4)]
            matrix=[[m[i][j]-(lam if i==j else z) for j in range(4)]+[-q[i]] for i in range(4)]+[q+[z]]
            correction=solve(matrix,[-r for r in residual]+[(one-sum((x*x for x in q),z))/2])
            q=[q[i]+correction[i] for i in range(4)];lam+=correction[4]
        w,a,b,d=q
        inc=[[-2*(b*b+d*d),2*(a*b-w*d),2*(a*d+w*b)],[2*(a*b+w*d),-2*(a*a+d*d),2*(b*d-w*a)],[2*(a*d-w*b),2*(b*d+w*a),-2*(a*a+b*b)]]
        for i in range(n):
            for j in range(3):
                values[6*i+j]=float(du[i][j]+sum((inc[k][j]*(du[i][k]+rc[i][k]) for k in range(3)),z))
    return values,gradient,hessian
sm.deformation=precise
owner=ss.create_analysis(definition=definition('mixed'))
try:
    try:
        r=owner.solve(load(owner),(.1,.2,.3));report=dict(status=r.status,steps=r.accepted_factors)
    except Exception as e:report=dict(error=type(e).__name__,detail=str(e),generation=owner._generation)
finally:owner.close()
Path('result.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
