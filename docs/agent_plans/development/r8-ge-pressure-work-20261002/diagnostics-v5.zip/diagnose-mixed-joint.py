from pathlib import Path
import sys,json,numpy as np
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
sys.path.insert(0,str(repo/'tests'))
from test_stiffened_shell_ge_pressure_owner import definition,load
from anysolver import stiffened_shell as ss
from anysolver._stiffened_shell_ge_finite_experimental import FinitePointDriver
original=FinitePointDriver._assemble
rows=[]
best=[float("inf"),None,None]
def watch(self,state,factor,*args,**kwargs):
    result=original(self,state,factor,*args,**kwargs)
    applied=factor*self._external.evaluate(state)[0]
    free=self.owner._free;r=result[0][free];f=applied[free]
    ratios=np.divide(abs(r),abs(f),out=np.zeros_like(r),where=f!=0)
    at=int(np.argmax(ratios));scale=self.owner._coordinate_scale[free]
    global_ratio=float(np.linalg.norm(r*scale)/np.linalg.norm(f*scale))
    rows.append(dict(factor=factor,reported=result[2],global_ratio=global_ratio,gap=result[3],row=int(free[at]),residual=float(r[at]),applied=float(f[at]),active_ratio=float(ratios[at])))
    if result[2]<best[0]:best[:]=[result[2],state,self]
    return result
FinitePointDriver._assemble=watch
a=ss.create_analysis(definition=definition('mixed'))
try:
    try:a.solve(load(a),(.1,))
    except Exception as e:print(type(e).__name__,str(e))
finally:
    from fractions import Fraction as F
    from math import fsum
    from anysolver._ge_beam3_variational_shell import deformation
    state,driver=best[1:];eid,element,slots,_=a._shell_parts[1]
    local,D,second=deformation(a._shell_xyz[slots[::6]//6],state.q[slots],stable_translation=True)
    force,tangent,candidate=element.compute_nonlinear_response(a._shell_model.mesh,a._shell_model.get_material('shell'),local,driver._shell_origins[1],3,True)
    products=D[:,6]*force
    exact=float(sum((F(float(x))*F(float(y)) for x,y in zip(D[:,6],force)),F(0)))
    actual=float((D.T@force)[6]);rounded=fsum(map(float,products))
    pressure=.1*driver._external.evaluate(state)[0][12]
    detail=dict(row=12,local_slot=6,pressure=float(pressure),blas=actual,fsum_rounded=rounded,exact_products=exact,blas_error=actual-exact,fsum_error=rounded-exact,absolute_product_sum=fsum(map(float,abs(products))),largest_product=float(max(abs(products))),residual_blas=actual-pressure,residual_exact=exact-pressure)
    linear=tangent@local
    exact_local=np.array([float(sum((F(float(x))*F(float(y)) for x,y in zip(row,local)),F(0))) for row in tangent])
    exact_linear_pullback=float(sum((F(float(x))*F(float(y)) for x,y in zip(D[:,6],exact_local)),F(0)))
    detail.update(local_force_linear_error=float(np.max(abs(force-linear))),exact_linear_pullback=exact_linear_pullback,spatial_delta=exact_linear_pullback-actual,best_global_ratio=best[0])
    from anysolver._stiffened_shell_ge_finite_experimental import _position_pair
    from anysolver._ge_beam3_pose_joint import _exp_terms
    i=2;joint=a._connections[i];js=a._joint_slots[i]
    shell_node=js[0]//6;beam_node=(js[6]-a._shell_count)//6
    sp,sl=_position_pair(a._shell_xyz[shell_node],state.q[js[:3]])
    bp,bl=_position_pair(driver._reference_positions[beam_node],state.q[js[6:9]])
    anchors=np.array((np.eye(3) if state.shell_anchors is None else state.shell_anchors[shell_node],state.frames[beam_node]))
    coordinates=np.zeros((2,3));coordinates[0]=state.q[js[3:6]]
    multipliers=state.multipliers[6*i:6*i+6]
    trial=joint.evaluate_ports(np.array((sp,bp)),anchors,multipliers,rotation_coordinates=coordinates,charted_ports=(True,False),position_low=np.array((sl,bl)))
    rs=_exp_terms(coordinates[0])[0]@anchors[0]
    exact_joint=float(-sum((F(float(x))*F(float(y)) for x,y in zip(rs[0],multipliers[:3])),F(0)))
    joint_actual=float(trial.pose.residual[0])
    detail.update(joint_type=type(joint).__module__,joint_actual=joint_actual,exact_joint=exact_joint,joint_delta=exact_joint-joint_actual,assembled_actual=fsum((actual,joint_actual,-pressure)),assembled_exact=fsum((exact_linear_pullback,exact_joint,-pressure)))
    np.savez('full-trial.npz',**{k:getattr(state,k) for k in ('q','frames','cells','resultants','multipliers','shell_anchors') if getattr(state,k) is not None},joint_rotation=rs,joint_force=trial.pose.residual)
    Path('split.json').write_text(json.dumps(detail,indent=2))
    np.savez('fixed-state.npz',q=state.q,local=local,D=D,force=force,tangent=tangent)
    print(json.dumps(detail,indent=2))
    a.close()
Path('diagnosis.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows[:4]+rows[-2:],indent=2))
