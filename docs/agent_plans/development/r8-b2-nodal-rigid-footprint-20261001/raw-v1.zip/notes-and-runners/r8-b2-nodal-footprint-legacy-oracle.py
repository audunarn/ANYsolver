from pathlib import Path
from dataclasses import asdict
import hashlib, json, sys, zipfile
import numpy as np
from scipy import sparse
import numba, threadpoolctl
from anysolver import stiffened_shell
from test_stiffened_shell_b2_q4_panel_experimental import _panel

r=Path.cwd(); site=Path(sys.argv[1]).resolve(); artifact=site.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((artifact/'source-manifest.json').read_text())
wheel=next((artifact/'wheels').glob('*.whl'))
with zipfile.ZipFile(wheel) as z:
    names={p for p in z.namelist() if p.startswith('anysolver/') and p.endswith('.py')}
    assert names=={p.removeprefix('src/') for p in source}
    for p,h in source.items():
        installed=site/p.removeprefix('src/')
        assert sha(installed)==h and z.read(p.removeprefix('src/'))==installed.read_bytes(),p
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
nodes,shells,members,points,free=_panel()
T=sparse.eye(54,format='csr')[:,free]; u0=np.zeros(54)
owner=stiffened_shell.create_analysis(definition=stiffened_shell.B2Q4PanelDefinition(
    stiffened_shell.B2_E4_PL_FAST_LINEAR_V1,nodes,shells,members,points,T,u0))
try:
    load=np.zeros(54);load[14]=-.12;load[32]=-.16;load[49]=.08
    results=[owner.solve_linear(scale*load) for scale in (1.,1.7)]
    assert all(v.status=='completed' for v in results)
    cases=tuple((f'case-{i}',(i+1)*load) for i in range(10))
    batch=owner.solve_linear_many(cases,selected_dofs=(14,32,49),selected_points=('joint-right',),recover_members={'beam-left':(0.,.5,1.)})
    assert batch.status=='completed' and batch.factorization_count==1
    arrays={}
    for name in ('_K','_C','_T'):
        matrix=getattr(owner,name).tocsr()
        arrays.update({name+'_data':matrix.data,name+'_indices':matrix.indices,name+'_indptr':matrix.indptr,name+'_shape':np.array(matrix.shape)})
    arrays['u0']=owner._u0
    np.savez_compressed(r/'operators.npz',**arrays)
    payload={'capabilities':asdict(owner.capabilities),'shell_ids':owner.shell_node_ids,'beam_ids':owner.beam_node_ids,'point_ids':owner.point_ids,'results':[asdict(v) for v in results],'batch':asdict(batch)}
    (r/'observables.json').write_text(json.dumps(payload,sort_keys=True,indent=2,allow_nan=False))
finally:owner.close()
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0]=='anysolver' and getattr(m,'__file__',None)}
assert all(Path(p).is_relative_to(site) for p in imports.values())
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
(r/'identity.json').write_text(json.dumps({'wheel_sha256':sha(wheel),'matching_modules':len(source),'imports':imports,'threads':pools,'numba_threads':numba.get_num_threads(),'jit_disabled':True,'fixtures':{p.name:sha(p) for p in Path(sys.argv[2]).glob('*.py')}},indent=2))
print(json.dumps({'status':'passed','wheel_sha256':sha(wheel),'modules':len(source),'onsite_imports':len(imports),'observables_sha256':sha(r/'observables.json')}))
