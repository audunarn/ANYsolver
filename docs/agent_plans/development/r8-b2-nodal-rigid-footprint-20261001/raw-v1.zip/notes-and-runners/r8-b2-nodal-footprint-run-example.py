from pathlib import Path
import contextlib,io,runpy,json,sys,hashlib
import anysolver,numba,threadpoolctl
r=Path.cwd();site=Path(sys.argv[1]).resolve();example=Path(sys.argv[2])
assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpoolctl.threadpool_info())
output=io.StringIO()
with contextlib.redirect_stdout(output):runpy.run_path(str(example),run_name='__main__')
text=output.getvalue();payload=json.loads(text)
assert payload['status']=='completed' and payload['production_qualified'] is False
assert payload['factorization_count']==1
(r/'outputs.json').write_text(text)
imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items() if n.split('.')[0]=='anysolver' and getattr(m,'__file__',None)}
assert all(Path(p).is_relative_to(site) for p in imports.values())
pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
(r/'identity.json').write_text(json.dumps({'example_sha256':hashlib.sha256(example.read_bytes()).hexdigest(),'imports':imports,'import_sha256':{n:hashlib.sha256(Path(p).read_bytes()).hexdigest() for n,p in imports.items()},'threads':pools,'numba_threads':1,'jit_disabled':True},indent=2))
print(json.dumps({'status':'passed','onsite_imports':len(imports),'law':payload['law'],'factorization_count':payload['factorization_count']}))
