from pathlib import Path
import hashlib,json,zipfile
r=Path(r'C:/Users/AUDUNA~1/AppData/Local/Temp')
out=r/'r8-b2-nodal-footprint-evidence-v1.zip';assert not out.exists()
files={}
def add(p,key):
    if p.is_file():
        assert key not in files,key
        files[key]=p
for name in ('r8-b2-nodal-footprint-installed-v1','r8-b2-nodal-footprint-legacy-old-v1',
             'r8-b2-nodal-footprint-legacy-old-v2','r8-b2-nodal-footprint-legacy-new-v1',
             'r8-b2-nodal-footprint-fixtures-old-v1','r8-b2-nodal-footprint-fixture-tree-old-v2',
             'r8-b2-nodal-footprint-example-installed-v1'):
    base=r/name;assert base.is_dir(),base
    for p in sorted(base.rglob('*')):
        rel=p.relative_to(base)
        if any(v in ('site','build-source','__pycache__','.pytest_cache') for v in rel.parts):continue
        if p.suffix in ('.pyc','.nbc','.nbi'):continue
        add(p,name+'/'+rel.as_posix())
    if (base/'build-source').exists():
        for n in ('_stiffened_shell_b2_nodal_footprint.py','_stiffened_shell_b2_q4_panel_experimental.py','stiffened_shell.py'):
            add(base/'build-source/src/anysolver'/n,name+'/runtime-source/anysolver/'+n)
for pattern in ('r8-b2-nodal*.py','r8-b2-nodal*.json','r8-b2-nodal*.md','r8-prepare-b2-nodal*.py'):
    for p in sorted(r.glob(pattern)):add(p,'notes-and-runners/'+p.name)
add(r/'r8-nodal-footprint-command-bounded.py','notes-and-runners/reused-command-bounded.py')
manifest={k:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'original_path':str(p.resolve())} for k,p in sorted(files.items())}
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for k,p in sorted(files.items()):z.write(p,k)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(out) as z:
    for k,v in manifest.items():assert hashlib.sha256(z.read(k)).hexdigest()==v['sha256'],k
identity={'files':len(manifest),'raw_bytes':sum(v['bytes'] for v in manifest.values()),'archive_bytes':out.stat().st_size,'archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'scope':'bounded static experimental source/artifact/raw failures/runners/fixtures/review; qualification open'}
(r/'r8-b2-nodal-footprint-evidence-v1-identity.json').write_text(json.dumps(identity,indent=2))
print(json.dumps(identity))
