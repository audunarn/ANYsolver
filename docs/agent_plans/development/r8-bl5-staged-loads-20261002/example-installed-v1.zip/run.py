from pathlib import Path
import sys,json,importlib.util
root=Path(__file__).parent
site=root.parent/'r8-bl5-staged-installed-v1/site'
if len(sys.argv)>1:
    sys.path.insert(0,str(root/'fixtures'))
    import anysolver,pytest,numba,threadpoolctl
    assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
    code=pytest.main(['-q','-p','no:cacheprovider','--junitxml=result.xml',str(root/'fixtures/test_example.py')])
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith('anysolver') and getattr(m,'__file__',None)}
    assert all(Path(p).is_relative_to(site.resolve()) for p in imports.values())
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p['num_threads']==1 for p in pools)
    assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
    Path('runtime.json').write_text(json.dumps(dict(imports=imports,pools=pools,python=sys.version,jit_disabled=True),indent=2))
    raise SystemExit(code)
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=str(site);s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
r=s.supervised([sys.executable,str(Path(__file__)),'child'],root/'test-v1')
print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
