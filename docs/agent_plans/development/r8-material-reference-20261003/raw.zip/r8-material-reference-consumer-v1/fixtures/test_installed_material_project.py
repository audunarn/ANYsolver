from dataclasses import replace
import json
import numpy as np
from anysolver import stiffened_shell as ss
from anyfem.solve.stiffened_shell import ExperimentalGEPointPanel,save_case,load_case
from anyfem.io.project_file import save_project,load_project
from anyfem.model.project import Project
from anyfem.model.records import AnalysisDefinition
from test_stiffened_shell_curved_material import curved_material_panel,_actions,assert_generalized_records_equal


def test_native_material_project_actual_history_and_restart(tmp_path,request):
 d=curved_material_panel()
 changes=tuple(ss.ReferencePosePerturbation('shell',n,(0.,0.,1e-4*(p[1]+.5))) for n,p in zip(d.shell.node_ids,d.shell.coordinates_m))
 reference=ss.create_stress_free_point_reference(d,changes)
 assert reference.source_identity!=reference.target_identity and reference.stress_free_scaled_max<=1e-9
 d=reference.definition
 shell=replace(d.shell,coordinates_m=tuple(tuple(float(v) for v in row) for row in d.shell.coordinates_m))
 panel=ExperimentalGEPointPanel(shell,d.beams,d.points,d.fixed,_actions(),q4_pullback_policy=d.q4_pullback_policy,shell_reference_policy=d.shell_reference_policy)
 reopened=load_case(save_case(panel,tmp_path/'material.anyfem-ge.json'));assert reopened.to_dict()==panel.to_dict()
 project=Project('curved simultaneous yielding',mesh_only=True)
 record=AnalysisDefinition.experimental_point_panel('material panel',reopened);project.add_analysis(record)
 path=save_project(project,tmp_path/'material.anyfem')
 stored=load_project(path).analyses[record.id]
 owner=stored.create_point_panel_analysis();request.addfinalizer(owner.close)
 result=owner.solve(panel.actions,(.5,1.),max_iterations=20,max_backtracks=12)
 assert max(max(v) for v in result.shell_layer_alpha)>0.
 assert max(max(v) for v in result.beam_station_accumulated)>0.
 assert result.beam_generalized_material
 prefix=owner.checkpoint();fresh=load_project(path).analyses[record.id].create_point_panel_analysis();request.addfinalizer(fresh.close)
 restored=fresh.restore(prefix);assert fresh.checkpoint()==prefix
 assert_generalized_records_equal(result.beam_generalized_material,restored.beam_generalized_material)
 history=[]
 for target in (.9,1.1):
  b=16 if target==1.1 else 12
  actual=owner.solve(panel.actions,(target,),max_iterations=20,max_backtracks=b)
  repeated=fresh.solve(panel.actions,(target,),max_iterations=20,max_backtracks=b)
  assert actual.free_equilibrium_ratio<=1e-8 and actual.constraint_max<=1e-9
  assert owner.checkpoint()==fresh.checkpoint()
  assert_generalized_records_equal(actual.beam_generalized_material,repeated.beam_generalized_material)
  np.testing.assert_array_equal(actual.cell_resultants,repeated.cell_resultants)
  np.testing.assert_array_equal(actual.shell_layer_alpha,repeated.shell_layer_alpha)
  history.append(dict(target=target,max_backtracks=b,equilibrium=actual.free_equilibrium_ratio,gap=actual.constraint_max))
 from pathlib import Path
 Path('material-history.json').write_text(json.dumps(dict(status=panel.status,identity=owner.preflight()['identity'],history=history),indent=2))
