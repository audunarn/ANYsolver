# B3-GE / E4-PL / B2 — active state, 2 October 2026

## Authority and restart

Revision8 plan/goal in ../b3-ge-e4-pl-coupling remains active. Full G0–G6,
F01–F13,V01–V28,B01–B18 scope and scientific criteria remain binding.
Solver: C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001,
branch codex/stiffened-main-reconcile-20261001. Slice base33f7ba7c; resolve latest
local commit with git log. ANYfem: C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer,
branch codex/experimental-ge-panel-consumer, slice base6fb7061.
Local scoped commits only; no push/main merge/publication or contact-worker messages.
Main untouched. All owned numerical runs and reviews are terminal.

Formal F03 UNCONSUMED; protected original script SHA256
c908b1f3e4d9467deb3a96876126d5488cd040503cc6c6ec485b8aeaecef9481.
Pressure assessment amendment still awaits user decision. Preserve existing failed
science and frozen evidence. Ceiling100krows/600s/8GiB/8threads; one heavy job at a
time. This slice used600s/1GiB/1thread/JIT off. Local/Mistral unavailable earlier;
OpenAI review is not cross-family scientific qualification.
Security: old tracked us3-modal-canary-v1.zip contains credentials. Do not print,
copy, disseminate or push affected history. User informed; no history-rewrite
permission. New archives contain whitelisted metadata, never environment maps.

## Delivered behavior and latest evidence

Experimental multi-element GE/B2 and coupled Q4-J2/generalized BL5 workflows,
adaptive displacement, selected physical/material recovery, chart rebase and
snapshot restart exist. No aggregate gate closes. Earlier source, installed and
consumer evidence stays linked in the acceptance matrix.

Public GENERALIZED_BRANCH_EVENT_TRIAL uses fixed-predecessor beam event estimates;
no shell event detection, constitutive/tolerance change or increased trial budget.
Default policies are unchanged. Typed generalized station recovery supplies actual
paired material fields and per-length stored/incremental-dissipation quantities.
[Previous integration](development/r8-generalized-recovery-20261002/results.md).

Latest: installed −66/−68/−66/−68um excursion passes, including exact checkpoint
and separate high/low material-field restart. Return dissipation is zero; reload
has tiny positive dissipation, so is not described as exactly elastic. Standing
regression and immutable authentic force seed added. Product source is unchanged.
Two further prescribed steps from the first −68um endpoint reach −70/−72um at
−485.652/−483.431 N, with equilibrium below1.3e−9 and exact restored checkpoints.
Accumulated histories do not decrease. Both runs stayed within600s/1GiB/1thread.
[Raw evidence, identities and limits](development/r8-event-material-excursion-20261002/results.md).

## Decision and next action

The equilibrium path softens across the tested −66 to −72um interval; seeking
−500 N by interpolation is not justified. The original force-history failure
remains open. No stability, limit-point, capacity or full signed-reversal claim.
The two-step bound is exhausted: do not automatically extend amplitudes or repeat
refinement. Next substantial decision is the physical capacity/branch contract:
reconcile the observed softening with the required continuation/stability checks
before choosing another solve. Reuse these saved equilibria, not off-equilibrium
failed tangents, for any justified derivative or branch analysis.

Full material breadth, F03 connection transfer, spectra/capacity, scale, external,
platform and complete consumer/release obligations remain open. Pressure amendment
requires its existing decision. No formal authority consumed. Historical note bytes
are preserved in the evidence archives; do not expand this into a feature ledger.


## Current implementation and decision

Private tangent-plane arc prototype uses the existing mixed KKT assembly and
fixed accepted histories. Explicit physical weights exclude algebraic variables
from the norm, not equilibrium. Homogeneous predictor and actual chart derivatives
are implemented. Source/tests remain DIRTY and UNACCEPTED, based on93453654.
Shared displacement border refactor still needs broader regression/installed checks.
No public arc API, checkpoint/controller, capacity or mesh-uniformity claim.

Native radius1e-5 fails at unchanged20Newton/12backtracks for both sphere and
plane candidates. The identical predictor-displacement target converges18iterations,
but its actual chord is8.11e-6: it is not equivalent to passing the arc target.
Saved-direction checks support a nearby shell active-set transition limiting the
useful step; the beam-only event predictor does not cover it. Actual path-row
chart/rebase/stale/radius checks pass. No constitutive defect is established.

Independent review recommends bounded adaptive arc cutback next: unchanged
accepted predecessor, physical orientation and per-attempt limits, finite total
attempts, all failed work recorded. Report actual accepted radius; do not relabel
smaller-radius success as the original request. Atomic public publication and
controller/restart are still required before exposing this route. Shell-event
prediction is deferred unless repeat evidence warrants its added mechanics.
No further row tuning or broader refinement campaign. All jobs/reviews terminal.
[Failures, candidate source and discriminator](development/r8-arc-prototype-20261002/results.md).


Current slice: bounded trial selection retries only typed arc Newton/backtrack
failures from the identical accepted predecessor. Requested1e-5, max4cutbacks and
5attempts, unchanged20/12per-attempt limits. Result must retain requested and actual
radius plus failed work; selecting a step is not completing the requested path.
The regression explicitly keeps the first radius failure and requires distinct
smaller-radius reporting. No public publication or checkpoint integration yet.
