from pathlib import Path
import sys,importlib.util,json
r=Path(__file__).parent;repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
if len(sys.argv)>1:
 sys.path.insert(0,str(repo/'tests'))
 import numpy as np
 from anysolver import stiffened_shell as ss
 from test_stiffened_shell_bl5_coupled_material import coupled
 from test_stiffened_shell_bl5_finite import _action
 from anysolver._stiffened_shell_displacement_corrector import correct
 from anysolver._stiffened_shell_arc_trial import path_row
 from anysolver._stiffened_shell_arc_metric import PhysicalChordMetric
 a=ss.create_analysis(definition=coupled());seed=(repo/'tests/data/stiffened_shell_event_excursion/force-seed.bin').read_bytes();a.restore(seed)
 d=a._finite_driver;parent=d._state;dof=a._shell_count+6*a._beam_index[105]+2
 n=len(a._shell_ids)+len(a._beam_ids);metric=PhysicalChordMetric(np.full(n,1/n),a._reference_length)
 base=d._applied_load if d._programme is not None else d._load_factor*d._pattern
 target=parent.q[dof]-1e-5*metric.length
 data=dict(length=metric.length,initial=float(parent.q[dof]),target=float(target),base_force=float(base[dof]))
 try:
  t=correct(d,base_load=base,load_direction=d._load(_action(-15.625)),amplitude=0.,control_dof=dof,target=float(target),max_iterations=20,max_backtracks=12,trial_policy=ss.GENERALIZED_BRANCH_EVENT_TRIAL)
  value,row=path_row(d,t.state,parent,metric)
  data.update(status='completed',equilibrium=t.evaluation[2],gap=t.evaluation[3],radius=float(np.sqrt(value)),iterations=t.iterations,evaluations=t.evaluations,amplitude=t.amplitude)
  np.savez(r/'candidate.npz',q=t.state.q,frames=t.state.frames,cells=t.state.cells,resultants=t.state.resultants,multipliers=t.state.multipliers)
 except Exception as e:
  data.update(status='failed',error=type(e).__name__,message=str(e))
  if getattr(e,'detail',None) is not None:
   from dataclasses import asdict
   data['detail']=asdict(e.detail)
 finally:
  assert a.checkpoint()==seed
  (r/'result.json').write_text(json.dumps(data,indent=2));a.close()
else:
 spec=importlib.util.spec_from_file_location('s',r.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV['PYTHONPATH']=str(repo/'src')
 out=s.supervised([sys.executable,str(Path(__file__)),'child'],r/'run-v1')
 print(json.dumps({k:out[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
