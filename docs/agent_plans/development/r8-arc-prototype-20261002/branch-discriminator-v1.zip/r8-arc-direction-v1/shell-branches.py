from pathlib import Path
import sys,importlib.util,json
r=Path(__file__).parent;repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
if len(sys.argv)>1:
 sys.path.insert(0,str(repo/'tests'))
 import numpy as np
 from anysolver import stiffened_shell as ss
 from test_stiffened_shell_bl5_coupled_material import coupled
 from test_stiffened_shell_bl5_finite import _action
 from anysolver._stiffened_shell_displacement_corrector import correct
 from anysolver._stiffened_shell_arc_trial import path_row
 from anysolver._stiffened_shell_arc_metric import PhysicalChordMetric
 a=ss.create_analysis(definition=coupled());seed=(repo/'tests/data/stiffened_shell_event_excursion/force-seed.bin').read_bytes();a.restore(seed)
 d=a._finite_driver;parent=d._state;dof=a._shell_count+6*a._beam_index[105]+2
 n=len(a._shell_ids)+len(a._beam_ids);metric=PhysicalChordMetric(np.full(n,1/n),a._reference_length)
 base=d._applied_load if d._programme is not None else d._load_factor*d._pattern
 target=parent.q[dof]-1e-5*metric.length
 data=dict(length=metric.length,initial=float(parent.q[dof]),target=float(target),base_force=float(base[dof]))
 from anysolver._stiffened_shell_ge_finite_experimental import _State
 from anysolver._stiffened_shell_branch_event_trial import trial_fraction
 f=np.load(r/'failed-candidate.npz');state=_State(f['q'],f['frames'],f['cells'],f['resultants'],f['multipliers'],parent.shell_anchors);step=f['step']
 pattern=d._load(_action(-15.625));amplitude=2.3843326093643027;delta=float(f['delta'])
 e=d._assemble(state,0.,d._shell_origins,d._beam_origins,applied_load=base+amplitude*pattern)
 residual,matrix=e[:2];expected=matrix@step-np.r_[pattern,np.zeros(len(state.multipliers))]*delta
 weights=np.r_[a._coordinate_scale,np.ones(len(state.multipliers))]
 cuts=(0,a._shell_count,a._shell_count+d._beam_nodal,len(state.q),len(residual));rows=[]
 for h in (1e-4,1e-5,1e-6):
  plus=d._assemble(d._advance(state,step,h),0.,d._shell_origins,d._beam_origins,applied_load=base+(amplitude+h*delta)*pattern)
  minus=d._assemble(d._advance(state,step,-h),0.,d._shell_origins,d._beam_origins,applied_load=base+(amplitude-h*delta)*pattern)
  error=((plus[0]-minus[0])/(2*h)-expected)*weights
  rows.append(dict(h=h,shell_alpha_range=[float(np.min([x['alpha'] for x in plus[4]])),float(np.max([x['alpha'] for x in plus[4]]))],shell_changed_active=int(sum(np.count_nonzero((np.array(x['alpha'])>np.array(o['alpha']))!=(np.array(y['alpha'])>np.array(o['alpha']))) for x,y,o in zip(plus[4],minus[4],d._shell_origins))),block_error=[float(np.linalg.norm(error[x:y])) for x,y in zip(cuts,cuts[1:])],block_expected=[float(np.linalg.norm((expected*weights)[x:y])) for x,y in zip(cuts,cuts[1:])]))
 (r/'shell-branches.json').write_text(json.dumps(dict(cuts=cuts,rows=rows),indent=2));assert a.checkpoint()==seed;a.close()

else:
 spec=importlib.util.spec_from_file_location('s',r.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV['PYTHONPATH']=str(repo/'src')
 out=s.supervised([sys.executable,str(Path(__file__)),'child'],r/'shell-branches-v1')
 print(json.dumps({k:out[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
