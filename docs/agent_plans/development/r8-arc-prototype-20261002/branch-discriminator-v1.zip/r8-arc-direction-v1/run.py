from pathlib import Path
import sys,importlib.util,json
r=Path(__file__).parent;repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
if len(sys.argv)>1:
 sys.path.insert(0,str(repo/'tests'))
 import numpy as np
 from anysolver import stiffened_shell as ss
 from test_stiffened_shell_bl5_coupled_material import coupled
 from test_stiffened_shell_bl5_finite import _action
 from anysolver._stiffened_shell_displacement_corrector import correct
 from anysolver._stiffened_shell_arc_trial import path_row
 from anysolver._stiffened_shell_arc_metric import PhysicalChordMetric
 a=ss.create_analysis(definition=coupled());seed=(repo/'tests/data/stiffened_shell_event_excursion/force-seed.bin').read_bytes();a.restore(seed)
 d=a._finite_driver;parent=d._state;dof=a._shell_count+6*a._beam_index[105]+2
 n=len(a._shell_ids)+len(a._beam_ids);metric=PhysicalChordMetric(np.full(n,1/n),a._reference_length)
 base=d._applied_load if d._programme is not None else d._load_factor*d._pattern
 target=parent.q[dof]-1e-5*metric.length
 data=dict(length=metric.length,initial=float(parent.q[dof]),target=float(target),base_force=float(base[dof]))
 import anysolver._stiffened_shell_arc_trial as arc
 original=arc.bordered_path_correction;last={}
 def border(*args):
  step,delta=original(*args);last.update(step=step,delta=delta)
  return step,delta
 arc.bordered_path_correction=border
 try:
  t=arc.correct(d,load_direction=d._load(_action(-15.625)),metric=metric,radius=1e-5,predictor_dof=dof,orientation=-1)
  data['status']='unexpected completion'
 except arc.ArcTrialFailure as error:
  t=error.trial;state=t.state;step=last['step'];delta=last['delta'];pattern=d._load(_action(-15.625))
  residual,matrix,*_=t.evaluation;free=np.r_[a._free,np.arange(len(state.q),len(residual))]
  energy=float(np.max((abs(a._K)@a._coordinate_scale)*a._coordinate_scale))
  weights=np.r_[a._coordinate_scale,energy/a._constraint_scale]/energy
  expected=matrix@step-np.r_[pattern,np.zeros(len(state.multipliers))]*delta
  rows=[]
  for h in (1e-2,1e-4,1e-6,1e-8):
   plus=d._assemble(d._advance(state,step,h),0.,t.shell_predecessor,t.beam_predecessor,applied_load=base+(t.amplitude+h*delta)*pattern)[0]
   minus=d._assemble(d._advance(state,step,-h),0.,t.shell_predecessor,t.beam_predecessor,applied_load=base+(t.amplitude-h*delta)*pattern)[0]
   change=(plus-minus)/(2*h)
   rows.append(dict(h=h,error=float(np.linalg.norm((change-expected)[free]*weights[free])/np.linalg.norm(expected[free]*weights[free])),merit_ratio=float(np.linalg.norm(plus[free]*weights[free])/np.linalg.norm(residual[free]*weights[free]))))
  data.update(status='failed candidate retained',target=float(state.q[dof]),amplitude=t.amplitude,equilibrium=t.evaluation[2],path_error=t.path_error,rows=rows)
  np.savez(r/'failed-candidate.npz',q=state.q,frames=state.frames,cells=state.cells,resultants=state.resultants,multipliers=state.multipliers,step=step,delta=delta,residual=residual)
 finally:
  assert a.checkpoint()==seed
  (r/'result.json').write_text(json.dumps(data,indent=2));a.close()

else:
 spec=importlib.util.spec_from_file_location('s',r.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV['PYTHONPATH']=str(repo/'src')
 out=s.supervised([sys.executable,str(Path(__file__)),'child'],r/'run-v2')
 print(json.dumps({k:out[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
