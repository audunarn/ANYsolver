from pathlib import Path
import sys,importlib.util,json
r=Path(__file__).parent;repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
if len(sys.argv)>1:
 sys.path.insert(0,str(repo/'tests'))
 import numpy as np
 from anysolver import stiffened_shell as ss
 from test_stiffened_shell_bl5_coupled_material import coupled
 from test_stiffened_shell_bl5_finite import _action
 from anysolver._stiffened_shell_displacement_corrector import correct
 from anysolver._stiffened_shell_arc_trial import path_row
 from anysolver._stiffened_shell_arc_metric import PhysicalChordMetric
 a=ss.create_analysis(definition=coupled());seed=(repo/'tests/data/stiffened_shell_event_excursion/force-seed.bin').read_bytes();a.restore(seed)
 d=a._finite_driver;parent=d._state;dof=a._shell_count+6*a._beam_index[105]+2
 n=len(a._shell_ids)+len(a._beam_ids);metric=PhysicalChordMetric(np.full(n,1/n),a._reference_length)
 base=d._applied_load if d._programme is not None else d._load_factor*d._pattern
 target=parent.q[dof]-1e-5*metric.length
 data=dict(length=metric.length,initial=float(parent.q[dof]),target=float(target),base_force=float(base[dof]))
 from anysolver._stiffened_shell_ge_finite_experimental import _State
 from anysolver._stiffened_shell_branch_event_trial import trial_fraction
 f=np.load(r/'failed-candidate.npz');state=_State(f['q'],f['frames'],f['cells'],f['resultants'],f['multipliers'],parent.shell_anchors);step=f['step']
 work={'cell_evaluations':0};fraction,events=trial_fraction(d,state,step,d._beam_origins,lambda:None,work)
 data.update(fraction=fraction,events=[dict(element=e.element_id,station=e.station,branch=e.branch,fraction=e.estimated_fraction) for e in events],rows=[])
 for h in (0.,1e-6,1e-4,1e-2):
  candidate=d._advance(state,step,h)
  branches=[]
  for i,((element,_,_),origin) in enumerate(zip(a._beam_parts,d._beam_origins)):
   retained=a._shell_count+d._beam_nodal;dp=step[retained+24*i+6:retained+24*i+24]
   response=element.operator.cell.response(candidate.resultants[i].tolist(),origin,branch_direction=dp.tolist())
   branches.append([v['branch'] for v in response['branch_direction']])
  data['rows'].append(dict(h=h,beam_branches=branches))
 (r/'events.json').write_text(json.dumps(data,indent=2));a.close()

else:
 spec=importlib.util.spec_from_file_location('s',r.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV['PYTHONPATH']=str(repo/'src')
 out=s.supervised([sys.executable,str(Path(__file__)),'child'],r/'events-v1')
 print(json.dumps({k:out[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
