from pathlib import Path
import importlib.util, sys, json, os
root=Path(__file__).parent
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py")
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
m.ENV["PYTHONPATH"]=str(repo/"src")
files=sys.argv[2:]
command=[sys.executable,"-m","pytest","-q","-o","addopts=","-p","no:cacheprovider",*[str(repo/"tests"/f) for f in files]]
r=m.supervised(command,root/sys.argv[1]);print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
