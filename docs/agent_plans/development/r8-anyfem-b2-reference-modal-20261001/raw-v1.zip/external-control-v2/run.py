"""One external wrench/coordinate feasibility control, not a matched comparison."""
from pathlib import Path
import hashlib, json, math, os, re, subprocess, time
import psutil

ROOT = Path(__file__).resolve().parent
EXE = Path('C:/Github/ANYsolver/.qualification/b3-ge-e4-pl/calculix-223/CalculiX-2.23.0-win-x64/bin/ccx.exe')
EXE_SHA = '27a9426a1ee2f72c38fbe892e0ffaf38e14867628ffd0235770261b6f3ec9c5f'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(EXE) == EXE_SHA
corners = [(0., -.5, -.05), (1., -.5, -.05), (1., .5, -.05), (0., .5, -.05),
           (0., -.5, .05), (1., -.5, .05), (1., .5, .05), (0., .5, .05)]
edges = [(0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6), (6, 7), (7, 4),
         (0, 4), (1, 5), (2, 6), (3, 7)]
xyz = corners+[tuple((a+b)/2 for a, b in zip(corners[i], corners[j])) for i, j in edges]
physical = {i+1: x for i, x in enumerate(xyz)}
left = [n for n, x in physical.items() if x[0] == 0.]
right = [n for n, x in physical.items() if x[0] == 1.]
controls = {901: (0., 0., 0.), 902: (3., 3., 3.), 903: (1., 0., .2), 904: (4., 4., 4.)}
force, moment = (0., 100., -50.), (10., -4., 5.)
deck = ['*HEADING', 'E02 rigid-face control: moment/work coordinate feasibility only', '*NODE']
deck += [str(n)+','+','.join(format(v, '.17g') for v in x) for n, x in (physical|controls).items()]
deck += ['*ELEMENT,TYPE=C3D20R,ELSET=SOLID', '1,'+','.join(map(str, range(1, 16))), ','.join(map(str, range(16, 21))),
         '*NSET,NSET=LEFT', ','.join(map(str, left)), '*NSET,NSET=RIGHT', ','.join(map(str, right)),
         '*NSET,NSET=CONTROLS', '901,902,903,904', '*NSET,NSET=PHYSICAL',
         ','.join(map(str, range(1, 13))), ','.join(map(str, range(13, 21))),
         '*RIGID BODY,NSET=LEFT,REF NODE=901,ROT NODE=902',
         '*RIGID BODY,NSET=RIGHT,REF NODE=903,ROT NODE=904',
         '*MATERIAL,NAME=ELASTIC', '*ELASTIC', '210000000000.,0.3', '*SOLID SECTION,ELSET=SOLID,MATERIAL=ELASTIC',
         '*BOUNDARY', '901,1,3,0.', '902,1,3,0.', '*STEP', '*STATIC', '1.,1.,0.000001,1.', '*CLOAD']
deck += [f'{903 if role == 0 else 904},{i+1},{v:.17g}'
         for role, load in enumerate((force, moment)) for i, v in enumerate(load) if v]
deck += ['*NODE PRINT,NSET=CONTROLS', 'U,RF', '*NODE PRINT,NSET=PHYSICAL', 'U', '*END STEP']
inp = ROOT/'control.inp'
with inp.open('x') as out: out.write('\n'.join(deck)+'\n')
manifest = dict(executable=str(EXE), executable_sha256=EXE_SHA, runner_sha256=sha(Path(__file__)),
    deck_sha256=sha(inp), physical_nodes=physical, control_nodes=controls,
    left_nodes=left, right_nodes=right, applied_force_N=force, applied_moment_Nm=moment,
    scope='external rigid-face solid control only; no native comparison, element accuracy or F03 authority',
    timeout_seconds=60, memory_limit_bytes=1024**3,
    manual='https://www.feacluster.com/CalculiX/ccx_2.18/doc/ccx/node320.html')
(ROOT/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
env = os.environ.copy()
env.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', CCX_NPROC_RESULTS='1', CCX_NPROC_EQUATION_SOLVER='1')
started, peak, max_threads, limit = time.monotonic(), 0, 0, None
with (ROOT/'stdout.log').open('x') as out, (ROOT/'stderr.log').open('x') as err:
    process = subprocess.Popen([str(EXE), '-i', 'control'], cwd=ROOT, env=env, stdout=out, stderr=err)
    owned = psutil.Process(process.pid); tree = [owned]
    while process.poll() is None:
        try:
            tree = [owned]+owned.children(recursive=True)
            peak = max(peak, sum(p.memory_info().rss for p in tree if p.is_running()))
            max_threads = max(max_threads, sum(p.num_threads() for p in tree if p.is_running()))
        except psutil.NoSuchProcess: pass
        except psutil.AccessDenied: limit = 'resource observation denied'
        if time.monotonic()-started > 60: limit = 'time'
        if peak > 1024**3: limit = 'memory'
        if limit:
            for p in reversed(tree):
                try: p.kill()
                except psutil.NoSuchProcess: pass
            break
        time.sleep(.01)
    code = process.wait()
execution = dict(exit_code=code, resource_limit=limit, elapsed_seconds=time.monotonic()-started,
                 peak_sampled_tree_bytes=peak, max_sampled_os_threads=max_threads,
                 timeout_seconds=60, memory_limit_bytes=1024**3)
(ROOT/'execution.json').write_text(json.dumps(execution, indent=2)+'\n')
stdout, stderr = (ROOT/'stdout.log').read_text(), (ROOT/'stderr.log').read_text()
assert code == 0 and limit is None and stdout.count('Job finished') == 1, execution
assert not re.search(r'(?i)\b(warning|error|fatal)\b', stdout+stderr), 'solver diagnostic'
sta = (ROOT/'control.sta').read_text()
steps = [line.split() for line in sta.splitlines() if re.match(r'^\s*1\s+1\s+1\s+1\s+', line)]
assert len(steps) == 1 and all(abs(float(t)-1.) <= 1e-12 for t in steps[0][4:]), 'incomplete step'
cpu_lines = [line for line in stdout.splitlines() if 'cpu' in line.lower()]
assert cpu_lines and all(re.search(r'\b1 cpu', line) for line in cpu_lines), 'solver reported thread setting differs'
dat = (ROOT/'control.dat').read_text()
def fields(label, group):
    marker = re.compile(r'^\s*'+label+r'\s+\([^\n]*\)\s+for set\s+'+group+r'\s+and time', re.I|re.M)
    matches = list(marker.finditer(dat))
    assert len(matches) == 1, (label, group, len(matches))
    values = {}
    for line in dat[matches[0].end():].splitlines()[1:]:
        row = line.split()
        if not row:
            if values: break
            continue
        if len(row) != 4 or not row[0].isdigit(): break
        values[int(row[0])] = tuple(float(v.replace('D', 'E')) for v in row[1:])
    return values
u = fields('displacements', 'CONTROLS')
rf = fields('forces', 'CONTROLS')
physical_u = fields('displacements', 'PHYSICAL')
assert set(u) == set(rf) == set(controls) and set(physical_u) == set(physical)
assert all(math.isfinite(v) for rows in (u, rf, physical_u) for row in rows.values() for v in row)
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
arm_moment = cross(controls[903], force)
expected_force = tuple(-v for v in force)
expected_moment = tuple(-a-b for a, b in zip(arm_moment, moment))
force_error = max(abs(a-b) for a, b in zip(rf[901], expected_force))/max(map(abs, force))
moment_error = max(abs(a-b) for a, b in zip(rf[902], expected_moment))/max(map(abs, expected_moment))
rigid_gap = 0.
for nodes, ref, rot in ((left, 901, 902), (right, 903, 904)):
    for n in nodes:
        arm = tuple(a-b for a, b in zip(physical[n], controls[ref]))
        predicted = tuple(a+b for a, b in zip(u[ref], cross(u[rot], arm)))
        rigid_gap = max(rigid_gap, *(abs(a-b) for a, b in zip(physical_u[n], predicted)))
work = sum(a*b for a, b in zip(force, u[903]))+sum(a*b for a, b in zip(moment, u[904]))
result = dict(status='COMPLETED_DEVELOPMENT_ONLY', support_force_N=rf[901], support_moment_Nm=rf[902],
              expected_support_force_N=expected_force, expected_support_moment_Nm=expected_moment,
              normalized_force_error=force_error, normalized_moment_error=moment_error,
              absolute_printed_rigid_gap_m=rigid_gap, conjugate_external_work_J=work,
              translations_m=u[903], rotations_rad=u[904], thread_reporting_lines=[line for line in stdout.splitlines() if 'cpu' in line.lower() or 'thread' in line.lower()])
assert force_error <= 1e-8 and moment_error <= 1e-8 and rigid_gap <= 1e-9 and work > 0., result
(ROOT/'result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result)); print(json.dumps(execution))
