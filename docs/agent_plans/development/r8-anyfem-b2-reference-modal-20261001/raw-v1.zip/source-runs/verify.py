from pathlib import Path
import hashlib, json, os, runpy, subprocess, sys, time
import psutil
ROOT = Path(__file__).resolve().parent
CONSUMER = Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
SITE = Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-footprint-modes-installed-v1/site')
FILES = ('src/anyfem/solve/stiffened_shell_b2.py', 'src/anyfem/solve/stiffened_shell_project.py', 'tests/test_stiffened_shell_b2_reference_modal_consumer.py', 'examples/stiffened_shell_b2_footprint_modes.py')

def child(label):
    import numpy, scipy, numba, threadpoolctl, anysolver, anyfem
    assert Path(anysolver.__file__).resolve().is_relative_to(SITE)
    assert Path(anyfem.__file__).resolve().is_relative_to(CONSUMER/'src')
    assert numba.config.DISABLE_JIT and numba.get_num_threads() == 1
    assert all(p['num_threads'] == 1 for p in threadpoolctl.threadpool_info())
    identity = {'python': sys.version, 'solver_site': str(SITE), 'consumer': str(CONSUMER),
      'jit_disabled': bool(numba.config.DISABLE_JIT), 'numba_threads': numba.get_num_threads(),
      'pools': threadpoolctl.threadpool_info(), 'source_sha256': {p: hashlib.sha256((CONSUMER/p).read_bytes()).hexdigest() for p in FILES}}
    (ROOT/(label+'-identity.json')).write_text(json.dumps(identity, indent=2))
    try:
        if label.startswith('example'):
            sys.argv = [str(CONSUMER/FILES[-1]), str(ROOT/(label+'.anyfem-b2.json'))]
            if label == 'example-project': sys.argv += ['--project', str(ROOT/'modal.anyfem')]
            runpy.run_path(str(CONSUMER/FILES[-1]), run_name='__main__'); code = 0
        else:
            import pytest
            targets = [str(CONSUMER/'tests'/name) for name in sys.argv[3:]]
            code = int(pytest.main(['-q', '--basetemp='+str(ROOT/(label+'-states')), '--junitxml='+str(ROOT/(label+'-inventory.xml')), *targets]))
    finally:
        imports = {n: str(Path(m.__file__).resolve()) for n, m in sys.modules.copy().items() if n.split('.')[0] in ('anysolver','anyfem') and getattr(m,'__file__',None)}
        (ROOT/(label+'-imports.json')).write_text(json.dumps(imports, indent=2))
        assert all(Path(p).is_relative_to(SITE if n.startswith('anysolver') else CONSUMER/'src') for n,p in imports.items())
        assert numba.get_num_threads() == 1 and all(p['num_threads'] == 1 for p in threadpoolctl.threadpool_info())
    sys.exit(code)

def supervise(label):
    env = os.environ.copy()
    env.update(PYTHONPATH=os.pathsep.join((str(CONSUMER/'src'),str(SITE))), PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', NUMBA_DISABLE_JIT='1', NUMBA_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', BLIS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
    command = [sys.executable, '-u', str(Path(__file__).resolve()), 'child', label, *sys.argv[3:]]
    start=time.monotonic(); peak=0; limit=None
    with (ROOT/(label+'.log')).open('w') as log:
        process=subprocess.Popen(command, cwd=CONSUMER, env=env, stdout=log, stderr=subprocess.STDOUT)
        root=psutil.Process(process.pid)
        while process.poll() is None:
            try:
                children=[root]+root.children(recursive=True)
                memory=sum(p.memory_info().rss for p in children if p.is_running())
                peak=max(peak,memory)
                if memory > 1073741824: limit='1 GiB process tree limit'
                if time.monotonic()-start > 180: limit='180 second timeout'
                if limit:
                    for p in reversed(children):
                        try: p.kill()
                        except psutil.NoSuchProcess: pass
                    break
            except psutil.NoSuchProcess: pass
            time.sleep(.1)
        code=process.wait()
    record={'command':command,'elapsed_seconds':time.monotonic()-start,'peak_sampled_tree_bytes':peak,'memory_limit_bytes':1073741824,'timeout_seconds':180,'resource_limit':limit,'exit_code':code}
    (ROOT/(label+'-execution.json')).write_text(json.dumps(record,indent=2))
    print(json.dumps(record)); print((ROOT/(label+'.log')).read_text()[-8000:]); sys.exit(code)

if sys.argv[1] == 'child': child(sys.argv[2])
else: supervise(sys.argv[2])
