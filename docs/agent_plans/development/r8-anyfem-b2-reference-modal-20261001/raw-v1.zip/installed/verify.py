from pathlib import Path
import hashlib, json, os, runpy, shutil, subprocess, sys, time, zipfile
import psutil

ROOT = Path(__file__).resolve().parent
CONSUMER = Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
SOLVER = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
SOLVER_ARTIFACT = Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-footprint-modes-installed-v1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
FIXTURES = ('test_stiffened_shell_b2_reference_modal_consumer.py',
 'test_stiffened_shell_b2_nodal_footprint_consumer.py',
 'test_experimental_b2_stiffened_shell_consumer.py',
 'test_stiffened_shell_ge_reference_modal_consumer.py')

def prepare():
    build = ROOT/'build-source'
    build.mkdir()
    shutil.copytree(CONSUMER/'src', build/'src', ignore=shutil.ignore_patterns('__pycache__', '*.egg-info'))
    for name in ('pyproject.toml', 'MANIFEST.in', 'README.md', 'LICENSE', 'NOTICE',
                 'THIRD_PARTY_NOTICES.md', 'dependency-licenses.json', 'CHANGELOG.md', 'run_gui.py'):
        shutil.copy2(CONSUMER/name, build/name)
    shutil.copytree(CONSUMER/'docs', build/'docs', ignore=shutil.ignore_patterns('__pycache__'))
    (build/'tools').mkdir()
    for name in ('check_licenses.py', 'check_release_artifacts.py'):
        shutil.copy2(CONSUMER/'tools'/name, build/'tools'/name)
    manifest = {str(p.relative_to(CONSUMER)).replace('\\', '/'): sha(p)
                for p in sorted((CONSUMER/'src/anyfem').rglob('*.py'))}
    (ROOT/'source-manifest.json').write_text(json.dumps(manifest, indent=2))
    (ROOT/'fixtures').mkdir()
    for name in FIXTURES:
        shutil.copy2(CONSUMER/'tests'/name, ROOT/'fixtures'/name)
    shutil.copy2(CONSUMER/'examples/stiffened_shell_b2_footprint_modes.py', ROOT/'example.py')
    (ROOT/'pytest.ini').write_text('[pytest]\n')
    (ROOT/'wheels').mkdir()
    subprocess.run([sys.executable, '-m', 'pip', 'wheel', '--no-deps', '--no-build-isolation',
                    '--no-cache-dir', '--wheel-dir', str(ROOT/'wheels'), str(build)], check=True, timeout=120)
    wheel, = (ROOT/'wheels').glob('*.whl')
    subprocess.run([sys.executable, '-m', 'pip', 'install', '--no-deps', '--no-index', '--no-cache-dir',
                    '--target', str(ROOT/'site'), str(wheel)], check=True, timeout=60)
    print(json.dumps({'consumer_wheel_sha256': sha(wheel), 'source_modules': len(manifest)}))

def bind(source, artifact, package):
    manifest = json.loads((artifact/'source-manifest.json').read_text())
    wheel, = (artifact/'wheels').glob('*.whl')
    assert all(sha(source/p) == h for p, h in manifest.items()), 'source changed since snapshot'
    with zipfile.ZipFile(wheel) as z:
        files = {p for p in z.namelist() if p.startswith(package+'/') and p.endswith('.py')}
        assert files == {p.removeprefix('src/') for p in manifest}
        assert all(z.read(p) == (artifact/'site'/p).read_bytes() == (source/'src'/p).read_bytes() for p in files)
    return dict(wheel_sha256=sha(wheel), matching_modules=len(files), site=str(artifact/'site'), source=str(source))

def check(label):
    from importlib import metadata
    import anysolver, anyfem, numpy, scipy, numba, threadpoolctl
    bindings = {'solver': bind(SOLVER, SOLVER_ARTIFACT, 'anysolver'), 'consumer': bind(CONSUMER, ROOT, 'anyfem')}
    assert numba.config.DISABLE_JIT and numba.get_num_threads() == 1
    pools = threadpoolctl.threadpool_info()
    assert pools and all(p['num_threads'] == 1 for p in pools)
    identity = dict(bindings=bindings, python=sys.version, pools=pools, jit_disabled=True, numba_threads=1,
      fixtures_sha256={p.name: sha(p) for p in (ROOT/'fixtures').glob('*.py')}, example_sha256=sha(ROOT/'example.py'),
      dependencies={n: metadata.version(n) for n in
                    ('numpy', 'scipy', 'numba', 'pytest', 'threadpoolctl', 'ANYmaterial', 'ANYmesher', 'ANYfileio')})
    (ROOT/(label+'-identity.json')).write_text(json.dumps(identity, indent=2))
    try:
        if label.startswith('example'):
            sys.argv = ['example.py', str(ROOT/(label+'.anyfem-b2.json'))]
            if label == 'example-project':
                sys.argv += ['--project', str(ROOT/(label+'.anyfem'))]
            runpy.run_path(str(ROOT/'example.py'), run_name='__main__')
            code = 0
        else:
            import pytest
            code = int(pytest.main(['-q', '-c', str(ROOT/'pytest.ini'),
                '--basetemp='+str(ROOT/(label+'-states')), '--junitxml='+str(ROOT/(label+'-inventory.xml')),
                *[str(ROOT/'fixtures'/p) for p in FIXTURES]]))
    finally:
        imports = {n: str(Path(m.__file__).resolve()) for n, m in sys.modules.copy().items()
                   if n.split('.')[0] in ('anysolver', 'anyfem') and getattr(m, '__file__', None)}
        (ROOT/(label+'-imports.json')).write_text(json.dumps(imports, indent=2))
        assert imports and all(Path(p).is_relative_to((ROOT/'site' if n.split('.')[0] == 'anyfem'
                    else SOLVER_ARTIFACT/'site').resolve()) for n, p in imports.items())
        assert numba.get_num_threads() == 1 and all(p['num_threads'] == 1 for p in threadpoolctl.threadpool_info())
    print(json.dumps({'exit': code, 'onsite_imports': len(imports), 'label': label}))
    sys.exit(code)

def supervise(label):
    env = os.environ.copy()
    env.update(PYTHONPATH=os.pathsep.join(map(str, (ROOT/'site', SOLVER_ARTIFACT/'site', ROOT/'fixtures', ROOT))),
      PYTHONNOUSERSITE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', NUMBA_DISABLE_JIT='1',
      OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', OMP_NUM_THREADS='1', NUMBA_NUM_THREADS='1')
    command = [sys.executable, '-u', str(Path(__file__)), 'child', label]
    started, peak, limit = time.monotonic(), 0, None
    with (ROOT/(label+'.log')).open('x') as log:
        p = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        owned = psutil.Process(p.pid); tree = [owned]
        while p.poll() is None:
            try:
                tree = [owned]+owned.children(recursive=True)
                peak = max(peak, sum(c.memory_info().rss for c in tree if c.is_running()))
            except psutil.NoSuchProcess: pass
            except psutil.AccessDenied: limit = 'memory observation denied'
            if time.monotonic()-started > 180: limit = 'time'
            if peak > 1024**3: limit = 'memory'
            if limit:
                for c in reversed(tree):
                    try: c.kill()
                    except psutil.NoSuchProcess: pass
                break
            time.sleep(.1)
        code = p.wait()
    record = dict(command=command, runner_sha256=sha(Path(__file__)), elapsed_seconds=time.monotonic()-started,
      peak_sampled_tree_bytes=peak, timeout_seconds=180, memory_limit_bytes=1024**3, resource_limit=limit, exit_code=code)
    (ROOT/(label+'-execution.json')).write_text(json.dumps(record, indent=2))
    print(json.dumps(record)); print('\n'.join((ROOT/(label+'.log')).read_text().splitlines()[-8:]))
    sys.exit(code if limit is None else 124)

if sys.argv[1] == 'child':
    if sys.argv[2] == 'prepare': prepare()
    else: check(sys.argv[2])
else: supervise(sys.argv[1])
