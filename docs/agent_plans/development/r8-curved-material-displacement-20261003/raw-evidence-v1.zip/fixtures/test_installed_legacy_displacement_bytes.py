from pathlib import Path
import json
import numpy as np
from anysolver import stiffened_shell as ss
from test_stiffened_shell_bl5_coupled_material import coupled
from test_stiffened_shell_bl5_finite import _action
from test_stiffened_shell_curved_material_displacement import material_equal


def test_legacy_installed_displacement_bytes_and_continuation(request):
 root=Path(__file__).resolve().parent.parent
 baseline=(root/'legacy-endpoint.bin').read_bytes()
 observation=json.loads((root/'legacy-observation.json').read_text())
 def make():
  owner=ss.create_analysis(definition=coupled());request.addfinalizer(owner.close);return owner
 owner=make();owner.solve(_action(500.),(.5,1.),max_iterations=20,max_backtracks=12)
 dof=owner._shell_count+6*owner._beam_index[105]+2;initial=owner._finite_driver._state.q[dof]
 assert initial==observation['initial']
 kw=dict(displacement_control=ss.DisplacementControl('beam',105,2),max_iterations=20,max_backtracks=12)
 endpoint=owner.solve(_action(50.),(initial*1.01,),**kw)
 assert owner.checkpoint()==baseline
 restored=make();again=restored.restore(baseline)
 assert restored.checkpoint()==baseline
 material_equal(endpoint,again)
 left=owner.solve(_action(50.),(initial*1.02,),**kw)
 right=restored.solve(_action(50.),(initial*1.02,),**kw)
 assert owner.checkpoint()==restored.checkpoint() and left.history==right.history
 material_equal(left,right)
 for name in ('shell_displacement','cell_resultants','support_reactions'):
  np.testing.assert_array_equal(getattr(left,name),getattr(right,name))
 (root/'legacy-compatibility.json').write_text(json.dumps(dict(baseline=observation,
     checkpoint_bytes_equal=True,continued_checkpoint_equal=True,history_equal=True),indent=2))
