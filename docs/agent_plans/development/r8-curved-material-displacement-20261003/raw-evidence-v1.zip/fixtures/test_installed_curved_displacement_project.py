from dataclasses import replace
from pathlib import Path
import json
import numpy as np
import pytest
from anysolver import stiffened_shell as ss
from anyfem.solve.stiffened_shell import ExperimentalGEPointPanel,save_case,load_case
from anyfem.io.project_file import save_project,load_project
from anyfem.model.project import Project
from anyfem.model.records import AnalysisDefinition
from test_stiffened_shell_curved_material import curved_material_panel,_actions
from test_stiffened_shell_curved_material_displacement import material_equal


@pytest.mark.parametrize('shell_j2',[False,True])
def test_native_curved_displacement_project(tmp_path,request,shell_j2):
 d=replace(curved_material_panel(),retained_scale_policy='native_force_moment_roles_v1')
 if not shell_j2:d=replace(d,shell=replace(d.shell,j2_curve=None))
 shell=replace(d.shell,coordinates_m=tuple(tuple(float(v) for v in row) for row in d.shell.coordinates_m))
 panel=ExperimentalGEPointPanel(shell,d.beams,d.points,d.fixed,_actions(),
     q4_pullback_policy=d.q4_pullback_policy,shell_reference_policy=d.shell_reference_policy,
     retained_scale_policy=d.retained_scale_policy)
 reopened=load_case(save_case(panel,tmp_path/'material.anyfem-ge.json'))
 assert reopened.to_dict()==panel.to_dict() and 'native-scale-v3' in reopened.to_dict()['schema']
 project=Project('curved displacement',mesh_only=True)
 record=AnalysisDefinition.experimental_point_panel('material panel',reopened);project.add_analysis(record)
 path=save_project(project,tmp_path/'material.anyfem')
 def make():
  owner=load_project(path).analyses[record.id].create_point_panel_analysis()
  request.addfinalizer(owner.close);return owner
 owner=make();seed=owner.solve(panel.actions,(.5,1.),max_iterations=20,max_backtracks=12)
 assert np.max(seed.beam_station_accumulated)>0
 if shell_j2:assert np.max(seed.shell_layer_alpha)>0
 else:assert not seed.shell_q4_material and not seed.shell_layer_alpha
 dof=owner._shell_count+6*owner._beam_index[105]+2;initial=owner._finite_driver._state.q[dof]
 kw=dict(displacement_control=ss.DisplacementControl('beam',105,2),max_iterations=20,max_backtracks=12)
 first=owner.solve(panel.actions,(initial*.99,),**kw)
 raw=owner.checkpoint();fresh=make();restored=fresh.restore(raw)
 assert fresh.checkpoint()==raw;material_equal(first,restored)
 second=owner.solve(panel.actions,(initial*.98,),**kw)
 repeated=fresh.solve(panel.actions,(initial*.98,),**kw)
 assert owner.checkpoint()==fresh.checkpoint() and second.history==repeated.history
 material_equal(second,repeated)
 assert second.free_equilibrium_ratio<=1e-8 and second.constraint_max<=1e-9
 for name in ('shell_displacement','cell_resultants','support_reactions','beam_station_accumulated'):
  np.testing.assert_array_equal(getattr(second,name),getattr(repeated,name))
 (Path(__file__).parent.parent/('consumer-shell-j2-'+str(shell_j2)+'.json')).write_text(json.dumps(dict(
     status=panel.status,identity=owner.preflight()['identity'],shell_j2=shell_j2,
     history=second.history,equilibrium=second.free_equilibrium_ratio,
     constraint=second.constraint_max,exact_restart=True),indent=2))
