from pathlib import Path
import sys,os,json,hashlib,importlib.util,subprocess,zipfile,ast,shutil
root=Path(__file__).parent;repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001');site=root/'site';fixtures=root/'fixtures';old_root=root.parent/'r8-native-retained-scale-installed-v1';old_site=old_root/'site';consumer_root=root.parent/'r8-native-retained-scale-consumer-installed-v1';consumer_site=consumer_root/'site';consumer_repo=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
checks=['test_stiffened_shell_curved_material_displacement.py','test_stiffened_shell_curved_material.py::test_old_curved_material_guards_and_new_policy_limits','test_stiffened_shell_displacement_public.py::test_public_displacement_cancel_restart_and_atomic_publication','test_stiffened_shell_displacement_rebase.py','test_stiffened_shell_displacement_checkpoint.py','test_stiffened_shell_curved_material_arc.py::test_material_arc_without_shell_j2','test_stiffened_shell_curved_arc.py','test_installed_legacy_displacement_bytes.py']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mode=sys.argv[1] if len(sys.argv)>1 else 'installed'
if mode=='prepare':
 fixtures.mkdir(exist_ok=True);pending=[v.split('::')[0][:-3] for v in checks if not v.startswith('test_installed')];seen=set()
 while pending:
  name=pending.pop()
  if name in seen:continue
  seen.add(name);p=repo/'tests'/(name+'.py');shutil.copyfile(p,fixtures/p.name)
  for node in ast.walk(ast.parse(p.read_text(encoding='utf-8-sig'))):
   if isinstance(node,ast.ImportFrom) and node.module and node.module.startswith('test_'):pending.append(node.module)
 for p in (repo/'docs/reference_cases').glob('*.py'):
  target=fixtures/'docs/reference_cases'/p.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
 for label,args in [('build',['wheel','--no-deps','--no-build-isolation','--no-cache-dir','--no-index','--wheel-dir',str(root/'wheels'),str(repo)]),('install',None)]:
  if args is None:args=['install','--no-deps','--no-cache-dir','--no-index','--target',str(site),str(next((root/'wheels').glob('*.whl')))]
  with (root/(label+'.log')).open('w') as log:subprocess.run([sys.executable,'-m','pip',*args],stdout=log,stderr=subprocess.STDOUT,check=True)
 artifacts={}
 for source,artifact_root,installed,package in ((repo,root,site,'anysolver'),(consumer_repo,consumer_root,consumer_site,'anyfem')):
  wheel=next((artifact_root/'wheels').glob('*.whl'));modules={}
  with zipfile.ZipFile(wheel) as z:
   for p in (source/'src'/package).rglob('*.py'):
    rel=p.relative_to(source/'src').as_posix();assert p.read_bytes()==z.read(rel)==(installed/rel).read_bytes(),rel;modules[rel]=sha(p)
  artifacts[package]=dict(wheel_sha256=sha(wheel),modules=modules)
 artifacts['fixtures']={p.relative_to(fixtures).as_posix():sha(p) for p in fixtures.rglob('*.py')};(root/'artifact.json').write_text(json.dumps(artifacts,indent=2));print(json.dumps({n:dict(wheel_sha256=v['wheel_sha256'],modules=len(v['modules'])) for n,v in artifacts.items() if n!='fixtures'}));raise SystemExit()
if mode in ('legacy-child','installed-child','consumer-child'):
 import anysolver,numba,threadpoolctl
 expected=old_site if mode=='legacy-child' else site;assert Path(anysolver.__file__).resolve().is_relative_to(expected.resolve())
 if mode=='legacy-child':
  from anysolver import stiffened_shell as ss
  from test_stiffened_shell_bl5_coupled_material import coupled
  from test_stiffened_shell_bl5_finite import _action
  owner=ss.create_analysis(definition=coupled())
  try:
   owner.solve(_action(500.),(.5,1.),max_iterations=20,max_backtracks=12)
   dof=owner._shell_count+6*owner._beam_index[105]+2;initial=owner._finite_driver._state.q[dof]
   endpoint=owner.solve(_action(50.),(initial*1.01,),displacement_control=ss.DisplacementControl('beam',105,2),max_iterations=20,max_backtracks=12)
   raw=owner.checkpoint();(root/'legacy-endpoint.bin').write_bytes(raw)
   (root/'legacy-observation.json').write_text(json.dumps(dict(wheel_sha256=sha(next((old_root/'wheels').glob('*.whl'))),checkpoint_sha256=hashlib.sha256(raw).hexdigest(),initial=initial,target=endpoint.target,amplitude=endpoint.amplitude,identity=owner.preflight()['identity']),indent=2))
  finally:owner.close()
  code=0
 else:
  import pytest
  selected=['test_installed_curved_displacement_project.py'] if mode=='consumer-child' else checks
  code=pytest.main(['-q','-p','no:cacheprovider','--basetemp=temporary','--junitxml=result.xml',*[str(fixtures/v) for v in selected]])
 pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools);assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
 imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith(('anysolver','anyfem')) and getattr(m,'__file__',None)}
 for n,p in imports.items():assert Path(p).is_relative_to((consumer_site if n.startswith('anyfem') else expected).resolve()),(n,p)
 Path('runtime.json').write_text(json.dumps(dict(imports=imports,pools=pools,jit_disabled=True,python=sys.version),indent=2));raise SystemExit(code)
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=os.pathsep.join(map(str,((old_site if mode=='legacy' else site),consumer_site,fixtures)));s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
r=s.supervised([sys.executable,'-u',str(Path(__file__)),('legacy-child' if mode=='legacy' else 'consumer-child' if mode=='consumer' else 'installed-child')],root/mode);print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
