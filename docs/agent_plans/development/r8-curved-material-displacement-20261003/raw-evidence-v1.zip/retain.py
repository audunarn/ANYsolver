"""Retain only the fresh scoped evidence; never archive inherited environments."""
from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET

root=Path(__file__).parent
repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
out=repo/'docs/agent_plans/development/r8-curved-material-displacement-20261003'
out.mkdir(exist_ok=True)
records={}
safe_keys=('command','exit_code','elapsed_seconds','sampled_peak_tree_bytes',
    'sampled_max_process_tree_threads','resource_observed','resource_limit',
    'timeout_seconds','memory_limit_bytes','supervisor_sha256')
thread_keys=('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS',
    'NUMBA_NUM_THREADS','NUMBA_DISABLE_JIT','CCX_NPROC_RESULTS','CCX_NPROC_EQUATION_SOLVER')
with zipfile.ZipFile(out/'raw-evidence-v1.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,path in (
        ('source-v1',root.parent/'r8-ge-pressure-source-v1/curved-displacement-v1'),
        ('source-v2',root.parent/'r8-ge-pressure-source-v1/curved-displacement-v2'),
        ('legacy',root/'legacy'),('installed',root/'installed'),('consumer',root/'consumer')):
        execution=json.loads((path/'execution.json').read_text())
        record={k:execution[k] for k in safe_keys if k in execution}
        record['environment']={k:execution.get('environment',{})[k] for k in thread_keys
            if k in execution.get('environment',{})}
        records[name]=record
        z.writestr(name+'/execution.json',json.dumps(record,indent=2))
        for filename in ('stdout.log','stderr.log','runtime.json','result.xml'):
            p=path/filename
            if p.exists():z.write(p,name+'/'+filename)
        if name in ('installed','consumer'):
            tests=ET.parse(path/'result.xml').getroot()
            suites=list(tests) if tests.tag=='testsuites' else [tests]
            records[name]['tests']={k:sum(int(s.attrib.get(k,'0')) for s in suites)
                for k in ('tests','failures','errors','skipped')}
    for filename in ('run.py','retain.py','artifact.json','build.log','install.log',
        'legacy-endpoint.bin','legacy-observation.json','legacy-compatibility.json',
        'independent-development-review.txt','consumer-shell-j2-False.json','consumer-shell-j2-True.json'):
        p=root/filename
        if p.exists():z.write(p,filename)
    for p in (root/'fixtures').rglob('*.py'):
        z.write(p,'fixtures/'+p.relative_to(root/'fixtures').as_posix())
    for filename,path in (
        ('supervisor.py',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py'),
        ('source-runner.py',root.parent/'r8-ge-pressure-source-v1/run-root.py')):
        z.write(path,filename)
artifact=json.loads((root/'artifact.json').read_text())
summary=dict(source_parent='a8a75970',status='IMPLEMENTED_NOT_QUALIFIED',
    executions=records,artifacts={n:dict(wheel_sha256=artifact[n]['wheel_sha256'],
    modules=len(artifact[n]['modules'])) for n in ('anysolver','anyfem')},
    raw_sha256=hashlib.sha256((out/'raw-evidence-v1.zip').read_bytes()).hexdigest())
(out/'summary-v1.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
