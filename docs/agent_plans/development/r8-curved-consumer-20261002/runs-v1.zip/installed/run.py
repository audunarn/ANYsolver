from pathlib import Path
import sys,os,json,hashlib,importlib.util,subprocess,zipfile
root=Path(__file__).parent;repo=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
solver_repo=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
site=root/'site';solver_site=root.parent/'r8-curved-arc-installed-v1/site';fixtures=root/'fixtures'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if len(sys.argv)>1 and sys.argv[1]=='prepare':
 for name,args in [('build',['wheel','--no-deps','--no-build-isolation','--no-cache-dir','--no-index','--wheel-dir',str(root/'wheels'),str(repo)]),('install',None)]:
  if args is None:args=['install','--no-deps','--no-cache-dir','--no-index','--target',str(site),str(next((root/'wheels').glob('*.whl')))]
  with (root/(name+'.log')).open('w') as log:subprocess.run([sys.executable,'-m','pip',*args],stdout=log,stderr=subprocess.STDOUT,check=True)
 wheel=next((root/'wheels').glob('*.whl'));modules={}
 with zipfile.ZipFile(wheel) as archive:
  for p in (repo/'src/anyfem').rglob('*.py'):
   n=p.relative_to(repo/'src').as_posix();assert p.read_bytes()==archive.read(n)==(site/n).read_bytes(),n;modules[n]=sha(p)
 for p in (solver_repo/'src/anysolver').rglob('*.py'):
  assert p.read_bytes()==(solver_site/p.relative_to(solver_repo/'src')).read_bytes(),p.name
 solver_artifact=json.loads((root.parent/'r8-curved-arc-installed-v1/artifact.json').read_text())
 (root/'artifact.json').write_text(json.dumps(dict(consumer_wheel_sha256=sha(wheel),consumer_modules=modules,solver_wheel_sha256=solver_artifact['wheel_sha256'],solver_modules_matched=len(solver_artifact['modules']),fixtures={p.relative_to(fixtures).as_posix():sha(p) for p in fixtures.rglob('*.py')}),indent=2))
 print(json.dumps(dict(consumer_modules=len(modules),consumer_wheel_sha256=sha(wheel))))
elif len(sys.argv)>1:
 sys.path.insert(0,str(fixtures))
 import anyfem,anysolver,numba,threadpoolctl,pytest
 assert Path(anyfem.__file__).resolve().is_relative_to(site.resolve())
 assert Path(anysolver.__file__).resolve().is_relative_to(solver_site.resolve())
 pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
 assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
 code=pytest.main(['-q','-p','no:cacheprovider','--junitxml=result.xml',str(fixtures/'test_curved_point_consumer.py'),str(fixtures/'test_experimental_stiffened_shell_consumer.py')+'::test_ge_point_panel_constructs_solves_and_reopens',str(fixtures/'test_experimental_stiffened_shell_consumer.py')+'::test_q4_pullback_v3_round_trip_and_strict_selection'])
 if code:raise SystemExit(code)
 # Actual E04 geometry is a captured reference-case fixture, not consumer-owned mechanics.
 from dataclasses import replace
 import numpy as np
 from docs.reference_cases.stiffened_shell_e04_roof import build,definition
 from anysolver import stiffened_shell as ss
 from anyfem.solve.stiffened_shell import ExperimentalGEPointPanel,save_case,load_case
 from anyfem.io.project_file import save_project,load_project
 from anyfem.model.project import Project
 from anyfem.model.records import AnalysisDefinition
 case=build(4,4);d=definition(case,density_kg_m3=1.);node=case.loaded_shell_node+1
 shell=replace(d.shell,coordinates_m=tuple(tuple(float(v) for v in row) for row in d.shell.coordinates_m))
 actions=(ss.NodalAction('shell',node,(0.,0.,-10.,0.,0.,0.)),)
 panel=ExperimentalGEPointPanel(shell,tuple(d.beams),tuple(d.points),tuple(d.fixed),actions,
  q4_pullback_policy=d.q4_pullback_policy,shell_reference_policy=d.shell_reference_policy)
 reopened=load_case(save_case(panel,'roof.anyfem-ge.json'));assert reopened.to_dict()==panel.to_dict()
 project=Project('E04 curved point roof',mesh_only=True);analysis=AnalysisDefinition.experimental_point_panel('roof',reopened);project.add_analysis(analysis)
 path=save_project(project,'roof.anyfem');stored=load_project(path).analyses[analysis.id]
 owner=stored.create_point_panel_analysis();restored=None
 try:
  owner.solve(actions,(1.,));control=ss.ArcLengthControl('shell',node,2,ss.PhysicalChordMetric(case.metric_weights,case.length),1e-5,-1)
  owner.continue_arc_length(actions,control);prefix=owner.checkpoint();Path('roof-prefix.bin').write_bytes(prefix)
  restored=load_project(path).analyses[analysis.id].create_point_panel_analysis();restored.restore(prefix)
  assert restored.checkpoint()==prefix
  live=owner.continue_arc_length(actions,control);repeated=restored.continue_arc_length(actions,control)
  assert owner.checkpoint()==restored.checkpoint();np.testing.assert_array_equal(live.cell_resultants,repeated.cell_resultants)
  Path('roof-final.bin').write_bytes(restored.checkpoint())
  Path('roof-result.json').write_text(json.dumps(dict(status='COMPLETED_DEVELOPMENT_ONLY',schema=panel.to_dict()['schema'],shells=len(case.quads),beams=len(case.beam_cells),restart_bytes_equal=True,equilibrium=repeated.free_equilibrium_ratio,constraint=repeated.constraint_max,central_translation_m=repeated.shell_displacement.reshape(-1,6)[case.loaded_shell_node,:3].tolist(),downward_force_n=10*(1+repeated.amplitude)),indent=2))
 finally:
  owner.close()
  if restored is not None:restored.close()
 imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith(('anysolver','anyfem')) and getattr(m,'__file__',None)}
 assert all(Path(p).is_relative_to((site if n.startswith('anyfem') else solver_site).resolve()) for n,p in imports.items())
 Path('runtime.json').write_text(json.dumps(dict(imports=imports,pools=threadpoolctl.threadpool_info(),python=sys.version,jit_disabled=bool(numba.config.DISABLE_JIT)),indent=2))
else:
 spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
 s.ENV['PYTHONPATH']=str(site)+os.pathsep+str(solver_site);s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
 result=s.supervised([sys.executable,'-u',str(Path(__file__)),'child'],root/'installed')
 print(json.dumps({k:result[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
