from pathlib import Path
import importlib.util,os,sys,json
root=Path(__file__).parent;repo=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=str(root.parent/'r8-curved-arc-installed-v1/site')+os.pathsep+str(repo/'src')
s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
r=s.supervised([sys.executable,'-m','pytest','-q','-p','no:cacheprovider',str(repo/'tests/test_curved_point_consumer.py'),str(repo/'tests/test_experimental_stiffened_shell_consumer.py')+'::test_ge_point_panel_constructs_solves_and_reopens',str(repo/'tests/test_experimental_stiffened_shell_consumer.py')+'::test_q4_pullback_v3_round_trip_and_strict_selection'],root/'tests')
print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
