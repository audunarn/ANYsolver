from pathlib import Path
import json
root=Path(__file__).parent
r=json.loads((root/"large-route-v1/result.json").read_text(encoding="utf-8"))
e=json.loads((root/"large-route-v1/execution.json").read_text(encoding="utf-8"))
p=json.loads((root/"joined-provenance-v1.json").read_text(encoding="utf-8"))["prior_files"]
assert r["status"]=="COMPLETED" and r["point_connections"]==110
assert r["shell_elements"]==10000 and r["beam_elements"]==1000
assert r["matrix_rows"]==97320 and r["preflight"]["matrix_nnz"]==4972608
assert r["input_sha256"]==p["large-v1/large.anyfem-ge.json"]
assert r["project_sha256"]==p["large-v1/large.anyfem"]
assert r["equilibrium_ratio"]<=1e-8 and r["constraint_max"]<=1e-9
assert max(r["force_balance_ratio"],r["moment_balance_ratio"])<=1e-8
assert max(r["baseline_physical_errors"].values())<=1e-10
assert r["factorizations"]==[1,1]
assert e["exit_code"]==0 and e["resource_limit"] is None and e["resource_observed"]
assert e["elapsed_seconds"]<=600 and e["sampled_peak_tree_bytes"]<=8*1024**3
out=dict(status="PASSED_DEVELOPMENT_CHECK",qualification="NOT_QUALIFIED",
    equilibrium=r["equilibrium_ratio"],constraint=r["constraint_max"],
    force=r["force_balance_ratio"],moment=r["moment_balance_ratio"],
    max_baseline_error=max(r["baseline_physical_errors"].values()),
    route_seconds=r["route_seconds"],supervised_seconds=e["elapsed_seconds"],
    sampled_peak_tree_bytes=e["sampled_peak_tree_bytes"],seconds=r["seconds"],
    dimensions={k:r[k] for k in ("shell_elements","beam_elements","point_connections","matrix_rows")},
    matrix_nnz=r["preflight"]["matrix_nnz"],
    frozen_input_hashes=p,
    thresholds=dict(equilibrium=1e-8,constraint=1e-9,balance=1e-8,physical_vector=1e-10,
        supervised_seconds=600,process_tree_bytes=8*1024**3),
    provenance_file="joined-provenance-v1.json",
    raw_files=["large-route-v1/result.json","large-route-v1/execution.json",
        "large-route-v1/runtime.json"])
(root/"large-adjudication-v2.json").write_text(json.dumps(out,indent=2),encoding="utf-8")
print(out["status"])
