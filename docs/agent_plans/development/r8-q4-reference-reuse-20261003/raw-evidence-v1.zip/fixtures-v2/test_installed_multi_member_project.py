from pathlib import Path
import json
import numpy as np
from anyfem.io.project_file import load_project, save_project
from anyfem.model.project import Project
from anyfem.model.records import AnalysisDefinition
from anyfem.solve.stiffened_shell import ExperimentalGEPointPanel, save_case, load_case
from scripts.experimental_stiffened_ge_multi_member_panel import make_definition, actions_for, check_balance

def test_installed_connected_multi_member_project_restart(tmp_path):
    definition=make_definition(8,4)
    actions=actions_for(definition)
    case=ExperimentalGEPointPanel(definition.shell,definition.beams,
        definition.points,definition.fixed,actions=actions)
    standalone=load_case(save_case(case,tmp_path/'multi.anyfem-ge.json'))
    assert standalone.to_dict()==case.to_dict()
    project=Project("connected four stiffeners",mesh_only=True)
    record=AnalysisDefinition.experimental_point_panel("32 native members",standalone)
    project.add_analysis(record)
    reopened=load_project(save_project(project,tmp_path/'multi.anyfem'))
    restored_record=reopened.analyses[record.id]
    assert restored_record.beam_formulation_options["panel"]==case.to_dict()
    owner=case.create_analysis()
    resumed=restored_record.create_point_panel_analysis()
    try:
        assert owner.preflight()["identity"]==resumed.preflight()["identity"]
        first=owner.solve_linear(actions)
        assert first.status=="completed" and not first.production_qualified
        force,moment=check_balance(definition,first,actions)
        assert force<=1e-8 and moment<=1e-8
        checkpoint=owner.checkpoint()
        resumed.restore(checkpoint)
        for name in ("shell_displacement","beam_coordinates","multipliers","reactions"):
            np.testing.assert_array_equal(getattr(first,name),getattr(resumed.recover(),name))
        assert resumed.checkpoint()==checkpoint
        second=owner.solve_linear(actions_for(definition,200.))
        continued=resumed.solve_linear(actions_for(definition,200.))
        for name in ("shell_displacement","beam_coordinates","multipliers","reactions"):
            np.testing.assert_array_equal(getattr(second,name),getattr(continued,name))
        assert owner.preflight()["reference_linear_factorizations"]==1
        assert resumed.preflight()["reference_linear_factorizations"]==1
        Path("consumer-screen.json").write_text(json.dumps(dict(
            status=first.status,qualified=False,standalone_bytes=(tmp_path/'multi.anyfem-ge.json').stat().st_size,
            project_bytes=(tmp_path/'multi.anyfem').stat().st_size,
            beam_elements=len(definition.beams),shell_elements=len(definition.shell.q4_elements),
            force_balance_ratio=force,moment_balance_ratio=moment,
            checkpoint_bytes=len(checkpoint),preflight=resumed.preflight()),indent=2),encoding="utf-8")
    finally:
        owner.close();resumed.close()
