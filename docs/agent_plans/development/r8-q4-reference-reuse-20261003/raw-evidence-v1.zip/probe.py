from pathlib import Path
import importlib.util,json,os,sys
root=Path(__file__).parent
site=root.parent/'r8-curved-material-staged-installed-v2/site'
if len(sys.argv)>1:
    import numpy as np,numba,threadpoolctl
    from anysolver import stiffened_shell as ss
    from anymaterial import DNVC208MaterialCurve
    from anysolver._stiffened_shell_ge_experimental import _shell_reference
    from anysolver.corotational import (_corotational_cache,_corotational_deformation_state,
        _consistent_corotational_tangent,_dense_block_rotation,corotational_element_response)
    assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
    pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
    rows=[]
    base=np.array(((0.,0.,0.),(2.,0.,0.),(2.,1.,0.),(0.,1.,0.)))
    angle=.47
    turn=np.array(((np.cos(angle),-np.sin(angle),0.),(np.sin(angle),np.cos(angle),0.),(0.,0.,1.)))
    cases=(('rectangle',base,.01,(1,2,3,4)),
           ('translated',base+[1e5,-2e5,.3],.01,(1,2,3,4)),
           ('skew',np.array(((0.,0.,0.),(2.,.2,0.),(1.8,1.,0.),(-.2,.8,0.))),.04,(1,2,3,4)),
           ('rotated',base@turn.T,.01,(1,2,3,4)),
           ('thin',base,.0005,(1,2,3,4)),
           ('cyclic',base,.01,(2,3,4,1)))
    for name,xyz,h,connectivity in cases:
        for j2 in (False,True):
            curve=DNVC208MaterialCurve(80e6,85e6,100e6,.002,.02,280e6,.18) if j2 else None
            panel=ss.ShellPanel((1,2,3,4),tuple(map(tuple,xyz)),(connectivity,),h,210e9,.3,7850.,j2_curve=curve)
            model,ids,coords,index,pieces=_shell_reference(panel)
            eid,element,slots,origin=pieces[0]
            before={k:v.copy() for k,v in origin.items()}
            oldf,oldk,_=corotational_element_response(model,eid,element,np.zeros(24),True,
                committed_state=origin,num_layers=3,tangent_mode='consistent')
            reference=_corotational_cache(model)[eid]
            u_d,R,deformed=_corotational_deformation_state(reference,element,np.zeros(24))
            k=element.compute_stiffness_matrix(model.mesh,model.get_material('shell')).copy()
            newf=np.zeros(24)
            newk=_consistent_corotational_tangent(reference,element,deformed,np.zeros((4,3)),R,
                _dense_block_rotation(R,4),newf,k)
            length=float(np.sqrt(np.mean(np.sum((reference.coordinates-reference.centroid)**2,axis=1))))
            scale=np.tile([length,length,length,1.,1.,1.],4)
            workold=scale[:,None]*oldk*scale[None,:]
            worknew=scale[:,None]*newk*scale[None,:]
            force=float(np.linalg.norm(scale*(newf-oldf))/max(np.linalg.norm(workold),np.finfo(float).tiny))
            raw=float(np.linalg.norm(newk-oldk)/np.linalg.norm(oldk))
            work=float(np.linalg.norm(worknew-workold)/np.linalg.norm(workold))
            basis=np.zeros((24,6))
            for i,arm in enumerate(reference.coordinates-reference.centroid):
                basis[6*i:6*i+3,:3]=np.eye(3)
                for j,axis in enumerate(np.eye(3)):
                    basis[6*i:6*i+3,3+j]=np.cross(axis,arm)
                    basis[6*i+3:6*i+6,3+j]=axis
            rigid=float(np.linalg.norm(newk@basis)/(np.linalg.norm(newk)*np.linalg.norm(basis)))
            row=dict(case=name,j2=j2,exact_zero_deformation=not np.any(u_d),
                     deformation_max=float(np.max(np.abs(u_d))),force_work_error=force,
                     raw_tangent_error=raw,work_tangent_error=work,rigid_error=rigid)
            rows.append(row)
            for k,v in before.items():np.testing.assert_array_equal(origin[k],v)
            assert raw<=1e-10 and work<=1e-10 and force<=1e-10 and rigid<=1e-9,row
    Path('result.json').write_text(json.dumps(dict(rows=rows,pools=pools,numba_threads=1,jit_disabled=True,
        anysolver_site=str(site)),indent=2),encoding='utf-8')
    print(json.dumps(dict(cases=len(rows),max_tangent=max(r['raw_tangent_error'] for r in rows),
        exact_zero=sum(r['exact_zero_deformation'] for r in rows))),flush=True)
    raise SystemExit()
spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV['PYTHONPATH']=str(site)
r=s.supervised([sys.executable,'-u',str(Path(__file__)),'child'],root/'probe-v1')
print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
