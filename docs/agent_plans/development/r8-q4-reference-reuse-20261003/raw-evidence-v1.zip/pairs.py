from pathlib import Path
import hashlib, importlib.util, json, os, sys, time
root=Path(__file__).parent
fixtures=root/"fixtures-v2"
baseline=root.parent/"r8-curved-material-staged-installed-v2/site"
candidate=root/"site"
if sys.argv[1]=="child":
    role,case=sys.argv[2:4]
    site=baseline if role=="baseline" else candidate
    begun=time.perf_counter()
    import numpy as np,anysolver,numba,threadpoolctl
    from anysolver import stiffened_shell as ss
    from anysolver.corotational_performance import corotational_performance_status, reset_corotational_performance_status
    from scripts.experimental_stiffened_ge_multi_member_panel import make_definition,actions_for,check_balance,run
    assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
    assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p["num_threads"]==1 for p in pools)
    import_seconds=time.perf_counter()-begun
    run(2,3)
    reset_corotational_performance_status()
    begun=time.perf_counter()
    definition=make_definition(20,6,shell_transverse_cells=20,tie_stride=2) if case=="400q4" else make_definition(8,4)
    definition_seconds=time.perf_counter()-begun
    actions=actions_for(definition)
    made=time.perf_counter()
    owner=ss.create_analysis(definition=definition)
    compile_seconds=time.perf_counter()-made
    resumed=None
    try:
        made=time.perf_counter();first=owner.solve_linear(actions);solve_seconds=time.perf_counter()-made
        recovered=owner.recover()
        assert recovered is first
        checkpoint=owner.checkpoint()
        second=owner.solve_linear(actions_for(definition,200.))
        made=time.perf_counter();resumed=ss.create_analysis(definition=definition)
        restore_compile_seconds=time.perf_counter()-made
        made=time.perf_counter();restored=resumed.restore(checkpoint);restore_seconds=time.perf_counter()-made
        assert resumed.checkpoint()==checkpoint
        continued=resumed.solve_linear(actions_for(definition,200.))
        full_seconds=time.perf_counter()-begun
        physical={}
        for name in ("shell_displacement","beam_coordinates","multipliers","reactions"):
            a=getattr(first,name);b=getattr(second,name)
            np.testing.assert_array_equal(a,getattr(restored,name))
            np.testing.assert_array_equal(b,getattr(continued,name))
            physical["first_"+name]=a;physical["second_"+name]=b
        force,moment=check_balance(definition,first,actions)
        assert force<=1e-8 and moment<=1e-8
        assert first.status=="completed" and first.free_equilibrium_ratio<=1e-8 and first.constraint_max<=1e-9
        preflight=owner.preflight()
        assert preflight["reference_linear_factorizations"]==1
        assert resumed.preflight()["reference_linear_factorizations"]==1
        np.savez("physical.npz",**physical)
        Path("checkpoint.bin").write_bytes(checkpoint)
        diagnostics=corotational_performance_status()
        pools=threadpoolctl.threadpool_info();assert all(p["num_threads"]==1 for p in pools)
        record=dict(role=role,case=case,status=first.status,
            source_site=str(site),anysolver_file=anysolver.__file__,python=sys.version,
            import_seconds=import_seconds,seconds=dict(definition=definition_seconds,
            compile=compile_seconds,first_solve=solve_seconds,
            restore_compile=restore_compile_seconds,restore=restore_seconds,full=full_seconds),
            shell_elements=len(definition.shell.q4_elements),beam_elements=len(definition.beams),
            preflight=preflight,equilibrium=first.free_equilibrium_ratio,
            constraint=first.constraint_max,force_balance=force,moment_balance=moment,
            checkpoint_sha256=hashlib.sha256(checkpoint).hexdigest(),
            rotation_work={k:diagnostics[k] for k in ("force_block_rotations","tangent_block_rotations","dense_consistent_rotations")},
            numba_threads=1,jit_disabled=True,pools=pools)
        Path("result.json").write_text(json.dumps(record,indent=2),encoding="utf-8")
        print(json.dumps(dict(role=role,case=case,full=full_seconds,compile=compile_seconds)))
    finally:
        if resumed is not None:resumed.close()
        owner.close()
    raise SystemExit()
spec=importlib.util.spec_from_file_location("supervisor",root.parent/"r8-b2-panel-resolution-installed-v1/matched-run.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
case,first,last=sys.argv[1],int(sys.argv[2]),int(sys.argv[3])
for pair in range(first,last+1):
    for role in (("baseline","candidate") if pair%2 else ("candidate","baseline")):
        site=baseline if role=="baseline" else candidate
        s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(site,fixtures)))
        folder=root/"pairs-v1"/case/(str(pair)+"-"+role)
        r=s.supervised([sys.executable,"-u",str(Path(__file__)),"child",role,case],folder)
        v=json.loads((folder/"result.json").read_text(encoding="utf-8"))
        print(json.dumps(dict(pair=pair,role=role,case=case,full=v["seconds"]["full"],
            elapsed=r["elapsed_seconds"],peak=r["sampled_peak_tree_bytes"])),flush=True)
