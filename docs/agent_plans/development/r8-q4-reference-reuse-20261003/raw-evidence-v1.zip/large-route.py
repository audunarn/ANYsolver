from pathlib import Path
import hashlib,importlib.util,json,os,sys,time
root=Path(__file__).parent
previous=root.parent/"r8-ge-member-scale-installed-v1"
site=root/"site";consumer=previous/"consumer-site"
if len(sys.argv)>1:
    import numpy as np,anysolver,anyfem,numba,threadpoolctl
    from anyfem.io.project_file import load_project
    from anyfem.solve.stiffened_shell import load_case
    from scripts.experimental_stiffened_ge_multi_member_panel import actions_for,check_balance
    assert Path(anysolver.__file__).resolve().is_relative_to(site.resolve())
    assert Path(anyfem.__file__).resolve().is_relative_to(consumer.resolve())
    pools=threadpoolctl.threadpool_info()
    assert pools and all(p["num_threads"]==1 for p in pools)
    assert numba.config.DISABLE_JIT and numba.get_num_threads()==1
    started=time.perf_counter()
    record=dict(status="IN_PROGRESS",qualification="NOT_QUALIFIED",seconds={})
    def phase(name,before):
        record["seconds"][name]=time.perf_counter()-before
        Path("progress.json").write_text(json.dumps(record,indent=2),encoding="utf-8")
        print(name,record["seconds"][name],flush=True)
    before=time.perf_counter()
    inp=previous/"large-v1/large.anyfem-ge.json"
    project_path=previous/"large-v1/large.anyfem"
    case=load_case(inp);project=load_project(project_path)
    analysis=next(iter(project.analyses.values()))
    assert analysis.beam_formulation_options["panel"]==case.to_dict()
    definition=case.definition();actions=actions_for(definition)
    record.update(input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),
        project_sha256=hashlib.sha256(project_path.read_bytes()).hexdigest(),
        shell_elements=len(definition.shell.q4_elements),beam_elements=len(definition.beams),
        point_connections=len(definition.points))
    assert record["shell_elements"]==10000 and record["beam_elements"]==1000
    phase("reopen",before)
    before=time.perf_counter()
    owner=analysis.create_point_panel_analysis();resumed=None
    preflight=owner.preflight()
    rows=preflight["physical_dofs"]+preflight["retained_dofs"]+preflight["constraints"]-len(definition.fixed)
    assert rows==97320 and rows<=100000
    record.update(matrix_rows=rows,preflight=preflight)
    phase("compile",before)
    try:
        before=time.perf_counter();first=owner.solve_linear(actions)
        assert first.status=="completed"
        force,moment=check_balance(definition,first,actions)
        assert force<=1e-8 and moment<=1e-8
        record.update(equilibrium_ratio=first.free_equilibrium_ratio,constraint_max=first.constraint_max,
            force_balance_ratio=force,moment_balance_ratio=moment)
        phase("first_solve",before)
        before=time.perf_counter();checkpoint=owner.checkpoint()
        assert checkpoint[:10]==bytes((65,78,89,83,71,69,67,80,50,0))
        Path("accepted.bin").write_bytes(checkpoint)
        phase("recovery_checkpoint",before)
        before=time.perf_counter();second=owner.solve_linear(actions_for(definition,200.))
        assert owner.preflight()["reference_linear_factorizations"]==1
        phase("continued_load",before)
        # Frozen prior-artifact numerical oracle; no independent input regeneration.
        errors={}
        for prefix,result in (("first",first),("second",second)):
            baseline=np.load(previous/"checkpoint-v2"/(prefix+".npz"))
            for name in baseline.files:
                a,b=getattr(result,name),baseline[name]
                e=float(np.linalg.norm(a-b)/max(np.linalg.norm(b),1e-8))
                errors[prefix+"_"+name]=e;assert e<=1e-10,(prefix,name,e)
            np.savez(prefix+".npz",**{name:getattr(result,name) for name in baseline.files})
        record["baseline_physical_errors"]=errors
        before=time.perf_counter();resumed=analysis.create_point_panel_analysis()
        phase("restore_compile",before)
        before=time.perf_counter();resumed.restore(checkpoint)
        assert resumed.checkpoint()==checkpoint
        for name in ("shell_displacement","beam_coordinates","multipliers","reactions"):
            np.testing.assert_array_equal(getattr(first,name),getattr(resumed.recover(),name))
        phase("snapshot_restore",before)
        before=time.perf_counter();continued=resumed.solve_linear(actions_for(definition,200.))
        for name in ("shell_displacement","beam_coordinates","multipliers","reactions"):
            np.testing.assert_array_equal(getattr(second,name),getattr(continued,name))
        assert resumed.preflight()["reference_linear_factorizations"]==1
        phase("restarted_continuation",before)
        record["checkpoint_bytes"]=len(checkpoint)
        record["checkpoint_sha256"]=hashlib.sha256(checkpoint).hexdigest()
        record["factorizations"]=(1,1)
    finally:
        if resumed is not None:resumed.close()
        owner.close()
    record.update(status="COMPLETED",route_seconds=time.perf_counter()-started)
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items()
        if n.startswith(("anysolver","anyfem")) and getattr(m,"__file__",None)}
    for n,p in imports.items():
        assert Path(p).is_relative_to((consumer if n.startswith("anyfem") else site).resolve()),(n,p)
    pools=threadpoolctl.threadpool_info();assert all(p["num_threads"]==1 for p in pools)
    Path("runtime.json").write_text(json.dumps(dict(imports=imports,pools=pools,
        jit_disabled=True,numba_threads=1,python=sys.version),indent=2),encoding="utf-8")
    Path("result.json").write_text(json.dumps(record,indent=2),encoding="utf-8")
    print(json.dumps(dict(status=record["status"],seconds=record["route_seconds"])),flush=True)
    raise SystemExit()
spec=importlib.util.spec_from_file_location("supervisor",previous/"size-supervisor.py")
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.ENV["PYTHONPATH"]=os.pathsep.join(map(str,(site,consumer,root/"fixtures-v2")))
r=s.supervised([sys.executable,"-u",str(Path(__file__)),"child"],root/"large-route-v1")
print(json.dumps({k:r[k] for k in ("exit_code","elapsed_seconds","sampled_peak_tree_bytes")}))
