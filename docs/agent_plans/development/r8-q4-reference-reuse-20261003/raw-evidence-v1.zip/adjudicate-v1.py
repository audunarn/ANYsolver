from pathlib import Path
import json,sys,statistics
import numpy as np
root=Path(__file__).parent
case=sys.argv[1];n=int(sys.argv[2])
rows=[]
for pair in range(1,n+1):
    folders={role:root/"pairs-v1"/case/(str(pair)+"-"+role) for role in ("baseline","candidate")}
    v={role:json.loads((p/"result.json").read_text(encoding="utf-8")) for role,p in folders.items()}
    data={role:np.load(p/"physical.npz") for role,p in folders.items()}
    errors={}
    for name in data["baseline"].files:
        a,b=data["candidate"][name],data["baseline"][name]
        error=float(np.linalg.norm(a-b)/max(np.linalg.norm(b),1e-8))
        errors[name]=error
        assert error<=1e-10,(pair,name,error)
    for key in ("identity","physical_dofs","retained_dofs","constraints","matrix_nnz",
                "reference_linear_factorizations","reference_linear_refinements"):
        assert v["candidate"]["preflight"][key]==v["baseline"]["preflight"][key],(pair,key)
    assert v["baseline"]["rotation_work"]==v["candidate"]["rotation_work"]
    rows.append(dict(pair=pair,baseline=v["baseline"]["seconds"]["full"],
        candidate=v["candidate"]["seconds"]["full"],
        baseline_compile=v["baseline"]["seconds"]["compile"],
        candidate_compile=v["candidate"]["seconds"]["compile"],physical_errors=errors))
med=lambda key:statistics.median(r[key] for r in rows)
report=dict(case=case,pairs=n,rows=rows,baseline_median=med("baseline"),
    candidate_median=med("candidate"),route_reduction_percent=100*(1-med("candidate")/med("baseline")),
    compile_reduction_percent=100*(1-med("candidate_compile")/med("baseline_compile")),
    max_physical_error=max(e for r in rows for e in r["physical_errors"].values()),
    qualification="NOT_QUALIFIED")
if case=="400q4":assert report["route_reduction_percent"]>=10.
else:assert report["route_reduction_percent"]>=-5.
path=root/("adjudication-"+case+"-"+str(n)+"-v1.json")
path.write_text(json.dumps(report,indent=2),encoding="utf-8")
print(json.dumps({k:v for k,v in report.items() if k!="rows"}))
