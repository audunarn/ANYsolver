from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).parent
repo=Path("C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001")
previous=root.parent/"r8-ge-member-scale-installed-v1"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inventory=json.loads((repo/"docs/agent_plans/development/r8-ge-member-scale-20261003/summary-v1.json").read_text(encoding="utf-8"))
expected={}
for name in ("prepare-solver-identity.json","large-v1/large.anyfem","large-v1/large.anyfem-ge.json",
             "checkpoint-v2/first.npz","checkpoint-v2/second.npz","checkpoint-v2/result.json"):
    value=inventory["files"][name]["sha256"]
    assert sha(previous/name)==value,name
    expected[name]=value
prior=json.loads((previous/"prepare-solver-identity.json").read_text(encoding="utf-8"))["anysolver"]
baseline_root=root.parent/"r8-curved-material-staged-installed-v2"
baseline_wheel=next((baseline_root/"wheels").glob("*.whl"))
assert sha(baseline_wheel)==prior["wheel_sha256"]=="c795a5da5476313a58463f36e84e05aecfa4930e6d338e7597bd97a40c3bcc7d"
candidate=json.loads((root/"identity-v3.json").read_text(encoding="utf-8"))
identities={}
for label,wheel,site,modules,package in (
    ("baseline",baseline_wheel,baseline_root/"site",prior["modules"],"anysolver"),
    ("candidate",Path(candidate["wheel"]),root/"site",candidate["modules"],"anysolver")):
    actual={p.relative_to(site).as_posix():sha(p) for p in (site/package).rglob("*.py")}
    assert actual==modules,label
    with zipfile.ZipFile(wheel) as z:
        for name,digest in actual.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,(label,name)
    identities[label]=dict(wheel_sha256=sha(wheel),site=str(site),modules=actual)
# Candidate wheel/module comparison remains exact after the local source commit.
for name,digest in identities["candidate"]["modules"].items():
    assert sha(repo/"src"/name)==digest,name
report=dict(binding="Prior immutable identity joined and installed trees reverified after samples",
    scientific_qualification="NOT_QUALIFIED",identities=identities,
    prior_inventory_path=str(repo/"docs/agent_plans/development/r8-ge-member-scale-20261003/summary-v1.json"),
    prior_inventory_sha256=sha(repo/"docs/agent_plans/development/r8-ge-member-scale-20261003/summary-v1.json"),
    prior_files=expected)
(root/"joined-provenance-v1.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
print(json.dumps(dict(baseline_modules=len(identities["baseline"]["modules"]),
    candidate_modules=len(identities["candidate"]["modules"]),prior_inputs=len(expected))))
