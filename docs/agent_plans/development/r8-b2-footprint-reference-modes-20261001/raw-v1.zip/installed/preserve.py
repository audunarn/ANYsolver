from pathlib import Path
import hashlib, json, zipfile

r = Path(__file__).resolve().parent
w = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
d = w/'docs/agent_plans/development/r8-b2-footprint-reference-modes-20261001'
sha = lambda data: hashlib.sha256(data).hexdigest()
files = {}
for p in r.rglob('*'):
    rel = p.relative_to(r)
    if p.is_file() and rel.parts[0] not in ('build-source', 'site', 'focused-states', '__pycache__'):
        files['installed/'+str(rel).replace('\\', '/')] = p
temp = r.parent
for label, folder in (('initial-collection-failed', 'anysolver-portable-ci-3l7f59n_'),
                      ('initial-source', 'anysolver-portable-ci-6xyiyo0f'),
                      ('frame-source', 'anysolver-portable-ci-_ct4srpa'),
                      ('final-source', 'anysolver-portable-ci-8lygjvtf')):
    for p in (temp/folder/'P01').glob('*'):
        if p.is_file(): files['source-records/'+label+'/'+p.name] = p
files['source-records/final-source/worker-console.log'] = temp/'anysolver-footprint-rigid-support-20261001-worker.log'
for name in ('src/anysolver/_stiffened_shell_b2_q4_panel_experimental.py',
             'src/anysolver/stiffened_shell.py',
             'tests/test_stiffened_shell_b2_footprint_reference_modes.py',
             'tests/test_stiffened_shell_b2_nodal_rigid_footprint.py',
             'examples/stiffened_shell_b2_footprint_reference_modes.py'):
    files['source/'+name] = w/name
archive = d/'raw-v1.zip'
manifest = {name: {'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
            for name, p in files.items()}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, p in sorted(files.items()): z.write(p, name)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(manifest)
    assert all(sha(z.read(name)) == v['sha256'] for name, v in manifest.items())
identity = dict(files=len(files), archive_bytes=archive.stat().st_size,
                archive_sha256=sha(archive.read_bytes()), contents=manifest)
(d/'raw-v1-identity.json').write_text(json.dumps(identity, indent=2)+'\n')

active = w/'docs/agent_plans/B3_GE_E4_PL_ACTIVE_STATE.md'
history = w/'docs/agent_plans/history/ACTIVE_STATE_20261001_B2_MODAL_PREDELIVERY.md'
old = active.read_bytes()
with history.open('xb') as out: out.write(old)
assert history.read_bytes() == old
active.write_text('''# B3-GE / E4-PL / B2 — active state, 1 October 2026

## Current decision and authority

User resumed development under the new testing regime; do not communicate with
the other task. Revision 8 plan/goal remain active. Global/repository AGENTS.md
were re-read on request: compact tiered coordination, explicit file ownership,
proportionate verification and no repeated passed campaigns without cause.
Scientific criteria, protected history, resource limits and final G0–G6/B2
scope remain binding. Formal F03 authority is UNCONSUMED; aggregate gates and
release are not accepted. No publication/default/version change is authorized.

Worktree: C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001
Branch: codex/stiffened-main-reconcile-20261001. Baseline shared main:
1a0ae90122995b8419f1ed87cf770590b4bd8c05, merged testing-only PR61, all25CI passed.
Coupling base before this product slice: a7ff866c. Main and the contact task's
files are untouched. Original foreign F03 script SHA remains c908b1f3...9481.

## Delivered behavior and established facts

- Experimental multi-element Q4/S3 GE point/footprint static workflows, atomic
  stepping, selective recovery, snapshots/restart and virgin descriptor modes
  exist. Explicit V2 footprint increment charts and ANYfem persistence were
  previously installed-tested; their detailed evidence is linked in history.
- Separate physical B2 batch/static point and nodal-footprint workflows exist.
  New supported virgin footprint modes reuse physical K/M and actual C/T;
  normal spin remains locked and mechanical qualification incomplete. Typed
  results retain full multiplier rows and actual reference frames. Explicit
  bounded rigid-motion support admission rejects free/under-supported requests.
  One frozen installed wheel passed76 affected checks and the headless example;
 391 module bytes match source/wheel/site. Separate one modal/static factors,
  residuals<6e-16. Independent Read review has no remaining blocker for this
  scope; no different-family review or external formulation oracle is claimed.
  [Product, example, evidence and boundaries](development/r8-b2-footprint-reference-modes-20261001/results.md).
- BL5 retained derivative's two failing constraint rows are numerically repaired
  by one unchanged sparse factor/one compensated correction. Backward1.35e-13;
  all original controls and exact rational confirmation pass. Local relative
  applied-work slope at alpha=1 is -3.83549e-4. Stop coefficient tuning; this is
  not finite removal, drilling independence or cause allocation. V1/V2 failures
  remain retained. [Repair](development/r8-bl5-completion-sensitivity-20261001/repair-results.md).

## Remaining uncertainty and next action

Principal scientific blocker remains the engineering connection/multiplier
decision: continuous law, physical torque/shear transfer, growing interface
spaces, matched references and mixed-system assessment. BL5 differs from full
six-pose points/footprints: normal spin is released. Existing fine matched work
agreement does not resolve Mz transfer/convergence or allocate beam/shell/law
causes. F03/G0B/M2 and mandatory external references remain OPEN. Do not resume
isolated axial/mesh/chart/completion sweeps without a discriminating hypothesis.

Next bounded consumer slice: carry the explicit supported B2 footprint-mode
request through the existing ANYfem experimental schema/Project dispatch, using
the existing solver API/result. Preserve ordinary V1/static payloads. No new
consumer framework or ordinary-native-project claim. In parallel where useful,
assess the remaining matched engineering reference obstruction from saved
BL5/common-action evidence; record competing explanations and the necessary
observable before any new reference execution. Preserve authority and limits.

## Verification and restart

Focused source: scripts/run_portable_ci.py --development <exact affected nodes>.
One installed artifact per coherent product slice; reuse unchanged evidence by
impact. Current installed wheel SHA27660d7357eedf36a2d96a73282b9ede974fd3219903b2492d32553c118f47ec;
raw site/runner: Temp/r8-b2-footprint-modes-installed-v1. Effective pools/Numba1,
JIT-off, supervised180s/1GiB. All owned jobs are terminal, no numerical slot held.
No broad acceptance/scale/platform campaign was repeated or overall saving claimed.
Preserved history: [previous note](history/ACTIVE_STATE_20261001_B2_MODAL_PREDELIVERY.md).
One acceptance matrix: B3_GE_E4_PL_REVISION_8_ACCEPTANCE_MATRIX.md. Product slice
source/tests/example and these evidence/note files are owned; no other repo edits.
Do not rely on obsolete pending-run instructions in historical notes.
''', encoding='utf-8')
matrix = w/'docs/agent_plans/B3_GE_E4_PL_REVISION_8_ACCEPTANCE_MATRIX.md'
old_matrix = matrix.read_text(encoding='utf-8')
title, rest = old_matrix.split('\n', 1)
entry = '''
B2/F07/F12/G4B development,1 October: existing physical B2/Q4 descriptor now
supports virgin selected-node rigid footprints with explicit physical mass,
coordinate supports detecting all six common rigid fields and zero offset.
Typed full multiplier/source-frame provenance preserves true point-prefix fields;
normal spin locked, mechanical qualification incomplete. Bounded QR/SVD support
audit corrects factor-success admission; no global dense operator/invented inertia.
One final installed wheel27660d...f47ec binds391 modules,76 affected checks and
public example pass; independent Read review clear. All previous empty-footprint
modal/static behavior retained. Free-free/prestress, drilling/torque physics,
external/scale/consumer and aggregate F07/F12/G4B/G6 remain OPEN. Initial collection
failure preserved. No tolerance/default/version/authority change.
[Implementation/evidence/boundaries](development/r8-b2-footprint-reference-modes-20261001/results.md).
'''
matrix.write_text(title+'\n'+entry+rest, encoding='utf-8')
(d/'live-note-history-identity.json').write_text(json.dumps(dict(
    path=str(history.relative_to(w)).replace('\\', '/'), bytes=len(old), sha256=sha(old)), indent=2)+'\n')
print(json.dumps({k: identity[k] for k in ('files', 'archive_bytes', 'archive_sha256')}))
print(json.dumps({'history_bytes': len(old), 'history_sha256': sha(old), 'active_note_lines': len(active.read_text().splitlines())}))
