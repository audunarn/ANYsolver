from pathlib import Path
import hashlib, importlib.util, json, shutil, sys
root = Path(__file__).parent
repo = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
supervisor = Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-panel-resolution-installed-v1/matched-run.py')
assert hashlib.sha256(supervisor.read_bytes()).hexdigest() == '5837645ddf40e591451cbd58f8975ce8f026cb908e750044b848c8c04dcae5d4'
spec = importlib.util.spec_from_file_location('owned_supervisor', supervisor)
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
module.ENV['PYTHONNOUSERSITE']='1'
source = repo/'scripts/r8_bl5_supported_completion_action_dev.py'
snapshot = root/source.name
shutil.copy2(source, snapshot)
command = [sys.executable, '-u', str(snapshot), '--inputs', 'C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-bl5-endpoint-response-v1/n64/outputs', '--inventory', str(repo/'docs/agent_plans/development/r8-bl5-endpoint-response-20261001/raw-v1.json'), '--old', str(repo/'docs/agent_plans/development/r8-bl5-matched-comparison-20261001/refinement-v1-raw/native/n64'), '--completion', 'C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-bl5-completion-sensitivity-20261001-v1/raw/numerical-completion.npz', '--original-runner', 'C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-bl5-completion-sensitivity-20261001-v1/b3_e4_bl5_completion_sensitivity_dev.py', '--output', str(root/'run/outputs')]
record = module.supervised(command, root/'run')
print(json.dumps(record))
