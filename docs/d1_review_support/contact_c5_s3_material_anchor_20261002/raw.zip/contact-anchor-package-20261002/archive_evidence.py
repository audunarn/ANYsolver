from pathlib import Path
import hashlib,json,zipfile

base=Path('C:/ANYworkspaceWork')
repo=base/'ANYsolver-contact-main-reconcile-20261001'
out=repo/'docs/d1_review_support/contact_c5_s3_material_anchor_20261002'
files={}
names=('contact-anchor-local-v1-20261002','contact-anchor-coupled-v1-20261002',
       'contact-anchor-corrective-v2-20261002','contact-anchor-limit-v3-20261002')
for name in names:
    for p in (base/name).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:
            files[p.relative_to(base).as_posix()]=p
    files[name+'.log']=base/(name+'.log')
for name in ('contact-friction-transfer-design-review-20261002.log',
             'contact-friction-anchor-mechanics-review-20261002.log',
             'contact-friction-anchor-corrective-review-20261002.log'):
    files[name]=base/name
package=Path(__file__).resolve().parent
for p in package.rglob('*'):
    if not p.is_file() or any(x in p.relative_to(package).parts for x in ('build-input','site','__pycache__')):
        continue
    if p.suffix in ('.log','.json','.xml','.py','.whl','.ini'):
        files[p.relative_to(base).as_posix()]=p
total=sum(p.stat().st_size for p in files.values())
assert total<100_000_000
archive=out/'raw.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(files.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(z.read(name)==p.read_bytes() for name,p in files.items())
result=dict(files=len(files),raw_bytes=total,zip_bytes=archive.stat().st_size,
            sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),readback='PASS')
(out/'raw-index.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
