import hashlib,json,zipfile
from pathlib import Path
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
base=Path('C:/ANYworkspaceWork')
folder=repo/'docs/d1_review_support/contact_c6_free_shell_history_20261003'
folder.mkdir(exist_ok=False)
history=repo/'docs/d1_review_support/GENERAL_CONTACT_RESTART_HISTORY_20261003_PART78.md'
assert not history.exists();history.write_bytes((repo/'GENERAL_CONTACT_RESTART.md').read_bytes())
raw={}
for name in ('contact_free_shell_history_20261003','contact_free_shell_history_v2_20261003','contact_free_shell_oracle_compat_20261003'):
    raw[name+'/runner.log']=base/(name+'.log')
    for file in (base/name).glob('*.json'):raw[name+'/'+file.name]=file
    for sub in (base/name).glob('anysolver-portable-ci-*/P01'):
        for file in sub.glob('*.json'):raw[name+'/'+file.name]=file
package=base/'contact_free_shell_history_package_20261003'
for file in package.iterdir():
    if file.suffix in ('.json','.log','.py'):raw['package/'+file.name]=file
with zipfile.ZipFile(folder/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,file in raw.items():archive.write(file,name)
installed=json.loads((package/'installed.json').read_text())
files=['tests/test_general_contact_transient_free_shell_sphere.py','examples/general_contact_free_shell_sphere_impact.py']
record=dict(parent_commit='18e40f9c',scope='development load-history/work verification; no engineering acceptance',
    owned_files_sha256={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in files},
    reused_solver_imports_sha256=installed['imports'],effective=installed['effective'],
    reused_wheel_sha256='5462ac6159aa315d3dc5d9d411b483024aeee41e7b7b7de6924d6e1088a3f4d8',
    raw_members=sorted(raw))
(folder/'source.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(dict(evidence=str(folder),raw_records=len(raw)),indent=2))
