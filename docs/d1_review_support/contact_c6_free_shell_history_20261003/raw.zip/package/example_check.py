import hashlib,json,os,runpy,sys
from pathlib import Path

root=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(root))
example=runpy.run_path(sys.argv[2])
result=example['run'](load_history=True)
from threadpoolctl import threadpool_info
import numba
assert numba.config.DISABLE_JIT==1
pools=threadpool_info()
assert all(pool['num_threads']==1 for pool in pools)
imports={}
for name,module in tuple(sys.modules.items()):
    if name=='anysolver' or name.startswith('anysolver.'):
        value=getattr(module,'__file__',None)
        if value:
            file=Path(value).resolve()
            assert file.is_relative_to(root),(name,str(file))
            imports[file.relative_to(root).as_posix()]=hashlib.sha256(file.read_bytes()).hexdigest()
Path(sys.argv[3]).write_text(json.dumps(dict(result=result,imports=imports,
    effective=dict(jit_disabled=numba.config.DISABLE_JIT,threadpools=pools,
                   python=sys.version,package_root=str(root))),indent=2),encoding='utf-8')
