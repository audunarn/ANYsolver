import copy,json,runpy,subprocess,sys,time
from pathlib import Path
import psutil

repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
folder=Path(__file__).parent
tooling=runpy.run_path(str(repo/'scripts/run_portable_ci.py'))
records=[]
for label,root in (('source',repo/'src'),('installed',folder/'installed')):
    env=tooling['_worker_environment'](folder/label)
    env['NUMBA_DISABLE_JIT']='1'
    command=[sys.executable,'-I',str(folder/'example_check.py'),str(root),
        str(repo/'examples/general_contact_q4_plastic_impact_dev.py'),str(folder/(label+'.json'))]
    started=time.monotonic(); peak=0
    with (folder/(label+'.log')).open('w',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT)
        try:
            while child.poll() is None:
                try:
                    process=psutil.Process(child.pid)
                    peak=max(peak,sum(p.memory_info().rss for p in [process,*process.children(recursive=True)] if p.is_running()))
                except psutil.NoSuchProcess: pass
                if time.monotonic()-started>180 or peak>953*1024**2:
                    raise RuntimeError('owned installed-check resource ceiling exceeded')
                time.sleep(.1)
        finally:
            tooling['_terminate_tree'](child)
    records.append(dict(label=label,command=command,elapsed_s=time.monotonic()-started,
        peak_sampled_bytes=peak,exit=child.returncode,limit_s=180,limit_mib=953))
    (folder/'resource.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    assert child.returncode==0,label
source=json.loads((folder/'source.json').read_text())
installed=json.loads((folder/'installed.json').read_text())
assert source['imports']==installed['imports'],'source/install module hash mismatch'
source_result=copy.deepcopy(source['result']); installed_result=copy.deepcopy(installed['result'])
sp=source_result.pop('provenance'); ip=installed_result.pop('provenance')
assert source_result==installed_result,'source/install numerical mismatch'
assert {k:v['sha256'] for k,v in sp['imported_modules'].items()}=={k:v['sha256'] for k,v in ip['imported_modules'].items()}
assert sp['example']==ip['example']
print(json.dumps(dict(result=installed_result,matched_imports=len(source['imports']),resources=records),indent=2))
