import hashlib,json,subprocess,zipfile
from pathlib import Path

repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
outside=Path('C:/ANYworkspaceWork')
folder=Path(__file__).parent
dest=repo/'docs/d1_review_support/contact_c6_q4_plane_events_20261003'
dest.mkdir(parents=True,exist_ok=True)
names=[
 'plane-newmark-events-dev-20261003-a','plane-newmark-events-dev-20261003-b',
 'contact_q4_event_elastic_a_20261003','contact_q4_event_elastic_b_20261003',
 'contact_q4_event_elastic_c_20261003','contact_q4_event_plastic_a_20261003',
 'contact_q4_event_controls_d_20261003','contact_q4_event_cancel_e_20261003',
 'contact_q4_event_restart_f_20261003','contact_q4_event_compat_g_20261003',
 'contact_q4_event_package_20261003']
paths=[repo/p for p in (
 'src/anysolver/general_contact/transient.py',
 'src/anysolver/general_contact/plane_newmark_events.py',
 'tests/test_general_contact_plane_newmark_events.py',
 'tests/test_general_contact_transient_plane_events.py',
 'examples/general_contact_q4_plastic_impact_dev.py')]
for name in names:
 root=outside/name
 if root.exists():
  paths.extend(p for p in root.rglob('*') if p.is_file() and p.suffix in ('.log','.json','.py')
      and not any(part in ('installed','wheels','__pycache__') or part.startswith('pip-')
                  for part in p.relative_to(root).parts))
 log=outside/(name+'.log')
 if log.exists():paths.append(log)
paths=sorted(set(paths))
records=[]
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for path in paths:
  content=path.read_bytes()
  relative=('source/'+path.relative_to(repo).as_posix() if path.is_relative_to(repo)
      else 'external/'+path.relative_to(outside).as_posix())
  z.writestr(relative,content)
  records.append(dict(path=str(path),archive_path=relative,bytes=len(content),
      sha256=hashlib.sha256(content).hexdigest()))
runtime=[]
for name in names[:-1]:
 root=outside/name
 if not root.exists():continue
 for path in root.rglob('runtime.json'):
  data=json.loads(path.read_text(encoding='utf-8-sig'))
  runtime.append(dict(path=str(path),fields=list(data),runtime=data))
wheel=folder/'wheels/anysolver-0.4.7-py3-none-any.whl'
source=json.loads((folder/'source.json').read_text())
installed=json.loads((folder/'installed.json').read_text())
assert source['imports']==installed['imports']
resources=json.loads((folder/'resource.json').read_text())
baseline=json.loads((folder/'matched-legacy.json').read_text())
evidence=dict(scope='development; not engineering acceptance or release',
 parent_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
 source_records=records,wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
 matched_imported_modules=len(source['imports']),resources=resources,
 event_energy=source['result']['energy_diagnostic'],
 matched_legacy_energy=baseline['result']['energy_diagnostic'],
 matched_legacy_resource=json.loads((folder/'matched-legacy-resource.json').read_text()),
 runtime_records=runtime)
(dest/'source.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
print(json.dumps(dict(raw_records=len(records),matched_imported_modules=len(source['imports']),
 wheel_sha256=evidence['wheel_sha256'],evidence=str(dest))))
