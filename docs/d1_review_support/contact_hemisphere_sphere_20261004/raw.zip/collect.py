from pathlib import Path
import json,hashlib,zipfile,platform,sys
from importlib.metadata import version
root=Path('C:/ANYworkspaceWork/contact_hemisphere_sphere_20261004')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_hemisphere_sphere_20261004';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=[];runs={}
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists():continue
    runtime=json.loads((folder/'runtime.json').read_text(encoding='utf-8')) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':json.loads((folder/'resource.json').read_text(encoding='utf-8')),'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,folder.name+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final'
imports=json.loads((final/'imports.json').read_text(encoding='utf-8'))
runtime=json.loads((final/'runtime.json').read_text(encoding='utf-8'))
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed/anysolver')
    assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
p=dest/'installed_parity.json';p.write_text(json.dumps({'loaded':loaded,'package':package},indent=2),encoding='utf-8');raw.append((p,p.name))
for name in ('support_review.md','design.md'):
    p=dest/name;p.write_bytes((root/name).read_bytes());raw.append((p,name))
source=('src/anysolver/general_contact/beam_hemisphere_sphere_work.py','src/anysolver/general_contact/beam_hemisphere_sphere.py','src/anysolver/general_contact/core.py','src/anysolver/general_contact/multiple_beam_rigid.py','src/anysolver/general_contact/beam_radial_ends.py','src/anysolver/general_contact/beam_end_radial_geometry.py','tests/test_general_contact_hemisphere_sphere.py','examples/general_contact_hemisphere_sphere.py')
raw.extend((root/p,p) for p in ('run.py','collect.py','build.log','build02.log','install.log'))
raw.extend((repo/p,'candidate/'+p) for p in source)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
summary={'scope':'D3 actual-tangent B2/B3 hemisphere support on one fixed analytic sphere; development/code verification only',
'source_parent':'b956dda313dc8cc9708ddde15f9655a10e03f7a1','source_files':{p:sha(repo/p) for p in source},
'wheels':{str(p.relative_to(root)):sha(p) for folder in ('dist','dist_before_radius_fix') for p in (root/folder).glob('*.whl')},'runs':runs,
'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],'effective_pools':runtime['effective_pools'],
'independent_bar':json.loads((final/'actual_result.json').read_text(encoding='utf-8')),
'directional_tangent_target':1e-5,'bar_response_target':1e-6,'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
'environment':{'python':sys.version,'platform':platform.platform(),'versions':{name:version(name) for name in ('numpy','scipy','numba','ANYmaterial','ANYgeometry')}},
'review_disposition':'supporting same-family source review found reversed Jet2 seed, explicit cap/spring and aggregate admission concerns, and radius-conversion dependency. Lead corrected these and verified actual all-coordinate scalar work, tangent/covariance/wrench, radius preservation, coupled bar and state. No independent engineering acceptance.',
'preserved_failures':['source01/source02 conservative active seam rejection; corrected spatial accuracy before temporal bound, same finite budgets','review-found reversed Jet2 seed corrected before first numerical run','source05_radius degree-zero curve fixture mistake','source06_radius verified radius Fraction cast loss; bounds owner now preserves Fraction inputs','private first pre-radius-fix wheel retained, not installed','all predecessor consumed and nonpass evidence unchanged'],
'unchanged':['legacy radial ownership crossing gate, float-radius arithmetic and profile/default','line integration/potential and line/end units','multiple fixed-plane support profile identity and geometry','old sphere APIs, no-contact and physical material commit semantics','ANYfem source, normal application admission false','engineering criteria, frozen authority and resource limits'],
'limits':['one explicit beam selection with classical scalar-elastic concentric B2/B3 von Karman','fixed analytic sphere only; no automatic/multiple sphere support yet','genuine all-material-node ends, actual tangent hemisphere point spring distinct from distributed line','exterior gap budget below both radii; exact literal radii sum for conservative bounds only','parallel nonunique rim is open with zero penalty work, no smooth contact claim','C1 sphere/rim seam with one-sided Hessians, no central smooth test across kink','whole-radius enclosure may reject geometrically safe cap paths; unresolved limits fail','no spin/material-surface friction, native contact or transient expansion','cylinder/pair/finite-face transitions, mesh/enforcement and C0-C9 acceptance remain']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({'runs':len(runs),'records':len(raw),'modules':len(loaded),'package_files':len(package),'resource':runs['installed_final']['resource'],'evidence':str(dest)}))
