# Supporting mechanics review: B2 pair physical ends

Read-only review of the candidate design and existing `_projection_work` / symmetric line potential. No tests or imports executed. Same-family supporting scrutiny, not engineering acceptance.

## Equations and ownership

No sign or factor error found in the proposed endpoint potential. For separation `d=p-q`, source outward ownership is `d.a<0`. At target parameter zero, strict `h<0` gives `(p-q).(-v)>0`, which is the target hemisphere facing the source; the parameter-one case is analogous. Combined with source ownership, strict cap-cap ownership is reciprocal for B2. Consequently one full endpoint spring per unordered physical node pair is correct; neither two full directional copies nor two independently selected half springs are needed. End/interior work needs the existing reduced projection Hessian, including target weights and cross blocks.

Keep deduplication by material node identities and canonical body ordering, never nearest-point coordinates or proximity tolerance. Verify body exchange and connectivity reversal. The distributed half-weighted line potential and the new atomic endpoint potential are different measures; their sum is the declared discrete model, not a continuous hemisphere-area integration claim.

## Concrete residual risk in reusing the line tangent

The design guards endpoint feature transitions, but does not explicitly guard a positive-measure **active line projection-clamp plateau**. At raw target projection identically zero or one, `_projection_work` chooses the endpoint Hessian; perturbations into the target interior have a different second derivative. This can remain exposed when the target junction is not a genuine physical end, so no endpoint candidate supplies a rejection.

Example geometry: selected target from `(0,0,0)` to `(L,0,0)`; selected source from `(0,-a,z)` to `(0,a,z)`, with `0<z<radius_sum<a`. Its central source interval is active and projects exactly to target parameter zero, although both source endpoints are open. Attach an unselected beam at the target's first node so that it is not a physical cap. Small positive/negative source-x shifts give interior/endpoint projection branches and different directional second derivatives. Decide explicitly whether this plateau is rejected by the new profile; endpoint-only tests are insufficient. This is a limitation inherited from the reused branch Hessian, not an argument for changing the declared mechanics.

## Certificate requirements

- The stated ownership and interior-distance numerators are correct, provided the strictly positive `bb` denominator is certified over the interval before division or ratio bounds. For lower distance bounds use a lower numerator and an upper denominator, not two lower bounds.
- Active ownership double roots and active clamp equalities must reject even without a sign change. Open-at-endpoint samples do not prove the root is open.
- Whole-pair gap sweep speed must cover all material pairs. A safe affine bound is `max_ij ||delta_A_i-delta_B_j||` (or the sum of each body's maximum nodal speed). Matching endpoint indices alone is not a relative-speed bound.
- Parallel segment interior minimization must fall back to complete edge/corner candidates; a vanishing stationary determinant is not proof of separation. Near-parallel unresolved arithmetic must fail conservatively.

## Cheapest discriminators

Unique cap-cap spring versus directional double counting; cap-interior complete both-body directional tangent; target motion and body exchange; active clamp transition and active double ownership root; the line plateau above; open endpoint poses with hidden intermediate proximity; parallel/near-parallel segment bounds; shared B3-middle-node topology inherited by a selected B2 end; restart rejection after endpoint stiffness/topology/limit changes.
