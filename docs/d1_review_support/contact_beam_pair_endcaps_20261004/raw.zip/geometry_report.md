# B2 pair end geometry supporting implementation

Implemented only repository file `C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001/src/anysolver/general_contact/beam_pair_end_geometry.py` (new file). SHA256: `f5d566572e62fbacca23c8297c2bea5fa4d3531a443e7ee80dd20c01553f4bc5`.

## API

- `minimum_gap(a, b, radius) -> float`: exact rational minimum of the convex segment/segment squared-distance rectangle using all four edges and any admissible interior stationary point; outward lower square-root/conversion bound. Parallel or collapsed segments retain edge candidates.
- `endpoint_feature(source, target, endpoint, radius) -> EndpointFeature`: endpoint index 0/1, B2 positions 2x3. Frozen return fields: `projection: Fraction` (clamped target parameter), `ownership: Fraction` (separation dot unnormalized source outward tangent; negative owns), `squared_distance: Fraction`, `gap: float` (rationalized subtraction), `gap_sign: int` (exact sign -1/0/+1), `interior: bool`, `target_endpoint: int|None`, `projection_tie: bool` (raw h=0 or h=bb), and `separation: tuple[Fraction,...]`. Collapsed target raises ValueError; topology and active tie policy remain caller decisions.
- `admissible_endpoint_path(a0, a1, b0, b1, ends_a, ends_b, radius, max_depth) -> bool`: ends tuples contain genuine physical-end indices. Checks both directions. Exact affine coordinate controls generate h, bb, clamp squared distances, infinite-line squared-distance numerator and source ownership numerator by exact Bernstein multiplication/elevation. It proves positive target length and either opening (gap >= 0), or a strict fixed branch with strict ownership sign. Owned active clamps require physical target ends. Exact samples only disprove admissibility; whole-interval Bernstein bounds alone establish success. Active ties or finite-budget exhaustion return False. Fractions remain exact on ingestion.

## Verification

Command: `python C:/ANYworkspaceWork/contact_beam_pair_endcaps_20261004/run.py geometry-support C:/ANYworkspaceWork/contact_beam_pair_endcaps_20261004/geometry_checks.py`.

Result: 4 focused test functions passed; runner completed with returncode 0, elapsed 3.1944936 seconds, peak process-tree RSS 160301056 bytes under the 180-second / 953-MiB caps. Runtime, input hashes and full output are retained in `geometry-support/resource.json`, `geometry-support/inputs.json`, `geometry-support/runtime.json`, `geometry-support/imports.json` and `geometry-support/run.log`.

Checks cover crossing/parallel/collapsed rectangle minima; sub-float rational geometry preservation; owned end/interior and unique reciprocal physical clamp admission; owned nonphysical clamp rejection; active projection tie rejection and opening bypass; collapsing intermediate target; open endpoint poses with active midpoint and non-dyadic double ownership roots.

## Findings and limits

The design ownership and interior-distance numerators are implemented as specified. Opening is sufficient at exact gap zero; only opening can bypass projection or ownership ties. Endpoint certificate does not replace physical-curve regularity, distributed-line active clamp plateau guarding, gap sweep admission, mesh/enforcement qualification or acceptance. Relative sweep speed is owned by the lead implementation and must cover all material endpoint pairs. No shared tests, restricted-case replay, commits or other repository edits were performed by this worker. The dirty restart/core files and new beam_pair_ends.py observed at handoff belong to concurrent lead work and were preserved.

This is developmental supporting work, not independent scientific or engineering acceptance. Optional lower-tier availability was not probed.
