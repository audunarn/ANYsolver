from fractions import Fraction as F
import math
from anysolver.general_contact.beam_pair_end_geometry import (
    minimum_gap, endpoint_feature, admissible_endpoint_path)


def test_rectangle_candidates_and_exact_inputs():
    a = ((-1, 0, 0), (1, 0, 0))
    b = ((0, -1, 0), (0, 1, 0))
    assert minimum_gap(a, b, F(1, 4)) <= -.25
    parallel = ((-1, 1, 0), (1, 1, 0))
    assert minimum_gap(a, parallel, F(1, 4)) <= .75
    assert minimum_gap(a, parallel, F(1, 4)) > .749999999999
    collapsed = ((0, 1, 0), (0, 1, 0))
    assert minimum_gap(a, collapsed, 0) <= 1
    p = F(1, 10**30)
    source = ((-1, 0, 0), (0, 0, 0))
    target = ((p, -1, 0), (p, 1, 0))
    feature = endpoint_feature(source, target, 1, p*2)
    assert feature.projection == F(1, 2)
    assert feature.ownership == -p
    assert feature.squared_distance == p*p
    assert feature.gap_sign == -1 and feature.gap < 0
    assert feature.interior and not feature.projection_tie


def test_fixed_branches_and_physical_clamp():
    a = ((-1, 0, 0), (0, 0, 0))
    b = ((F(1, 5), -1, 0), (F(1, 5), 1, 0))
    assert admissible_endpoint_path(a, a, b, b, (1,), (), F(3, 10), 0)
    b = ((F(1, 5), 0, 0), (F(6, 5), 0, 0))
    assert admissible_endpoint_path(a, a, b, b, (1,), (0,), F(3, 10), 0)
    assert not admissible_endpoint_path(a, a, b, b, (1,), (), F(3, 10), 3)


def test_active_ties_open_bypass_and_target_degeneracy():
    a = ((-1, 0, 0), (0, 0, 0))
    b = ((0, F(1, 10), 0), (1, F(1, 10), 0))
    feature = endpoint_feature(a, b, 1, F(1, 5))
    assert feature.projection_tie and feature.target_endpoint == 0
    assert not admissible_endpoint_path(a, a, b, b, (1,), (0,), F(1, 5), 3)
    assert admissible_endpoint_path(a, a, b, b, (1,), (), F(1, 20), 0)
    reversed_b = (b[1], b[0])
    assert not admissible_endpoint_path(a, a, b, reversed_b, (1,), (), 0, 3)


def test_hidden_double_ownership_root_and_fractional_crossing():
    b = ((0, 0, -1), (0, 0, 1))
    for root in (F(1, 2), F(1, 3)):
        a0 = ((0, 1, 0), (-root, 0, 0))
        a1 = ((0, 1, 0), (1-root, 0, 0))
        assert endpoint_feature(a0, b, 1, F(1, 5)).gap_sign > 0
        assert endpoint_feature(a1, b, 1, F(1, 5)).gap_sign > 0
        assert not admissible_endpoint_path(a0, a1, b, b, (1,), (), F(1, 5), 8)
