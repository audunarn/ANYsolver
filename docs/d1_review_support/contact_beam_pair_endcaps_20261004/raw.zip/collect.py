from pathlib import Path
import hashlib,json,zipfile,sys,platform
from importlib.metadata import version

root=Path('C:/ANYworkspaceWork/contact_beam_pair_endcaps_20261004')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_beam_pair_endcaps_20261004'
dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=[];runs={}
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists():continue
    runtime=json.loads((folder/'runtime.json').read_text()) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':json.loads((folder/'resource.json').read_text()),
                      'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,folder.name+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final';imports=json.loads((final/'imports.json').read_text())
runtime=json.loads((final/'runtime.json').read_text())
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed/anysolver')
    assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
parity=dest/'installed_parity.json'
parity.write_text(json.dumps({'loaded':loaded,'package':package},indent=2))
review=dest/'source_review.md';review.write_bytes((root/'source_review.md').read_bytes())
source=('src/anysolver/general_contact/beam_pair_ends.py',
    'src/anysolver/general_contact/beam_pair_end_geometry.py','src/anysolver/general_contact/core.py',
    'tests/test_general_contact_beam_pair_ends.py','examples/general_contact_beam_pair_ends.py')
raw.extend(((parity,'installed_parity.json'),(review,'source_review.md')))
raw.extend((root/p,p) for p in ('run.py','collect.py','design.md','design_review.md','geometry_report.md','geometry_checks.py'))
raw.extend((repo/p,'candidate/'+p) for p in source)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
bar=json.loads((final/'independent_two_bar.json').read_text())
error=max(abs(a-b)/abs(a) for a,b in zip(bar['independent_displacement_m'],bar['force_result_m']))
summary={'scope':'D3 explicit B2/B2 physical-end pair work; developmental code verification, not engineering acceptance',
    'source_parent':'c075ea0526fb902cf36696f7071e59ba26105d7f','source_files':{p:sha(repo/p) for p in source},
    'wheels':{p.name:sha(p) for p in (root/'dist').glob('*.whl')},'runs':runs,
    'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
    'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],
    'effective_pools':runtime['effective_pools'],'independent_bar_relative_error':error,
    'bar_relative_target':1e-6,'gap_budget_m':1e-5,'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
    'environment':{'python':sys.version,'platform':platform.platform(),
        'versions':{name:version(name) for name in ('numpy','scipy','numba','ANYmaterial','ANYgeometry')}},
    'review_disposition':'intermediate active line-clamp plateau now certified along full affine path; isolated manager regression, finite-normal ownership root, topology/settings restart, actual candidate exception/cancel reuse pass',
    'retained_failures':'source01 three test defects: unpartitioned scalar quadrature missed narrow active intervals; nonexistent capability.profile field. Inputs/logs retained; independent oracle corrected without changing production law/tolerances.',
    'limits':'180s/953MiB process tree; one elastic scalar/von-Karman B2 per side; explicit hemisphere point penalties, strict resolved feature branches; no B3/chains/cap transitions, native/friction/dynamics, normal application admission, release or independent engineering acceptance'}
(dest/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'runs':len(runs),'raw_records':len(raw),'modules':len(loaded),'package_files':len(package),
    'outcomes':runs['installed_final']['outcomes'],'resource':runs['installed_final']['resource'],'bar_error':error}))
