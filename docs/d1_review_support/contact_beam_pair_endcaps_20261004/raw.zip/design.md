# B2 physical-end pair development candidate

Reuse the existing symmetric half-weighted directional distributed line potential.
Add .5*k_endpoint*min(g,0)^2 for each physically owned end/interior feature and
each unique end/end feature (not two directional copies). Both beam selections
declare hemisphere ends, explicit radius, line stiffness N/m² and endpoint
stiffness N/m. Genuine ends use all classical material-node incidence.

For source end p with outward tangent a and target segment b0,b1, v=b1-b0,
w=p-b0, h=w.v, bb=v.v. Projection t=clip(h/bb,0,1), separation d=w-t*v.
Source owns only if d.a<0. An active t=0 or1 target must be a genuine end; strict
clamping also establishes its outward-hemisphere ownership. At h=0, h=bb or
d.a=0 an active candidate rejects. Such closed transitions are not generalized
tangent admission. An end/end pair is counted once because reciprocal strict
ownership yields the same closest physical features.

Use existing complete closest-projection gradient/Hessian, including target
coordinate response. Assemble R=ke*g*Dg and K=ke*(Dg outer Dg+g*D2g) for both
bodies. End/interior has moving target weights and nonzero cross blocks.

At affine static paths, positions/tangents are affine. Exact Bernstein h,bb and
ownership polynomials certify one branch and sign or opening. Interior distance
numerator is ww*bb-h²; interior ownership numerator is (w.a)*bb-h*(v.a).
Infinite-line and whole-segment box lower bounds may certify opening. Otherwise
subdivide within the same finite swept budget; active tie or exhaustion rejects.
Whole segment/segment gap is minimized independently with exact rational edges
and interior stationary point; outward norm bounds feed the Lipschitz sweep.
Both physical curves also retain the existing nonzero-speed certificate.

One B2 per side initially uses available analytic work. Full B3/chain endpoints,
cap/interior ownership transitions, mesh/enforcement qualification, friction,
dynamics and engineering acceptance remain required successors. Tests must expose
double counting, target motion, body exchange, root crossings and state/restart.
Routine process-tree caps 180s/953MiB; scientific targets unchanged. No new engine,
backend, solver stack, historical-default change or restricted-case replay.
