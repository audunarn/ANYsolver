from pathlib import Path
import hashlib,json,platform,sys,zipfile
from importlib.metadata import version

root=Path('C:/ANYworkspaceWork/contact_curve_endcaps_20261004')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_curve_endcaps_20261004';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=[];runs={}
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists():continue
    runtime=json.loads((folder/'runtime.json').read_text(encoding='utf-8')) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':json.loads((folder/'resource.json').read_text(encoding='utf-8')),
                      'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,folder.name+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final';imports=json.loads((final/'imports.json').read_text(encoding='utf-8'))
runtime=json.loads((final/'runtime.json').read_text(encoding='utf-8'))
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed/anysolver')
    assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
parity=dest/'installed_parity.json'
parity.write_text(json.dumps({'loaded':loaded,'package':package},indent=2),encoding='utf-8')
review=dest/'source_review.md';review.write_bytes((root/'source_review.md').read_bytes())
source=('src/anysolver/general_contact/beam_curve_ends.py','src/anysolver/general_contact/beam_curve_end_geometry.py',
    'src/anysolver/general_contact/beam_pair_ends.py','src/anysolver/general_contact/core.py',
    'tests/test_general_contact_beam_curve_ends.py','examples/general_contact_beam_curve_ends.py')
raw.extend(((parity,'installed_parity.json'),(review,'source_review.md')))
raw.extend((root/p,p) for p in ('run.py','collect.py','design.md'))
raw.extend((repo/p,'candidate/'+p) for p in source)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
bar=json.loads((final/'p2_bar.json').read_text(encoding='utf-8'))
summary={'scope':'D3 single classical B2/B3-cell physical ends on actual quadratic curves; developmental code verification, not engineering acceptance',
    'source_parent':'8081d582e60fe519e0de23fdf6b352c2a3b6ee5d','source_files':{p:sha(repo/p) for p in source},
    'wheels':{p.name:sha(p) for p in (root/'dist').glob('*.whl')},'runs':runs,
    'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
    'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],
    'effective_pools':runtime['effective_pools'],'independent_p2_bar':bar,'bar_relative_target':1e-6,
    'smooth_directional_tangent_target':1e-5,'bar_gap_budget_m':.008,
    'full_curve_gap_accuracies_m':[1e-5,1e-7],'full_curve_gap_caps':{'cells':10000,'depth':25},
    'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
    'environment':{'python':sys.version,'platform':platform.platform(),
        'versions':{name:version(name) for name in ('numpy','scipy','numba','ANYmaterial','ANYgeometry')}},
    'review_disposition':'rounded clamp penetration lost its finite active tangent; exact stable squared-gap calculation/underflow rejection plus interior roundoff rejection close it. Whole-curve tensor/path bounds reviewed after actual rotated AABB depth failure. Supporting same-family source scrutiny only.',
    'preserved_failures':['source01 exploratory1e-7m AABB depth25 exhaustion;2fail',
        'source02 separating-support experiment still exhausteddepth25;2fail+exact-oblique1pass;experiment abandoned',
        'source04 incorrect through-crossing endpose actually still overlapping;1testdefect+4pass',
        'source05 rotated complete reference geometry AABB depth25 failure at1e-5m;1fail+2pass'],
    'unchanged':['legacy beam_curve_pair.py/uncapped profiles','material/contact law units','historical sphere/default/no-contact semantics',
        'frozen scientific criteria/failed authorities','ANYfem source','engineering acceptance/release flags'],
    'limits':['oneB2/B3cellperbody','elastic scalar vonKarman','strict globallyconvex endpoint projection certificate',
        'unresolved closed ownership/branch changes and nonconvex minima reject','point end law is not continuous cap-surface integration',
        'normal application/mesh-enforcement/engineering qualification/native-friction-dynamics/fullprogramme incomplete']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({'runs':len(runs),'records':len(raw),'modules':len(loaded),'package_files':len(package),
    'bar_error':bar['relative_error'],'resource':runs['installed_final']['resource'],'evidence':str(dest)}))
