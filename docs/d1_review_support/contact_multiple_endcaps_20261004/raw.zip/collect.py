from pathlib import Path
import json,hashlib,zipfile
root=Path('C:/ANYworkspaceWork/contact_multiple_endcaps_20261004')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_multiple_endcaps_20261004';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=[];runs={}
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists():continue
    runtime=json.loads((folder/'runtime.json').read_text()) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':json.loads((folder/'resource.json').read_text()),
        'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,folder.name+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final'
imports=json.loads((final/'imports.json').read_text());runtime=json.loads((final/'runtime.json').read_text())
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed2/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed2/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed2/anysolver')
    assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
parity=dest/'installed_parity.json';parity.write_text(json.dumps({'loaded':loaded,'package':package},indent=2))
review=dest/'review.md';review.write_bytes((root/'review.md').read_bytes())
source=('src/anysolver/general_contact/multiple_beam_rigid.py',
    'tests/test_general_contact_multiple_beam_ends.py','examples/general_contact_multiple_beam_ends.py')
raw.extend(((parity,'installed_parity.json'),(root/'run.py','run.py'),(root/'setup_runner.py','setup_runner.py'),
    (root/'collect.py','collect.py'),(review,'review.md')))
raw.extend((repo/p,'candidate/'+p) for p in source)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
bars={kind:json.loads((final/('bar_'+kind+'.json')).read_text()) for kind in ('sphere','cylinder','capped_cylinder')}
errors={kind:max(abs(a-b)/abs(a) for a,b in zip(r['independent_end_displacements_m'],
    r['solved_end_displacements_m'])) for kind,r in bars.items()}
summary={'scope':'D3 explicit fixed multiple classical beam physical-end work composition; developmental code verification, not engineering acceptance',
    'source_parent':'98350a4590e1b9974b3273bb42ac5d433bd16b96','source_files':{p:sha(repo/p) for p in source},
    'wheels':{p.name:sha(p) for p in (root/'dist2').glob('*.whl')},'runs':runs,
    'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
    'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],
    'effective_pools':runtime['effective_pools'],'independent_bar_relative_errors':errors,
    'bar_relative_target':1e-6,'gap_budget_m':1e-5,'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
    'review_disposition':'plane endpoint candidate spelling normalized; regular-prefix rejection now counted; supporting same-family source review only',
    'limits':'180s/953MiB process tree; child elastic scalar/von-Karman geometry/work/ownership bounds; fixed analytic tools only; no moving multi-tool, native, friction, dynamics, normal application admission, release or independent engineering acceptance'}
(dest/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'runs':len(runs),'raw_records':len(raw),'modules':len(loaded),'package_files':len(package),
    'outcomes':runs['installed_final']['outcomes'],'resource':runs['installed_final']['resource'],'bar_errors':errors}))
