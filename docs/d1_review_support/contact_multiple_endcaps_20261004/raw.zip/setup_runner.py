from pathlib import Path
root=Path('C:/ANYworkspaceWork/contact_multiple_endcaps_20261004')
source=Path('C:/ANYworkspaceWork/contact_radial_endcaps_20261003/run.py')
text=source.read_text().replace('contact_radial_endcaps_20261003','contact_multiple_endcaps_20261004')
text=text.replace('paths += [',"paths += [SOLVER/'src/anysolver/general_contact/multiple_beam_rigid.py',",1)
(root/'run.py').write_text(text,encoding='utf-8')
