import hashlib,json,zipfile
from importlib.metadata import version
from pathlib import Path

repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
folder=Path(__file__).parent
destination=repo/'docs/d1_review_support/contact_c6_s3_pressure_events_20261003'
destination.mkdir(exist_ok=True)
labels=['contact_s3_pressure_bounds_a_20261003','contact_s3_pressure_driver_b_20261003',
 'contact_s3_pressure_state_c_20261003','contact_s3_pressure_event_d_20261003',
 'contact_s3_pressure_final_e_20261003','contact_s3_pressure_final_f_20261003',
 'contact_s3_pressure_budget_g_20261003']
records=[];files=[]
for label in labels:
 directory=Path('C:/ANYworkspaceWork')/label
 runtimes=list(directory.rglob('runtime.json'))
 assert len(runtimes)==1,(label,len(runtimes))
 runtime=json.loads(runtimes[0].read_text())
 resource=json.loads((runtimes[0].parent/'resource.json').read_text())
 assert runtime['errors']==[] and runtime['jit_disabled'] and runtime['numba_threads']==1,(label,runtime['errors'])
 assert all(p['num_threads']==1 for p in runtime['effective_pools'])
 assert all(Path(v).resolve().is_relative_to(repo/'src') for v in runtime['imports'].values())
 assert resource['status']=='terminal' and resource['elapsed_seconds']<180
 assert resource['peak_sampled_bytes']<953*1024**2
 records.append(dict(label=label,outcomes=runtime['outcomes'],exit=runtime['exit_code'],
     imported_modules=len(runtime['imports']),jit_disabled=runtime['jit_disabled'],
     numba_threads=runtime['numba_threads'],pool_threads=[p['num_threads'] for p in runtime['effective_pools']],
     elapsed_s=resource['elapsed_seconds'],peak_sampled_bytes=resource['peak_sampled_bytes']))
 for path in directory.rglob('*'):
  if path.is_file():files.append((path,'runs/'+label+'/'+path.relative_to(directory).as_posix()))
 files.append((directory.with_suffix('.log'),'runs/'+label+'.log'))
source=json.loads((folder/'source.json').read_text());installed=json.loads((folder/'installed.json').read_text())
assert source['result']==installed['result']
assert source['imports']==installed['imports']
assert all(hashlib.sha256((repo/'src'/path).read_bytes()).hexdigest()==value
 for path,value in source['imports'].items())
wheel=next((folder/'dist').glob('*.whl'))
changed=['src/anysolver/general_contact/transient.py','src/anysolver/general_contact/normal_s3_skin_path.py',
 'src/anysolver/general_contact/s3_pressure_hermite_bounds.py',
 'examples/general_contact_deforming_s3_impact_dev.py',
 'tests/test_general_contact_transient_deforming_s3.py','tests/test_s3_pressure_hermite_bounds.py']
resources={name:json.loads((folder/(name+'-resource.json')).read_text()) for name in ('source','installed')}
assert all(r['exit']==0 and r['elapsed_s']<180 and r['peak_sampled_bytes']<953*1024**2 for r in resources.values())
record=dict(parent='e7b0a1d5c7fcbe417769606e25cb25dde5d2ddb7',
 numerical_environment={name:version(name) for name in ('numpy','scipy','numba','llvmlite','pytest','psutil')},
 source_sha256={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in changed},
 wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),installed_import_hashes=len(installed['imports']),
 example_parity=True,runtimes=records,package_resources=resources,
 temporal=json.loads((Path('C:/ANYworkspaceWork')/'contact_s3_pressure_final_f_20261003'/'deforming_s3_temporal.json').read_text()),
 event_refinement=json.loads((Path('C:/ANYworkspaceWork')/'contact_s3_pressure_event_d_20261003'/'deforming_s3_event_refinement.json').read_text()))
for name in ('source.json','installed.json','source-resource.json','installed-resource.json','source.log',
 'installed.log','example_check.py','run_case.py','record_evidence.py','build.log','install.log'):
 files.append((folder/name,'package/'+name))
for path in changed:files.append((repo/path,'candidate/'+path))
files.append((destination/'supporting_review.md','review/supporting_review.md'))
with zipfile.ZipFile(destination/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path,name in files:archive.write(path,name)
record['raw_records']=len(files)
(destination/'source.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(raw_records=len(files),passed=sum(r['outcomes'].get('passed',0) for r in records),
 failed=sum(r['outcomes'].get('failed',0) for r in records),exits=[r['exit'] for r in records],
 imports=record['installed_import_hashes'],wheel_sha256=record['wheel_sha256'],source_installed_parity=True,
 resources={name:dict(elapsed_s=r['elapsed_s'],peak_bytes=r['peak_sampled_bytes']) for name,r in resources.items()})))
