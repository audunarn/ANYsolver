import ast
from pathlib import Path
import runpy
import sys
import pytest


@pytest.mark.parametrize('args',[[],['--quadratic','--deformable']])
def test_installed_beam_impact_example(monkeypatch,capsys,args):
    monkeypatch.setattr(sys,'argv',['beam_example.py',*args])
    runpy.run_path(str(Path(__file__).with_name('beam_example.py')),run_name='__main__')
    summary = ast.literal_eval(capsys.readouterr().out.strip())
    assert 'ROUND_TUBE_VON_KARMAN_FIXED_PLANE_NEWMARK_DEV_V1' in summary['profile']
    assert summary['minimum_swept_gap_m'] >= -.002
    assert summary['maximum_residual_n'] <= 1e-6
    assert summary['maximum_line_force_n'] > 0.
    if args:
        assert summary['partial_line_contact']
    else:
        assert summary['final_line_active'] == 0

@pytest.mark.parametrize('args',[['--multiple-planes'],['--quadratic','--multiple-planes']])
def test_installed_multiple_plane_impact_example(monkeypatch,capsys,args):
    monkeypatch.setattr(sys,'argv',['beam_example.py',*args])
    runpy.run_path(str(Path(__file__).with_name('beam_example.py')),run_name='__main__')
    summary = ast.literal_eval(capsys.readouterr().out.strip())
    assert 'MULTIPLE_FIXED_PLANES_NEWMARK_DEV_V1' in summary['profile']
    assert summary['minimum_swept_gap_m'] >= -.002
    assert summary['maximum_residual_n'] <= 1e-6
    assert all(force > 0. for force in summary['maximum_pair_forces_n'].values())
    assert all(active == 0 for active in summary['final_pair_active'].values())


@pytest.mark.parametrize('args', [['--tool-motion'], ['--quadratic', '--multiple-planes', '--tool-motion']])
def test_installed_translating_plane_example(monkeypatch, capsys, args):
    monkeypatch.setattr(sys, 'argv', ['beam_example.py', *args])
    runpy.run_path(str(Path(__file__).with_name('beam_example.py')), run_name='__main__')
    summary = ast.literal_eval(capsys.readouterr().out.strip())
    assert 'PRESCRIBED_TRANSLATION_NEWMARK_DEV_V1' in summary['profile']
    assert summary['minimum_swept_gap_m'] >= -.002
    assert summary['maximum_residual_n'] <= 1e-6
    expected = {'plane', 'y_plane'} if '--multiple-planes' in args else {'plane'}
    assert set(summary['prescribed_tool_work_j']) == expected
    assert set(summary['prescribed_tool_work_error_j']) == expected
    assert all(value > 0. for value in summary['prescribed_tool_work_j'].values())
    assert all(value >= 0. for value in summary['prescribed_tool_work_error_j'].values())
