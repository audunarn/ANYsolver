"""Retain this bounded development candidate and independent saved-field checks."""
import ast, hashlib, json, math, subprocess, zipfile
from pathlib import Path
import numpy as np

repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
workspace=Path('C:/ANYworkspaceWork')
package=Path(__file__).parent
destination=repo/'docs/d1_review_support/contact_c6_guided_shell_pair_20261003'
destination.mkdir(parents=True,exist_ok=True)
test=repo/'tests/test_general_contact_transient_guided_shell_pair.py'
functions=[node for node in ast.parse(test.read_text()).body
           if isinstance(node,ast.FunctionDef) and node.name in ('reference','continuous')]
scope=dict(np=np,MASS=np.diag([20.,14.4]),GAP=.0002,KN=3.e8,D=np.array([1.,-1.]))
exec(compile(ast.Module(body=functions,type_ignores=[]),str(test),'exec'),scope)
data=json.loads((workspace/'contact_guided_shell_pair_impact_c_20261003/shell_pair_impact.json').read_text())
t,q,v,a=(np.array(data[name]) for name in ('times_s','q','v','a'))
expected=scope['reference'](t)
g=.0002+q[:,0]-q[:,1]
rate=v[:,0]-v[:,1]
minima=[]
for j,h in enumerate(np.diff(t)):
    coefficients=np.array([g[j],h*rate[j],3*(g[j+1]-g[j])-h*(2*rate[j]+rate[j+1]),
                           2*(g[j]-g[j+1])+h*(rate[j]+rate[j+1])])
    aa,bb,cc=3*coefficients[3],2*coefficients[2],coefficients[1]
    if aa==0.:roots=[] if bb==0. else [-cc/bb]
    elif bb*bb-4*aa*cc<0.:roots=[]
    else:
        # Stable quadratic roots avoid subtracting nearly equal values when the
        # represented cubic is nearly quadratic. This calls no production bound.
        discriminant=math.sqrt(bb*bb-4*aa*cc)
        root_q=-.5*(bb+math.copysign(discriminant,bb))
        roots=[-bb/(2*aa)] if root_q==0. else [root_q/aa,cc/root_q]
    points=[0.,1.]+[root for root in roots if 0<root<1]
    minima.append(min(np.polynomial.polynomial.polyval(s,coefficients) for s in points))
force=np.array([row['integration_force'] for row in data['contact']])
target=np.array([row['target_force'] for row in data['contact']])
moment=np.array([row['integration_moment'] for row in data['contact']])
target_moment=np.array([row['target_moment'] for row in data['contact']])
predicted=3.e8*np.maximum(-g,0.)
source=json.loads((package/'source.json').read_text())
installed=json.loads((package/'installed.json').read_text())
assert source['imports']==installed['imports'] and source['result']==installed['result']
prefixes=['contact_guided_shell_pair_local_a_20261003','contact_guided_shell_pair_local_b_20261003',
          'contact_guided_shell_pair_impact_c_20261003','contact_guided_shell_pair_state_d_20261003',
          'contact_guided_shell_pair_refinement_e_20261003']
folders={prefix:workspace/prefix for prefix in prefixes}
folders.update(helper=workspace/'guided-shell-pair-path-dev-20261003-02',
               helper_delta=workspace/'guided-shell-pair-path-dev-20261003-03')
resources=[]; archived=[]
with zipfile.ZipFile(destination/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for label,folder in folders.items():
        external=workspace/(label+'.log')
        files=list(folder.rglob('*.json'))+list(folder.rglob('*.log'))
        if external.exists():files.append(external)
        for path in sorted(set(files)):
            name=label+'/'+(path.relative_to(folder).as_posix() if path.is_relative_to(folder) else path.name)
            archive.write(path,name);archived.append(dict(path=name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        for path in folder.rglob('runtime.json'):
            runtime=json.loads(path.read_text())
            assert runtime['imports'] and all(Path(value).is_relative_to(repo/'src') for value in runtime['imports'].values())
            assert runtime['jit_disabled'] and runtime['numba_threads']==1 and not runtime['errors']
            assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
            resource=json.loads(path.with_name('resource.json').read_text())
            resources.append(dict(label=label,outcomes=runtime['outcomes'],collected=runtime['collected'],
                resource=resource,source_imports=len(runtime['imports'])))
    for path in sorted(package.iterdir()):
        if path.is_file() and path.suffix in ('.py','.json','.log'):
            name='package/'+path.name;archive.write(path,name)
            archived.append(dict(path=name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
changed=['src/anysolver/general_contact/pair.py','src/anysolver/general_contact/transient.py',
 'src/anysolver/general_contact/guided_pair_transient_geometry.py',
 'tests/test_general_contact_guided_pair_transient_geometry.py',
 'tests/test_general_contact_transient_guided_shell_pair.py',
 'examples/general_contact_guided_shell_pair_impact_dev.py']
wheel=next((package/'dist').glob('*.whl'))
record=dict(parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    candidate_sha256={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in changed},
    wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),installed_import_hashes=len(source['imports']),
    example_parity=True,raw_records=len(archived),archive_manifest=archived,resources=resources,
    package_resources={label:json.loads((package/(label+'-resource.json')).read_text()) for label in ('source','installed')},
    development_metrics=dict(states=len(t),cutbacks=data['cutbacks'],events_s=data['events_s'],
        endpoint_requests=data['endpoint_requests'],stage_evaluations=data['stage_evaluations'],
        independent_discrete_q_v_a_maximum_errors=[float(np.max(np.abs(value-expected[:,i]))) for i,value in enumerate((q,v,a))],
        target_final_velocity_m_s=float(v[-1,1]),momentum_error_kg_m_s=float(np.max(np.abs(v@np.array([20.,14.4])+2.))),
        body_force_error_n=float(np.max(np.abs(force-np.column_stack((np.zeros(len(t)),np.zeros(len(t)),predicted))))),
        exchange_force_error_n=float(np.max(np.abs(force+target))),
        exchange_moment_error_nm=float(np.max(np.abs(moment+target_moment))),
        body_moment_error_nm=float(np.max(np.abs(moment-np.column_stack((.5*predicted,-.5*predicted,np.zeros(len(t))))))),
        modal_equilibrium_error_n=float(np.max(np.abs(a@np.diag([20.,14.4])+np.column_stack((-predicted,predicted))))),
        represented_minimum_gap_m=float(min(minima)),
        represented_bound_discrepancy_m=float(np.max(np.abs(np.array(minima)-data['swept_gaps'][1:]))),
        continuous_refinement=[{k:v for k,v in row.items() if k not in ('times_s','q','v','swept_gaps')}
            for row in json.loads((workspace/'contact_guided_shell_pair_refinement_e_20261003/temporal_refinement.json').read_text())]))
(destination/'source.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps({k:record[k] for k in ('wheel_sha256','installed_import_hashes','raw_records','development_metrics')},indent=2))
