from pathlib import Path
import hashlib, json, zipfile

repo = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
workspace = Path('C:/ANYworkspaceWork')
package = Path(__file__).resolve().parent
out = repo/'docs/d1_review_support/contact_c6_algebraic_path_20261001'
out.mkdir(exist_ok=True)
entries = {}
for version in range(1, 5):
    root = workspace/f'contact-algebraic-path-20261001-v{version}'
    for p in root.rglob('*'):
        if p.is_file():
            entries[f'source-v{version}/{p.relative_to(root).as_posix()}'] = p
root = workspace/'contact-algebraic-path-review-20261001'
for p in root.rglob('*'):
    if p.is_file():
        entries[f'mistral-incomplete/{p.relative_to(root).as_posix()}'] = p
for p in package.iterdir():
    if p.is_file():
        entries[f'installed/{p.name}'] = p
for name in ('fixtures', 'wheels'):
    for p in (package/name).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:
            entries[f'installed/{p.relative_to(package).as_posix()}'] = p
for name in ('src/anysolver/general_contact/algebraic_path.py',
             'src/anysolver/general_contact/transient.py',
             'tests/test_general_contact_algebraic_path.py',
             'examples/general_contact_s3_plane_impact.py',
             'docs/d1_review_support/C6_S3_ALGEBRAIC_PATH_SLICE_20261001.md'):
    entries['candidate/'+name] = repo/name
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = {name: sha(p.read_bytes()) for name,p in sorted(entries.items())}
archive = out/'raw.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(entries.items()):
        z.writestr(name,p.read_bytes())
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha(z.read(name)) == digest for name,digest in manifest.items())
receipt = dict(files=len(manifest),archive_bytes=archive.stat().st_size,
               archive_sha256=sha(archive.read_bytes()),readback_matches=True)
(out/'archive-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
