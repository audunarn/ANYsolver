import ast
from pathlib import Path
import runpy
import sys


def test_lifted_ramped_example(monkeypatch, capsys):
    monkeypatch.setattr(sys, 'argv', ['example.py', '--one-sided-rates', '--algebraic-path',
                                    '--ramp-downward-load-n', '0.0002'])
    runpy.run_path(str(Path(__file__).with_name('example.py')), run_name='__main__')
    summary = ast.literal_eval(capsys.readouterr().out.strip())
    assert summary['profile'].endswith('NEWMARK_ALGEBRAIC_PATH_HISTORY_DEV_V1')
    assert summary['accepted_steps'] == 60
    assert summary['minimum_swept_gap_m'] >= -.001
    assert summary['maximum_residual_n'] <= 1e-6
    assert summary['represented_path_transition_times_s']
    print(summary)
