from pathlib import Path
import hashlib,json,zipfile,subprocess

workspace=Path('C:/ANYworkspaceWork')
repo=workspace/'ANYsolver-contact-main-reconcile-20261001'
out=repo/'docs/d1_review_support/contact_c6_event_subdivision_20261001'
out.mkdir(exist_ok=True)
entries={}
for root in sorted(workspace.glob('contact-event-source-20261001-*')):
    if root.is_file():
        entries['source/'+root.name]=root
    else:
        for p in root.rglob('*'):
            if p.is_file(): entries['source/'+root.name+'/'+p.relative_to(root).as_posix()]=p
for p in Path(__file__).parent.iterdir():
    if p.is_file(): entries['review-attempt/'+p.name]=p
for name in ('src/anysolver/general_contact/event_subdivision.py',
             'src/anysolver/general_contact/transient.py',
             'tests/test_general_contact_event_subdivision.py',
             'examples/general_contact_s3_plane_impact.py',
             'docs/d1_review_support/C6_S3_EVENT_SUBDIVISION_SLICE_20261001.md'):
    entries['candidate/'+name]=repo/name
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest={name:sha(p.read_bytes()) for name,p in sorted(entries.items())}
diff=subprocess.check_output(['git','diff','--binary'],cwd=repo)
archive=out/'raw.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(entries.items()): z.writestr(name,p.read_bytes())
    z.writestr('candidate/tracked.diff',diff)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha(z.read(name))==digest for name,digest in manifest.items())
    assert z.read('candidate/tracked.diff')==diff
(out/'archive-receipt.json').write_text(json.dumps(dict(files=len(manifest),
    archive_sha256=sha(archive.read_bytes()),readback_matches=True),indent=2))

note=repo/'GENERAL_CONTACT_RESTART.md'
history=repo/'docs/d1_review_support/GENERAL_CONTACT_RESTART_HISTORY_20261001_PART41.md'
assert not history.exists()
history.write_bytes(note.read_bytes())
note.write_text('''# General contact restart — 1 October 2026

## Authority and worktree

Goal active; fullC0–C9 remains required. User authorizes tiered/new testing workflow
and prohibits communication with the other task. None occurred. Worktree
`C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001`, branch
`codex/contact-main-reconcile-20261001`; slice parent `f2bab7ee`. Read latest Git
identity/status for the checkpoint. [Goal](GENERAL_CONTACT_GOAL.md) rev2026-09-30.4,
[plan](GENERAL_CONTACT_PLAN.md) rev2026-10-01.65. No publication, main merge,
release or changed defaults. Original contact checkout/six foreign files untouched.

## Current candidate and evidence

Prior affine S3 path slicef2bab7ee is installed-tested/reviewed development, not
C6 acceptance. Current event-subdivision candidate is not promoted. New
event_subdivision.py uses algebraic-only condensation and generalized physical
modes (at most3), complete rational gap numerators, bounded Bernstein isolation
and actual Newmark endpoint refinement. Ordinary solver reequilibrates proposed
event durations from committed origin before physical commit. Explicit time/gap
and root/localization budgets, new constant/history identities; old defaults and
schemas preserved. Current event profile uses fingerprint-bound version3 schema.
An event root pose seeds the coupled solve; no force/mass/eigenvalue is softened.

[Results/raw](docs/d1_review_support/contact_c6_event_subdivision_20261001/results.md)
and [review findings](docs/d1_review_support/contact_c6_event_subdivision_20261001/review.md):
sourcev7 13passes at that source stage (uniform activation/release, scalar Newmark/
energy, history work, restart, finite limits and failure/cancellation). Finalv10
two focused point-root/boundary-time regressions pass. Whole current candidate
and installed verification are pending. Retain v2 bad selector/no execution,
v3/v4/v5 numerical nonpasses and v8/v9 tilted failure; none is regraded.
Mistral startup Access denied; independent OpenAI review identified missing
point-root handling and gap-only checkpoint promotion; corrected withv10 tests.
No final candidate review, scientific acceptance, release or speed claim.

## Principal open question and next action

Tilted guided S3(.002tilt,.1span) remains NONPASS. Sourcev9 reaches
t=.0101500192s then exhausts9cutbacks: event below minimum resolved duration.
Earlier seed/root-precision correction moved the failure but did not close it.
Preserve limits/tolerances. Next run exactly that fixture with newly retained
start/probe pressure gaps, branch activity and initial gap rates (diagnostic
fields added afterv10). Determine repeated localization of the same approximate
boundary versus genuinely distinct sub-minimum events. If repeated, derive
incoming/outgoing continuation and restart-bound boundary state; do not suppress
contacts or simply shrink minimum_dt/increase budgets. If distinct, retain explicit
resource non-success and choose an admitted event-resolution contract.
Current right rates and path reconstruction may identify a tiny transition after
an approximate committed root; that explanation is not yet verified.

After correction, reuse unaffected evidence, run coherent source selection and
one installed artifact/example, then close independent review. Do not start a
temporal sweep or replay consumed native authorities. D2–D8 breadth remains open.

## Processes and budget

No owned process running; independent internal reviewer idle, no worker edits.
Only lead owns dirty/new candidate files. Routine source runner:
`scripts/run_portable_ci.py --development <exact targets> --jit off
--timeout-seconds 180 --memory-limit-mib 953`, new RUNNER_TEMP/thread1.
Stricter frozen caps prevail. ANYfemebce855 unchanged/admissionfalse. Historical
full-preimport ABC annotation-cache guard NONPASS open; do not edit shared guard.

At20:35:19UTC goal189086s+retained3120s offset=192206s,53.39h used/66.61h
remaining from original120activehours. Subsequent active time additional; no reset.
[Prior history](docs/d1_review_support/GENERAL_CONTACT_RESTART_HISTORY_20261001_PART41.md)
links accepted slices, prior source/installed failures and consumed authorities.
''',encoding='utf-8')
print(json.dumps(dict(files=len(manifest),archive_bytes=archive.stat().st_size,
                     archive_sha256=sha(archive.read_bytes()))))
