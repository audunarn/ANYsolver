from pathlib import Path
import hashlib,json,platform,sys,zipfile
from importlib.metadata import version
root=Path('C:/ANYworkspaceWork/contact_multiple_beam_s3_caps_20261004')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_multiple_beam_s3_caps_20261004';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=[];runs={}
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists():continue
    runtime=json.loads((folder/'runtime.json').read_text(encoding='utf-8')) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':json.loads((folder/'resource.json').read_text(encoding='utf-8')),'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,folder.name+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final'
imports=json.loads((final/'imports.json').read_text(encoding='utf-8'))
runtime=json.loads((final/'runtime.json').read_text(encoding='utf-8'))
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed/anysolver')
    assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
p=dest/'installed_parity.json';p.write_text(json.dumps({'loaded':loaded,'package':package},indent=2),encoding='utf-8');raw.append((p,p.name))
for name in ('contract_review.md','design.md'):
    p=dest/name;p.write_bytes((root/name).read_bytes());raw.append((p,name))
source=('src/anysolver/general_contact/multiple_beam_s3_caps.py','src/anysolver/general_contact/core.py','tests/test_general_contact_multiple_beam_s3_caps.py','examples/general_contact_multiple_beam_s3_caps.py')
raw.extend((root/p,p) for p in ('run.py','collect.py'))
raw.extend((repo/p,'candidate/'+p) for p in source)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
summary={'scope':'D3 explicit multiple deformable fixed-director S3 interiors and optional fixed plane/sphere contributors with actual B2/B3 caps; development/code verification only',
'source_parent':'6168937154ebdc00eae128aad6a803afded9831c','source_files':{p:sha(repo/p) for p in source},
'wheels':{str(p.relative_to(root)):sha(p) for p in (root/'dist').glob('*.whl')},'runs':runs,
'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],'effective_pools':runtime['effective_pools'],
'independent_response':json.loads((root/'installed_response/multiple_s3_response.json').read_text(encoding='utf-8')),
'directional_tangent_target':1e-5,'contact_gradient_target':1e-6,'linearized_response_target':1e-3,'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
'environment':{'python':sys.version,'platform':platform.platform(),'versions':{name:version(name) for name in ('numpy','scipy','numba','ANYmaterial','ANYgeometry')}},
'review_disposition':'supporting same-family review identified plane endpoint-count spelling and omitted effective rigid geometry restart settings; both fixed before source01. Independent four-coordinate reference scrutinized and restricted to verified open roots/inward sphere tips. Real heterogeneous driver and shared-S3/junction checks added. No independent engineering acceptance.',
'preserved_failures':['source01 5pass/4fail: decoupled oracle omitted moving-normal cross motion; incorrect callback API and capability-property name. Fixture/API corrections documented; raw evidence retained','review counterexample demonstrates fixture oracle is not valid with active root caps; explicit actual/reference domain and production branch checks added','quantitative installed response output would be overwritten by later leaf tests; isolated output-name correction and one focused installed replay retain actual four-coordinate result','all predecessor numerical nonpasses, consumed authorities and frozen acceptance boundaries unchanged'],
'unchanged':['single-pair S3/plane/sphere equations, work maps, path bounds and true ends','old all-plane and multiple-rigid profiles/restart','legacy owned-point settings and defaults','no-contact and historical sphere APIs','physical commit/material state ownership','ANYfem and normal application admission false','engineering criteria and frozen execution/resource restrictions'],
'limits':['explicit one-cell classical scalar-elastic B2/B3 selections and fixed-director physical S3 face interiors, ordinary force/displacement','multiple independent whole-beam/one-face pairs, not a patch union or partial-face clipping','optional fixed planes/spheres with effective child settings recorded; no moving tools or cylinder fallback','distinct line N/m2 and endpoint N/m laws/budgets retained','fixture-specific independent contact reference including moving-normal cross motion; structural response reference explicitly linearized','no rim/native/material-surface friction/transient or general profile admission','mesh/enforcement qualification and full C0-C9 remain']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({'runs':len(runs),'records':len(raw),'modules':len(loaded),'package_files':len(package),'resource':runs['installed_final']['resource'],'response':{k:v for k,v in summary['independent_response'].items() if k!='contact'},'evidence':str(dest)}))
