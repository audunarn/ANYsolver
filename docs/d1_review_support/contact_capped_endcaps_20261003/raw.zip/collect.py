from pathlib import Path
import json,hashlib,zipfile
root=Path('C:/ANYworkspaceWork/contact_capped_endcaps_20261003')
old=Path('C:/ANYworkspaceWork/contact_chain_consistent_20261003')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_capped_endcaps_20261003'
dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
runs={};raw=[]
for base,tags in ((old,('endcaps_first','endcaps_cap_roots','endcaps_complete_source','endcaps_tool_discriminator','endcaps_activation_stage')),(root,('seam_and_restart','seam_guard','build','install','installed_final'))):
    for tag in tags:
        folder=base/tag
        resource=json.loads((folder/'resource.json').read_text()) if (folder/'resource.json').exists() else None
        runtime=json.loads((folder/'runtime.json').read_text()) if (folder/'runtime.json').exists() else None
        runs[tag]={'resource':resource,'outcomes':runtime.get('outcomes') if runtime else None}
        raw.extend((p,base.name+'/'+tag+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final'
imports=json.loads((final/'imports.json').read_text());runtime=json.loads((final/'runtime.json').read_text())
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed/anysolver');assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
parity=dest/'installed_parity.json';parity.write_text(json.dumps({'loaded':loaded,'package':package},indent=2))
work=json.loads((final/'tool_work.json').read_text())
prior=json.loads((old/'endcaps_tool_discriminator/tool_work.json').read_text())
source=('src/anysolver/general_contact/capped_cylinder.py','src/anysolver/general_contact/beam_end_topology.py','src/anysolver/general_contact/beam_plane.py','src/anysolver/nonlinear_static.py','tests/test_general_contact_capped_cylinder_endcaps.py','examples/general_contact_beam_end_capped_cylinder.py')
raw.extend(((root/'collector_initial_failure.txt','collector_initial_failure.txt'),(parity,'installed_parity.json'),(root/'run.py','run.py'),(root/'collect.py','collect.py'),(dest/'review.md','review.md')))
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
summary={'scope':'D3 B2/B3 exterior capped-cylinder hemispherical-end point penalty development; not engineering acceptance',
'source_parent':'47d4ab19eb8156e9a51e098935f6d6972f12913b','source_files':{p:sha(repo/p) for p in source},
'wheels':{p.name:sha(p) for p in (root/'dist').glob('*.whl')},'runs':runs,
'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],'effective_pools':runtime['effective_pools'],
'prospective_activation_stage_work':{'reported_j':work['reported_work'],'stored_j':work['storage'],'independent_history_j':work['independent_work'],'relative_storage_error':abs(work['reported_work']-work['storage'])/work['storage'],'target':1e-6},
'preserved_unaligned_work_nonpass':{'reported_j':prior['reported_work'],'stored_j':prior['storage'],'independent_history_j':prior['independent_work'],'relative_storage_error':abs(prior['reported_work']-prior['storage'])/prior['storage'],'target':1e-6},
'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
'limits':'180s/953MiB per process tree; additive line+endpoint point model; exterior only; active ownership and atomic feature seams reject; no dynamics/native/friction/application/engineering acceptance'}
(dest/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'runs':len(runs),'raw_records':len(raw),'installed_modules':len(loaded),'package_files':len(package),'outcomes':runs['installed_final']['outcomes'],'work_error':summary['prospective_activation_stage_work']['relative_storage_error'],'pools':runtime['effective_pools']}))

