from pathlib import Path
import json,hashlib,zipfile
root=Path('C:/ANYworkspaceWork/contact_radial_endcaps_20261003')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_radial_endcaps_20261003'
dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=[];runs={}
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists():continue
    resource=json.loads((folder/'resource.json').read_text())
    runtime=json.loads((folder/'runtime.json').read_text()) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':resource,'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,folder.name+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final'
imports=json.loads((final/'imports.json').read_text());runtime=json.loads((final/'runtime.json').read_text())
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
assert all(p['num_threads']==1 for p in runtime['effective_pools'])
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed/anysolver')
    assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
parity=dest/'installed_parity.json'
parity.write_text(json.dumps({'loaded':loaded,'package':package},indent=2))
review=dest/'review.md';review.write_bytes((root/'review.md').read_bytes())
source=('src/anysolver/general_contact/beam_end_radial_geometry.py',
    'src/anysolver/general_contact/beam_radial_ends.py','src/anysolver/general_contact/core.py',
    'tests/test_general_contact_radial_beam_ends.py','examples/general_contact_beam_end_capped_cylinder.py')
raw.extend(((parity,'installed_parity.json'),(root/'run.py','run.py'),
    (root/'collect.py','collect.py'),(review,'review.md')))
raw.extend((repo/p,'candidate/'+p) for p in source)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
tool={kind:json.loads((final/('tool_'+kind+'.json')).read_text()) for kind in ('sphere','cylinder')}
summary={'scope':'D3 static classical radial hemisphere line-plus-point development; not engineering acceptance',
    'source_parent':'76a3519f4ce78c50cc98717d727ddf76b9fd645a',
    'source_files':{p:sha(repo/p) for p in source},
    'wheels':{p.name:sha(p) for p in (root/'dist').glob('*.whl')},'runs':runs,
    'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
    'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],
    'effective_pools':runtime['effective_pools'],'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
    'tool_work_storage_relative_errors':{kind:abs(r['work_J']-r['storage_J'])/r['storage_J'] for kind,r in tool.items()},
    'tool_work_history_relative_errors':{kind:abs(r['work_J']-r['independent_work_J'])/r['independent_work_J'] for kind,r in tool.items()},
    'limits':'180s/953MiB process tree; elastic scalar/von-Karman; fixed radial map and affine static paths; exterior centreline; rejected closed end ownership changes, unresolved integration and geometry; no native, friction, dynamics, normal application admission, release or engineering acceptance',
    'retained_failures':{'radial_first':'7 integration-limit nonpasses: floating activation cuts left closed slivers',
        'exact_activation_cuts':'9 pass, singular collinear B3 fixture failed existing geometry guard',
        'complete_path_work':'3 pass, 2 B2 constant-derivative restriction errors',
        'state_and_public':'4 pass, callback test incorrectly expected progress-callback exception propagation'},
    'review_disposition':'supporting same-family review only; B2 derivative control promoted to constant degree-one; rotating and collapsing path checked; moving tool/tilted map/multiple pockets/grazing/budget discriminators implemented and installed-tested'}
(dest/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'runs':len(runs),'raw_records':len(raw),'modules':len(loaded),'package_files':len(package),
    'outcomes':runs['installed_final']['outcomes'],'resource':runs['installed_final']['resource'],
    'tool_work_storage_relative_errors':summary['tool_work_storage_relative_errors']}))
