from pathlib import Path
import runpy


def test_installed_s3_friction_example():
    module=runpy.run_path(str(Path(__file__).with_name('friction_example.py')))
    result=module['run_example']()
    rows=result.info['force_displacement_history']
    assert result.status == 'completed'
    assert set(rows[1]['friction']['branch']) == {'stick'}
    assert set(rows[2]['friction']['branch']) == {'slip'}
    assert set(rows[4]['friction']['branch']) == {'open'}
