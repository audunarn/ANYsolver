from pathlib import Path
import hashlib,json,zipfile

workspace=Path('C:/ANYworkspaceWork')
repo=workspace/'ANYsolver-contact-main-reconcile-20261001'
dest=repo/'docs/d1_review_support/contact_c5_s3_pressure_history_20261002/raw.zip'
assert not dest.exists()
files=[]
for folder in (workspace/'contact-friction-static-package-20261002',
               workspace/'contact-friction-static-package-v2-20261002'):
    files.extend(p for p in folder.glob('*') if p.is_file())
    files.extend((folder/'fixtures').glob('*.py'))
    files.extend((folder/'wheels').glob('*.whl'))
for pattern in ('contact-friction-static-v*-20261002.log',
                'contact-friction-spin-*-20261002.log',
                'contact-friction-cut-*-20261002.log',
                'contact-friction-owner-review-20261002*.log'):
    files.extend(workspace.glob(pattern))
for folder in workspace.glob('contact-friction-*-tmp-20261002'):
    files.extend(p for p in folder.rglob('*') if p.is_file()
                 and p.suffix in ('.json','.xml'))
unique={p.relative_to(workspace).as_posix():p for p in files}
manifest={name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
          for name,p in sorted(unique.items())}
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,p in sorted(unique.items()):
        archive.write(p,name)
    archive.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(dest) as archive:
    assert archive.testzip() is None
    assert all(hashlib.sha256(archive.read(n)).hexdigest()==v['sha256']
               for n,v in manifest.items())
print(json.dumps(dict(files=len(manifest),bytes=sum(v['bytes'] for v in manifest.values()),
    archive_bytes=dest.stat().st_size,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),readback='PASS')))
