from pathlib import Path
import hashlib,json,platform,sys,zipfile
from importlib.metadata import version
root=Path('C:/ANYworkspaceWork/contact_multiple_hemisphere_planes_20261004')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_multiple_hemisphere_planes_20261004';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=[];runs={}
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists():continue
    runtime=json.loads((folder/'runtime.json').read_text(encoding='utf-8')) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':json.loads((folder/'resource.json').read_text(encoding='utf-8')), 'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,folder.name+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final'
imports=json.loads((final/'imports.json').read_text(encoding='utf-8'))
runtime=json.loads((final/'runtime.json').read_text(encoding='utf-8'))
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed/anysolver')
    assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
parity=dest/'installed_parity.json'
parity.write_text(json.dumps({'loaded':loaded,'package':package},indent=2),encoding='utf-8')
raw.append((parity,'installed_parity.json'))
for name in ('multiple_support_review.md','beam_shell_next.md','design.md'):
    p=dest/name;p.write_bytes((root/name).read_bytes());raw.append((p,name))
source=('src/anysolver/general_contact/multiple_beam_rigid.py','src/anysolver/general_contact/beam_hemisphere_support.py','src/anysolver/general_contact/beam_hemisphere_plane.py','src/anysolver/general_contact/core.py','tests/test_general_contact_multiple_hemisphere_planes.py','examples/general_contact_multiple_hemisphere_planes.py')
raw.extend((root/p,p) for p in ('run.py','collect.py'))
raw.extend((repo/p,'candidate/'+p) for p in source)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
summary={'scope':'D3 explicit multiple fixed-plane actual hemisphere support work, development/code verification only',
'source_parent':'8691c2b8aaa54716c5437a8df076dd501db74414','source_files':{p:sha(repo/p) for p in source},
'wheels':{p.name:sha(p) for p in (root/'dist').glob('*.whl')},'runs':runs,
'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],'effective_pools':runtime['effective_pools'],
'independent_two_plane_bar':json.loads((final/'two_plane_bar.json').read_text(encoding='utf-8')),
'directional_tangent_target':1e-5,'bar_response_target':1e-6,'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
'environment':{'python':sys.version,'platform':platform.platform(),'versions':{name:version(name) for name in ('numpy','scipy','numba','ANYmaterial','ANYgeometry')}},
'review_disposition':'same-family source scrutiny identified required child protocol, rejection and accounting conditions; actual installed tests exercise complete shared B3 work, both orthogonal body wrenches, unsupported selectors/nonplanes, common fraction, duplicate/resource admission and restart/state. No independent engineering acceptance.',
'preserved_failures':['none in this measured slice; all predecessor owned-point mechanical nonpasses and fixture failures retained unchanged'],
'unchanged':['default owned_point multiple/fixed-rigid law arithmetic and profile identity','line/end units and dimensional criteria','normal application admission false','no-contact/historical defaults/sphere APIs','frozen authority and historical failures','ANYfem source'],
'limits':['explicit fixed planes only for new selector','scalar isotropic elastic concentric B2/B3 von Karman','genuine all-material-node physical ends','exterior gap tolerance below radius','aggregate active endpoint counts are endpoint-target pairs, not unique physical ends','frictionless centreline-tangent support springs, not material-surface integration/spin','pair/radial/shell-boundary cap transitions and engineering qualification remain','full C0-C9 programme incomplete']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({'runs':len(runs),'records':len(raw),'modules':len(loaded),'package_files':len(package),'resource':runs['installed_final']['resource'],'evidence':str(dest)}))
