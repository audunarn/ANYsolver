from pathlib import Path
import hashlib, json, zipfile

repo = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
workspace = Path('C:/ANYworkspaceWork')
out = repo/'docs/d1_review_support/contact_c6_free_sphere_20261002'
entries = {}
for version in range(1, 9):
    root = workspace/f'contact-free-sphere-20261002-v{version}'
    for p in root.rglob('*'):
        if p.is_file(): entries[f'source-v{version}/{p.relative_to(root).as_posix()}'] = p
    entries[f'source-v{version}/runner.log'] = workspace/f'contact-free-sphere-20261002-v{version}.log'
for name in ('contact-free-sphere-review-20261002.log', 'contact-free-sphere-review-20261002-followup.log'):
    entries['review/'+name] = workspace/name
package = workspace/'contact-free-sphere-package-20261002'
for p in package.iterdir():
    if p.is_file(): entries['installed/'+p.name] = p
for folder in ('fixtures', 'wheels', 'examples'):
    for p in (package/folder).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:
            entries['installed/'+p.relative_to(package).as_posix()] = p
for name in ('src/anysolver/general_contact/transient.py',
             'src/anysolver/general_contact/free_rigid.py',
             'src/anysolver/general_contact/sphere_temporal_bounds.py',
             'tests/test_general_contact_transient_free_sphere.py',
             'tests/test_general_contact_sphere_temporal_bounds.py',
             'examples/general_contact_free_sphere_impact.py',
             'docs/GENERAL_CONTACT_C6_CLASSICAL_BEAM_DEV.md',
             'docs/d1_review_support/C6_FREE_SPHERE_SLICE_20261002.md',
             'docs/d1_review_support/contact_c6_free_sphere_20261002/results.md',
             'docs/d1_review_support/contact_c6_free_sphere_20261002/source-review-adjudication.md'):
    entries['candidate/'+name] = repo/name
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = {name: sha(p.read_bytes()) for name, p in sorted(entries.items())}
archive = out/'raw.zip'
assert not archive.exists(), 'Never overwrite retained evidence'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for name, p in sorted(entries.items()): z.writestr(name, p.read_bytes())
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha(z.read(name)) == h for name, h in manifest.items())
receipt = dict(files=len(manifest), archive_bytes=archive.stat().st_size,
               archive_sha256=sha(archive.read_bytes()), readback_matches=True)
(out/'archive-receipt.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt))
