from pathlib import Path
import hashlib, json, zipfile
package = Path(__file__).resolve().parent
repo = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
out = repo/'docs/d1_review_support/contact_c6_free_sphere_20261002'
entries = {'installed/'+p.name: p for p in package.glob('free-sphere-history-v2*') if p.is_file()}
entries['candidate/test_general_contact_transient_free_sphere.py'] = repo/'tests/test_general_contact_transient_free_sphere.py'
for name in ('docs/d1_review_support/C6_FREE_SPHERE_SLICE_20261002.md',
             'docs/d1_review_support/contact_c6_free_sphere_20261002/results.md'):
    entries['candidate/'+name] = repo/name
entries['recipe.py'] = Path(__file__)
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = {name: sha(p.read_bytes()) for name, p in sorted(entries.items())}
archive = out/'raw-history-supplement.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for name, p in sorted(entries.items()): z.writestr(name, p.read_bytes())
    z.writestr('manifest.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha(z.read(name)) == h for name, h in manifest.items())
receipt = dict(files=len(manifest), archive_bytes=archive.stat().st_size,
               archive_sha256=sha(archive.read_bytes()), readback_matches=True)
(out/'history-supplement-receipt.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt))
