import hashlib,json,runpy,zipfile
from pathlib import Path
from importlib.metadata import version
folder=Path(__file__).parent
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
data=runpy.run_path(str(folder/'inspect_runs.py'))
records=data['records'];labels=data['labels'];summary=data['summary']
assert len(records)==13 and all('runtime_path' in row or row['label']=='k' for row in records)
destination=repo/'docs/d1_review_support/contact_c6_s3_matched_overlap_20261003'
changed=[
 'src/anysolver/general_contact/s3_overlap_hermite_gap.py',
 'src/anysolver/general_contact/s3_pressure_hermite_bounds.py',
 'src/anysolver/general_contact/normal_s3_skin_path.py',
 'src/anysolver/general_contact/transient.py',
 'examples/general_contact_deforming_s3_impact_dev.py',
 'examples/general_contact_nonuniform_s3_impact_dev.py',
 'tests/test_s3_overlap_hermite_gap.py',
 'tests/test_general_contact_transient_clipped_s3.py',
 'tests/test_general_contact_transient_deforming_s3.py',
]
files=[]
for label,name in labels.items():
 directory=Path('C:/ANYworkspaceWork')/name
 files.extend((path,'runs/'+label+'/'+path.relative_to(directory).as_posix())
              for path in directory.rglob('*') if path.is_file())
 files.append((directory.with_suffix('.log'),'runs/'+label+'.log'))
for name in ('source.json','installed.json','source-resource.json','installed-resource.json',
             'source.log','installed.log','build.log','install.log','example_check.py','run_case.py',
             'inspect_runs.py','record_evidence.py','package_summary.json','runs.json'):
 files.append((folder/name,'package/'+name))
for path in folder.glob('*profile*'):
 if path.is_file():files.append((path,'profile/'+path.name))
files.extend((path,'profile/'+path.name) for path in folder.glob('*.prof'))
files.extend((path,'profile/'+path.name) for path in folder.glob('*-functions.txt'))
files.append((next((folder/'dist').glob('*.whl')),'package/artifact.whl'))
for name in ('contact_s3_overlap_coarse_e_candidate.py','contact_s3_overlap_failed_g_reference_j_candidate.py'):
 files.append((Path('C:/ANYworkspaceWork')/name,'historical_snapshots/'+name))
files.extend((repo/path,'candidate/'+path) for path in changed)
files.append((destination/'supporting_review.md','review/supporting_review.md'))
with zipfile.ZipFile(destination/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path,name in files:archive.write(path,name)
record=dict(parent='d0bb6a38ea6b7f5c77c8bbd62c83807948b61b65',
 status='implemented/source-tested/installed-tested development; no engineering acceptance',
 source_sha256={path:hashlib.sha256((repo/path).read_bytes()).hexdigest() for path in changed},
 numerical_environment={name:version(name) for name in ('numpy','scipy','numba','llvmlite','pytest','psutil')},
 runtimes=records,package=summary,raw_records=len(files),
 coarse_discriminator=json.loads((Path('C:/ANYworkspaceWork')/labels['f']/'coarse_clipped_gap_discriminator.json').read_text()),
 refined_discriminator=json.loads((Path('C:/ANYworkspaceWork')/labels['i']/'refined_clipped_gap_discriminator.json').read_text()),
 independent_stiffer_preflight=json.loads((Path('C:/ANYworkspaceWork')/labels['j']/'stiffer_clipped_reference_preflight.json').read_text()))
record['saved_state_profile']=json.loads((folder/'profile-components.json').read_text())
record['profile_resource']=json.loads((folder/'profile-resource.json').read_text())
record['saved_profile_interpretation']='Saved KN1e9 prefix coordinates already exceed20um; evaluating declared KN2e10 does not change that pose. Strong endpoint/path calls reject endpoint penetration. Their costs are rejected-call observations, not successful path certification or an equilibrated KN2e10 trajectory. Weak constant-path phase resolves.'
trajectory=Path('C:/ANYworkspaceWork')/labels['k']/'clipped_s3_coupled.json'
record['coupled_candidate']=json.loads(trajectory.read_text()) if trajectory.exists() else None
(destination/'source.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(raw_records=len(files),passed=sum(row['outcomes'].get('passed',0) for row in records),
 failed=sum(row['outcomes'].get('failed',0) for row in records),exits=[row['exit'] for row in records],
 imported_hashes=summary['imported_hashes'],wheel_sha256=summary['wheel_sha256'],
 coupled_candidate_saved=record['coupled_candidate'] is not None)))
