import json
from pathlib import Path
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
labels={
 'a':'contact_s3_overlap_local_a_20261003',
 'b':'contact_s3_overlap_local_b_20261003',
 'c':'contact_s3_overlap_driver_c_20261003',
 'd':'contact_s3_overlap_driver_d_20261003',
 'e':'contact_s3_overlap_coupled_e_20261003',
 'f':'contact_s3_overlap_resolution_f_20261003',
 'g':'contact_s3_overlap_refined_g_20261003',
 'h':'contact_s3_overlap_enforcement_h_20261003',
 'i':'contact_s3_overlap_reference_i_20261003',
 'j':'contact_s3_overlap_preflight_j_20261003',
 'k':'contact_s3_overlap_coupled_k_20261003',
 'l':'contact_s3_overlap_state_l_20261003',
 'm':'contact_s3_overlap_work_m_20261003',
}
records=[]
for label,name in labels.items():
 directory=Path('C:/ANYworkspaceWork')/name
 if not directory.exists():continue
 paths=list(directory.rglob('runtime.json'))
 if not paths:
  resources=list(directory.rglob('resource.json'))
  assert label=='k' and len(resources)==1
  resource=json.loads(resources[0].read_text())
  assert resource['status']=='timeout' and resource['limit_mib']==3814
  assert resource['peak_sampled_bytes']<3814*1024**2
  records.append(dict(label=label,runtime='absent after forced timeout',outcomes={},exit=1,
   effective_runtime_verified=False,resource=resource,resource_path=str(resources[0]),
   log=str(directory.with_suffix('.log'))))
  continue
 assert len(paths)==1,(label,len(paths))
 runtime=json.loads(paths[0].read_text())
 resource=json.loads((paths[0].parent/'resource.json').read_text())
 assert not runtime['errors'] and runtime['jit_disabled'] and runtime['numba_threads']==1
 assert all(p['num_threads']==1 for p in runtime['effective_pools'])
 assert all(Path(v).resolve().is_relative_to(repo/'src') for v in runtime['imports'].values())
 assert resource['status']=='terminal'
 cap=900 if label in ('g','k') else 180
 memory=3814 if label in ('g','k') else 953
 assert resource['elapsed_seconds']<cap and resource['peak_sampled_bytes']<memory*1024**2
 records.append(dict(label=label,outcomes=runtime['outcomes'],exit=runtime['exit_code'],
  imported_modules=len(runtime['imports']),jit_disabled=runtime['jit_disabled'],numba_threads=1,
  elapsed_s=resource['elapsed_seconds'],peak_sampled_bytes=resource['peak_sampled_bytes'],
  runtime_path=str(paths[0]),limit_s=cap,limit_mib=memory))
Path(__file__).with_name('runs.json').write_text(json.dumps(records,indent=2)+'\n')
for row in records:
 print(json.dumps({key:value for key,value in row.items() if key not in ('runtime_path','log')}))

import hashlib
folder=Path(__file__).parent
source=json.loads((folder/'source.json').read_text())
installed=json.loads((folder/'installed.json').read_text())
assert source['result']==installed['result'] and source['imports']==installed['imports']
assert all(hashlib.sha256((repo/'src'/name).read_bytes()).hexdigest()==value
           for name,value in source['imports'].items())
resources={name:json.loads((folder/(name+'-resource.json')).read_text()) for name in ('source','installed')}
assert all(value['exit']==0 and value['elapsed_s']<180 and value['peak_sampled_bytes']<953*1024**2
           for value in resources.values())
wheel=next((folder/'dist').glob('*.whl'))
summary=dict(imported_hashes=len(source['imports']),all_fields_match=True,
 profile=source['result']['profile'],states=len(source['result']['times_s']),
 events=len(source['result']['localized_contact_event_times_s']),cutbacks=source['result']['cutbacks'],
 wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),resources=resources)
(folder/'package_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({key:value for key,value in summary.items() if key!='resources'}))
