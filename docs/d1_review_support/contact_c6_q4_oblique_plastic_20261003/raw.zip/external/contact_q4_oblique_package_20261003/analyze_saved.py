import json
from pathlib import Path
import numpy as np

folder=Path(__file__).parent
files={
 'coarse':Path('C:/ANYworkspaceWork/contact_q4_oblique_integrated_c_20261003/oblique_impact.json'),
 'half':Path('C:/ANYworkspaceWork/contact_q4_oblique_half_e_20261003/oblique_impact_half.json')}
E,G,H,Y,KN,RHO=1.e9,1.e9/2.6,.05,.2,4.e11,1.e4
nx,nz=np.sin(2.e-5),np.cos(2.e-5)
D=np.array([[-nx/6,nz],[nx/6,nz]])
B=D[:,0]+nz*.0008
mass=np.array([RHO*H/6,RHO*H]); scales=np.array([5.,1.5e7])
records={}
for name,path in files.items():
 data=json.loads(path.read_text()); q=np.array(data['q']);v=np.array(data['v']);a=np.array(data['a'])
 p=np.array(data['plastic_xx']);alpha=np.array(data['alpha']);tau=2*G*(q[:,0]-p)
 reference=np.array([row['q'] for row in data['reference']])
 gaps=B+q@D.T
 force=KN*(.5*np.minimum(gaps,0.))@D
 force[:,0]+=2*H*tau
 storage=.25*KN*np.sum(np.minimum(gaps,0.)**2,axis=1)
 energy=.5*np.sum(mass*v*v,axis=1)+H*tau*tau/(2*G)+H*Y*alpha+storage
 assert np.max(alpha)<.005 and max(row['alpha'] for row in data['reference'])<.005
 records[name]=dict(saved_states=len(q),final_q=q[-1].tolist(),final_v=v[-1].tolist(),
  final_alpha=float(alpha[-1]),final_plastic_xx=float(p[-1]),
  maximum_alpha=float(np.max(alpha)),maximum_modal_residual=(np.max(np.abs(mass*a+force)/scales,axis=0)).tolist(),
  maximum_reference_coordinate_error=(np.max(np.abs(q-reference),axis=0)).tolist(),
  max_total_energy_relative_defect=float(np.max(np.abs(energy/energy[0]-1))),
  cutbacks=data['cutback_diagnostics'],events=data['events_s'],
  endpoint_requests=data['endpoint_requests'],stage_evaluations=data['stage_evaluations'])
coarse,half=records['coarse'],records['half']
comparison={key:float(abs(coarse[key]-half[key])/abs(half[key]))
 for key in ('final_alpha','final_plastic_xx')}
comparison['final_membrane_coordinate_relative_change']=abs(coarse['final_q'][0]-half['final_q'][0])/abs(half['final_q'][0])
report=dict(scope='development; discrete-reference agreement and two-level sensitivity only',
 inputs={name:str(path) for name,path in files.items()},records=records,refinement_comparison=comparison,
 limitation='Two levels do not establish convergence; total energy cannot verify tiny coupling work.')
(folder/'saved_comparison.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
