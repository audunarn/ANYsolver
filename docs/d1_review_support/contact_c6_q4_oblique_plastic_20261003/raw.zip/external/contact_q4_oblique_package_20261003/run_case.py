import json,runpy,subprocess,sys,time
from pathlib import Path
import psutil

repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
folder=Path(__file__).parent
tooling=runpy.run_path(str(repo/'scripts/run_portable_ci.py'))
label=sys.argv[1]; dt=float(sys.argv[2])
env=tooling['_worker_environment'](folder/label); env['NUMBA_DISABLE_JIT']='1'
command=[sys.executable,'-I',str(folder/'example_check.py'),str(repo/'src'),
    str(repo/'examples/general_contact_q4_oblique_plastic_impact_dev.py'),str(folder/(label+'.json')),str(dt),sys.argv[3]]
started=time.monotonic();peak=0
with (folder/(label+'.log')).open('w',encoding='utf-8') as log:
    child=subprocess.Popen(command,cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT)
    try:
        while child.poll() is None:
            try:
                p=psutil.Process(child.pid)
                peak=max(peak,sum(q.memory_info().rss for q in [p,*p.children(recursive=True)] if q.is_running()))
            except psutil.NoSuchProcess:pass
            if time.monotonic()-started>180 or peak>953*1024**2:
                raise RuntimeError('owned temporal development resource cap exceeded')
            time.sleep(.1)
    finally: tooling['_terminate_tree'](child)
record=dict(scope='bounded temporal development; not qualification',command=command,
    elapsed_s=time.monotonic()-started,peak_sampled_bytes=peak,exit=child.returncode,limit_s=180,limit_mib=953)
(folder/(label+'-resource.json')).write_text(json.dumps(record,indent=2))
assert child.returncode==0,record
