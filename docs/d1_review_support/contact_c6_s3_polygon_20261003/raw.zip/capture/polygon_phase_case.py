import dataclasses,hashlib,json,sys,time
from pathlib import Path
import numpy as np
folder=Path(__file__).parent;root=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001/src');sys.path.insert(0,str(root))
from anysolver.general_contact.s3_pressure_hermite_bounds import s3_pressure_hermite_bounds
from threadpoolctl import threadpool_info
import numba
assert numba.config.DISABLE_JIT==1 and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpool_info())
x=dict(np.load(folder/'stalled_weak.npz'));c=json.loads((folder/'stalled_weak.json').read_text())
values=[x[k] for k in ('reference_source','reference_target','source_faces','a0','a1','b0','b1','av0','av1','bv0','bv1')]
values[2]=tuple(tuple(int(i) for i in face) for face in values[2])
started=time.monotonic();result=s3_pressure_hermite_bounds(*values,c['dt'],active=x['active'],gap_tolerance_m=c['gap_tolerance_m'],maximum_time_panels=c['maximum_time_panels'],maximum_spatial_cells=c['maximum_spatial_cells'],maximum_depth=c['maximum_depth'],_polygon_bounds=True)
elapsed=time.monotonic()-started
imports={}
for name,module in tuple(sys.modules.items()):
 path=getattr(module,'__file__',None)
 if path and (name=='anysolver' or name.startswith('anysolver.')):
  path=Path(path).resolve();assert path.is_relative_to(root)
  imports[path.relative_to(root).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
record=dict(result=dataclasses.asdict(result),elapsed_s=elapsed,effective=dict(root=str(root),jit_disabled=1,numba_threads=1,pools=threadpool_info(),imports=imports),scope='Saved-path development; V3 hidden guard unchanged; no complete trajectory.')
(folder/'polygon_phase.json').write_text(json.dumps(record,indent=2));print(json.dumps(dict(status=result.status,elapsed_s=elapsed,cells=result.visited_spatial_cells,panels=result.visited_time_panels)))
