import json,inspect,sys,time
from pathlib import Path
import numpy as np
root=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001/src');sys.path.insert(0,str(root))
from anysolver.general_contact import s3_overlap_hermite_gap as m
folder=Path(__file__).parent;x=dict(np.load(folder/'first_hidden.npz'));c=json.loads((folder/'first_hidden.json').read_text())
original=m._gap_interval;lines,start=inspect.getsourcelines(m.s3_overlap_hermite_gap_bounds)
hidden_line=start+next(i for i,line in enumerate(lines) if 'hidden=_gap_interval' in line)
records=[]
def watch(face,vertices,factor):
 result=original(face,vertices,factor);caller=inspect.currentframe().f_back
 if caller.f_lineno==hidden_line and caller.f_locals['depth']==c['maximum_depth'] and result is not None and result[0]<-c['approach_tolerance_m']:
  entries=[]
  for v in vertices:
   p=m._blend(face.polynomials[4:7],v)
   entries.append(dict(bary=[float(i) for i in v],H_min=float(min(p)),H_max=float(max(p)),H_endpoints=[float(p[0]),float(p[-1])]))
  records.append(dict(ids=face.ids,lower_m=float(result[0]),upper_m=float(result[1]),factor=[float(i) for i in factor],vertices=entries))
 return result
m._gap_interval=watch
values=[x[k] for k in ('reference_source','reference_target','source_faces','a0','a1','b0','b1','av0','av1','bv0','bv1')]
values[2]=tuple(tuple(int(i) for i in face) for face in values[2])
started=time.monotonic();proof=m.s3_overlap_hermite_gap_bounds(*values,c['dt'],gap_tolerance_m=c['gap_tolerance_m'],exclude_open_endpoint_approach_tolerance_m=c['approach_tolerance_m'],maximum_time_panels=c['maximum_time_panels'],maximum_spatial_cells=c['maximum_spatial_cells'],maximum_depth=c['maximum_depth'])
record=dict(proof=proof.__dict__,elapsed_s=time.monotonic()-started,leaf_failures=records)
(folder/'hidden_leaf.json').write_text(json.dumps(record,indent=2));print(json.dumps(dict(status=proof.status,elapsed_s=record['elapsed_s'],failed_leaves=len(records),minimum_m=min(r['lower_m'] for r in records))))
