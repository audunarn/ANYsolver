import cProfile,dataclasses,hashlib,importlib.util,json,sys,time,os
from pathlib import Path
import numpy as np
folder=Path(__file__).parent;root=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001/src');sys.path.insert(0,str(root))
from anysolver.general_contact import s3_pressure_hermite_bounds as baseline
name='anysolver.general_contact._pressure_prototype'
spec=importlib.util.spec_from_file_location(name,folder/'pressure_prototype.py');prototype=importlib.util.module_from_spec(spec);sys.modules[name]=prototype;spec.loader.exec_module(prototype)
x=dict(np.load(folder/'stalled_weak.npz'));c=json.loads((folder/'stalled_weak.json').read_text())
values=[x[k] for k in ('reference_source','reference_target','source_faces','a0','a1','b0','b1','av0','av1','bv0','bv1')]
values[2]=tuple(tuple(int(i) for i in face) for face in values[2])
records={}
def evaluate(mod,budget,key,profile=False):
 started=time.monotonic()
 profiler=cProfile.Profile() if profile else None
 if profiler:profiler.enable()
 result=mod.s3_pressure_hermite_bounds(*values,c['dt'],active=x['active'],gap_tolerance_m=c['gap_tolerance_m'],maximum_time_panels=c['maximum_time_panels'],maximum_spatial_cells=budget,maximum_depth=c['maximum_depth'])
 if profiler:profiler.disable();profiler.dump_stats(str(folder/(key+'.prof')))
 records[key]=dict(result=dataclasses.asdict(result),elapsed_s=time.monotonic()-started)
 (folder/'saved_phase.json').write_text(json.dumps(records,indent=2))
 return records[key]['result']
for budget in (128,512):
 a=evaluate(baseline,budget,'baseline_'+str(budget),budget==512)
 b=evaluate(prototype,budget,'prototype_'+str(budget))
 assert a==b,(budget,a,b)
full=evaluate(prototype,c['maximum_spatial_cells'],'prototype_full')
print(json.dumps({k:dict(elapsed_s=v['elapsed_s'],status=v['result']['status'],cells=v['result']['visited_spatial_cells']) for k,v in records.items()}))
