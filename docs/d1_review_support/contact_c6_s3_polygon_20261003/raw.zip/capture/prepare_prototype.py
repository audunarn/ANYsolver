from pathlib import Path
folder=Path(__file__).parent
source=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001/src/anysolver/general_contact/s3_pressure_hermite_bounds.py').read_text()
addition='''class _SpatialPartition:
    """Exact incremental bounds; heap preserves largest-area/stable-order choice."""
    def __init__(self,cells,count,maximum_depth):
        self.totals=_aggregate(cells,count)
        self.maximum_depth=maximum_depth
        self.heap=[];self.serial=0
        for cell in cells:self._offer(cell)

    def _offer(self,cell):
        import heapq
        if cell[3][3] and cell[2]<self.maximum_depth:
            heapq.heappush(self.heap,(-_fraction(cell[1]),self.serial,cell))
        self.serial+=1

    def _change(self,cell,sign):
        for local,index in enumerate(cell[0].ids):
            for total,part in zip(self.totals,cell[3][:3]):
                total[index][0]+=sign*part[local][0]
                total[index][1]+=sign*part[local][1]

    def pop(self):
        import heapq
        if not self.heap:return None
        cell=heapq.heappop(self.heap)[2];self._change(cell,-1)
        return cell

    def add(self,cell):
        self._change(cell,1);self._offer(cell)


'''
source=source.replace('def _prepare_overlap(',addition+'def _prepare_overlap(',1)
source=source.replace('            while True:\n                supports,opens,closed=_aggregate(cells,count)',
'''            partition=_SpatialPartition(cells,count,maximum_depth)
            while True:
                supports,opens,closed=partition.totals''',1)
old='''                candidates=[i for i,cell in enumerate(cells) if cell[3][3] and cell[2]<maximum_depth]
                if not candidates:break
                # Largest unresolved reference cell first, stable index tie-break.
                chosen=max(candidates,key=lambda i:_fraction(cells[i][1]))
                face,vertices,spatial_depth,_=cells.pop(chosen)'''
new='''                chosen=partition.pop()
                if chosen is None:break
                face,vertices,spatial_depth,_=chosen'''
assert old in source;source=source.replace(old,new,1)
old='cells.append((face,child,spatial_depth+1,_cell(face,child,tolerance,factor)));visited_space+=1'
new='partition.add((face,child,spatial_depth+1,_cell(face,child,tolerance,factor)));visited_space+=1'
assert old in source;source=source.replace(old,new,1)
(folder/'pressure_prototype.py').write_text(source)
print('Prepared external exact-aggregation prototype; production source unchanged.')
