import json,time
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar
folder=Path(__file__).parent;x=dict(np.load(folder/'first_hidden.npz'));controls=json.loads((folder/'first_hidden.json').read_text())
dt=controls['dt'];tau=controls['approach_tolerance_m']
def hermite(a,b,v,w,t):return (2*t**3-3*t*t+1)*a+(-2*t**3+3*t*t)*b+(t**3-2*t*t+t)*dt*v+(t**3-t*t)*dt*w
def clip(poly,values):
 if not poly:return []
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  fa,fb=a@values,b@values
  if fa>=0:out.append(a)
  if (fa<0 and fb>0) or (fa>0 and fb<0):out.append(a+(b-a)*fa/(fa-fb))
 return out
def face_data(ids,t):
 a=hermite(x['a0'][ids],x['a1'][ids],x['av0'][ids],x['av1'][ids],t)
 b=hermite(x['b0'],x['b1'],x['bv0'],x['bv1'],t)
 normal=np.cross(a[1]-a[0],a[2]-a[0]);normal=normal/np.linalg.norm(normal)
 # Independent linear intersection x_source + g*n = target(u,v).
 matrix=np.column_stack((b[1]-b[0],b[2]-b[0],-normal))
 solved=np.linalg.solve(matrix,(a-b[0]).T).T
 uv=solved[:,:2];gap=-solved[:,2]
 return np.column_stack((1-uv.sum(axis=1),uv)),gap
assert abs(face_data(x['source_faces'][0],0)[1][0]-float((x['a0'][x['source_faces'][0][0]]-x['b0'][0])@ (np.cross(x['b0'][1]-x['b0'][0],x['b0'][2]-x['b0'][0])/np.linalg.norm(np.cross(x['b0'][1]-x['b0'][0],x['b0'][2]-x['b0'][0])))))<1.e-9
endpoints=[]
for ids in x['source_faces']:endpoints.append((ids,face_data(ids,0)[1]-tau,face_data(ids,1)[1]-tau))
def minimum(t,details=False):
 best=float('inf');record=None
 for ids,open0,open1 in endpoints:
  uv,g=face_data(ids,t);poly=[v for v in np.eye(3)]
  for values in [*uv.T,open0,open1]:poly=clip(poly,values)
  for bary in poly:
   value=float(bary@g)
   if value<best:
    best=value;record=dict(time_fraction=float(t),ids=ids.tolist(),barycentric=bary.tolist(),gap_m=value,
        start_gap_m=float(bary@(open0+tau)),end_gap_m=float(bary@(open1+tau)),target_barycentric=(bary@uv).tolist())
 return (best,record) if details else best
started=time.monotonic();times=np.linspace(0,1,401);values=np.array([minimum(t) for t in times]);index=int(np.argmin(values))
lo=times[max(0,index-1)];hi=times[min(len(times)-1,index+1)]
opt=minimize_scalar(minimum,bounds=(lo,hi),method='bounded',options={'xatol':1.e-12})
value,witness=minimum(opt.x,True)
record=dict(controls=controls,sampled_minimum_m=float(values[index]),refined_witness=witness,
    elapsed_s=time.monotonic()-started,note='Independent numerical witness only; no conservative path certificate or full trajectory claim. Boundary openness is closed tau; finite numerical error remains.')
(folder/'hidden_witness.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))

