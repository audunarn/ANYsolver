import inspect,json,os,runpy,sys,hashlib
from pathlib import Path
import numpy as np
root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root))
repo=root.parent;folder=Path(__file__).parent
from anysolver.general_contact import normal_s3_skin_path as module
from threadpoolctl import threadpool_info
import numba
assert numba.config.DISABLE_JIT==1 and numba.get_num_threads()==1
assert all(p['num_threads']==1 for p in threadpool_info())
def identity():
 imports={}
 for name,item in tuple(sys.modules.items()):
  path=getattr(item,'__file__',None)
  if path and (name=='anysolver' or name.startswith('anysolver.')):
   path=Path(path).resolve();assert path.is_relative_to(root)
   imports[path.relative_to(root).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
 return dict(imports=imports,root=str(root),jit_disabled=1,numba_threads=1,pools=threadpool_info())
(folder/'effective_start.json').write_text(json.dumps(identity(),indent=2))
class Captured(Exception):pass
def save(name,self,args,kwargs,at):
 manager,start,end,v0,v1,dt=args
 skins=self.skins(manager,start,end,v0,v1);ids=manager.law.target_face_indices[0]
 values=[manager.reference[0],manager.reference[1][ids],manager.law.source_face_indices,
         *[skin if i in (0,1,4,5) else skin[ids] for i,skin in enumerate(skins)]]
 keys=['reference_source','reference_target','source_faces','a0','a1','b0','b1','av0','av1','bv0','bv1']
 fields=dict(zip(keys,values))
 if 'active' in kwargs:fields['active']=kwargs['active']
 np.savez(folder/(name+'.npz'),**fields)
 controls=dict(dt=float(dt),time_s=at,maximum_time_panels=manager.settings.maximum_gap_triangles,
    maximum_spatial_cells=manager.settings.maximum_gap_triangles,maximum_depth=manager.settings.maximum_swept_subdivisions,
    gap_tolerance_m=float(kwargs.get('gap_tolerance_m',manager.gap_tolerance)),
    approach_tolerance_m=kwargs.get('event_gap_tolerance_m'))
 (folder/(name+'.json')).write_text(json.dumps(controls,indent=2))
original=module.NormalS3SkinPath.pressure_sweep
first_hidden=False
strong=module.NormalS3SkinPath.overlap_sweep
def watch_strong(self,*args,**kwargs):
 global first_hidden
 at=inspect.currentframe().f_back.f_locals.get('current_time')
 result=strong(self,*args,**kwargs)
 if not first_hidden and result[1] and 'hidden_approach_unresolved' in result[1]:
  save('first_hidden',self,args,kwargs,at);first_hidden=True
 return result
def watch_weak(self,*args,**kwargs):
 at=inspect.currentframe().f_back.f_locals.get('current_time')
 if at is not None and at>=.0015968323:
  save('stalled_weak',self,args,kwargs,at);raise Captured()
 return original(self,*args,**kwargs)
module.NormalS3SkinPath.overlap_sweep=watch_strong
module.NormalS3SkinPath.pressure_sweep=watch_weak
try:
 case=runpy.run_path(str(repo/'tests/test_general_contact_transient_clipped_s3.py'))
 case['test_moving_clipped_overlap_with_explicit_enforcement_matches_coupled_reference']()
 raise AssertionError('named proof was not reached')
except Captured:
 (folder/'effective_final.json').write_text(json.dumps(identity(),indent=2))
 (folder/'outcome.json').write_text(json.dumps(dict(status='captured',scope='diagnostic prefix; full test not assessed',first_hidden=first_hidden)))
 print('Captured named weak path and first hidden-approach failure; full case not assessed.')
