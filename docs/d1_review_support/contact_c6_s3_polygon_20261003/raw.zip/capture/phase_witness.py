import json,runpy,sys,time
from pathlib import Path
import numpy as np
folder=Path(__file__).parent;repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001');sys.path.insert(0,str(repo/'src'))
case=runpy.run_path(str(repo/'tests/test_general_contact_transient_clipped_s3.py'));moments=case['moments']
x=dict(np.load(folder/'stalled_weak.npz'));c=json.loads((folder/'stalled_weak.json').read_text())
count=len(x['a0']);assert count==18
assert np.array_equal(x['a0'][:,:2],case['layout'](8)[0])
assert np.array_equal(x['b0'][:,:2],case['TARGET_XY'])
for key in ('av0','av1','bv0','bv1'):assert np.count_nonzero(x[key][:,:2])==0
for key in ('a1','b1'):assert np.array_equal(x[key][:,:2],x['a0' if key=='a1' else 'b0'][:,:2])
def hermite(a,b,v,w,t):return (2*t**3-3*t*t+1)*a+(-2*t**3+3*t*t)*b+(t**3-2*t*t+t)*c['dt']*v+(t**3-t*t)*c['dt']*w
rows=[];times=np.linspace(0,1,201);started=time.monotonic()
for t in times:
 a=hermite(x['a0'],x['a1'],x['av0'],x['av1'],t)
 b=hermite(x['b0'],x['b1'],x['bv0'],x['bv1'],t)
 q=np.r_[a[:,2]-.0102,b[:,2]-.01]
 g,s,min_gap=moments(q,8)
 rows.append((g,s,min_gap))
gaps=np.array([v[0] for v in rows]);supports=np.array([v[1] for v in rows]);phase=x['active'];tau=c['gap_tolerance_m']
violations=np.where(phase,gaps-tau,-gaps-tau)
index=np.unravel_index(np.argmax(violations),violations.shape)
record=dict(active=phase.tolist(),gap_start_m=gaps[0].tolist(),gap_end_m=gaps[-1].tolist(),
    minimum_gap_m=float(min(v[2] for v in rows)),maximum_sampled_phase_violation_m=float(violations[index]),
    worst_time_fraction=float(times[index[0]]),worst_node=int(index[1]),minimum_support_m2=float(np.min(supports)),
    elapsed_s=time.monotonic()-started,scope='Independent direct P1 polygon moments on201sampled physical Hermite poses; not a conservative path certificate.')
(folder/'phase_witness.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
