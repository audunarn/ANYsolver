import json,runpy,subprocess,sys,time
from pathlib import Path
import psutil
folder=Path(__file__).parent
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
tooling=runpy.run_path(str(repo/'scripts/run_portable_ci.py'))
env=tooling['_worker_environment'](folder/'runtime');env['NUMBA_DISABLE_JIT']='1'
command=[sys.executable,'-I',str(folder/'capture_case.py'),str(repo/'src')]
started=time.monotonic();peak=0;status='terminal'
with (folder/'capture.log').open('w') as log:
 child=subprocess.Popen(command,cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:
  while child.poll() is None:
   try:
    proc=psutil.Process(child.pid)
    peak=max(peak,sum(p.memory_info().rss for p in [proc,*proc.children(recursive=True)] if p.is_running()))
   except psutil.NoSuchProcess:pass
   if time.monotonic()-started>900 or peak>3814*1024**2:
    status='timeout' if time.monotonic()-started>900 else 'memory_limit';break
   time.sleep(.1)
 finally:tooling['_terminate_tree'](child)
record=dict(command=command,elapsed_s=time.monotonic()-started,peak_sampled_bytes=peak,exit=child.returncode,status=status,limit_s=900,limit_mib=3814)
(folder/'resource.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
if child.returncode:sys.exit(1)
