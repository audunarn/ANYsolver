"""External development timing; mathematics, proof gates and states unchanged."""
import hashlib,inspect,json,runpy,sys,time
from pathlib import Path
root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root))
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
mode,label=sys.argv[2:4];folder=Path(__file__).parent
from anysolver.general_contact import normal_s3_skin_path as module
from threadpoolctl import threadpool_info
import numba

def identities():
 assert numba.config.DISABLE_JIT==1 and numba.get_num_threads()==1
 pools=threadpool_info();assert all(pool['num_threads']==1 for pool in pools)
 imports={}
 for name,value in tuple(sys.modules.items()):
  if name=='anysolver' or name.startswith('anysolver.'):
   path=getattr(value,'__file__',None)
   if path:
    path=Path(path).resolve();assert path.is_relative_to(root),(name,str(path))
    imports[path.relative_to(root).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
 return dict(imports=imports,jit_disabled=1,numba_threads=1,pools=pools,root=str(root))

state=dict(mode=mode,components={},current=None,preparations=0,hits=0)
def publish():
 (folder/(label+'-progress.json')).write_text(json.dumps(state,indent=2)+'\n')
original_factory=module.prepare_normal_s3_skin_path
def factory(*args,**kwargs):
 owner=original_factory(*args,**kwargs)
 if mode=='baseline':object.__setattr__(owner,'_preparation',None)
 (folder/(label+'-effective.json')).write_text(json.dumps(identities(),indent=2)+'\n')
 return owner
module.prepare_normal_s3_skin_path=factory

for name in ('overlap_endpoint','overlap_sweep','pressure_sweep'):
 original=getattr(module.NormalS3SkinPath,name)
 def make_wrapper(name,original):
  def wrapped(self,*args,**kwargs):
   caller=inspect.currentframe().f_back.f_locals
   state['current']=dict(component=name,solver_time_s=caller.get('current_time'),
      dt_s=float(args[5]) if name!='overlap_endpoint' else None)
   publish();started=time.monotonic()
   try:
    result=original(self,*args,**kwargs)
    record=state['components'].setdefault(name,dict(calls=0,elapsed_s=0.,failures=0,
        maximum_spatial_cells=0,maximum_time_panels=0))
    record['calls']+=1;record['elapsed_s']+=time.monotonic()-started
    if hasattr(result,'success'):
     record['failures']+=not result.success
     record['maximum_spatial_cells']=max(record['maximum_spatial_cells'],result.visited_spatial_cells)
     record['maximum_time_panels']=max(record['maximum_time_panels'],result.visited_time_panels)
     record['latest_status']=result.status
    else:
     record['failures']+=result[1] is not None;record['latest_failure']=result[1]
    if self._preparation is not None:
     state['preparations']=self._preparation.preparations;state['hits']=self._preparation.hits
    state['current']=None;publish()
    return result
   except BaseException as exc:
    state['exception']=type(exc).__name__+': '+str(exc);publish();raise
  return wrapped
 setattr(module.NormalS3SkinPath,name,make_wrapper(name,original))

(folder/(label+'-effective.json')).write_text(json.dumps(identities(),indent=2)+'\n')
publish()
if mode=='coupled':
 case=runpy.run_path(str(repo/'tests/test_general_contact_transient_clipped_s3.py'))
 from dataclasses import replace
 case['test_moving_clipped_overlap_with_explicit_enforcement_matches_coupled_reference'](solver_controls=replace(case['demo']['CONTROLS'],normal_s3_polygon_pressure_bounds_dev=True))
 result=json.loads((Path(__import__('os').environ['RUNNER_TEMP'])/'clipped_s3_coupled.json').read_text())
else:
 case=runpy.run_path(str(repo/'examples/general_contact_deforming_s3_impact_dev.py'))
 result=case['run']()
(folder/(label+'.json')).write_text(json.dumps(dict(result=result,effective=identities()),indent=2)+'\n')

