import json,hashlib,re,zipfile
from pathlib import Path
from importlib.metadata import version
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001');folder=Path(__file__).parent
capture=Path('C:/ANYworkspaceWork/contact_s3_proof_capture_20261003')
destination=repo/'docs/d1_review_support/contact_c6_s3_polygon_20261003';destination.mkdir(exist_ok=True)
changes=['src/anysolver/general_contact/s3_pressure_hermite_bounds.py','src/anysolver/general_contact/s3_pressure_polygon_bounds.py','src/anysolver/general_contact/normal_s3_skin_path.py','src/anysolver/general_contact/transient.py','examples/general_contact_deforming_s3_impact_dev.py','tests/test_s3_pressure_partition.py','tests/test_s3_pressure_polygon_bounds.py','tests/test_general_contact_transient_s3_polygon.py','tests/test_general_contact_transient_clipped_s3.py']
labels=['contact_s3_pressure_partition_a_20261003','contact_s3_pressure_partition_b_20261003','contact_s3_pressure_polygon_a_20261003','contact_s3_polygon_profile_a_20261003','contact_s3_polygon_legacy_b_20261003','contact_s3_polygon_legacy_c_20261003']
files=[];runs=[]
for label in labels:
 directory=Path('C:/ANYworkspaceWork')/label;log=directory.with_suffix('.log')
 runtimes=list(directory.rglob('runtime.json'));assert len(runtimes)==1
 runtime=json.loads(runtimes[0].read_text());text=log.read_text(encoding='utf-8')
 for path in runtime['imports'].values():assert Path(path).resolve().is_relative_to(repo/'src')
 assert runtime['jit_disabled'] and runtime['numba_threads']==1 and all(p['num_threads']==1 for p in runtime['effective_pools'])
 runs.append(dict(label=label,runtime=runtime,summary=[line for line in text.splitlines() if re.search(r'passed in|failed.*passed.*in|no tests ran',line)]))
 files.extend((p,'checks/'+label+'/'+p.relative_to(directory).as_posix()) for p in directory.rglob('*') if p.is_file())
 files.append((log,'checks/'+label+'.log'))
for base,kind in ((capture,'capture'),(folder,'route')):
 files.extend((p,kind+'/'+p.name) for p in base.iterdir() if p.is_file())
wheel=next((folder/'dist').glob('*.whl'));files.append((wheel,'route/artifact.whl'))
files.extend((repo/name,'candidate/'+name) for name in changes)
record=dict(parent='d7a257bc',status='implemented/tested/installed development; not independently accepted or released',
 source_sha256={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in changes},numerical_environment={name:version(name) for name in ('numpy','scipy','numba','llvmlite','pytest','psutil')},checks=runs,
 captured_input=dict(resource=json.loads((capture/'resource.json').read_text()),outcome=json.loads((capture/'outcome.json').read_text())),
 saved_phase_comparison=json.loads((capture/'saved_phase.json').read_text()),polygon_saved_phase=json.loads((capture/'polygon_phase.json').read_text()),
 phase_numerical_witness=json.loads((capture/'phase_witness.json').read_text()),hidden_numerical_witness=json.loads((capture/'hidden_witness.json').read_text()),
 hidden_reversed_sign_failure_retained=True,hidden_leaf=json.loads((capture/'hidden_leaf.json').read_text()),
 package=json.loads((folder/'package_summary.json').read_text()),coupled_resource=json.loads((folder/'coupled_p1-resource.json').read_text()),
 coupled_partial=json.loads((folder/'coupled_p1-progress.json').read_text()),coupled_effective=json.loads((folder/'coupled_p1-effective.json').read_text()),
 coupled_complete_result=None,scope='No full coupled trajectory. C4 snapshot matches recorded imported helper hash; final source uses verified exact mass batching. Saved-phase timings include distinct instrumentation, not a whole-route speed claim.')
review=destination/'supporting_review.md';review.write_text('''# Supporting source reviews\n\nSame-family OpenAI Read-only scrutiny found no concrete defect in incremental\nFraction totals, heap tie ordering or control-call order. Signed inner/outer\npolygon proof was reviewed, then the sharpened inner Bernstein integration and\nV4/V16 wiring were reviewed; no concrete enclosure/wiring defect was found.\nOriginal hidden-approach tolerance remains supplied to the complete-path guard.\nThe omitted-guard proposal would change that safeguard and is not adopted.\nWorkers ran no additional checks; these are not independent engineering acceptance.\n''')
files.append((review,'review/supporting_review.md'));files.append((repo/'docs/d1_review_support/S3_PRESSURE_PATH_BOUND_DESIGN_20261003.md','design.md'))
with zipfile.ZipFile(destination/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for p,name in files:archive.write(p,name)
record['raw_records']=len(files)
(destination/'source.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(raw_records=len(files),outcomes={r['label']:r['runtime']['outcomes'] for r in runs},coupled_status=record['coupled_resource']['status'],wheel=record['package']['wheel_sha256'])))
