from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
import numpy,scipy
root=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
out=root/'docs/d1_review_support/contact_c6_multiple_shell_planes_20261003'
out.mkdir(exist_ok=True)
sources=['src/anysolver/general_contact/core.py','src/anysolver/general_contact/transient.py',
 'src/anysolver/general_contact/multiple_shell_planes.py',
 'examples/general_contact_multiple_q4_planes_dev.py',
 'tests/test_general_contact_multiple_shell_planes.py',
 'tests/test_general_contact_transient_multiple_shell_planes.py']
files={'source/'+n:root/n for n in sources}
runs={}
names=['multiple-shell-planes-dev-20261003-a','multiple-shell-planes-dev-20261003-b',
 'contact_multiple_shell_impact_a_20261003','contact_multiple_shell_impact_b_20261003',
 'contact_multiple_shell_impact_c_20261003','contact_multiple_shell_history_d_20261003',
 'contact_multiple_shell_compat_e_20261003']
for name in names:
 folder=Path('C:/ANYworkspaceWork')/name
 packet=next(folder.glob('anysolver-portable-ci-*/P01'))
 for n in ['selection.json','runtime.json','resource.json']:
  files[name+'/'+n]=packet/n
 log=folder/'runner.log' if name.startswith('multiple-') else folder.with_suffix('.log')
 files[name+'/runner.log']=log
 for p in folder.glob('*.py'):files[name+'/'+p.name]=p
 for p in folder.glob('*.json'):files[name+'/'+p.name]=p
 runs[name]={n:json.loads((packet/(n+'.json')).read_text()) for n in ['selection','runtime','resource']}
pkg=Path('C:/ANYworkspaceWork/contact_multiple_shell_package_20261003')
for p in pkg.iterdir():
 if p.is_file() and p.suffix in {'.json','.log','.py'}:files['package/'+p.name]=p
files['capture.py']=Path(__file__)
manifest={n:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for n,p in files.items()}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n,p in files.items():z.write(p,n)
report=dict(scope='development; not engineering acceptance or release',
 parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 source_hashes={n:manifest['source/'+n]['sha256'] for n in sources},
 environment=dict(python=sys.version,numpy=numpy.__version__,scipy=scipy.__version__),
 records=manifest,runs=runs,archive_sha256=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest(),
 package=json.loads((pkg/'comparison.json').read_text()))
(out/'source.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(len(files),'retained records')
for name,r in runs.items():
 resource=r['resource']; runtime=r['runtime']
 print(name,json.dumps(resource),json.dumps(runtime.get('environment',{})))
