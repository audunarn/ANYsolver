import ast,hashlib,itertools,json
from pathlib import Path
import numpy as np
folder=Path(__file__).parent
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
source=json.loads((folder/'source.json').read_text())
installed=json.loads((folder/'installed.json').read_text())
assert source['imports']==installed['imports']
assert source['result']==installed['result']
saved=json.loads(Path('C:/ANYworkspaceWork/contact_multiple_shell_impact_c_20261003/multiple_shell_impact.json').read_text())
D=np.array([[1.,0.],[0.,1.],[.5,.5]]); M=.05*D.T@D
B=np.array([.01,.008,.01]); KN=np.array([1.e5,2.e5,1.e5])
test=repo/'tests/test_general_contact_transient_multiple_shell_planes.py'
function=next(node for node in ast.parse(test.read_text()).body if isinstance(node,ast.FunctionDef) and node.name=='reference')
scope=dict(np=np,itertools=itertools,D=D,M=M,B=B,KN=KN)
exec(compile(ast.Module(body=[function],type_ignores=[]),str(test),'exec'),scope)
expected=scope['reference'](saved['times_s'])
q,v,a=map(np.asarray,(saved['q'],saved['v'],saved['a']))
pressure=KN*np.maximum(-B-q@D.T,0.)
residual=a@M.T-(pressure@D)
contact=np.array([row['penalty_energy'] for row in saved['pairs']])
energy=.5*np.einsum('ij,jk,ik->i',v,M,v)+contact
physical=[]
for i,h in enumerate(np.diff(saved['times_s'])):
 minima=[]
 for column in range(3):
  g0=B[column]+D[column]@q[i]
  velocity0=D[column]@v[i]
  difference=D[column]@(v[i+1]-v[i])
  values=[g0,B[column]+D[column]@q[i+1]]
  if difference != 0.:
   parameter=-velocity0/difference
   if 0.<parameter<1.:values.append(g0+h*(velocity0*parameter+.5*difference*parameter**2))
  minima.append(min(values))
 physical.append({'first':min(minima[0],minima[2]),'second':minima[1]})
bound_error=max(abs(saved['pair_gaps'][i+1][key]-row[key]) for i,row in enumerate(physical) for key in row)
wheel=next((folder/'wheels').glob('*.whl'))
report=dict(scope='development/discrete-grid verification, not engineering acceptance',
 imports_match=True,numerical_fields_match=True,module_count=len(source['imports']),
 wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
 maximum_q_error_m=float(np.max(np.abs(q-expected[:,0]))),
 maximum_velocity_error_m_s=float(np.max(np.abs(v-expected[:,1]))),
 maximum_acceleration_error_m_s2=float(np.max(np.abs(a-expected[:,2]))),
 maximum_modal_force_residual_n=float(np.max(np.abs(residual))),
 maximum_energy_relative_defect=float(np.max(np.abs(energy/energy[0]-1.))),
 independent_physical_path_minimum_m={key:min(row[key] for row in physical) for key in ('first','second')},
 maximum_reported_physical_bound_discrepancy_m=bound_error,
 reference_function_source_sha256=hashlib.sha256(test.read_bytes()).hexdigest(),
 resources={label:json.loads((folder/(label+'-resource.json')).read_text()) for label in ('source','installed')})
(folder/'comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
