import cProfile,json,pstats,runpy,sys,time
from pathlib import Path
import numpy as np
root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root))
folder=Path(__file__).parent
repo=root.parent
from anysolver.general_contact.s3_patch_static import GeneralS3PatchManager
from anysolver.general_contact.normal_s3_skin_path import prepare_normal_s3_skin_path
from threadpoolctl import threadpool_info
import numba
assert numba.config.DISABLE_JIT==1 and numba.get_num_threads()==1
assert all(pool['num_threads']==1 for pool in threadpool_info())
import anysolver
assert Path(anysolver.__file__).resolve().is_relative_to(root)
(folder/'profile-effective.json').write_text(json.dumps(dict(jit_disabled=1,numba_threads=1,
 pools=threadpool_info(),import_root=str(root),profile_input='refined KN1e9 prefix saved coordinates; evaluate declared KN2e10'),indent=2))
demo=runpy.run_path(str(repo/'examples/general_contact_deforming_s3_impact_dev.py'))
saved=json.loads(Path('C:/ANYworkspaceWork/contact_s3_overlap_reference_i_20261003/refined_clipped_gap_discriminator.json').read_text())
model,definition,modes=demo['build_model'](target_xy=[[-2,-2],[.6,-2],[.6,3]],source_columns=8,normal_stiffness=2.e10)
manager=GeneralS3PatchManager(model,definition,demo['_fixture']['SETTINGS'])
owner=prepare_normal_s3_skin_path(model,manager,modes)
full=modes@np.asarray(saved['normal_coordinates_m']);rate=np.zeros_like(full)
records=[]
def measure(name,call):
 records.append(dict(component=name,status='running'))
 (folder/'profile-components.json').write_text(json.dumps(records,indent=2))
 profile=cProfile.Profile();started=time.monotonic()
 value=profile.runcall(call)
 elapsed=time.monotonic()-started
 profile.dump_stats(str(folder/(name+'.prof')))
 with (folder/(name+'-functions.txt')).open('w') as output:
  pstats.Stats(profile,stream=output).strip_dirs().sort_stats('cumulative').print_stats(30)
 records[-1]=dict(component=name,status='completed',elapsed_s=elapsed,
   result_status=getattr(value,'status',None),success=getattr(value,'success',None),
   spatial_cells=getattr(value,'visited_spatial_cells',None),time_panels=getattr(value,'visited_time_panels',None))
 (folder/'profile-components.json').write_text(json.dumps(records,indent=2))
 return value
_,_,result=measure('production_work_tangent',lambda:manager.evaluate(full,tangent=True))
measure('matched_endpoint',lambda:owner.overlap_endpoint(manager,full,result))
measure('matched_path',lambda:owner.overlap_sweep(manager,full,full,rate,rate,2.5e-5,event_gap_tolerance_m=1.e-10))
measure('weak_phase_path',lambda:owner.pressure_sweep(manager,full,full,rate,rate,2.5e-5,
 active=np.asarray(result.normalized_weighted_gap_m)<0.,gap_tolerance_m=1.e-10))
