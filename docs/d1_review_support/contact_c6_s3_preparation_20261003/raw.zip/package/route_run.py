import json,runpy,subprocess,sys,time
from pathlib import Path
import psutil
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
folder=Path(__file__).parent;tooling=runpy.run_path(str(repo/'scripts/run_portable_ci.py'))
mode,label=sys.argv[1:3]
root=sys.argv[3] if len(sys.argv)>3 else str(repo/'src')
cap,memory=(900,3814) if mode=='coupled' else (180,953)
env=tooling['_worker_environment'](folder/label);env['NUMBA_DISABLE_JIT']='1'
command=[sys.executable,'-I',str(folder/'route_case.py'),root,mode,label]
started=time.monotonic();peak=0;status='terminal'
with (folder/(label+'.log')).open('w') as log:
 child=subprocess.Popen(command,cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:
  while child.poll() is None:
   try:
    process=psutil.Process(child.pid)
    peak=max(peak,sum(p.memory_info().rss for p in [process,*process.children(recursive=True)] if p.is_running()))
   except psutil.NoSuchProcess:pass
   if time.monotonic()-started>cap or peak>memory*1024**2:
    status='timeout' if time.monotonic()-started>cap else 'memory_limit';break
   time.sleep(.1)
 finally:tooling['_terminate_tree'](child)
record=dict(command=command,elapsed_s=time.monotonic()-started,peak_sampled_bytes=peak,
 exit=child.returncode,status=status,limit_s=cap,limit_mib=memory)
(folder/(label+'-resource.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
if child.returncode:sys.exit(1)
