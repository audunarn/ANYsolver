import json,statistics
from pathlib import Path
folder=Path(__file__).parent
labels=('covered_b1','covered_o1','covered_o2','covered_b2')
cases={name:json.loads((folder/(name+'.json')).read_text()) for name in labels}
resources={name:json.loads((folder/(name+'-resource.json')).read_text()) for name in labels}
for name in labels:
 assert resources[name]['exit']==0 and resources[name]['status']=='terminal'
 assert resources[name]['elapsed_s']<180 and resources[name]['peak_sampled_bytes']<953*1024**2
 assert cases[name]['result']==cases[labels[0]]['result']
 assert cases[name]['effective']['imports']==cases[labels[0]]['effective']['imports']
historical=json.loads(Path('C:/ANYworkspaceWork/contact_s3_overlap_package_20261003/source.json').read_text())
assert cases[labels[0]]['result']==historical['result']
summary={}
for name,selected in (('baseline',('covered_b1','covered_b2')),('optimized',('covered_o1','covered_o2'))):
 elapsed=[resources[label]['elapsed_s'] for label in selected]
 summary[name]=dict(elapsed_s=elapsed,median_s=statistics.median(elapsed),spread_s=[min(elapsed),max(elapsed)],
  peak_sampled_bytes=[resources[label]['peak_sampled_bytes'] for label in selected])
summary['observed_elapsed_reduction_fraction']=1-summary['optimized']['median_s']/summary['baseline']['median_s']
summary['all_fields_and_imports_match']=True
summary['historical_v3_fields_match']=True
summary['scope']='Instrumented covered default route, ABBA two runs each; not refined-route/acceptance/general speed claim'
(folder/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
