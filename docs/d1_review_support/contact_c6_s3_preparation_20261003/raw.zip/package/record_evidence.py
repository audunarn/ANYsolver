import json,hashlib,zipfile,re,sys
from pathlib import Path
from importlib.metadata import version
folder=Path(__file__).parent;repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
source=json.loads((folder/'covered_o2.json').read_text());installed=json.loads((folder/'installed_check.json').read_text())
assert source['result']==installed['result']
assert source['effective']['imports']==installed['imports']
assert installed['effective']['jit_disabled']==1 and installed['effective']['numba_threads']==1
assert all(p['num_threads']==1 for p in installed['effective']['threadpools'])
wheel=next((folder/'dist').glob('*.whl'))
changes=['src/anysolver/general_contact/normal_s3_skin_path.py','src/anysolver/general_contact/s3_overlap_hermite_gap.py','src/anysolver/general_contact/s3_pressure_hermite_bounds.py','tests/test_s3_prepared_overlap.py']
runs={}
for key,label in [('a','contact_s3_prepare_cache_a_20261003'),('b','contact_s3_prepare_validation_b_20261003'),('c','contact_s3_prepare_state_c_20261003')]:
 directory=Path('C:/ANYworkspaceWork')/label;log=directory.with_suffix('.log')
 runtimes=list(directory.rglob('runtime.json'));assert len(runtimes)==1
 data=json.loads(runtimes[0].read_text());lines=log.read_text(encoding='utf-8').splitlines()
 summary=[line for line in lines if re.search(r'\bpassed in\b',line)];assert summary and '[portable-ci] P01 exit=0' in lines
 # Keep complete effective settings in raw; no claim from command alone.
 for path in data['imports'].values():assert Path(path).resolve().is_relative_to(repo/'src')
 runs[key]=dict(summary=summary[-1],runtime=data)
destination=repo/'docs/d1_review_support/contact_c6_s3_preparation_20261003';destination.mkdir(exist_ok=True)
record=dict(parent='5867bea56cfd53ca321abee698cfe3da474a28a4',status='implemented/tested/installed development; not independent engineering acceptance',
 source_sha256={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in changes},numerical_environment={name:version(name) for name in ('numpy','scipy','numba','llvmlite','pytest','psutil')},
 focused=runs,comparison=json.loads((folder/'comparison.json').read_text()),profile=json.loads((folder/'profile-components.json').read_text()),
 refined_resource=json.loads((folder/'coupled_c1-resource.json').read_text()),refined_partial=json.loads((folder/'coupled_c1-progress.json').read_text()),
 refined_effective=json.loads((folder/'coupled_c1-effective.json').read_text()),
 package=dict(wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),imported_hashes=len(installed['imports']),all_fields_and_imports_match=True,resource=json.loads((folder/'installed_check-resource.json').read_text())))
files=[]
for key,label in [('a','contact_s3_prepare_cache_a_20261003'),('b','contact_s3_prepare_validation_b_20261003'),('c','contact_s3_prepare_state_c_20261003')]:
 directory=Path('C:/ANYworkspaceWork')/label
 files.extend((p,'runs/'+key+'/'+p.relative_to(directory).as_posix()) for p in directory.rglob('*') if p.is_file())
 files.append((directory.with_suffix('.log'),'runs/'+key+'.log'))
for p in folder.iterdir():
 if p.is_file():files.append((p,'package/'+p.name))
files.append((wheel,'package/artifact.whl'))
files.extend((repo/name,'candidate/'+name) for name in changes)
review=destination/'supporting_review.md'
review.write_text('''# Supporting source scrutiny\n\nRead-only same-family OpenAI review of the disposable preparation delta found a\nmixed-boolean list validation mismatch: NumPy promotion could hit a cached float\npayload before the original parser rejected the input. The lead added original\nscalar validation before snapshot matching. B5 covers populated/empty cache\nrejection for reference and velocity lists plus failed preparation retention.\nNo other concrete stale-payload/control reuse defect was reported. This is\nsupporting source review, not independent engineering acceptance.\n''')
files.append((review,'review/supporting_review.md'))
with zipfile.ZipFile(destination/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for p,name in files:archive.write(p,name)
record['raw_records']=len(files)
(destination/'source.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(outcomes={k:v['summary'] for k,v in runs.items()},raw_records=len(files),wheel_sha256=record['package']['wheel_sha256'],imported_hashes=record['package']['imported_hashes'],refined_status=record['refined_resource']['status'])))
