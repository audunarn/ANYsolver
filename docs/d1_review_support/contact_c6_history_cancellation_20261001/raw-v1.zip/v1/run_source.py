from pathlib import Path
import hashlib, json, sys
import numba, pytest, threadpoolctl

root = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
out = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
files = [*root.joinpath('src/anysolver').rglob('*.py'),
         root/'tests/test_general_contact_transient_plane.py',
         root/'tests/test_general_contact_transient_s3_history.py']
before = {p.relative_to(root).as_posix(): sha(p) for p in files}
assert numba.config.DISABLE_JIT and numba.get_num_threads() == 1
assert all(p['num_threads'] == 1 for p in threadpoolctl.threadpool_info())
(out/'source-identity.json').write_text(json.dumps({
    'files': before, 'python': sys.version, 'threads': threadpoolctl.threadpool_info(),
    'jit_disabled': True, 'scope': 'development source checks only',
}, indent=2))
code = pytest.main(['-q', '-c', str(root/'pyproject.toml'),
    '--basetemp='+str(out/'states'), '--junitxml='+str(out/'inventory.xml'),
    str(root/'tests/test_general_contact_transient_s3_history.py'),
    str(root/'tests/test_general_contact_transient_plane.py')+'::test_q4_nodal_load_history_rejects_invalid_or_unsupported_input',
    str(root/'tests/test_general_contact_transient_plane.py')+'::test_q4_ramped_nodal_load_during_contact_matches_forced_oscillator',
    str(root/'tests/test_general_contact_transient_plane.py')+'::test_transient_development_load_admission_is_nodal_and_mass_consistent',
    str(root/'tests/test_general_contact_transient_plane.py')+'::test_s3_descriptor_constant_load_free_motion_impact_and_restart',
    str(root/'tests/test_general_contact_transient_plane.py')+'::test_s3_descriptor_nonuniform_load_initial_dae_acceleration',
])
imports = {n: str(Path(m.__file__).resolve()) for n, m in sys.modules.copy().items()
           if n.split('.')[0] == 'anysolver' and getattr(m, '__file__', None)}
assert imports and all(Path(p).is_relative_to(root/'src') for p in imports.values())
assert before == {p.relative_to(root).as_posix(): sha(p) for p in files}
assert all(p['num_threads'] == 1 for p in threadpoolctl.threadpool_info())
(out/'imports.json').write_text(json.dumps(imports, indent=2))
sys.exit(code)
