from pathlib import Path
import json, os, subprocess, sys, time
import psutil

out = Path(__file__).resolve().parent
env = os.environ.copy()
env.update(PYTHONPATH='C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001/src',
           PYTHONNOUSERSITE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', NUMBA_DISABLE_JIT='1',
           OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', OMP_NUM_THREADS='1', NUMBA_NUM_THREADS='1')
start = time.monotonic(); peak = 0; failure = None
with (out/'run.log').open('w', encoding='utf-8') as log:
    process = subprocess.Popen([sys.executable, '-X', 'utf8', str(out/'run_source.py')],
                               cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT)
    parent = psutil.Process(process.pid)
    while process.poll() is None:
        try:
            tree = [parent]+parent.children(recursive=True)
            peak = max(peak, sum(p.memory_info().rss for p in tree if p.is_running()))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            tree = []
        if time.monotonic()-start > 180 or peak > 1_000_000_000:
            failure = 'resource limit exceeded'
            for p in reversed(tree):
                try: p.kill()
                except psutil.NoSuchProcess: pass
            break
        time.sleep(.5)
    code = process.wait()
record = dict(exit_code=code, status=failure or ('passed' if code == 0 else 'failed'),
              elapsed_seconds=time.monotonic()-start, peak_process_tree_rss_bytes=peak,
              timeout_seconds=180, memory_limit_bytes=1_000_000_000)
(out/'execution.json').write_text(json.dumps(record, indent=2))
print(json.dumps(record))
print('\n'.join((out/'run.log').read_text(encoding='utf-8').splitlines()[-24:]))
sys.exit(124 if failure else code)
