from pathlib import Path
import ast, runpy, sys

def test_installed_s3_ramp_example(monkeypatch, capsys):
    path = Path(__file__).resolve().parent.parent/'scripts/general_contact_s3_plane_impact.py'
    monkeypatch.setattr(sys, 'argv', [str(path),'--ramp-downward-load-n','0.0002'])
    runpy.run_path(str(path),run_name='__main__')
    result = ast.literal_eval(capsys.readouterr().out.strip())
    assert result['profile'] == 'PLANAR_S3_V2D_FIXED_PLANE_NEWMARK_DESCRIPTOR_HISTORY_DEV_V1'
    assert result['accepted_steps'] == 60 and result['cutbacks'] == 0
    assert result['minimum_swept_gap_m'] >= -.001
    assert result['maximum_residual_n'] <= 1e-7
    assert result['external_nodal_work_j'] > 0
    print(result)
