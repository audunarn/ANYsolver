from pathlib import Path
import hashlib, json, shutil, subprocess, sys

out = Path(__file__).resolve().parent
source = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
shutil.copy2(source/'tests/test_general_contact_transient_s3_history.py',
             out/'fixtures/test_general_contact_transient_s3_history.py')
(out/'build.log').rename(out/'build-v1-cache-denial.log')
with (out/'build.log').open('w') as log:
    subprocess.run([sys.executable,'-m','pip','wheel','--no-cache-dir','--no-index',
                    '--no-deps','--no-build-isolation',str(out/'build-input'),
                    '-w',str(out/'wheels')], stdout=log,stderr=log,check=True)
    wheel, = (out/'wheels').glob('*.whl')
    subprocess.run([sys.executable,'-m','pip','install','--no-cache-dir','--no-index',
                    '--no-deps','--target',str(out/'site'),str(wheel)],
                    stdout=log,stderr=log,check=True)
(out/'pytest.ini').write_text('[pytest]\naddopts = -p no:cacheprovider\n')
for name in ('run_installed.py','run_bounded.py'):
    shutil.copy2(Path('C:/ANYworkspaceWork/contact-main-reconciliation-20261001')/name,out/name)
print(json.dumps(dict(wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest())))
