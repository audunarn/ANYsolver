from pathlib import Path
import hashlib, json, shutil, subprocess, sys

out = Path(__file__).resolve().parent
source = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
build = out/'build-input'
build.mkdir()
for name in ('pyproject.toml','README.md','LICENSE','COPYRIGHT','THIRD_PARTY_NOTICES.md'):
    shutil.copy2(source/name, build/name)
shutil.copytree(source/'src/anysolver', build/'src/anysolver',
                ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copytree(source/'tests', out/'fixtures',
                ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = {p.relative_to(source).as_posix(): sha(p)
            for p in source.joinpath('src/anysolver').rglob('*.py')}
(out/'source-manifest.json').write_text(json.dumps(manifest, indent=2))
(out/'source-identity.json').write_text(json.dumps(dict(
    parent='978a3c9706864bf0698becfe496df07300564094',
    scope='guided single-S3 history and exact-token cancellation development',
    module_count=len(manifest)), indent=2))
with (out/'build.log').open('w') as log:
    subprocess.run([sys.executable,'-m','pip','wheel','--no-deps','--no-build-isolation',
                    str(build),'-w',str(out/'wheels')], stdout=log,stderr=log,check=True)
    wheel, = (out/'wheels').glob('*.whl')
    subprocess.run([sys.executable,'-m','pip','install','--no-deps','--target',str(out/'site'),
                    str(wheel)], stdout=log,stderr=log,check=True)
(out/'pytest.ini').write_text('[pytest]\naddopts = -p no:cacheprovider\n')
for name in ('run_installed.py','run_bounded.py'):
    shutil.copy2(Path('C:/ANYworkspaceWork/contact-main-reconciliation-20261001')/name,out/name)
print(json.dumps(dict(wheel_sha256=sha(wheel), modules=len(manifest))))
