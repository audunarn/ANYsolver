from pathlib import Path
import hashlib,json,platform,sys,zipfile
from importlib.metadata import version
root=Path('C:/ANYworkspaceWork/contact_multiple_hemisphere_analytic_20261004')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_multiple_hemisphere_analytic_20261004';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=[];runs={}
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists():continue
    runtime=json.loads((folder/'runtime.json').read_text(encoding='utf-8')) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':json.loads((folder/'resource.json').read_text(encoding='utf-8')),'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,folder.name+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final'
imports=json.loads((final/'imports.json').read_text(encoding='utf-8'))
runtime=json.loads((final/'runtime.json').read_text(encoding='utf-8'))
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed/anysolver')
    assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
p=dest/'installed_parity.json';p.write_text(json.dumps({'loaded':loaded,'package':package},indent=2),encoding='utf-8');raw.append((p,p.name))
for name in ('composition_review.md','design.md'):
    p=dest/name;p.write_bytes((root/name).read_bytes());raw.append((p,name))
source=('src/anysolver/general_contact/multiple_beam_rigid.py','tests/test_general_contact_multiple_hemisphere_analytic.py','examples/general_contact_multiple_hemisphere_analytic.py','tests/test_general_contact_hemisphere_sphere.py','tests/test_general_contact_multiple_hemisphere_planes.py')
raw.extend((root/p,p) for p in ('run.py','collect.py'))
raw.extend((repo/p,'candidate/'+p) for p in source)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
summary={'scope':'D3 explicit multiple fixed planes/spheres with actual-tangent B2/B3 hemisphere support; development/code verification only',
'source_parent':'f42f3d56d270b7d2328a9637456b38be62890529','source_files':{p:sha(repo/p) for p in source},
'wheels':{str(p.relative_to(root)):sha(p) for p in (root/'dist').glob('*.whl')},'runs':runs,
'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],'effective_pools':runtime['effective_pools'],
'independent_bars':{name:json.loads((final/(name+'.json')).read_text(encoding='utf-8')) for name in ('bar_mixed','bar_spheres')},
'directional_tangent_target':1e-5,'bar_response_target':1e-6,'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
'environment':{'python':sys.version,'platform':platform.platform(),'versions':{name:version(name) for name in ('numpy','scipy','numba','ANYmaterial','ANYgeometry')}},
'review_disposition':'supporting same-family source review found no production defect; disjoint-beam junction-coverage mismatch corrected by a real endpoint/material-midnode junction and direct end-identity assertions. Focused source and final installed checks pass. Not independent engineering acceptance.',
'preserved_failures':['all predecessor numerical nonpasses, consumed authorities and frozen acceptance boundaries unchanged'],
'unchanged':['old all-plane support profile and restart revision','legacy owned-point profiles, kernels and settings defaults','single-pair mechanics, quadrature, conservative path bounds and regularity','historical sphere APIs and no-contact path','physical commit and material histories','ANYfem source and normal application admission false','scientific tolerances and resource restrictions'],
'limits':['explicit classical scalar-elastic concentric B2/B3 von Karman static force/displacement','fixed planes/spheres only, declared hemisphere caps and distinct endpoint N/m stiffness','same inherited whole-curve/whole-radius path and genuine material-end rules','nonunique parallel rims open only, C1 seams with one-sided Hessians','no cylinder/capped-cylinder support fallback, moving tools, automatic/self-contact, friction/native/dynamics','engineering mesh/enforcement qualification and full C0-C9 completion remain']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({'runs':len(runs),'records':len(raw),'modules':len(loaded),'package_files':len(package),'resource':runs['installed_final']['resource'],'bars':{n:r['relative_error'] for n,r in summary['independent_bars'].items()},'evidence':str(dest)}))
