from pathlib import Path
import json,hashlib,zipfile,platform,sys
from importlib.metadata import version
root=Path('C:/ANYworkspaceWork/contact_deformable_s3_caps_20261004')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_deformable_s3_caps_20261004';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=[];runs={}
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists():continue
    runtime=json.loads((folder/'runtime.json').read_text(encoding='utf-8')) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':json.loads((folder/'resource.json').read_text(encoding='utf-8')),'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,folder.name+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final'
imports=json.loads((final/'imports.json').read_text(encoding='utf-8'))
runtime=json.loads((final/'runtime.json').read_text(encoding='utf-8'))
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed/anysolver')
    assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
p=dest/'installed_parity.json';p.write_text(json.dumps({'loaded':loaded,'package':package},indent=2),encoding='utf-8');raw.append((p,p.name))
for name in ('integration_review.md','design.md'):
    p=dest/name;p.write_bytes((root/name).read_bytes());raw.append((p,name))
source=('src/anysolver/general_contact/beam_hemisphere_s3_support.py','src/anysolver/general_contact/deformable_beam_s3_caps.py','src/anysolver/general_contact/core.py','src/anysolver/nonlinear_static.py','tests/test_general_contact_deformable_beam_s3_caps.py','examples/general_contact_deformable_s3_caps.py')
raw.extend((root/p,p) for p in ('run.py','collect.py','build.log','build02.log','install.log'))
raw.extend((repo/p,'candidate/'+p) for p in source)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
summary={'scope':'D3 opt-in complete actual hemisphere work on a deforming fixed-director S3 physical interior; development/code verification only',
'source_parent':'69097c11e402ee719d69ef0d8be1d0eaba4b03c0','source_files':{p:sha(repo/p) for p in source},
'wheels':{p.name:sha(p) for p in (root/'dist').glob('*.whl')},'runs':runs,
'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],'effective_pools':runtime['effective_pools'],
'coupled_reference':json.loads((final/'actual_result.json').read_text(encoding='utf-8')),
'directional_tangent_target':1e-5,'contact_gradient_comparison_target':1e-6,
'linearized_structural_comparison_target':1e-3,'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
'environment':{'python':sys.version,'platform':platform.platform(),'versions':{name:version(name) for name in ('numpy','scipy','numba','ANYmaterial','ANYgeometry')}},
'review_disposition':'same-family source-only supporting review of lead-owned integration/driver; geometry author did not assess own geometry for independent acceptance. Lead numerically checked all-coordinate scalar work, tangent, wrenches, offset couples, actual coupled response and transactions. No engineering acceptance.',
'preserved_failures':['source01: local work fixture wrongly asserted admission beyond dimensional gap budget; fixture now expects cutback','source02: rejected first displacement trial masked by missing qualified-S3 origin state during final sealing; production recovery at accepted origin retains non-success','source03: unsupported-law exception regex and arbitrary completed fixture incorrectly expected rejection','source05: honest failed checkpoint is correctly noncontinuable; test now preserves existing restriction; invalid settings construction fixture corrected','build01: cache permission denial; no-cache build succeeded','all historical consumed/nonpass evidence unchanged'],
'unchanged':['line/end units and dimensional criteria','uncapped deformable-S3 line kernel/profile','default owned_point arithmetic/settings and old sphere APIs','normal application admission false','frozen authority/resource caps and historical failures','ANYfem source'],
'limits':['one scalar-elastic concentric B2 or straight-reference B3 and one qualified S3 V2D','von Karman structural route, target rotations exactly zero','physical top/bottom offsets and moving skin translations/normal','face-interior radius-covering clearance, not physical rims/corners/multiple faces','full-radius sweep envelope may reject a safe hemisphere path conservatively','genuine material ends, distinct endpoint N/m support spring, no material-surface spin/friction','linearized independent structural comparison is bounded, not full nonlinear engineering qualification','native contact, broader pair/radial transitions, dynamics, mesh/enforcement and full C0-C9 acceptance remain']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({'runs':len(runs),'records':len(raw),'modules':len(loaded),'package_files':len(package),'resource':runs['installed_final']['resource'],'evidence':str(dest)}))
