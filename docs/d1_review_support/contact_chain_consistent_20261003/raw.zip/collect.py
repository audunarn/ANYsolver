from pathlib import Path
import hashlib,json,zipfile

root=Path('C:/ANYworkspaceWork/contact_chain_consistent_20261003')
solver=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
destination=solver/'docs/d1_review_support/contact_chain_consistent_20261003'
destination.mkdir(exist_ok=True)
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
runs={}
raw=[]
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists(): continue
    resource=json.loads((folder/'resource.json').read_text())
    runtime=json.loads((folder/'runtime.json').read_text()) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':resource,'outcomes':runtime.get('outcomes') if runtime else None}
    for name in ('inputs.json','resource.json','runtime.json','run.log','actual_result.json','imports.json'):
        if (folder/name).exists():raw.append(folder/name)
final=root/'installed_final'
imports=json.loads((final/'imports.json').read_text())
runtime=json.loads((final/'runtime.json').read_text())
assert not imports['errors'] and not runtime['errors']
parity=[]
for name,row in imports['modules'].items():
    if not (name=='anysolver' or name.startswith('anysolver.')):continue
    path=Path(row['path']);relative=path.relative_to(root/'installed/anysolver')
    source=solver/'src/anysolver'/relative
    parity.append({'module':name,'relative':relative.as_posix(),'sha256':row['sha256'],'matches_source':source.exists() and sha(source)==row['sha256']})
assert all(row['matches_source'] for row in parity)
package=[]
for path in sorted((root/'installed/anysolver').rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts:continue
    relative=path.relative_to(root/'installed/anysolver');source=solver/'src/anysolver'/relative
    package.append({'relative':relative.as_posix(),'sha256':sha(path),'matches_source':source.exists() and sha(source)==sha(path)})
assert all(row['matches_source'] for row in package)
(destination/'installed_parity.json').write_text(json.dumps({'modules':parity,'package':package},indent=2))
benchmark=json.loads((final/'actual_result.json').read_text())
summary={'scope':'implemented/tested B2-chain consistent tangent development; not engineering acceptance or release',
    'source_parent':'a1fd1c5eeee035c37f44f10fd684dc75bf49a29e',
    'source_files':{p:sha(solver/p) for p in ('src/anysolver/general_contact/core.py','src/anysolver/general_contact/beam_pair.py','src/anysolver/general_contact/beam_chain_pair.py','src/anysolver/general_contact/beam_chain_consistent.py','tests/test_general_contact_beam_chain_consistent.py','examples/general_contact_round_beam_chain_pair.py')},
    'wheels':{p.name:sha(p) for p in (root/'dist').glob('*.whl')},
    'runs':runs,'installed_checks':29,'additional_installed_checks':1,
    'installed_modules_matching':len(parity),'installed_package_files_matching':len(package),
    'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],
    'effective_pools':runtime['effective_pools'],'benchmark':benchmark,
    'resource_limits':{'seconds':180,'memory_mib':953},
    'remaining':['broader geometry/refinement and engineering acceptance','normal application admission','full D3 and C0-C9 completion'],
    'failure_disposition':'All exploratory failures retained. Legacy force-route integration failures remain failures; balanced displacement route is a different case.'}
for name in ('run.py','collect.py','collector_initial_failure.txt'):raw.append(root/name)
raw.append(destination/'review.md')
with zipfile.ZipFile(destination/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in raw:
        relative=path.relative_to(root).as_posix() if path.is_relative_to(root) else 'review.md'
        archive.write(path,relative)
summary['raw_records']=len(raw)
summary['raw_sha256']=sha(destination/'raw.zip')
(destination/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'runs':len(runs),'raw_records':len(raw),'modules':len(parity),'package_files':len(package),
    'median_s':benchmark['median_s'],'speed_ratio':benchmark['speed_ratio'],'wheels':summary['wheels']}))
