from pathlib import Path
import hashlib,json,zipfile

repo = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
workspace = Path('C:/ANYworkspaceWork')
out = repo/'docs/d1_review_support/contact_c6_classical_beam_20261001'
entries = {}
for version in range(1,10):
    root = workspace/f'contact-beam-transient-20261001-v{version}'
    for p in root.rglob('*'):
        if p.is_file():
            entries[f'source-v{version}/{p.relative_to(root).as_posix()}'] = p
    log = workspace/f'contact-beam-transient-20261001-v{version}.log'
    if log.exists():
        entries[f'source-v{version}/runner.log'] = log
for version in (1,2):
    root = workspace/f'beam-temporal-check-20261001-0{version}'
    for p in root.rglob('*'):
        if p.is_file():
            entries[f'geometry-worker-v{version}/{p.relative_to(root).as_posix()}'] = p
entries['review/mistral-read.log'] = workspace/'contact-beam-temporal-review-20261001.log'
for label,name in (('installed-stage1','contact-beam-impact-package-20261001'),
                   ('installed-final','contact-beam-impact-package-20261001-v2')):
    package = workspace/name
    for p in package.iterdir():
        if p.is_file():
            entries[f'{label}/{p.name}'] = p
    for folder in ('fixtures','wheels'):
        for p in (package/folder).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts:
                entries[f'{label}/{p.relative_to(package).as_posix()}'] = p
for name in ('src/anysolver/general_contact/transient.py',
             'src/anysolver/general_contact/beam_temporal_bounds.py',
             'tests/test_general_contact_transient_beam_plane.py',
             'tests/test_general_contact_beam_temporal_bounds.py',
             'examples/general_contact_beam_plane_impact.py',
             'docs/d1_review_support/C6_CLASSICAL_BEAM_NEWMARK_SLICE_20261001.md'):
    entries['candidate/'+name] = repo/name
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = {name:sha(p.read_bytes()) for name,p in sorted(entries.items())}
archive = out/'raw.zip'
assert not archive.exists(), 'Never overwrite retained evidence'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(entries.items()):
        z.writestr(name,p.read_bytes())
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha(z.read(name)) == h for name,h in manifest.items())
receipt = dict(files=len(manifest),archive_bytes=archive.stat().st_size,
               archive_sha256=sha(archive.read_bytes()),readback_matches=True)
(out/'archive-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
