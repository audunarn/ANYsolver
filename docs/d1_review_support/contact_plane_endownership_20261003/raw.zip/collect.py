from pathlib import Path
import json,hashlib,zipfile
root=Path('C:/ANYworkspaceWork/contact_plane_endownership_20261003')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_plane_endownership_20261003'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tags=('ownership_source','corrected_contract_covariance','build','install','build_legacy_arithmetic','install_legacy_arithmetic','installed_final')
raw=[];runs={}
for tag in tags:
    folder=root/tag
    resource=json.loads((folder/'resource.json').read_text())
    runtime=json.loads((folder/'runtime.json').read_text()) if (folder/'runtime.json').exists() else None
    runs[tag]={'resource':resource,'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,tag+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final'
imports=json.loads((final/'imports.json').read_text());runtime=json.loads((final/'runtime.json').read_text())
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed2/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed2/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed2/anysolver');assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
parity=dest/'installed_parity.json';parity.write_text(json.dumps({'loaded':loaded,'package':package},indent=2))
source=('src/anysolver/general_contact/beam_plane.py','tests/test_general_contact_plane_end_ownership.py','examples/general_contact_beam_end_capped_cylinder.py')
raw.extend(((parity,'installed_parity.json'),(root/'run.py','run.py'),(root/'collect.py','collect.py'),(dest/'review.md','review.md')))
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
summary={'scope':'D3 exact affine plane-hemisphere ownership guard and coupled static endpoint code verification; not engineering acceptance',
'source_parent':'6158f882','source_files':{p:sha(repo/p) for p in source},
'wheels':{p.name:sha(p) for p in (root/'dist2').glob('*.whl')},'runs':runs,
'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],'effective_pools':runtime['effective_pools'],
'independent_bar_relative_target':1e-6,'normal_gap_budget_m':1e-5,
'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
'limits':'180s/953MiB process tree; fixed plane and elastic small-motion structural scope; exact declared affine end paths; closed ownership switches reject; no generalized-tangent/native/dynamic/friction/application/engineering acceptance'}
(dest/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'runs':len(runs),'raw_records':len(raw),'modules':len(loaded),'package_files':len(package),'outcomes':runs['installed_final']['outcomes'],'resource':runs['installed_final']['resource']}))
