from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
import numpy,scipy

root=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
out=root/'docs/d1_review_support/contact_c6_reactions_reference_20261003'
out.mkdir(parents=True,exist_ok=True)
sources=[
 'src/anysolver/general_contact/transient.py',
 'scripts/check_general_contact_oblique_temporal_dev.py',
 'tests/reference_oblique_q4_plateau.py','tests/test_reference_oblique_q4_plateau.py',
 'tests/test_general_contact_transient_constraint_reactions.py',
 'tests/test_general_contact_transient_oblique_q4_plastic.py',
 'tests/test_general_contact_oblique_temporal_comparison.py']
files={('source/'+name):root/name for name in sources}
runs={}
for name in ['contact_constraint_reactions_a_20261003','contact_constraint_reactions_b_20261003',
 'contact_constraint_reactions_c_20261003','contact_oblique_yielded_restart_20261003',
 'contact_temporal_comparison_zero_20261003',
 'oblique-continuous-reference-dev-20261003-b','oblique-continuous-reference-dev-20261003-c']:
 folder=Path('C:/ANYworkspaceWork')/name
 packet=next(folder.glob('anysolver-portable-ci-*/P01'))
 log=folder/'runner.log' if name.startswith('oblique-') else folder.with_suffix('.log')
 files[name+'/runner.log']=log
 for record in ('selection.json','runtime.json','resource.json'):
  files[name+'/'+record]=packet/record
 runs[name]={'resource':json.loads((packet/'resource.json').read_text()),
  'selection':json.loads((packet/'selection.json').read_text())}
 controls=folder/'oblique_continuous_reference_controls.json'
 if controls.exists():files[name+'/controls.json']=controls
for name in ['contact_q4_oblique_continuous_comparison_pre_review_20261003.json',
 'contact_q4_oblique_continuous_comparison_corrected_20261003.json',
 'contact_q4_oblique_continuous_comparison_20261003.log',
 'contact_q4_oblique_continuous_comparison_corrected_20261003.log']:
 files['comparison/'+name]=Path('C:/ANYworkspaceWork')/name
for name,path in [('coarse','C:/ANYworkspaceWork/contact_q4_oblique_integrated_c_20261003/oblique_impact.json'),
 ('half','C:/ANYworkspaceWork/contact_q4_oblique_half_e_20261003/oblique_impact_half.json')]:
 files['saved_fields/'+name+'.json']=Path(path)
files['capture.py']=Path(__file__)
manifest={name:dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
          for name,path in files.items()}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for name,path in files.items():archive.write(path,name)
report=dict(scope='source development and temporal discriminator; not engineering acceptance',
 parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 source_hashes={name:manifest['source/'+name]['sha256'] for name in sources},
 environment=dict(python=sys.version,numpy=numpy.__version__,scipy=scipy.__version__),
 records=manifest,runs=runs,
 archive_sha256=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest())
(out/'source.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(len(files),'retained records',out)
