import json,math
from pathlib import Path

folder=Path(__file__).parent
records=[]; initial=.5*.05+.5/120*.2**2
baseline=json.loads((folder/'source.json').read_text())
for name in ('source','half_dt','quarter_dt'):
    data=json.loads((folder/(name+'.json')).read_text())
    assert data['imports']==baseline['imports']
    result=data['result']; velocity=result['final_modal_velocities']
    tau=result['observations']['final_elasticity_inferred_equivalent_stress_pa']/math.sqrt(3.)
    kinetic=.5*.05*velocity[1]**2+.5/120*velocity[0]**2
    elastic=.05*tau*tau/(2*(1e5/2.6))
    plastic=.05*20*result['final_alpha']
    assert result['observations']['contact_open_at_end']
    assert result['maximum_alpha']<.005
    assert data['effective']['jit_disabled']==1 and data['effective']['numba_threads']==1
    records.append(dict(label=name,dt_s=result['dt_s'],end_s=result['final_time_s'],
        accepted_steps=result['accepted_steps'],initial_energy_j=initial,
        final_kinetic_j=kinetic,final_material_elastic_j=elastic,
        plateau_plastic_work_j=plastic,contact_storage_j=0.,external_work_j=0.,
        energy_defect_j=kinetic+elastic+plastic-initial,
        relative_energy_defect=(kinetic+elastic+plastic-initial)/initial))
report=dict(scope='exploratory temporal development; not qualification',records=records,
    endpoint_note='Base end .003 includes unloading; fine ends .0012 after contact release during plateau loading. Zero external work; same initial energy and constitutive/mass maps. Not a matched-end formal temporal qualification.',
    matched_source_modules=len(baseline['imports']))
(folder/'temporal_energy.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
