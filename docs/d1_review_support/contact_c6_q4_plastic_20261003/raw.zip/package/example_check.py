import hashlib,json,runpy,sys
from pathlib import Path

root=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(root))
example=runpy.run_path(sys.argv[2])
result=example['run'](**(dict(dt=float(sys.argv[4]),end=float(sys.argv[5])) if len(sys.argv)>4 else {}))
from threadpoolctl import threadpool_info
import numba
assert numba.config.DISABLE_JIT==1 and numba.get_num_threads()==1
pools=threadpool_info()
assert all(pool['num_threads']==1 for pool in pools)
imports={}
for name,module in tuple(sys.modules.items()):
    if name=='anysolver' or name.startswith('anysolver.'):
        value=getattr(module,'__file__',None)
        if value:
            path=Path(value).resolve()
            assert path.is_relative_to(root),(name,str(path))
            imports[path.relative_to(root).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
Path(sys.argv[3]).write_text(json.dumps(dict(result=result,imports=imports,
    effective=dict(jit_disabled=numba.config.DISABLE_JIT,numba_threads=numba.get_num_threads(),
        threadpools=pools,python=sys.version,package_root=str(root))),indent=2),encoding='utf-8')
