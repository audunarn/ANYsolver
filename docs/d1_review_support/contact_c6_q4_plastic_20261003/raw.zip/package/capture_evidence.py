import hashlib,json,zipfile
from pathlib import Path

repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
base=Path('C:/ANYworkspaceWork')
folder=repo/'docs/d1_review_support/contact_c6_q4_plastic_20261003'
folder.mkdir(exist_ok=False)
files=['src/anysolver/general_contact/transient.py','src/anysolver/general_contact/q4_material_checkpoint.py',
    'tests/test_general_contact_q4_material_checkpoint.py','tests/test_general_contact_transient_q4_plastic.py',
    'examples/general_contact_q4_plastic_impact_dev.py','scripts/run_portable_ci.py',
    'GENERAL_CONTACT_PLAN.md','GENERAL_CONTACT_RESTART.md',
    'docs/GENERAL_CONTACT_CAPABILITIES.md','docs/GENERAL_CONTACT_C6_Q4_PLASTIC_DEV.md',
    'docs/d1_review_support/C6_Q4_PLASTIC_SLICE_20261003.md']
manifest={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in files}
runs=['q4-material-checkpoint-dev-20261003-'+name for name in ('a','b','c')]
runs+=['contact_q4_plastic_'+name+'_20261003' for name in
    ('driver_compat','integrated_a','integrated_b','integrated_c','oracle_d','reference_e',
     'compat_f','rollback_g','cutback_h','reference_i')]
raw={}
for name in runs:
    run=base/name
    log=base/(name+'.log')
    if log.exists():raw[name+'/runner.log']=log
    for path in run.glob('*.log'):raw[name+'/'+path.name]=path
    for sub in run.glob('anysolver-portable-ci-*/P01'):
        for path in sub.glob('*.json'):raw[name+'/'+path.relative_to(run).as_posix()]=path
package=base/'contact_q4_plastic_package_20261003'
for ext in ('json','log','py'):
    for path in package.glob('*.'+ext):raw['package/'+path.name]=path
for name in files:
    if name.endswith('.py'):raw['final-source/'+name]=repo/name
with zipfile.ZipFile(folder/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(raw.items()):archive.write(path,name)
installed=json.loads((package/'installed.json').read_text())
record=dict(scope='tested development and isolated package verification; no engineering acceptance or release',
    parent_commit='26402e722ccd6f70950f7bf794e3156fa296e1bc',branch='codex/contact-main-reconcile-20261001',
    source_files_sha256=manifest,loaded_installed_modules_sha256=installed['imports'],
    effective=installed['effective'],wheel_sha256=hashlib.sha256((package/'wheels/anysolver-0.4.7-py3-none-any.whl').read_bytes()).hexdigest(),
    raw_members=sorted(raw),identity_note='Final source snapshots retained; intermediate revisions not all snapshotted. Selected-test hashes/commands/failure records retained. Packet tests unchanged since final worker c run. Final driver tested in reference_i, compatibility_f, rollback_g and cutback_h.',
    review=dict(kind='different owned OpenAI worker source review; not engineering acceptance',
        findings=['existing tool-work fingerprint scope restored','exported checkpoint deep-copy prevents state aliasing'],
        final_delta='No additional defect found in driver/helper/direct reference algebra or public example. Review did not independently execute numerical checks.'))
(folder/'source.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(dict(raw_records=len(raw),source_hashes=len(manifest),installed_module_hashes=len(installed['imports']),evidence=str(folder))))
