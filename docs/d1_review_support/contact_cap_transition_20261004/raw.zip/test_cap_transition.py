"""Development discriminator: finite energy cannot be patched by a tangent."""
from dataclasses import replace
from pathlib import Path
import json,os
import numpy as np
import pytest

from anysolver import ContactDefinition,ContactSurface,RigidContactBody,ContactInteraction,ContactSolverSettings
from anysolver.elements import BeamElement
from anysolver.fe_core import FEModel
from anysolver.general_contact.beam_plane import _BeamPlaneManager


def fixture():
    model=FEModel('one_physical_cap')
    model.add_material('elastic',1000.,.3,density=1.)
    for node,p in enumerate(((0.,0.,.12),(1.,0.,.12),(0.,1.,.3)),1):model.add_node(node,*p)
    section={'area':.001,'Iy':1e-4,'Iz':1e-4,'J':1e-4}
    model.add_element(1,BeamElement(1,(1,2),'elastic',section))
    model.add_element(2,BeamElement(2,(1,3),'elastic',section))
    definition=ContactDefinition(surfaces=(ContactSurface('beam',(1,),beam_radius=.1,beam_end_caps='hemisphere'),),
        rigid_bodies=(RigidContactBody('plane','plane',point=(0.,0.,0.),normal=(0.,0.,1.)),),
        interactions=(ContactInteraction('contact','beam','plane',normal_stiffness=None,
            line_stiffness=1000.,endpoint_stiffness=1000.,gap_tolerance=.01),))
    settings=ContactSolverSettings(pair_motion='general',maximum_swept_subdivisions=18)
    return model,definition,settings


def pose(model,theta):
    point=np.array((1.,0.,.095));first=point-np.array((np.cos(theta),0.,np.sin(theta)))
    u=np.zeros(model.mesh.dof_manager.total_dofs);du=np.zeros_like(u)
    for node,current in ((1,first),(2,point)):
        dofs=model.mesh.dof_manager.get_node_dofs(node)[:3]
        u[dofs]=current-model.mesh.nodes[node].coords()
    du[model.mesh.dof_manager.get_node_dofs(1)[:3]]=(np.sin(theta),0.,-np.cos(theta))
    return u,du


def test_legacy_closed_seam_energy_discriminator(tmp_path):
    model,definition,settings=fixture();manager=_BeamPlaneManager(model,definition,settings)
    assert tuple(manager.endpoints)==(2,)
    rows=[]
    for theta in (-1e-3,-1e-5,-1e-7,1e-7,1e-5,1e-3):
        u,du=pose(model,theta);f,K,r=manager.evaluate(u)
        analytic=.5*1000*(.005**2+.005*np.sin(theta)+np.sin(theta)**2/3)
        assert r.line_contact_energy==pytest.approx(analytic,rel=1e-12)
        expected=.5*1000*.005**2 if theta<0 else 0.
        assert r.endpoint_contact_energy==pytest.approx(expected,abs=1e-15)
        line_def=replace(definition,surfaces=(replace(definition.surfaces[0],beam_end_caps='none'),),
            interactions=(replace(definition.interactions[0],endpoint_stiffness=None),))
        line=_BeamPlaneManager(model,line_def,settings).evaluate(u)[0]
        assert abs((f-line)@du)<1e-15  # Genuine cap centre does not move.
        rows.append({'theta_rad':theta,'line_energy_J':r.line_contact_energy,
            'endpoint_energy_J':r.endpoint_contact_energy,'beam_force_N':r.beam_force,
            'endpoint_virtual_power_J_per_rad':float((f-line)@du)})
    with pytest.raises(ValueError,match='ownership'):manager.evaluate(pose(model,0.)[0])
    assert not manager.swept_increment_admissible(pose(model,-1e-3)[0],pose(model,1e-3)[0],0.,1.)
    jump=rows[2]['endpoint_energy_J']-rows[3]['endpoint_energy_J']
    assert jump==pytest.approx(.0125,abs=1e-15)
    output=Path(os.environ.get('CONTACT_APP_RESULT_RECORD',str(tmp_path/'result.json'))).with_name('legacy_limits.json')
    output.write_text(json.dumps({'question':'can an active ownership seam be extended by generalized derivatives?',
        'disposition':'NO: finite endpoint energy jump with zero endpoint virtual work; existing rejection required',
        'energy_jump_J':jump,'rows':rows},indent=2),encoding='utf-8')
