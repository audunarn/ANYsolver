from pathlib import Path
import hashlib,json,platform,sys,zipfile
from importlib.metadata import version
root=Path('C:/ANYworkspaceWork/contact_cap_transition_20261004')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_cap_transition_20261004';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=[];runs={}
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists():continue
    runtime=json.loads((folder/'runtime.json').read_text(encoding='utf-8')) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':json.loads((folder/'resource.json').read_text(encoding='utf-8')), 'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,folder.name+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final2'
imports=json.loads((final/'imports.json').read_text(encoding='utf-8'))
runtime=json.loads((final/'runtime.json').read_text(encoding='utf-8'))
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed/anysolver')
    assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
parity=dest/'installed_parity.json'
parity.write_text(json.dumps({'loaded':loaded,'package':package},indent=2),encoding='utf-8')
raw.append((parity,'installed_parity.json'))
for name in ('source_review.md','support_review.md','design.md'):
    p=dest/name;p.write_bytes((root/name).read_bytes());raw.append((p,name))
source=('src/anysolver/general_contact/beam_hemisphere_support.py','src/anysolver/general_contact/beam_hemisphere_plane.py','src/anysolver/general_contact/core.py','tests/test_general_contact_hemisphere_plane.py','examples/general_contact_hemisphere_plane.py')
raw.extend((root/p,p) for p in ('run.py','collect.py','test_cap_transition.py'))
raw.extend((repo/p,'candidate/'+p) for p in source)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
summary={'scope':'D3 opt-in classical B2/B3 fixed-plane hemisphere support point spring; development/code verification, not engineering acceptance',
'source_parent':'3a501e6994cc53f372638f0402cd2f0b2b6e332b','source_files':{p:sha(repo/p) for p in source},
'wheels':{p.name:sha(p) for p in (root/'dist').glob('*.whl')},'runs':runs,
'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],'effective_pools':runtime['effective_pools'],
'legacy_discriminator':json.loads((root/'discriminator01/legacy_limits.json').read_text(encoding='utf-8')),
'directional_tangent_target':1e-5,'bar_response_target':1e-6,
'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
'environment':{'python':sys.version,'platform':platform.platform(),'versions':{name:version(name) for name in ('numpy','scipy','numba','ANYmaterial','ANYgeometry')}},
'review_disposition':'supporting same-family source scrutiny; compatibility settings/control, fixed-plane validation and candidate size/finiteness issues resolved and tested. No engineering acceptance.',
'preserved_failures':['source02 two fixture errors: central FD inadvertently crossed B3 kink; sphere fixture violated public construction contract',
'source04 three fixture failures: no reduced equations in fully prescribed model, so callbacks never reached',
'source05 assumed fixed step count despite solver adaptive growth;1fail2pass',
'source01/installed_final runner preflight missing-target paths: no numerical execution; directory retained externally'],
'unchanged':['legacy owned_point cap laws and rejection','line/end units and explicit regularization','normal application admission false','no-contact/historical defaults/sphere APIs','frozen authority and historical failures','ANYfem source'],
'limits':['fixed analytic plane only','scalar isotropic elastic concentric B2/B3 von Karman','exterior gap_tolerance below radius','genuine physical ends from all material-node incidence','centreline-tangent hemisphere support spring, not material-surface integration/friction/spin','beam-pair/cylinder/shell cap transition still unresolved','mesh/enforcement/independent acceptance/release/full programme incomplete']}
(dest/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({'runs':len(runs),'records':len(raw),'modules':len(loaded),'package_files':len(package),'resource':runs['installed_final2']['resource'],'evidence':str(dest)}))
