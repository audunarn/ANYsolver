import ast,hashlib,json
from pathlib import Path
import numpy as np
folder=Path(__file__).parent
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
source=(repo/'tests/test_general_contact_transient_deforming_q4_planes.py').read_text()
module=ast.parse(source)
functions=[n for n in module.body if isinstance(n,ast.FunctionDef) and n.name in
           {'pressure_geometry','structural','contact','reference'}]
scope=dict(np=np,GAP=1.e-5,KN=1.e9,MASS=np.diag([.05,.05/12]),
           KS=(5/6)*1.e5/2.6*.05,Q4=1.e5*.05/(8*(1-.3**2)))
exec(compile(ast.Module(body=functions,type_ignores=[]),'<independent-reference>','exec'),scope)
saved=Path('C:/ANYworkspaceWork/contact_deforming_q4_impact_f_20261003/deforming_shell_impact.json')
d=json.loads(saved.read_text());times=np.array(d['times_s'])
q,v,a=(np.array(d[n]) for n in ['q','v','a'])
expected=scope['reference'](times)
weights,direction=scope['pressure_geometry']()
energy=.5*np.einsum('ij,jk,ik->i',v,scope['MASS'],v)+.5*scope['KS']*q[:,1]**2+scope['Q4']*q[:,1]**4
force_error=[];moment_error=[];equilibrium=[]
for i,(z,acc,row) in enumerate(zip(q,a,d['pair_results'])):
 gaps=scope['GAP']+direction@z
 pressures=scope['KN']*np.maximum(-gaps,0.)
 energy[i]+=row['penalty_energy']
 fs,_=scope['structural'](z);fc,_,_=scope['contact'](z)
 equilibrium.append(np.max(np.abs(scope['MASS']@acc+fs+fc)))
 for child,section,sign in zip(row['pairs'],(slice(0,5),slice(5,10)),(-1.,1.)):
  force=sign*np.dot(weights[section],pressures[section])
  moment=-scope['KN']*np.dot(direction[section,1]*weights[section],np.minimum(gaps[section],0.))
  force_error.append(abs(child['contact']['rigid_force'][2]-force))
  moment_error.append(abs(child['contact']['rigid_moment'][1]-moment))
minimum={n:float('inf') for n in ['lower','upper']}
bound_error=[]
for i,h in enumerate(np.diff(times)):
 avgacc=.5*(a[i]+a[i+1])
 for name,sign in [('lower',1.),('upper',-1.)]:
  gapminimum=float('inf')
  for x in (-.5,.5):
   mode=sign*np.array([1.,x]);g0=scope['GAP']+mode@q[i];rate=mode@v[i];acc=mode@avgacc
   candidates=[g0,g0+rate*h+.5*acc*h*h]
   if acc and 0.<-rate/acc<h:
    t=-rate/acc;candidates.append(g0+rate*t+.5*acc*t*t)
   gapminimum=min(gapminimum,min(candidates))
  minimum[name]=min(minimum[name],gapminimum)
  bound_error.append(abs(gapminimum-d['pair_gaps'][i+1][name]))
installed=json.loads((folder/'installed.json').read_text())
original=json.loads((folder/'source.json').read_text())
assert original['imports']==installed['imports'] and original['result']==installed['result']
wheel=next((folder/'dist').glob('*.whl'))
report=dict(scope='discrete development verification, not engineering acceptance',
 imported_modules=len(original['imports']),imports_match=True,numerical_fields_match=True,
 wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
 reference_ast_sha256=hashlib.sha256(ast.dump(ast.Module(body=functions,type_ignores=[])).encode()).hexdigest(),
 maximum_q_error=float(np.max(np.abs(q-expected[:,0]))),
 maximum_velocity_error=float(np.max(np.abs(v-expected[:,1]))),
 maximum_acceleration_error=float(np.max(np.abs(a-expected[:,2]))),
 maximum_modal_equilibrium_error=float(max(equilibrium)),
 maximum_body_force_error_n=float(max(force_error)),maximum_body_moment_error_nm=float(max(moment_error)),
 maximum_energy_relative_defect=float(np.max(np.abs(energy/energy[0]-1))),
 independent_physical_path_minimum_m=minimum,maximum_reported_bound_error_m=float(max(bound_error)),
 resources={n:json.loads((folder/(n+'-resource.json')).read_text()) for n in ['source','installed']})
(folder/'comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='resources'},indent=2))
