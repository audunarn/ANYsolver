from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
import numpy,scipy
root=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
out=root/'docs/d1_review_support/contact_c6_deforming_shell_planes_20261003'
out.mkdir(exist_ok=True)
sources=['src/anysolver/general_contact/plane_newmark_events.py',
 'src/anysolver/general_contact/transient.py',
 'examples/general_contact_deforming_q4_planes_dev.py',
 'tests/test_general_contact_transient_deforming_q4_planes.py',
 'tests/test_general_contact_plane_newmark_events.py',
 'tests/test_general_contact_plane_event_front_controls.py']
files={'source/'+n:root/n for n in sources};runs={}
names=['local_a','impact_b','impact_c','front_d','impact_e','impact_f','controls_g','restart_h']
for n in names:
 name='contact_deforming_q4_'+n+'_20261003'
 folder=Path('C:/ANYworkspaceWork')/name
 packet=next(folder.glob('anysolver-portable-ci-*/P01'))
 for entry in ['selection','runtime','resource']:
  files[name+'/'+entry+'.json']=packet/(entry+'.json')
 files[name+'/runner.log']=folder.with_suffix('.log')
 for p in folder.glob('*.py'):files[name+'/'+p.name]=p
 for p in folder.glob('*.json'):files[name+'/'+p.name]=p
 records={k:json.loads((packet/(k+'.json')).read_text()) for k in ['selection','runtime','resource']}
 runtime=records['runtime']
 assert runtime['jit_disabled'] and runtime['numba_threads']==1
 assert all(p['num_threads']==1 for p in runtime['effective_pools'])
 assert all(Path(p).is_relative_to(root/'src') for p in runtime['imports'].values())
 runs[name]=records
pkg=Path(__file__).parent
for p in pkg.iterdir():
 if p.is_file() and p.suffix in {'.json','.log','.py'}:files['package/'+p.name]=p
manifest={n:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for n,p in files.items()}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n,p in files.items():z.write(p,n)
report=dict(scope='development/discrete verification; not engineering acceptance or release',
 parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 source_hashes={n:manifest['source/'+n]['sha256'] for n in sources},
 environment=dict(python=sys.version,numpy=numpy.__version__,scipy=scipy.__version__),
 records=manifest,runs=runs,archive_sha256=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest(),
 package=json.loads((pkg/'comparison.json').read_text()))
(out/'source.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(len(files),'retained records')
for n,r in runs.items():print(n,r['runtime']['outcomes'],r['resource'])
