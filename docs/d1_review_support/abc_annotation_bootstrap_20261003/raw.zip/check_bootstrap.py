"""Execute the exact package bootstrap using stdlib only on a chosen runtime."""
import abc,inspect,json,sys,hashlib
from pathlib import Path
source=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001/src/anysolver/__init__.py').read_text()
bootstrap=source.split('# Establish CPython',1)[1].split('from .fe_core import',1)[0]
bootstrap='# Establish CPython'+bootstrap
exec(compile(bootstrap,'owner-bootstrap','exec'),{})
before=dict(type.__getattribute__(abc.ABC,'__dict__'))
observed=inspect.get_annotations(abc.ABC)
after=dict(type.__getattribute__(abc.ABC,'__dict__'))
assert set(before)==set(after) and all(after[key] is value for key,value in before.items())
assert observed=={}
record={'python':sys.version,'bootstrap_sha256':hashlib.sha256(bootstrap.encode()).hexdigest(),
        'metadata_keys':sorted(key for key in after if 'annotat' in key),
        'inspection_added':sorted(set(after)-set(before)),'inspection_rebound':[],
        'scope':'exact bootstrap language check, not full solver/dependency or engineering qualification'}
Path(sys.argv[1]).write_text(json.dumps(record,indent=2))
print(json.dumps(record))
