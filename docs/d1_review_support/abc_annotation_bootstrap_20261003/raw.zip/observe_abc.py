import json,sys,inspect,annotationlib
from pathlib import Path
from abc import ABC

def capture():
    return dict(type.__getattribute__(ABC,'__dict__'))
rows=[]
for name,observe in [('start',lambda:None),('inspect',lambda:inspect.get_annotations(ABC)),('public',lambda:ABC.__annotations__),('annotationlib',lambda:annotationlib.get_annotations(ABC))]:
    before=capture()
    value=observe()
    after=capture()
    rows.append({'observation':name,'added':sorted(set(after)-set(before)),
                 'removed':sorted(set(before)-set(after)),
                 'rebound':[k for k in before if k in after and before[k] is not after[k]],
                 'value_type':type(value).__name__,
                 'metadata':{k:{'type':type(v).__name__,'value':v if v is None or type(v) in (dict,list,str,int) else str(type(v))}
                            for k,v in after.items() if 'annotat' in k}})
record={'python':sys.version,'rows':rows}
Path('C:/ANYworkspaceWork/contact_app_guard_20261003/abc-observation.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
