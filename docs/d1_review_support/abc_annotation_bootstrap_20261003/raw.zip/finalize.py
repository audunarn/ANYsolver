from pathlib import Path
import json,hashlib,shutil,zipfile,subprocess
root=Path('C:/ANYworkspaceWork/contact_app_guard_20261003'); solver=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001'); app=Path('C:/ANYworkspaceWork/ANYfem-contact-intent')
for name,temp in [('source-final','kwp770sq'),('cold-final','7pclfr47'),('source-intermediate','g4hgrz7d'),('cold-intermediate','lzhpk2wd')]:
 p=Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/anysolver-portable-ci-'+temp)/'P01'
 shutil.copytree(p,root/name,dirs_exist_ok=True)
rows={}
for tag in ['installed_preimport_final','installed_order_final','installed_mechanics_final']:
 r=json.loads((root/tag/'imports.json').read_text()); mismatches=[]
 for n,v in r['modules'].items():
  p=Path(v['path']); owner=app if n.startswith('anyfem') else solver
  source=owner/'src'/p.relative_to(root/'installed2')
  if hashlib.sha256(source.read_bytes()).hexdigest()!=v['sha256']:mismatches.append(n)
 runtime=json.loads((root/tag/'runtime.json').read_text())
 rows[tag]={'modules':len(r['modules']),'path_errors':r['errors'],'byte_mismatches':mismatches,'runtime':{k:v for k,v in runtime.items() if k!='imports'}}
 assert not r['errors'] and not mismatches
# Compare all Python package source entries against the unchanged prior wheel.
old=next(Path('C:/ANYworkspaceWork/contact_app_moments_20261003/dist').glob('anysolver-*.whl')); new=next((root/'dist2').glob('anysolver-*.whl'))
with zipfile.ZipFile(old) as a,zipfile.ZipFile(new) as b:
 names=sorted(n for n in a.namelist() if n.startswith('anysolver/') and n.endswith('.py'))
 changed=[n for n in names if a.read(n)!=b.read(n)]
 semantic_changed=[n for n in changed if a.read(n).replace(b'\r\n',b'\n')!=b.read(n).replace(b'\r\n',b'\n')]
 assert semantic_changed==['anysolver/__init__.py'],semantic_changed
summary={'scope':'isolated development; no engineering acceptance, release or application admission','solver_parent':'4a87da5581b5eaa4a3e43b1f580803a29c027c20','app_sha':'3d6a7bb','wheel_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'dist2').glob('*.whl')},'python_package_byte_changes_from_baseline':changed,'python_package_normalized_changes_from_baseline':semantic_changed,'loaded_module_agreement':rows,'source_file_hashes':{str(p.relative_to(solver)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [solver/'src/anysolver/__init__.py',solver/'tests/test_abc_annotation_authority.py']}}
(root/'summary.json').write_text(json.dumps(summary,indent=2))
# Archive diagnostic/reproducibility files, not private installed copies or wheel contents.
files=sorted(p for p in root.rglob('*') if p.is_file() and not any(part in ('dist','dist2','installed','installed2','bootstrap-v1-runtime','bootstrap-v2-runtime','__pycache__') for part in p.relative_to(root).parts) and p.name!='raw.zip')
with zipfile.ZipFile(root/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,p.relative_to(root).as_posix())
print(json.dumps({'records':len(files),'archive_bytes':(root/'raw.zip').stat().st_size,'changes':changed,'modules':{k:v['modules'] for k,v in rows.items()},'runtime_keys':list(rows['installed_mechanics_final']['runtime'])}))
