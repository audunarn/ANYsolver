"""Package bounded nonuniform-target component evidence, without rerunning solves."""
import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
workspace=root.parent
target=root/'docs/d1_review_support/contact_c6_nonuniform_s3_components_20261003'
target.mkdir(parents=True,exist_ok=True)
folders={f'pressure_{label}':workspace/f'contact_fixed_projection_s3_events_{label}_20261003' for label in 'abcde'}
folders['geometry']=workspace/'shell-pair-cubic-sweep-20261003-6ebd2221'
manifest=[];runs=[]
with zipfile.ZipFile(target/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for label,folder in folders.items():
        files=list(folder.rglob('*.json'))+list(folder.rglob('*.log'))+list(folder.rglob('*.snapshot'))
        if label.startswith('pressure_'):files.append(folder.with_suffix('.log'))
        for path in sorted(set(files)):
            name=label+'/'+(path.relative_to(folder).as_posix() if path.is_relative_to(folder) else path.name)
            archive.write(path,name);manifest.append(dict(path=name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        for path in folder.rglob('runtime.json'):
            runtime=json.loads(path.read_text())
            assert runtime['imports'] and all(Path(p).is_relative_to(root/'src') for p in runtime['imports'].values())
            assert runtime['jit_disabled'] and runtime['numba_threads']==1 and not runtime['errors']
            assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
            runs.append(dict(label=label,outcomes=runtime['outcomes'],collected=runtime['collected'],
                resource=json.loads(path.with_name('resource.json').read_text()),import_count=len(runtime['imports'])))
    path=workspace/'shell-pair-cubic-sweep-20261003-6d0fcde7/runner.log'
    archive.write(path,'geometry_preliminary/runner.log')
    manifest.append(dict(path='geometry_preliminary/runner.log',sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    archive.write(Path(__file__),'package_evidence.py')
files=['src/anysolver/general_contact/shell_pair_hermite_sweep.py',
 'src/anysolver/general_contact/fixed_projection_s3_events.py',
 'tests/test_general_contact_shell_pair_hermite_sweep.py',
 'tests/test_general_contact_fixed_projection_s3_events.py']
record=dict(parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    candidate_sha256={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files},
    raw_records=len(manifest)+1,archive_manifest=manifest,runs=runs,
    disposition='component implementation/source-tested; no public-driver/installed/engineering admission',
    review='Read-only same-family scrutiny; no geometry defect found. Pressure epsilon-affinity, derived nonfinite, int64 absolute-value overflow and reversible array ownership findings corrected; exact represented-skin path checks added before driver admission.',
    current_pass_outcomes=89,current_unique_checks=87)
(target/'source.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(dict(raw_records=record['raw_records'],runs=runs),indent=2))
