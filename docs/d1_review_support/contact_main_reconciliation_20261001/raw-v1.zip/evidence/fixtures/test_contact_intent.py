"""Contact intent is persistent design data, not an executable solver route."""

from dataclasses import replace

import pytest
from anygeometry.entities import EntityRef

from anyfem import pinned, solve_linear_static, steel
from anyfem.document import DocumentSession
from anyfem.io.project_file import (
    ProjectFileError, load_project, project_from_dict, project_to_dict,
    save_project,
)
from anyfem.jobs import JobManager, analysis_hash
from anyfem.model.project import Project, ProjectError
from anyfem.model.records import AnalysisDefinition, ContactPairIntent, JobStatus
from anyfem.model.regions import ManualRegion, Region, RegionRef
from anyfem.solve.contact_intent import with_contact_solver_settings


def _project_with_pair() -> tuple[Project, AnalysisDefinition]:
    project = Project("stored contact")
    source = Region("source", "geometry", "face", ManualRegion((EntityRef("face", 1),)))
    target = Region("target", "geometry", "face", ManualRegion((EntityRef("face", 2),)))
    project.regions.add(source)
    project.regions.add(target)
    pair = ContactPairIntent(
        RegionRef(source.id), RegionRef(target.id),
        gap_tolerance=1e-5, normal_stiffness=2e8,
        source_side="top", target_side="bottom",
    )
    analysis = project.add_analysis(
        AnalysisDefinition("contact design", type="nonlinear_static", contact_pairs=(pair,))
    )
    return project, analysis


def test_contact_intent_round_trips_without_mesh_ids_or_pressure_method(tmp_path):
    project, analysis = _project_with_pair()
    document = project_to_dict(project)
    encoded = document["analyses"][0]["contact_pairs"][0]
    assert encoded["source_region"] == analysis.contact_pairs[0].source_region.id
    assert "element_ids" not in encoded
    assert "pressure_method" not in encoded
    reopened = project_from_dict(document)
    assert reopened.analyses[analysis.id].contact_pairs == analysis.contact_pairs
    assert project_to_dict(reopened) == document
    saved = save_project(project, tmp_path / "stored-contact.anyfem")
    from_file = load_project(saved)
    assert from_file.analyses[analysis.id].contact_pairs == analysis.contact_pairs


def test_contact_intent_rejects_malformed_and_missing_regions():
    project, analysis = _project_with_pair()
    pair = analysis.contact_pairs[0]
    with pytest.raises(ValueError, match="normal_stiffness"):
        replace(pair, normal_stiffness=float("nan"))
    with pytest.raises(ValueError, match="must differ"):
        replace(pair, target_region=pair.source_region)
    with pytest.raises(ProjectError, match="does not exist"):
        project.add_analysis(AnalysisDefinition(
            "missing", contact_pairs=(replace(pair, target_region=RegionRef("missing")),)
        ))
    document = project_to_dict(project)
    document["analyses"][0]["contact_pairs"][0]["element_ids"] = [1]
    with pytest.raises(ProjectFileError, match="unknown contact pair field"):
        project_from_dict(document)
    del document["analyses"][0]["contact_pairs"][0]["element_ids"]
    document["analyses"][0]["contact_pairs"][0]["source_region"] = {"id": "bad"}
    with pytest.raises(ProjectFileError, match="region ID strings"):
        project_from_dict(document)


def test_contact_intent_hashes_physics_without_pair_presentation_identity():
    _project, analysis = _project_with_pair()
    pair = analysis.contact_pairs[0]
    baseline = analysis_hash(analysis)
    renamed = replace(analysis, name="another analysis", id="another-analysis", contact_pairs=(
        replace(pair, name="another pair", id="another-pair"),
    ))
    assert analysis_hash(renamed) == baseline
    assert analysis_hash(replace(analysis, contact_pairs=(
        replace(pair, normal_stiffness=3e8),
    ))) != baseline
    assert analysis_hash(replace(analysis, contact_pairs=(
        replace(pair, source_side="bottom"),
    ))) != baseline


def test_contact_intent_rejects_missing_region_on_reload():
    project, _analysis = _project_with_pair()
    # A later geometry edit cannot silently retarget a previously valid pair.
    project.regions.remove(next(iter(project.analyses.values())).contact_pairs[0].source_region.id)
    with pytest.raises(ProjectFileError, match="source region .* does not exist"):
        project_from_dict(project_to_dict(project))


def test_other_analysis_solves_while_selected_contact_submission_fails():
    project = Project("ordinary plate with stored contact")
    project.add_material(steel("S355", 0.01))
    project.add_plate_section("plate", thickness=0.01, material="S355")
    points = project.geometry.add_points(
        [(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)]
    )
    edges = project.geometry.add_polyline(points, close=True)
    face = project.geometry.add_face(edges)
    project.assign_plate(face, "plate")
    for edge in edges:
        project.add_support(pinned(project.edge(edge)))
    project.load_case().add_pressure(project.face(face), 100.0)
    source = Region("source", "geometry", "face", ManualRegion((project.face(face),)))
    target = Region("target", "geometry", "face", ManualRegion((project.face(face),)))
    project.regions.add(source)
    project.regions.add(target)
    pair = ContactPairIntent(
        RegionRef(source.id), RegionRef(target.id), gap_tolerance=1e-5
    )
    contact = project.add_analysis(
        AnalysisDefinition("stored contact", type="nonlinear_static", contact_pairs=(pair,))
    )
    ordinary = project.add_analysis(AnalysisDefinition("ordinary", type="linear_static"))
    manager = JobManager(project)
    snapshot = DocumentSession(project).snapshot()
    invoked = []

    def forbidden(*, project, progress, cancellation_token):
        invoked.append(True)

    with pytest.raises(ValueError, match="contact execution is unavailable"):
        manager.submit(contact, snapshot, forbidden)
    assert not invoked and not project.jobs

    def solve(*, project, progress, cancellation_token):
        return solve_linear_static(project, target_size=0.5)

    job = manager.submit(ordinary, snapshot, solve)
    finished = manager.wait(job.id, timeout=20)
    assert finished.status == JobStatus.COMPLETED, finished.diagnostics
    assert manager.result(job.id).max_translation()[1] > 0.0


def test_ordinary_analysis_serialization_stays_unchanged():
    assert "contact_pairs" not in AnalysisDefinition("static").to_dict()


def test_explicit_owner_settings_save_load_and_analysis_identity(tmp_path):
    import anysolver

    project, original = _project_with_pair()
    owner = anysolver.ContactSolverSettings(
        enforcement_solver="monolithic_active_set", complementarity_force_scale_n=7.0,
        maximum_candidate_pairs=73,
    )
    configured = with_contact_solver_settings(original, owner)
    assert original.settings == {}
    assert analysis_hash(configured) != analysis_hash(original)
    project.analyses[original.id] = configured
    saved = save_project(project, tmp_path / "contact-settings.anyfem")
    reopened = load_project(saved)
    restored = reopened.analyses[original.id]
    assert restored.settings == configured.settings
    assert analysis_hash(restored) == analysis_hash(configured)
    assert restored.contact_pairs == original.contact_pairs
    changed = with_contact_solver_settings(configured, replace(owner, maximum_candidate_pairs=74))
    assert analysis_hash(changed) != analysis_hash(configured)
    assert configured.settings["general_contact_solver_settings"]["values"]["maximum_candidate_pairs"] == 73
