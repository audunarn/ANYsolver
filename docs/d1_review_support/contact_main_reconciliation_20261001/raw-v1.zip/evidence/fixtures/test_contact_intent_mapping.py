"""Exact source-face lineage for non-executable contact candidates."""

from dataclasses import replace
from types import SimpleNamespace

import pytest

from anyfem import Project, pinned, steel
from anyfem.model.records import AnalysisDefinition, ContactPairIntent
from anyfem.model.regions import ManualRegion, Region, RegionRef
from anyfem.solve.build import build_fe_model
from anyfem.solve.contact_intent import map_contact_intent, with_contact_solver_settings


def _built_pair():
    project = Project("two plates")
    project.add_material(steel("S355", 0.01))
    project.add_plate_section("plate", thickness=0.01, material="S355")
    faces = []
    for x in (0.0, 2.0):
        points = project.geometry.add_points(
            [(x, 0, 0), (x + 1, 0, 0), (x + 1, 1, 0), (x, 1, 0)]
        )
        edges = project.geometry.add_polyline(points, close=True)
        face = project.geometry.add_face(edges)
        project.assign_plate(face, "plate")
        for edge in edges:
            project.add_support(pinned(project.edge(edge)))
        faces.append(face)
    project.load_case().add_pressure(project.face(faces[0]), 100.0)
    regions = []
    for face in faces:
        region = Region(
            f"face {face}", "geometry", "face",
            ManualRegion((project.face(face),)),
        )
        project.regions.add(region)
        regions.append(region)
    pair = ContactPairIntent(
        RegionRef(regions[0].id), RegionRef(regions[1].id),
        gap_tolerance=1e-5, normal_stiffness=1e8,
    )
    analysis = project.add_analysis(AnalysisDefinition(
        "stored contact", type="nonlinear_static", contact_pairs=(pair,),
    ))
    mesh = project.generate_mesh(0.5)
    return build_fe_model(project, mesh), analysis, faces


def _settings():
    import anysolver

    if not hasattr(anysolver, "ContactSolverSettings"):
        pytest.fail(
            "mapping tests require the active ANYsolver general-contact source; "
            f"imported {anysolver.__file__}"
        )
    return anysolver.ContactSolverSettings()


def test_maps_only_owner_face_element_ids_and_reports_development_capability():
    built, analysis, faces = _built_pair()
    settings = _settings()
    result = map_contact_intent(built, analysis, settings=settings)
    assert result.mapped, result.diagnostics
    assert result.settings == settings and result.settings is not settings
    assert result.capability is not None
    assert not result.implemented
    assert not result.capability.validation.valid
    assert result.capability.validation.issues
    assert not result.admitted_for_application
    assert not replace(
        result, capability=SimpleNamespace(admitted_for_application=True)
    ).admitted_for_application
    assert result.definition.rigid_bodies == ()
    assert result.definition.surfaces[0].element_ids == tuple(
        sorted(built.mesh.elements_of_face[faces[0]])
    )
    assert result.definition.surfaces[1].element_ids == tuple(
        sorted(built.mesh.elements_of_face[faces[1]])
    )


@pytest.mark.parametrize("change, expected", [
    ("stale", "stale_mesh"),
    ("unmapped", "unmapped_face"),
    ("non_shell", "non_shell_element"),
    ("ambiguous", "ambiguous_lineage"),
    ("dual_collection", "ambiguous_lineage"),
    ("inconsistent", "inconsistent_built_mesh"),
    ("malformed", "invalid_lineage"),
])
def test_rejects_untrusted_or_ambiguous_lineage(change, expected):
    built, analysis, faces = _built_pair()
    settings = _settings()
    if change == "stale":
        built.mesh.geometry_revision += 1
    elif change == "unmapped":
        del built.mesh.elements_of_face[faces[0]]
    elif change == "non_shell":
        built.mesh.elements_of_face[faces[0]] = [999999]
    elif change == "ambiguous":
        built.mesh.elements_of_face[faces[1]] = list(
            built.mesh.elements_of_face[faces[0]]
        )
    elif change == "dual_collection":
        element_id = built.mesh.elements_of_face[faces[0]][0]
        built.mesh.tris[element_id] = built.mesh.quads[element_id][:3]
    elif change == "inconsistent":
        element_id = built.mesh.elements_of_face[faces[0]][0]
        collection = built.mesh.quads if element_id in built.mesh.quads else built.mesh.tris
        collection[element_id] = tuple(reversed(collection[element_id]))
    else:
        built.mesh.elements_of_face[faces[0]] = ["invalid"]
    result = map_contact_intent(built, analysis, settings=settings)
    assert not result.mapped
    assert result.definition is None and result.capability is None
    assert expected in {item.code for item in result.diagnostics}


def test_requires_explicit_settings():
    built, analysis, _faces = _built_pair()
    result = map_contact_intent(built, analysis, settings=None)
    assert not result.mapped
    assert result.diagnostics[0].code in {"settings_required", "owner_api_unavailable"}


def test_stored_explicit_settings_map_and_conflicting_override_rejects():
    built, original, _faces = _built_pair()
    settings = replace(_settings(), maximum_candidate_pairs=73)
    analysis = with_contact_solver_settings(original, settings)
    result = map_contact_intent(built, analysis)
    assert result.mapped, result.diagnostics
    assert result.settings == settings
    assert not result.admitted_for_application
    agrees = map_contact_intent(built, analysis, settings=settings)
    assert agrees.mapped
    conflicts = map_contact_intent(built, analysis, settings=replace(settings, maximum_candidate_pairs=74))
    assert not conflicts.mapped
    assert conflicts.diagnostics[0].code == "settings_conflict"


@pytest.mark.parametrize("change", ["future_schema", "future_field", "missing_field", "invalid_value"])
def test_incompatible_stored_controls_are_preserved_and_rejected(change):
    built, original, _faces = _built_pair()
    analysis = with_contact_solver_settings(original, _settings())
    record = analysis.settings["general_contact_solver_settings"]
    if change == "future_schema":
        record["schema"] = "FUTURE_SCHEMA"
    elif change == "future_field":
        record["values"]["future_control"] = {"retain": [1, 2, None]}
    elif change == "missing_field":
        del record["values"]["maximum_candidate_pairs"]
    else:
        record["values"]["maximum_candidate_pairs"] = -1
    encoded = analysis.to_dict()
    restored = AnalysisDefinition.from_dict(encoded)
    assert restored.to_dict() == encoded
    result = map_contact_intent(built, restored, settings=_settings())
    assert not result.mapped and not result.admitted_for_application
    expected = "invalid_stored_settings" if change == "invalid_value" else "settings_incompatible"
    assert result.diagnostics[0].code == expected
    assert restored.to_dict() == encoded
