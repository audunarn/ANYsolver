from pathlib import Path
import ast, hashlib, json, shutil, subprocess

r = Path(__file__).resolve().parent
w = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
app = Path('C:/ANYworkspaceWork/ANYfem-contact-intent')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = {p.relative_to(w).as_posix(): sha(p) for p in sorted((w/'src/anysolver').rglob('*.py'))}
(r/'source-manifest.json').write_text(json.dumps(source, indent=2))
(r/'source-identity.json').write_text(json.dumps({
    'contact_merge': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w, text=True).strip(),
    'main_pin': 'ef85882858533eb82086810c04eec58d18fe625a',
    'application_checkpoint': subprocess.check_output(
        ['git', '-c', 'safe.directory='+str(app), 'rev-parse', 'HEAD'], cwd=app, text=True).strip(),
    'module_count': len(source), 'scope': 'development installed compatibility only',
}, indent=2))
pending = [w/'tests'/n for n in (
    'test_nonlinear_trusted_v2d_and_token.py', 'test_plane_stress_stopping_consistency.py',
    'test_spectral_validation_preparation.py', 'test_s3_angle_element.py',
    'test_general_contact_ordinary_supported_schur.py', 'test_general_contact_monolithic_restart.py',
    'test_general_contact_q4_s3_jet2_static_owner.py', 'test_general_contact_s3_jet2_static_owner.py',
)]
seen = set()
while pending:
    p = pending.pop()
    if p in seen:
        continue
    seen.add(p)
    destination = r/'fixtures'/p.name if p.parent == w/'tests' else r/p.relative_to(w)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(p, destination)
    for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
        modules = ([node.module] if isinstance(node, ast.ImportFrom) else
                   [a.name for a in node.names] if isinstance(node, ast.Import) else [])
        for module in modules:
            if not module:
                continue
            if module.startswith('scripts.'):
                candidate = w/Path(*module.split('.')).with_suffix('.py')
            else:
                candidate = w/'tests'/(module.split('.')[0]+'.py')
            if candidate.is_file() and candidate not in seen:
                pending.append(candidate)
for name in ('test_contact_intent.py', 'test_contact_intent_mapping.py'):
    shutil.copyfile(app/'tests'/name, r/'fixtures'/name)
(r/'pytest.ini').write_text('[pytest]\naddopts = -ra -p no:cacheprovider\n')
print(json.dumps({'source_modules': len(source), 'fixture_and_helper_files': len(seen)+2}))
