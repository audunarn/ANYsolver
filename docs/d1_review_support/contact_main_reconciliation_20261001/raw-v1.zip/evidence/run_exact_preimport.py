"""Historical application preimport sequence against the new installed artifact."""
import anyfem, anysolver, pytest
from pathlib import Path
import hashlib, json, sys, zipfile
import numba, threadpoolctl

r = Path('C:/ANYworkspaceWork/contact-main-reconciliation-20261001')
w = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
app = Path('C:/ANYworkspaceWork/ANYfem-contact-intent')
label = 'app-original-preimport'
assert Path(anysolver.__file__).resolve().is_relative_to((r/'site').resolve())
assert Path(anyfem.__file__).resolve().is_relative_to((app/'src').resolve())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads((r/'source-manifest.json').read_text())
wheel, = (r/'wheels').glob('*.whl')
assert all(sha(w/p) == h for p,h in source.items())
with zipfile.ZipFile(wheel) as z:
    assert all(z.read(p.replace('src/', '', 1)) == (r/'site'/p.replace('src/', '', 1)).read_bytes()
               == (w/p).read_bytes() for p in source)
assert numba.get_num_threads() == 1 and numba.config.DISABLE_JIT
assert all(p['num_threads'] == 1 for p in threadpoolctl.threadpool_info())
code = pytest.main([str(app/'tests/test_contact_intent.py'),
                   str(app/'tests/test_contact_intent_mapping.py'), '-q',
                   '--junitxml='+str(r/(label+'-inventory.xml'))])
imports = {n: str(Path(m.__file__).resolve()) for n,m in sys.modules.copy().items()
           if n.split('.')[0] == 'anysolver' and getattr(m, '__file__', None)}
(r/(label+'-imports.json')).write_text(json.dumps(imports, indent=2))
assert all(Path(p).is_relative_to((r/'site').resolve()) for p in imports.values())
assert all(sha(w/p) == h for p,h in source.items())
(r/(label+'-identity.json')).write_text(json.dumps({
    'wheel_sha256': sha(wheel), 'matching_modules': len(source),
    'anysolver': anysolver.__file__, 'anyfem': anyfem.__file__,
    'entry_order': 'import anyfem,anysolver,pytest before pytest.main',
    'plugin_autoload': 'normal environment, not disabled',
    'python': sys.version, 'threads': threadpoolctl.threadpool_info(),
    'numba_threads': numba.get_num_threads(), 'jit_disabled': bool(numba.config.DISABLE_JIT),
    'pytest_exit': int(code), 'onsite_imports': len(imports),
}, indent=2))
print(json.dumps({'pytest_exit': int(code), 'onsite_imports': len(imports)}))
sys.exit(code)
