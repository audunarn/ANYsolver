from pathlib import Path
import hashlib, json, zipfile

r = Path(__file__).resolve().parent
w = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
app = Path('C:/ANYworkspaceWork/ANYfem-contact-intent')
out = w/'docs/d1_review_support/contact_main_reconciliation_20261001'
out.mkdir(exist_ok=True)
archive = out/'raw-v1.zip'
assert not archive.exists()
entries = {}
for p in sorted(r.rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
        assert p.resolve().is_relative_to(r.resolve())
        entries['evidence/'+p.relative_to(r).as_posix()] = p
source = json.loads((r/'source-manifest.json').read_text())
for relative, expected in source.items():
    p = w/relative
    assert hashlib.sha256(p.read_bytes()).hexdigest() == expected
    entries['source/'+relative] = p
for relative in ('src/anyfem/solve/contact_intent.py', 'tests/test_contact_intent.py',
                 'tests/test_contact_intent_mapping.py', 'docs/contact_intent_task.md'):
    entries['application/'+relative] = app/relative
hashes = {name: hashlib.sha256(p.read_bytes()).hexdigest() for name,p in entries.items()}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name,p in entries.items():
        z.write(p, name)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(hashes)
    assert all(hashlib.sha256(z.read(name)).hexdigest() == h for name,h in hashes.items())
identity = {
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_bytes': archive.stat().st_size, 'verified_files': len(hashes),
    'files': hashes,
}
(out/'raw-v1-identity.json').write_text(json.dumps(identity, indent=2))
print(json.dumps({k:v for k,v in identity.items() if k != 'files'}))
