import json,runpy,subprocess,sys,time
from pathlib import Path
import psutil

repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
folder=Path(__file__).parent
tooling=runpy.run_path(str(repo/'scripts/run_portable_ci.py'))
records=[]
for label,root in (('source',repo/'src'),('installed',folder/'installed')):
    env=tooling['_worker_environment'](folder/label)
    env['NUMBA_DISABLE_JIT']='1'
    command=[sys.executable,'-I',str(folder/'example_check.py'),str(root),
             str(repo/'examples/general_contact_free_shell_sphere_impact.py'),str(folder/(label+'.json'))]
    started=time.monotonic();peak=0
    with (folder/(label+'.log')).open('w',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT)
        try:
            while child.poll() is None:
                try:
                    process=psutil.Process(child.pid)
                    peak=max(peak,sum(p.memory_info().rss for p in [process,*process.children(recursive=True)] if p.is_running()))
                except psutil.NoSuchProcess:pass
                if time.monotonic()-started>180 or peak>953*1024**2:
                    raise RuntimeError('owned installed check resource ceiling exceeded')
                time.sleep(.1)
        finally:
            tooling['_terminate_tree'](child)
    records.append(dict(label=label,command=command,elapsed_s=time.monotonic()-started,
        peak_sampled_bytes=peak,exit=child.returncode,limit_s=180,limit_mib=953))
    (folder/'resource.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    assert child.returncode==0,label
source=json.loads((folder/'source.json').read_text())
installed=json.loads((folder/'installed.json').read_text())
assert source['imports']==installed['imports'],'source/install module hash mismatch'
assert source['result']==installed['result'],'source/install numerical mismatch'
print(json.dumps(dict(result=installed['result'],matched_imports=len(source['imports']),resources=records),indent=2))
