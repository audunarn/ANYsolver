import hashlib,json,zipfile
from pathlib import Path

repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
folder=repo/'docs/d1_review_support/contact_c6_free_shell_sphere_20261003'
folder.mkdir(exist_ok=False)
history=repo/'docs/d1_review_support/GENERAL_CONTACT_RESTART_HISTORY_20261003_PART77.md'
assert not history.exists()
history.write_bytes((repo/'GENERAL_CONTACT_RESTART.md').read_bytes())
files=['src/anysolver/general_contact/free_rigid.py','src/anysolver/general_contact/transient.py',
       'src/anysolver/general_contact/shell_sphere_temporal_bounds.py',
       'tests/test_general_contact_shell_sphere_temporal_bounds.py',
       'tests/test_general_contact_transient_free_shell_sphere.py',
       'examples/general_contact_free_shell_sphere_impact.py','scripts/run_portable_ci.py']
manifest={file:hashlib.sha256((repo/file).read_bytes()).hexdigest() for file in files}
base=Path('C:/ANYworkspaceWork')
runs=['contact_free_shell_work_20261003','contact_free_shell_impact_20261003',
      'contact_free_shell_energy_20261003','contact_free_shell_compat_20261003',
      'contact_free_shell_side_20261003','contact_free_shell_modes_20261003','contact_free_shell_mpc_20261003',
      'q4-sphere-bounds-dev-20261003-a','q4-sphere-bounds-dev-20261003-b',
      'q4-sphere-bounds-dev-20261003-c','q4-sphere-bounds-dev-20261003-d']
raw={}
for name in runs:
    run=base/name
    log=base/(name+'.log')
    if log.exists():raw[name+'/runner.log']=log
    for file in run.glob('*.log'):raw[name+'/'+file.name]=file
    for file in run.glob('*.json'):raw[name+'/'+file.name]=file
    for sub in run.glob('anysolver-portable-ci-*/P01'):
        for file in sub.glob('*.json'):raw[name+'/'+str(file.relative_to(run)).replace('\\','/')]=file
package=base/'contact_free_shell_package_20261003'
for file in package.glob('*.json'):raw['package/'+file.name]=file
for file in package.glob('*.log'):raw['package/'+file.name]=file
for file in package.glob('*.py'):raw['package/'+file.name]=file
for suffix in ('build.log','build-local.log','install.log'):
    file=base/('contact_free_shell_package_20261003-'+suffix)
    if file.exists():raw['package/'+suffix]=file
with zipfile.ZipFile(folder/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for name,file in sorted(raw.items()):archive.write(file,name)
installed=json.loads((package/'installed.json').read_text())
record=dict(scope='source-tested development; no engineering acceptance or release',
    parent_commit='7b7a88c2',branch='codex/contact-main-reconcile-20261001',
    source_files_sha256=manifest,imported_installed_modules_sha256=installed['imports'],
    effective=installed['effective'],wheel_sha256=hashlib.sha256(
        (package/'wheels/anysolver-0.4.7-py3-none-any.whl').read_bytes()).hexdigest(),
    raw_members=list(sorted(raw)),source_identity_note='Final source hashes captured; not every intermediate kernel version was snapshotted. Portable selected-test hashes and failed logs retained.')
(folder/'source.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(dict(raw_records=len(raw),final_owned_hashes=len(manifest),
    installed_module_hashes=len(installed['imports']),evidence=str(folder)),indent=2))
