"""Independent affine DAE derivative oracles and public S3 integration."""

from itertools import product
from dataclasses import replace

import numpy as np
import pytest

from anysolver import ContactTransientSolverControls, TransientConfig, solve_transient_contact
from anysolver.general_contact.descriptor_rates import directional_descriptor_rate
from anysolver.general_contact.core import active_contact_manager
from test_general_contact_transient_plane import _guided_s3_descriptor_impact


@pytest.mark.parametrize("physical_rate", [-2., 0., 2.])
def test_two_coordinate_touch_matches_exact_right_derivative(physical_rate):
    k, c = 2., 3.
    rate = directional_descriptor_rate(
        np.diag([0., k]), np.array([[0.], [1.]]), np.array([physical_rate, 0.]),
        np.array([[1., 1.]]), np.array([c]), [False], [True],
    )
    exact = np.array([physical_rate, -c*physical_rate/(k+c) if physical_rate < 0 else 0.])
    np.testing.assert_allclose(rate, exact, atol=1e-15)
    # Direct right difference of the independently defined algebraic force.
    h = 1e-5
    q = h*rate
    algebraic_force = k*q[1]+c*min(q[0]+q[1], 0.)
    assert abs(algebraic_force/h) < 1e-14
    # The same oracle applies to acceleration at stationary touch; algebraic
    # coordinates have no inertia and do not obey full-coordinate Newmark.
    q = .5*h*h*rate
    assert abs((k*q[1]+c*min(q[0]+q[1], 0.))/(.5*h*h)) < 1e-14


def _enumerated_oracle(K, B, weights, fixed, switching, physical, offset):
    """Enumerate scalar inequalities and solve two algebraic unknowns directly."""
    for choices in product((False, True), repeat=int(np.count_nonzero(switching))):
        active = fixed.copy()
        active[switching] = choices
        A = K+B[active].T @ np.diag(weights[active]) @ B[active]
        result = np.r_[physical, np.linalg.solve(A[1:, 1:], -A[1:, 0]*physical-offset[1:])]
        gap_rate = B @ result
        if np.all(gap_rate[switching & active] <= 1e-13) and np.all(gap_rate[switching & ~active] >= -1e-13):
            return result
    raise AssertionError("oracle has no consistent branch")


@pytest.mark.parametrize("physical", [-1.3, .7])
def test_multiple_constraints_basis_scaling_and_offset_match_enumerated_oracle(physical):
    K = np.diag([0., 2., 3.])
    B = np.array([[1., 1., 0.], [1., 0., -1.], [0., 1., 1.]])
    weights = np.array([5., 7., 11.])
    fixed = np.array([True, False, False])
    switching = np.array([False, True, True])
    offset = np.array([0., 2., -3.])
    expected = _enumerated_oracle(K, B, weights, fixed, switching, physical, offset)
    for Z in (np.eye(3)[:, 1:], np.array([[0., 0.], [2., 0.], [0., 3.]])):
        seed = np.array([physical, 10., -8.])
        original = seed.copy()
        actual = directional_descriptor_rate(K, Z, seed, B, weights, fixed, switching, offset=offset)
        np.testing.assert_allclose(actual, expected, atol=2e-14)
        np.testing.assert_array_equal(seed, original)


def test_directional_iteration_exhaustion_is_explicit_and_does_not_mutate_seed():
    seed = np.array([1., 0.])
    args = (np.diag([0., 2.]), np.array([[0.], [1.]]), seed,
            np.array([[1., 1.]]), np.array([3.]), [False], [True])
    with pytest.raises(ValueError, match="limit exhausted"):
        directional_descriptor_rate(*args, offset=np.array([0., 10.]), maximum_iterations=1)
    np.testing.assert_array_equal(seed, [1., 0.])
    result = directional_descriptor_rate(*args, offset=np.array([0., 10.]), maximum_iterations=2)
    np.testing.assert_allclose(result, [1., -2.6])


def test_directional_s3_tilted_impact_restart_preserves_physical_newmark():
    controls = ContactTransientSolverControls(allow_s3_descriptor_dev=True, s3_one_sided_rates_dev=True)
    def solve(end, checkpoint=None, emit=False, supplied_controls=controls):
        model, contact, velocity = _guided_s3_descriptor_impact(tilt=.002, span=.1)
        return model, solve_transient_contact(
            model, contact, TransientConfig(.0002, end, initial_velocity=velocity),
            solver_controls=supplied_controls, restart_checkpoint=checkpoint,
            emit_restart_checkpoint=emit,
        )
    model, direct = solve(.012)
    assert direct.profile.endswith("NEWMARK_DIRECTIONAL_RATES_DEV_V1")
    assert any(c.active_pressure_dofs for c in direct.contact)
    _, prefix = solve(.011, emit=True)
    _, resumed = solve(.012, prefix.restart_checkpoint)
    for field in ("displacements", "velocities", "accelerations", "external_nodal_work_j"):
        np.testing.assert_allclose(
            np.concatenate((getattr(prefix, field), getattr(resumed, field)[1:])),
            getattr(direct, field), rtol=0., atol=1e-11,
        )
    with pytest.raises(ValueError, match="checkpoint analysis is incompatible"):
        solve(.012, prefix.restart_checkpoint, supplied_controls=replace(controls, s3_one_sided_rates_dev=False))
    physical = [model.mesh.dof_manager.get_node_dofs(node)[2] for node in (1, 2, 3)]
    for i in range(1, len(direct.times)):
        dt = direct.times[i]-direct.times[i-1]
        q0, q1 = direct.displacements[i-1:i+1, physical]
        v0, v1 = direct.velocities[i-1:i+1, physical]
        a0, a1 = direct.accelerations[i-1:i+1, physical]
        np.testing.assert_allclose(q1-q0-dt*v0-dt*dt*(a0+a1)/4, 0., atol=1e-12)
        np.testing.assert_allclose(v1-v0-dt*(a0+a1)/2, 0., atol=1e-10)
    assert active_contact_manager() is None


def test_directional_controls_require_explicit_s3_opt_in():
    with pytest.raises(ValueError, match="descriptor opt-in"):
        ContactTransientSolverControls(s3_one_sided_rates_dev=True)
