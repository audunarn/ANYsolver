from pathlib import Path
import hashlib, json, zipfile

out = Path(__file__).resolve().parent
repo = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest = repo/'docs/d1_review_support/contact_c6_directional_rates_20261001'
dest.mkdir(exist_ok=True)
files = {}
for i in range(1, 5):
    root = Path(f'C:/ANYworkspaceWork/contact-directional-rates-20261001-v{i}')
    for p in root.rglob('*'):
        if p.is_file() and (p.name in ('run.log', 'selection.json', 'resource.json', 'runtime.json')
                           or 'first-candidate' in p.parts):
            files[f'source-v{i}/'+p.relative_to(root).as_posix()] = p
review = Path('C:/ANYworkspaceWork/contact-directional-rate-review-20261001-v1')
for name in ('mistral.log', 'integration.log', 'launch.ps1', 'integration-launch.ps1'):
    if (review/name).is_file():
        files['review/'+name] = review/name
for p in out.rglob('*'):
    if p.is_file() and p.suffix in ('.json', '.log', '.xml', '.whl', '.py', '.ini'):
        if not any(n in p.parts for n in ('build-input', 'site', '__pycache__')):
            files['installed/'+p.relative_to(out).as_posix()] = p
for name in ('transient.py', 'descriptor_rates.py'):
    files['final-source/'+name] = repo/'src/anysolver/general_contact'/name
archive = dest/'raw-v1.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, p in sorted(files.items()):
        z.writestr(name, p.read_bytes())
identity = {name: hashlib.sha256(p.read_bytes()).hexdigest() for name, p in files.items()}
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(identity)
    assert all(hashlib.sha256(z.read(n)).hexdigest() == h for n, h in identity.items())
(dest/'raw-identity.json').write_text(json.dumps(identity, indent=2))
resources = {}
for i in range(1, 5):
    root = Path(f'C:/ANYworkspaceWork/contact-directional-rates-20261001-v{i}')
    resources[str(i)] = json.loads(next(root.rglob('resource.json')).read_text())
resources['installed'] = json.loads((out/'c6-directional-v2-execution.json').read_text())
(dest/'resources.json').write_text(json.dumps(resources, indent=2))
print(json.dumps(dict(files=len(files), zip_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                      resources=resources), indent=2))
