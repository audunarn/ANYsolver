"""Archive owned development evidence, with final source and installed identities."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

repo = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
workspace = Path('C:/ANYworkspaceWork')
package = workspace/'contact_nonuniform_s3_package_20261003'
destination = repo/'docs/d1_review_support/contact_c6_nonuniform_s3_driver_20261003'
destination.mkdir(parents=True, exist_ok=True)
source = json.loads((package/'source.json').read_text())
installed = json.loads((package/'installed.json').read_text())
assert source['imports'] == installed['imports']
assert source['result'] == installed['result']
for relative, digest in source['imports'].items():
    assert hashlib.sha256((repo/'src'/relative).read_bytes()).hexdigest() == digest
files = []
runtime_summary = []
for label in 'abcde':
    root = workspace/f'contact_nonuniform_s3_driver_{label}_20261003'
    files += [root.with_suffix('.log'), *root.rglob('*.json')]
    for path in root.rglob('runtime.json'):
        runtime = json.loads(path.read_text())
        assert not runtime['errors']
        assert runtime['jit_disabled'] and runtime['numba_threads'] == 1
        assert all(pool['num_threads'] == 1 for pool in runtime['effective_pools'])
        assert all(Path(value).is_relative_to(repo) for value in runtime['imports'].values())
        resource = json.loads(path.with_name('resource.json').read_text())
        assert resource['status'] == 'terminal'
        assert resource['limit_mib'] == 953
        runtime_summary.append(dict(label=label, outcomes=runtime['outcomes'],
            exit=runtime['exit_code'], imported_modules=len(runtime['imports']),
            jit_disabled=True, numba_threads=1, pool_threads=[pool['num_threads'] for pool in runtime['effective_pools']],
            elapsed_s=resource['elapsed_seconds'], peak_sampled_bytes=resource['peak_sampled_bytes']))
files += [path for path in package.iterdir() if path.is_file()]
files.append(Path(__file__))
wheel, = (package/'dist').glob('*.whl')
manifest = []
with zipfile.ZipFile(destination/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(set(files)):
        relative = path.relative_to(workspace).as_posix()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        archive.write(path,relative)
        manifest.append(dict(path=relative,sha256=digest))
paths = ['src/anysolver/general_contact/transient.py',
         'src/anysolver/general_contact/fixed_projection_s3_events.py',
         'src/anysolver/general_contact/shell_pair_hermite_sweep.py',
         'examples/general_contact_nonuniform_s3_impact_dev.py',
         'tests/test_general_contact_transient_nonuniform_s3.py']
record = dict(parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    source_sha256={path:hashlib.sha256((repo/path).read_bytes()).hexdigest() for path in paths},
    wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(),
    installed_import_hashes=len(source['imports']), example_parity=True,
    runtimes=runtime_summary,
    source_route=json.loads((package/'source-resource.json').read_text()),
    installed_route=json.loads((package/'installed-resource.json').read_text()),
    accounting=json.loads((workspace/'contact_nonuniform_s3_driver_c_20261003/nonuniform_s3_accounting.json').read_text()),
    raw_records=len(manifest),archive_manifest=manifest,
    status='implemented/source/installed-tested development; not engineering acceptance or release',
    historical_run_identity_note='Incremental development runs a-e predate final source. Retained logs/commands describe failures and corrections; final source hashes and installed parity are exact. No retrospective frozen acceptance claim.')
(destination/'source.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(raw_records=len(manifest), imported_hashes=len(source['imports']),
    wheel_sha256=record['wheel_sha256'], runtimes=runtime_summary),indent=2))
