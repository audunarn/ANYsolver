from pathlib import Path
import hashlib, json, sys, zipfile
from importlib import metadata
import numba, pytest, threadpoolctl

r = Path.cwd()
site = r/'site'
w = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads((r/'source-manifest.json').read_text())
wheel, = (r/'wheels').glob('*.whl')
assert all(sha(w/p) == h for p, h in source.items())
with zipfile.ZipFile(wheel) as z:
    files = {p for p in z.namelist() if p.startswith('anysolver/') and p.endswith('.py')}
    assert files == {p.replace('src/', '', 1) for p in source}
    assert all(z.read(p) == (site/p).read_bytes() == (w/'src'/p).read_bytes() for p in files)
pools = threadpoolctl.threadpool_info()
assert pools and all(p['num_threads'] == 1 for p in pools)
assert numba.config.DISABLE_JIT and numba.get_num_threads() == 1
label = sys.argv[1]
if label.startswith('app-'):
    sys.path.insert(0, 'C:/ANYworkspaceWork/ANYfem-contact-intent/src')
if label == 'app-preimport-guard':
    # Retain the failing entry order as a diagnostic; do not silently replace it.
    import anyfem, anysolver
identity = {
    **json.loads((r/'source-identity.json').read_text()),
    'wheel_sha256': sha(wheel), 'matching_modules': len(files),
    'python': sys.version, 'site': str(site), 'threads': pools,
    'numba_threads': numba.get_num_threads(), 'jit_disabled': True,
    'fixtures_sha256': {p.relative_to(r).as_posix(): sha(p) for p in
                       [*(r/'fixtures').glob('*.py'), *(r/'scripts').glob('*.py'), *(r/'examples').glob('*.py')]},
    'dependencies': {n: metadata.version(n) for n in
                     ('numpy','scipy','numba','pytest','threadpoolctl','ANYmaterial','ANYmesher','ANYfileio')},
}
(r/(label+'-identity.json')).write_text(json.dumps(identity, indent=2))
targets = [str(r/'fixtures'/v.split('::')[0])+
           ('::'+v.split('::',1)[1] if '::' in v else '') for v in sys.argv[2:]]
code = pytest.main(['-q', '-c', str(r/'pytest.ini'),
                   '--basetemp='+str(r/(label+'-states')),
                   '--junitxml='+str(r/(label+'-inventory.xml')), *targets])
imports = {n: str(Path(m.__file__).resolve()) for n, m in sys.modules.copy().items()
           if n.split('.')[0] == 'anysolver' and getattr(m, '__file__', None)}
(r/(label+'-imports.json')).write_text(json.dumps(imports, indent=2))
assert imports and all(Path(p).is_relative_to(site.resolve()) for p in imports.values())
assert all(sha(w/p) == h for p,h in source.items())
assert numba.get_num_threads() == 1
assert all(p['num_threads'] == 1 for p in threadpoolctl.threadpool_info())
if label.startswith('app-'):
    assert Path(sys.modules['anyfem'].__file__).resolve().is_relative_to(
        Path('C:/ANYworkspaceWork/ANYfem-contact-intent/src').resolve())
print(json.dumps({'pytest_exit': int(code), 'onsite_imports': len(imports), 'label': label}), flush=True)
sys.exit(code)
