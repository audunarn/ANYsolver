from pathlib import Path
import hashlib,json,zipfile,sys,platform
from importlib.metadata import version

root=Path('C:/ANYworkspaceWork/contact_chain_endcaps_20261004')
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=repo/'docs/d1_review_support/contact_chain_endcaps_20261004';dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=[];runs={}
for folder in sorted(root.iterdir()):
    if not folder.is_dir() or not (folder/'resource.json').exists():continue
    runtime=json.loads((folder/'runtime.json').read_text(encoding='utf-8')) if (folder/'runtime.json').exists() else None
    runs[folder.name]={'resource':json.loads((folder/'resource.json').read_text(encoding='utf-8')),
                      'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend((p,folder.name+'/'+p.name) for p in folder.iterdir() if p.is_file())
final=root/'installed_final';imports=json.loads((final/'imports.json').read_text(encoding='utf-8'))
runtime=json.loads((final/'runtime.json').read_text(encoding='utf-8'))
assert not imports['errors'] and not runtime['errors']
assert runtime['jit_disabled'] and runtime['numba_threads']==1
assert all(pool['num_threads']==1 for pool in runtime['effective_pools'])
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    relative=Path(row['path']).relative_to(root/'installed/anysolver')
    assert sha(repo/'src/anysolver'/relative)==row['sha256'],relative
    loaded.append({'module':name,**row})
for p in (root/'installed/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed/anysolver')
    assert sha(p)==sha(repo/'src/anysolver'/relative),relative
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
parity=dest/'installed_parity.json'
parity.write_text(json.dumps({'loaded':loaded,'package':package},indent=2),encoding='utf-8')
review=dest/'source_review.md';review.write_bytes((root/'source_review.md').read_bytes())
source=('src/anysolver/general_contact/beam_chain_ends.py','src/anysolver/general_contact/beam_chain_end_geometry.py',
    'src/anysolver/general_contact/beam_pair_ends.py','src/anysolver/general_contact/core.py',
    'tests/test_general_contact_beam_chain_ends.py','examples/general_contact_beam_chain_ends.py')
raw.extend(((parity,'installed_parity.json'),(review,'source_review.md')))
raw.extend((root/p,p) for p in ('run.py','collect.py','design.md','geometry_report.md','check_geometry.py','geometry_check.log'))
raw.extend((repo/p,'candidate/'+p) for p in source)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p,name in raw:archive.write(p,name)
bars={p.stem:json.loads(p.read_text(encoding='utf-8')) for p in final.glob('bar_*.json')}
errors={name:max(abs(a-b)/abs(a) for a,b in zip(row['independent_displacement_m'],row['solved_displacement_m']) if a)
        for name,row in bars.items()}
summary={'scope':'D3 explicit nearest-curve B2 chain physical-end work; developmental code verification, not engineering acceptance',
    'source_parent':'f2f0010ce5fc8dbb2e53eb5a6cea7c8623c91b57','source_files':{p:sha(repo/p) for p in source},
    'wheels':{p.name:sha(p) for p in (root/'dist').glob('*.whl')},'runs':runs,
    'installed_modules_matching':len(loaded),'installed_package_files_matching':len(package),
    'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],
    'effective_pools':runtime['effective_pools'],'independent_bar_relative_errors':errors,
    'bar_relative_target':1e-6,'bar_gap_budget_m':1e-5,'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
    'environment':{'python':sys.version,'platform':platform.platform(),
        'versions':{name:version(name) for name in ('numpy','scipy','numba','ANYmaterial','ANYgeometry')}},
    'review_disposition':'source03 reproduces nonreciprocal cap activation admitted by independent endpoint paths; common all-end interval proof now binds reciprocal partners, cutback and candidate/work admission; installed source04/source05 successor checks pass',
    'retained_failures':'source02 fixture confounded nearest-feature tie with zero ownership; corrected finite-normal independent fixture. source03 actual reciprocal swept-admission mechanics omission retained before correction; no scientific tolerance change.',
    'supporting_geometry_checks':'1045 exact assertions passed in 1.57s; source explicitly pinned but memory/runtime settings uninstrumented; supporting only, no measured cap claim',
    'limits':'180s/953MiB process tree measured runs; one-to-sixteen elastic scalar/von-Karman B2 cells/side and existing candidate cap; explicit hemisphere point penalties; strict resolved feature branches or shared equivalent material junction; no B3/generalized closed switches, native/friction/dynamics, normal application admission, release or independent engineering acceptance'}
(dest/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({'runs':len(runs),'raw_records':len(raw),'modules':len(loaded),'package_files':len(package),
    'outcomes':runs['installed_final']['outcomes'],'resource':runs['installed_final']['resource'],'bar_errors':errors}))
