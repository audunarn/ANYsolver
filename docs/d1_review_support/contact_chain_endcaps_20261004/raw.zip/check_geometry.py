import sys
sys.dont_write_bytecode = True
sys.path.insert(0, 'C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001/src')
from fractions import Fraction as F
import random
from anysolver.general_contact.beam_chain_end_geometry import (
    nearest_endpoint_feature as nearest, admissible_chain_endpoint_path as path,
    _polynomials, _distance_bounds,
)
from anysolver.general_contact.beam_pair_end_geometry import _affine, endpoint_feature

checks = 0
def check(value):
    global checks
    assert value
    checks += 1
def reject(call):
    try:
        call()
    except ValueError:
        check(True)
    else:
        raise AssertionError('expected active tie rejection')

# Source end 1 is leftward-facing, making ownership strict negative below.
source = ((1, 0, 0), (0, 0, 0))
interior = (((-1, -1, 0), (-1, 1, 0)),)
node_pairs = ((10, 11),)
result = nearest(source, interior, node_pairs, 1, 2)
check(result.owner == 0 and result.feature.interior and result.feature.ownership < 0)
check(path(source, source, interior, interior, node_pairs, 1, 2, 0))
shared = (((-1, -2, 0), (-1, -1, 0)), ((-1, -1, 0), (-1, -2, 1)))
shared_nodes = ((10, 11), (11, 12))
result = nearest(source, shared, shared_nodes, 1, 2)
check(result.target_node == 11 and result.tied_owners == (0, 1))
check(path(source, source, shared, shared, shared_nodes, 1, 2, 0, allowed_target_nodes={11}))
check(not path(source, source, shared, shared, shared_nodes, 1, 2, 3, allowed_target_nodes={10, 12}))
reject(lambda: nearest(source, shared, ((10, 11), (14, 12)), 1, 2))
reject(lambda: nearest(source, interior*2, node_pairs*2, 1, 2))
projection_tie = (((-1, 0, 0), (-1, 1, 0)),)
reject(lambda: nearest(source, projection_tie, node_pairs, 1, 2))
check(not path(source, source, projection_tie, projection_tie, node_pairs, 1, 2, 3))
ownership_tie = (((0, -1, 0), (0, 1, 0)),)
reject(lambda: nearest(source, ownership_tie, node_pairs, 1, 2))
check(nearest(source, shared, ((10, 11), (14, 12)), 1, F(1, 2)).owner == 0)
check(path(source, source, shared, shared, ((10, 11), (14, 12)), 1, F(1, 2), 0))
check(path(source, source, projection_tie, projection_tie, node_pairs, 1, 1, 0))

# Distinct active nearest switch rejects; the same switch with small radius opens.
targets0 = (((-1, -1, 0), (-1, 1, 0)), ((-2, -1, 0), (-2, 1, 0)))
targets1 = tuple(reversed(targets0))
two_nodes = ((10, 11), (12, 13))
check(not path(source, source, targets0, targets1, two_nodes, 1, 3, 4))
check(path(source, source, targets0, targets1, two_nodes, 1, F(1, 2), 0))

# Shared material node identity persists under affine movement.
move = lambda segment: tuple(tuple(F(c)+F(1, 4) if j == 0 else F(c)
                                    for j, c in enumerate(point)) for point in segment)
moving_shared = tuple(move(segment) for segment in shared)
check(path(source, source, shared, moving_shared, shared_nodes, 1, 2, 2, allowed_target_nodes={11}))

# Selection-cut clamp is open at both endpoint poses but closed inside the path.
cut0 = (((-1, -1, 0), (-2, -1, 0)),)
cut1 = (((-1, 1, 0), (-2, 1, 0)),)
check(not path(source, source, cut0, cut1, node_pairs, 1, F(5, 4), 5, allowed_target_nodes=set()))
check(path(source, source, cut0, cut1, node_pairs, 1, F(5, 4), 0, allowed_target_nodes={10}))

# Non-nearest projection ties do not replace the minimum-over-curves decision.
remote = tuple(((10+i, 0, 0), (10+i, 1, 0)) for i in range(15))
many = interior+remote
many_nodes = node_pairs+tuple((20+2*i, 21+2*i) for i in range(15))
check(path(source, source, many, many, many_nodes, 1, 2, 0))
check(nearest(source, many, many_nodes, 1, 2).owner == 0)

# Random exact distance enclosure checks against rational point evaluations.
rng = random.Random(441)
for case in range(180):
    def segment():
        return tuple(tuple(F(rng.randrange(-20, 21), 7) for _ in range(3)) for _ in range(2))
    a0, a1, b0, b1 = (segment() for _ in range(4))
    first = tuple(_affine(x, y) for x, y in zip(a0, a1))
    second = tuple(_affine(x, y) for x, y in zip(b0, b1))
    values = _polynomials(first, second, case % 2)
    lower, upper = _distance_bounds(values)
    for t in (F(0), F(1, 11), F(1, 2), F(8, 11), F(1)):
        pose = lambda before, after: tuple(tuple((1-t)*x+t*y for x,y in zip(p,q)) for p,q in zip(before,after))
        actual = endpoint_feature(pose(a0,a1), pose(b0,b1), case % 2, 1).squared_distance
        check(lower <= actual)
        if upper is not None:
            check(actual <= upper)
print(f'PASS {checks} exact geometry assertions; deterministic seed 441')
