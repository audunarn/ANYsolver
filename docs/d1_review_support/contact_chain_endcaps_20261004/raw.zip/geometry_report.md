# Chain endpoint geometry implementation report

Supporting development implementation; this report is not independent acceptance,
engineering qualification or release evidence.

## Scope and result

Created only the new repository source file:
`C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001/src/anysolver/general_contact/beam_chain_end_geometry.py`.
No commits, branch changes, other repository edits or workers were launched.
The file is untracked for lead integration. Git inspections reported an existing
user Git-ignore access warning; the source status was still obtained.

The module exports `NearestEndpointFeature` with `owner`, `feature`,
`target_node`, and `tied_owners`, plus `nearest_endpoint_feature` and
`admissible_chain_endpoint_path`.

The nearest resolver compares exact rational squared distances over target
segments. Active raw projection ties, zero ownership and distinct tied features
raise `ValueError`. Strict clamps to the same material-node ID and exact point
are equivalent, with the smallest target index chosen deterministically. Open
ties may choose deterministically, while retaining all tied target indices.

The path certificate uses exact affine coordinate Bernstein controls. Each
recursive interval recomputes dot products and squared norms from split
coordinates. Lower distance bounds combine point/segment coordinate hulls,
infinite-line numerator over positive squared-length bounds, and branch-specific
squared distance when available. Strict winners use a squared-distance upper
bound below every nongroup lower bound. Shared groups require strict clamps,
the same material-node identity and identical coordinate polynomials throughout
the interval. Source ownership must have a strict sign. All-target opening can
bypass nearest branch restrictions. Samples choose/reject candidates only.

Added the requested keyword `allowed_target_nodes=None`; when supplied, active
clamps at other nodes reject. This prevents an intermediate closed selection
cut from admission even when both endpoint poses are open. `None` leaves that
topology decision to the caller.

## Checks actually run

Command (Python 3.14, bytecode writes disabled):
`python -B C:/ANYworkspaceWork/contact_chain_endcaps_20261004/check_geometry.py`.
The final run completed in approximately 1.57 seconds with 1045 exact geometry
assertions passing. Maximum process memory was not instrumented; this is not a
measured memory-cap claim. No tests approaching the 180-second limit were run.

Evidence:
- Script: `C:/ANYworkspaceWork/contact_chain_endcaps_20261004/check_geometry.py`.
- Final stdout: `C:/ANYworkspaceWork/contact_chain_endcaps_20261004/geometry_check.log`.

Checks cover strict interior features, shared junction clamps, different-node
and duplicate-interior active ties, raw projection and ownership ties, exact
opening/touching, active/open nearest switches, moving shared coordinates,
allowed topology, intermediate forbidden selection cuts, and a 16-target case
with irrelevant non-nearest projection ties. A seeded set of 180 random affine
segment pairs checks rational distance lower/upper enclosures against five exact
parameter values per pair. Those sampled algebra checks test bound consistency;
they do not constitute a path certificate or scientific acceptance.

The script was extended after its first successful run to replace a selection
cut fixture whose intermediate segment collapsed with a constant-length fixture
that isolates the topology restriction, and to cover the 16-target limit. The
final 1045-assertion run supersedes the earlier 1042-assertion stdout; neither
run reported failure.

## Limits and handoff

Caller retains physical regularity, whole-chain gap, distributed-line plateau,
source end membership, eligible-node construction and cap/cap reciprocity.
The certificate does not admit unresolved active nearest switches. Coarse
interval enclosures may return `False` for admissible geometry at finite depth;
such a result is a failed certificate, not proof of a mechanics defect. Source
and target coordinates remain exact Fractions when supplied as Fractions; float
inputs are converted to their exact rational representations.
