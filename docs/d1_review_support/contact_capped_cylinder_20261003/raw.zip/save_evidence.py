from pathlib import Path
import hashlib,json,zipfile,platform,sys

ROOT=Path(__file__).parent
SOLVER=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
OUT=SOLVER/'docs/d1_review_support/contact_capped_cylinder_20261003'
OUT.mkdir(parents=True,exist_ok=True)
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
installed=ROOT/'installed/anysolver'; source=SOLVER/'src/anysolver'
package_files={str(p.relative_to(source)):digest(p) for p in source.rglob('*')
               if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
package_errors=[name for name,value in package_files.items()
                if not (installed/name).is_file() or digest(installed/name)!=value]
imports=json.loads((ROOT/'installed_final/imports.json').read_text())
module_errors=[]
for name,row in imports['modules'].items():
    if not name.startswith('anysolver'): continue
    original=source/Path(row['path']).relative_to(installed)
    if digest(original)!=row['sha256']: module_errors.append(name)
assert not package_errors and not module_errors and not imports['errors']
runs={p.name:json.loads((p/'resource.json').read_text()) for p in sorted(ROOT.iterdir())
      if p.is_dir() and (p/'resource.json').is_file()}
files=[SOLVER/'src/anysolver/general_contact/capped_cylinder.py',
       SOLVER/'src/anysolver/general_contact/core.py',SOLVER/'src/anysolver/__init__.py',
       SOLVER/'src/anysolver/general_contact/__init__.py',
       SOLVER/'tests/test_general_contact_capped_cylinder.py',
       SOLVER/'examples/general_contact_round_beam_capped_cylinder.py']
summary={'scope':'development implementation and installed checks; not independent engineering acceptance',
    'base_solver_sha':'999bcaea0c8d5b73b636e28d783075ca27244834',
    'candidate_files':{str(p.relative_to(SOLVER)):digest(p) for p in files},
    'python':sys.version,'platform':platform.platform(),'runs':runs,
    'installed_final':'37 installed checks + 1 historical lazy source-child compatibility check passed',
    'installed_lazy_corrected':'1 additional actual installed-root no-contact/lazy export check passed',
    'installed_reference_measure':'1 additional owner-enforced straight-midpoint reference rejection passed',
    'source_final':'34 checks passed before two additive capability/lazy tests',
    'loaded_solver_modules':sum(n.startswith('anysolver') for n in imports['modules']),
    'package_files':len(package_files),'package_errors':package_errors,'module_errors':module_errors,
    'wheel_sha256':{p.name:digest(p) for p in (ROOT/'dist').glob('*.whl')},
    'resource_limits':{'seconds':180,'MiB':953},
    'review_limits':['same-family source scrutiny, no independent engineering acceptance',
        'exterior-centreline restriction closes known medial-seam interface defect',
        'adaptive mixed-panel Gauss estimate is not a rigorous general integration-error certificate']}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
archive=[]
for p in ROOT.iterdir():
    if not p.is_dir() or not (p/'resource.json').is_file(): continue
    archive.extend(f for f in p.rglob('*') if f.is_file() and f.suffix in ('.json','.log') and 'temp' not in f.parts)
archive.extend((ROOT/'run.py',ROOT/'save_evidence.py'))
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in archive: z.write(p,p.relative_to(ROOT))
print(json.dumps({'raw_records':len(archive),'package_files':len(package_files),
    'solver_modules':summary['loaded_solver_modules'],'runs':len(runs),'summary':str(OUT/'summary.json')}))
