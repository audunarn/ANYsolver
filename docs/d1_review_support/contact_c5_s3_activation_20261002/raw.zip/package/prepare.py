from pathlib import Path
import hashlib,json,shutil,subprocess,sys

out=Path(__file__).resolve().parent
repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
old=Path('C:/ANYworkspaceWork/contact-friction-static-package-v2-20261002')
build=out/'build-input'
build.mkdir()
for name in ('pyproject.toml','README.md','LICENSE','COPYRIGHT','THIRD_PARTY_NOTICES.md'):
    shutil.copy2(repo/name,build/name)
shutil.copytree(repo/'src/anysolver',build/'src/anysolver',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
(out/'fixtures').mkdir()
for name in ('test_general_contact_s3_friction_activation.py','test_general_contact_s3_friction_integration.py','test_general_contact_s3_sliding_friction.py','test_general_contact_s3_friction_static.py',
             'test_general_contact_s3_friction_pair.py'):
    shutil.copy2(repo/'tests'/name,out/'fixtures'/name)
shutil.copy2(repo/'examples/general_contact_s3_friction_static.py',out/'fixtures/friction_example.py')
(out/'fixtures/test_friction_example.py').write_text('''import pytest
from friction_example import run_example

@pytest.mark.parametrize("material_anchor",[False,True])
def test_installed_example(material_anchor):
    result=run_example(material_anchor=material_anchor)
    assert result.status=="completed"
    assert result.info["force_displacement_history"][-1]["friction"]["profile"].endswith("DEV_V1")
''')
for name in ('run_installed.py','run_bounded.py'):
    shutil.copy2(old/name,out/name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={p.relative_to(repo).as_posix():sha(p) for p in (repo/'src/anysolver').rglob('*.py')}
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
parent=subprocess.check_output(['git','-c','safe.directory='+str(repo),'rev-parse','HEAD'],cwd=repo,text=True).strip()
(out/'source-identity.json').write_text(json.dumps(dict(parent=parent,
    scope='planar S3 constant-normal affine first-touch activation history development',module_count=len(manifest)),indent=2))
(out/'pytest.ini').write_text('[pytest]\naddopts = -p no:cacheprovider\n')
with (out/'build.log').open('w') as log:
    subprocess.run([sys.executable,'-m','pip','wheel','--no-cache-dir','--no-index','--no-deps',
        '--no-build-isolation',str(build),'-w',str(out/'wheels')],stdout=log,stderr=log,check=True)
    wheel,=(out/'wheels').glob('*.whl')
    subprocess.run([sys.executable,'-m','pip','install','--no-cache-dir','--no-index','--no-deps',
        '--target',str(out/'site'),str(wheel)],stdout=log,stderr=log,check=True)
print(json.dumps(dict(wheel_sha256=sha(wheel),modules=len(manifest))))



