import pytest
from friction_example import run_example

@pytest.mark.parametrize("material_anchor",[False,True])
def test_installed_example(material_anchor):
    result=run_example(material_anchor=material_anchor)
    assert result.status=="completed"
    assert result.info["force_displacement_history"][-1]["friction"]["profile"].endswith("DEV_V1")
