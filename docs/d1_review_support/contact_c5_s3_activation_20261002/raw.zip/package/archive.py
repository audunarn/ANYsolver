from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET

repo=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
root=Path(__file__).resolve().parent
dest=repo/'docs/d1_review_support/contact_c5_s3_activation_20261002'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'source-manifest.json').read_text())
assert all(sha(repo/p)==h for p,h in manifest.items())
entries=[]
def add(path,name):
    assert path.is_file()
    entries.append((path,name))
for p in root.iterdir():
    if p.is_file() and p.suffix in {'.py','.json','.log','.xml','.ini'}:
        add(p,'package/'+p.name)
for folder in ('fixtures','wheels'):
    for p in (root/folder).iterdir():
        if p.is_file():add(p,'package/'+folder+'/'+p.name)
for name in ('contact-friction-activation-baseline-20261002.log',
             'contact-friction-activation-source-20261002.log',
             'contact-friction-activation-coupled-20261002.log',
             'contact-friction-activation-design-review-20261002.log',
             'contact-friction-activation-source-review-20261002.log'):
    p=Path('C:/ANYworkspaceWork')/name
    add(p,'development/'+name)
for p in ('src/anysolver/general_contact/s3_sliding_friction.py',
          'src/anysolver/general_contact/s3_friction_touch.py','tests/test_general_contact_s3_friction_activation.py','tests/test_general_contact_s3_friction_integration.py',
          'tests/test_general_contact_s3_sliding_friction.py',
          'examples/general_contact_s3_friction_static.py'):
    add(repo/p,'source/'+p)
for p in Path('C:/ANYworkspaceWork/contact-friction-activation-baseline-inputs-20261002').iterdir():
    if p.is_file():add(p,'failed-inputs/'+p.name)
for name in ('contact-friction-activation-seam-20261002.log','contact-friction-activation-final-source-20261002.log'):
    add(Path('C:/ANYworkspaceWork')/name,'development/'+name)
passed=set()
for label in ('focused',):
    tree=ET.parse(root/(label+'-inventory.xml'))
    for t in tree.findall('.//testcase'):
        if not any(t.find(k) is not None for k in ('failure','error','skipped')):
            passed.add((t.get('classname'),t.get('name')))
assert len(passed)==32,len(passed)
index={'source_parent':json.loads((root/'source-identity.json').read_text())['parent'],
       'unique_installed_passed_checks':len(passed),
       'artifact':str(root),'files':[{'path':n,'bytes':p.stat().st_size,'sha256':sha(p)} for p,n in entries]}
archive=dest/'raw.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p,n in entries:z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(v['path'])).hexdigest()==v['sha256'] for v in index['files'])
index.update(zip_sha256=sha(archive),readback='PASS',file_count=len(entries),
             raw_bytes=sum(v['bytes'] for v in index['files']))
(dest/'raw_index.json').write_text(json.dumps(index,indent=2),encoding='utf-8')
print(json.dumps({k:index[k] for k in ('unique_installed_passed_checks','file_count','raw_bytes','zip_sha256','readback')}))

