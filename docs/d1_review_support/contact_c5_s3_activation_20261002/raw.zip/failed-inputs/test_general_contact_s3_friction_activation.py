"""Independent first-touch slider reference, not a general friction admission."""
from dataclasses import replace

import numpy as np
import pytest

from anysolver.general_contact.s3_sliding_friction import S3SlidingFrictionManager
from anysolver.general_contact.s3_patch_static import GeneralS3PatchManager
from test_general_contact_s3_sliding_friction import _manager
from test_general_contact_s3_friction_static import _mode


def _slider(steps):
    model,definition,normal_settings,friction,_unused=_manager()
    manager=S3SlidingFrictionManager(model,GeneralS3PatchManager(model,definition,normal_settings),
        replace(friction,source_quadrature_refinement=3))
    x,z=(_mode(model,(1,2,3),a) for a in (0,2))
    dissipation=0.
    for tau in np.linspace(0,1,steps+1)[1:]:
        u=tau*(.1*x-.02*z)
        candidate=manager.prepare_commit(u)
        dissipation+=candidate[2]["dissipation_increment_j"]
        manager.commit(candidate)
    reaction=x@manager._friction(u)[0]
    return float(reaction),dissipation


def test_simultaneous_approach_slide_resolves_first_touch_reaction():
    # g(tau)=.015-.02*tau, so tau_touch=.75. In active contact
    # p=20*(tau-.75), cap=6*(tau-.75), elastic_gap=.006*(tau-.75).
    # dx/dtau=.1 > d(elastic_gap)/dtau=.006: slip starts at touch.
    reaction,dissipation=_slider(1)
    assert reaction==pytest.approx(.08*.3*5,rel=1e-3),(reaction,dissipation)
