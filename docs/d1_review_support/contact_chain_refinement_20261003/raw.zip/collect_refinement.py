from pathlib import Path
import hashlib,json,zipfile
root=Path('C:/ANYworkspaceWork/contact_chain_consistent_20261003')
solver=Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
dest=solver/'docs/d1_review_support/contact_chain_refinement_20261003'
dest.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tags=('partial_foundation_first','partial_foundation_merit','exact_owner_discriminator',
      'exact_owner_source','canonical_tie_guards','build_refinement','install_refinement',
      'installed_refinement','installed_independent_gap')
raw=[];runs={}
for tag in tags:
    folder=root/tag
    resource=json.loads((folder/'resource.json').read_text()) if (folder/'resource.json').exists() else None
    runtime=json.loads((folder/'runtime.json').read_text()) if (folder/'runtime.json').exists() else None
    runs[tag]={'resource':resource,'outcomes':runtime.get('outcomes') if runtime else None}
    raw.extend(p for p in folder.iterdir() if p.is_file())
final=root/'installed_refinement'
imports=json.loads((final/'imports.json').read_text());runtime=json.loads((final/'runtime.json').read_text())
assert not imports['errors'] and not runtime['errors']
loaded=[];package=[]
for name,row in imports['modules'].items():
    if not(name=='anysolver' or name.startswith('anysolver.')):continue
    path=Path(row['path']);relative=path.relative_to(root/'installed2/anysolver')
    assert sha(solver/'src/anysolver'/relative)==row['sha256']
    loaded.append({'module':name,**row})
for p in (root/'installed2/anysolver').rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    relative=p.relative_to(root/'installed2/anysolver');assert sha(p)==sha(solver/'src/anysolver'/relative)
    package.append({'relative':relative.as_posix(),'sha256':sha(p)})
parity=dest/'installed_parity.json';parity.write_text(json.dumps({'loaded':loaded,'package':package},indent=2));raw.append(parity)
reference=[]
for p in sorted((root/'installed_independent_gap').glob('foundation_*.json')):
    r=json.loads(p.read_text())
    reference.append({k:r[k] for k in ('cells','line_stiffness_n_per_m2','reaction_n','oracle_reaction_n',
        'oracle_equilibrium_n','displacement_relative_error','reaction_relative_error',
        'independent_minimum_gap_m','normalized_contact_force_balance')})
benchmark=json.loads((final/'actual_result.json').read_text())
raw.extend((root/'run.py',root/'collect_refinement.py',dest/'review.md'))
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p in raw:archive.write(p,p.relative_to(root).as_posix() if p.is_relative_to(root) else p.name)
summary={'scope':'D3 small-motion B2 partial-contact code verification and mesh/penalty sensitivity; not engineering acceptance',
    'source_parent':'8d584718','source_files':{p:sha(solver/p) for p in ('src/anysolver/general_contact/beam_chain_consistent.py',
        'tests/test_general_contact_beam_chain_consistent.py','tests/test_general_contact_beam_chain_refinement.py')},
    'wheels':{p.name:sha(p) for p in (root/'dist2').glob('*.whl')},'runs':runs,
    'reference_cases':reference,'reference_error_target':1e-6,'normal_gap_budget_m':1e-7,
    'benchmark':{k:benchmark[k] for k in ('scope','times_s','median_s','speed_ratio','displacement_difference_norm_m')},
    'imported_modules_matching':len(loaded),'package_files_matching':len(package),
    'effective_jit_disabled':runtime['jit_disabled'],'effective_numba_threads':runtime['numba_threads'],
    'effective_pools':runtime['effective_pools'],'raw_records':len(raw),'raw_sha256':sha(dest/'raw.zip'),
    'restrictions':'fixed-target small-motion fixture; no finite-motion/continuum/profile/application acceptance; original scientific and resource limits retained'}
(dest/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'runs':len(runs),'raw_records':len(raw),'modules':len(loaded),'package_files':len(package),
    'maximum_displacement_error':max(r['displacement_relative_error'] for r in reference),
    'maximum_reaction_error':max(r['reaction_relative_error'] for r in reference),
    'median_s':summary['benchmark']['median_s'],'speed_ratio':summary['benchmark']['speed_ratio']}))
