"""Disposable observation of existing evaluations; no extra material trials."""
import json
from pathlib import Path

import numpy as np

from test_general_contact_event_subdivision import _solve
import anysolver.general_contact.transient as driver


def test_observe_restart_rate_recovery(monkeypatch):
    assembly = driver._assemble_nonlinear_system
    rates = driver._consistent_s3_descriptor_rates
    matrices = []
    records = []

    def observe_assembly(*args, **kwargs):
        result = assembly(*args, **kwargs)
        if kwargs.get('tangent'):
            matrices.append(result[1].copy())
        return result

    def observe_rates(*args, **kwargs):
        before = len(matrices)
        result = rates(*args, **kwargs)
        T, q, h = args[1], args[4], args[9]
        pair = matrices[before:]
        full_v = np.asarray(T @ result[0]).reshape(-1)
        curvature = np.asarray(T.T @ ((pair[-2]-pair[-1]) @ full_v)).reshape(-1)/(2*h)
        records.append(dict(q=q.tolist(), incoming_a=args[6].tolist(),
            outgoing_a=result[1].tolist(), curvature=curvature.tolist(),
            touches=list(kwargs.get('event_touch_indices',()))))
        return result

    monkeypatch.setattr(driver, '_assemble_nonlinear_system', observe_assembly)
    monkeypatch.setattr(driver, '_consistent_s3_descriptor_rates', observe_rates)
    _, direct = _solve(.016)
    direct_records = records.copy()
    records.clear()
    _, prefix = _solve(direct.localized_contact_event_times[0], emit=True)
    prefix_records = records.copy()
    records.clear()
    _, resumed = _solve(.016, prefix.restart_checkpoint)
    joined = np.concatenate((prefix.accelerations,resumed.accelerations[1:]))
    delta = joined-direct.accelerations
    payload = dict(direct=direct_records,prefix=prefix_records,resumed=records,
        times=direct.times.tolist(),direct_a=direct.accelerations.tolist(),
        joined_a=joined.tolist(), max_difference=float(np.max(abs(delta))),
        max_curvature=max(float(np.max(np.abs(r['curvature']))) for r in direct_records+prefix_records+records))
    Path('C:/ANYworkspaceWork/contact-event-continuation-diagnostic-20261001.json').write_text(json.dumps(payload))
    assert payload['max_curvature'] >= 0
