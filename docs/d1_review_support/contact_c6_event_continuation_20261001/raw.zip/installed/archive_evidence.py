from pathlib import Path
import hashlib, json, zipfile

repo = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
workspace = Path('C:/ANYworkspaceWork')
package = Path(__file__).resolve().parent
out = repo/'docs/d1_review_support/contact_c6_event_continuation_20261001'
entries = {}
for version in range(1,8):
    root = workspace/f'contact-event-continuation-20261001-v{version}'
    for p in root.rglob('*'):
        if p.is_file():
            entries[f'source-v{version}/{p.relative_to(root).as_posix()}'] = p
    log = workspace/f'contact-event-continuation-20261001-v{version}.log'
    if log.exists():
        entries[f'source-v{version}/runner.log'] = log
for p in (workspace/'contact-event-review-20261001').rglob('*'):
    if p.is_file():
        entries[f'review/{p.name}'] = p
for p in package.iterdir():
    if p.is_file():
        entries[f'installed/{p.name}'] = p
for name in ('fixtures','wheels'):
    for p in (package/name).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:
            entries[f'installed/{p.relative_to(package).as_posix()}'] = p
for name in ('contact-event-continuation-diagnostic-20261001.json',
             'contact-event-continuation-restart-diagnostic-20261001.py'):
    entries['diagnostic/'+name] = workspace/name
for name in ('src/anysolver/general_contact/transient.py',
             'src/anysolver/general_contact/event_subdivision.py',
             'tests/test_general_contact_event_subdivision.py',
             'examples/general_contact_s3_plane_impact.py',
             'docs/d1_review_support/C6_S3_EVENT_SUBDIVISION_SLICE_20261001.md'):
    entries['candidate/'+name] = repo/name
sha = lambda b: hashlib.sha256(b).hexdigest()
manifest = {name:sha(p.read_bytes()) for name,p in sorted(entries.items())}
archive = out/'raw.zip'
assert not archive.exists(), 'Do not overwrite an archived evidence package'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(entries.items()):
        z.writestr(name,p.read_bytes())
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha(z.read(name)) == h for name,h in manifest.items())
receipt = dict(files=len(manifest),archive_bytes=archive.stat().st_size,
               archive_sha256=sha(archive.read_bytes()),readback_matches=True)
(out/'archive-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
