from pathlib import Path
import hashlib, json, shutil, subprocess, sys

out = Path(__file__).resolve().parent
repo = Path('C:/ANYworkspaceWork/ANYsolver-contact-main-reconcile-20261001')
old = Path('C:/ANYworkspaceWork/contact-algebraic-path-package-20261001')
build = out/'build-input'
build.mkdir(exist_ok=True)
for name in ('pyproject.toml','README.md','LICENSE','COPYRIGHT','THIRD_PARTY_NOTICES.md'):
    shutil.copy2(repo/name,build/name)
shutil.copytree(repo/'src/anysolver',build/'src/anysolver',ignore=shutil.ignore_patterns('__pycache__','*.pyc'),dirs_exist_ok=True)
(out/'fixtures').mkdir(exist_ok=True)
for name in ('test_general_contact_event_subdivision.py','test_general_contact_transient_plane.py',
             'test_general_contact_transient_s3_history.py','test_general_contact_descriptor_directional_rates.py',
             'test_general_contact_algebraic_path.py'):
    shutil.copy2(repo/'tests'/name,out/'fixtures'/name)
shutil.copy2(repo/'examples/general_contact_s3_plane_impact.py',out/'fixtures/example.py')
for name in ('run_installed.py','run_bounded.py'):
    shutil.copy2(old/name,out/name)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = {p.relative_to(repo).as_posix():sha(p) for p in (repo/'src/anysolver').rglob('*.py')}
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
parent = subprocess.check_output(['git','-c','safe.directory='+str(repo),'rev-parse','HEAD'],cwd=repo,text=True).strip()
(out/'source-identity.json').write_text(json.dumps(dict(parent=parent,
    scope='S3 event boundary continuation development',module_count=len(manifest)),indent=2))
(out/'pytest.ini').write_text('[pytest]\naddopts = -p no:cacheprovider\n')
with (out/'build.log').open('w') as log:
    subprocess.run([sys.executable,'-m','pip','wheel','--no-cache-dir','--no-index','--no-deps',
                    '--no-build-isolation',str(build),'-w',str(out/'wheels')],stdout=log,stderr=log,check=True)
    wheel, = (out/'wheels').glob('*.whl')
    subprocess.run([sys.executable,'-m','pip','install','--no-cache-dir','--no-index','--no-deps',
                    '--target',str(out/'site'),str(wheel)],stdout=log,stderr=log,check=True)
print(json.dumps(dict(wheel_sha256=sha(wheel),modules=len(manifest))))
