import ast
from pathlib import Path
import runpy
import sys


def test_event_subdivided_ramped_example(monkeypatch,capsys):
    monkeypatch.setattr(sys,'argv',['example.py','--one-sided-rates','--algebraic-path',
                                  '--event-subdivision','--ramp-downward-load-n','0.0002'])
    runpy.run_path(str(Path(__file__).with_name('example.py')),run_name='__main__')
    summary = ast.literal_eval(capsys.readouterr().out.strip())
    assert summary['profile'].endswith('NEWMARK_EVENT_SUBDIVISION_HISTORY_DEV_V1')
    assert summary['accepted_steps'] >= 60
    assert summary['minimum_swept_gap_m'] >= -.001
    assert summary['maximum_residual_n'] <= 1e-6
    assert summary['localized_contact_event_times_s']
    assert summary['event_endpoint_evaluations'] > 0
    print(summary)
