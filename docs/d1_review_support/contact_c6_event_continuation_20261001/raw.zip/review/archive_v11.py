from pathlib import Path
import hashlib,json,zipfile
workspace=Path('C:/ANYworkspaceWork')
root=workspace/'contact-event-source-20261001-v11'
out=workspace/'ANYsolver-contact-main-reconcile-20261001/docs/d1_review_support/contact_c6_event_subdivision_20261001'
entries={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()}
entries['run.log']=workspace/'contact-event-source-20261001-v11.log'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest={name:sha(p.read_bytes()) for name,p in entries.items()}
archive=out/'current-source-check.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in entries.items(): z.writestr(name,p.read_bytes())
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(sha(z.read(name))==h for name,h in manifest.items())
(out/'current-source-check-receipt.json').write_text(json.dumps(dict(files=len(entries),
    archive_sha256=sha(archive.read_bytes()),readback_matches=True),indent=2))
print(json.dumps(dict(files=len(entries),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()))))
